@echo off
title PropFirm Titan - Institutional Gold & FX Algorithmic Engine
echo [PropFirm Titan] Launching MetaTrader 5 SMC/ICT Execution Sentinel...
python fundingpips_london_orb_engine.py
pause
