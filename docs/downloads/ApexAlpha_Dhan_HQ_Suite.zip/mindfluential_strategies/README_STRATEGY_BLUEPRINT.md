# Mindfluential Algo System: Complete Quantitative Blueprint & Implementation Guide

> **System Classification**: Intraday Asymmetric Option Buying & Defined-Risk Spreads  
> **Underlying Assets**: NSE Nifty 50 & BSE Sensex Weekly Options  
> **Execution Platform**: AlgoTest (`algotest.in`) / Dhan Webhook / Direct Broker API  
> **Overnight Margin**: ₹0 (100% Intraday Flat, Zero Gap Risk)  
> **Extracted Source Version**: `v39` FINAL (Reverse-Engineered from Mindfluential Production Engine & Supabase)  

---

## 1. Executive Summary & Architecture

The Mindfluential trading architecture is an intraday multi-strategy portfolio designed to exploit **intraday volatility asymmetry** and **theta decay** on Indian equity index options.

Instead of deploying static straddles or taking overnight exposure, the system operates on two complementary pillars:
1. **The Cash-Flow Anchor (Defined-Risk Spreads - `IA-2`, `IA-4`, `IA-6`):**
   - High win rates (54%–62%).
   - Capped risk via long hedge wings.
   - Generates steady baseline cash flow during range-bound and orderly market sessions.
2. **The Convexity Engine (Asymmetric Option Buying - `IA-1`, `IA-3`, `IA-5`, `IA-7`, `IA-8`, `IA-9`, `IA-10`, `IA-11`):**
   - Low to moderate win rates (25%–61%) with high payoff asymmetry (**2.2x to 7.6x Reward-to-Risk**).
   - Strict stop-losses (average loss ₹467–₹883 per lot) paired with aggressive trailing stops (average win ₹3,378–₹3,535).
   - Designed to capture explosive trend days without blowing up on choppy days.

### The 3.6x Capital Multiplier (Intraday Capital Reuse)
Because all positions are squared off by 15:15 IST every day, **margin never sits idle across overnight sessions**. Capital is dynamically re-allocated each day of the week:

| Trading Day | Strategies Active | Exposure Type | Target Margin (1 Lot Setup) |
| :--- | :--- | :--- | :--- |
| **Monday** | `IA-1` (Sensex Weekly Opener) | Selective Bullish Buyer | ₹15,000 |
| **Tuesday** | `IA-3` (Buyer) + `IA-4` (Spread) + `IA-6` (Spread) | Mixed Momentum & Spreads | ₹262,500 (or ₹10,000 if Buyer only) |
| **Wednesday** | `IA-7` (Nifty Bullish) + `IA-8` (Sensex Surge) | Mid-Week Directional Buyers | ₹25,000 |
| **Thursday** | `IA-5` (Sensex Expiry Alpha) | 0DTE Open Momentum Buyer | ₹10,000 |
| **Friday (Peak Day)**| `IA-2` (Spread) + `IA-9` + `IA-10` + `IA-11` | Weekend Pivot & Bear Trend | ₹335,500 (or ₹20,000 if Buyers only) |

> [!NOTE]
> For accounts under ₹2,00,000, Mindfluential **exclusively runs the Option Buying strategies** (8 active strategies), requiring peak capital of only **₹20,000 to ₹40,000**, leaving a 60% cash buffer. Spreads are only activated when account capital reaches ₹5,00,000+.

---

## 2. Complete Strategy Catalog (All 11 Strategies)

Below is the verified performance and specification table extracted from their production engine:

| Code | Strategy Name | Underlying | Day | DTE | Type | Direction | Win Rate | R:R | Max Historical DD | Avg Annual Return (0% Slip) | Avg Annual Return (1% Slip) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`IA-1`** | Sensex Weekly Opener | Sensex | Mon | 3DTE | Option Buy | Bullish | 55.6% | 3.83x | -₹3,005 | +100% | +85% |
| **`IA-2`** | Nifty Contra Shield | Nifty | Fri | 2DTE | Spread | Bearish | 53.6% | 1.32x | -₹26,173 | +60% | +35% |
| **`IA-3`** | Nifty Expiry Momentum | Nifty | Tue | 0DTE | Option Buy | Bullish | 25.7% | 5.77x | -₹5,558 | +136% | +123% |
| **`IA-4`** | Nifty Premium Harvester| Nifty | Tue | 0DTE | Spread | Bearish | 61.9% | 1.04x | -₹36,602 | +55% | +47% |
| **`IA-5`** | Sensex Expiry Alpha | Sensex | Thu | 0DTE | Option Buy | Momentum | 47.8% | 2.18x | -₹8,390 | +184% | +152% |
| **`IA-6`** | Nifty Expiry Guard | Nifty | Tue | 0DTE | Spread | Bearish | 61.9% | 1.04x | -₹24,869 | +40% | +32% |
| **`IA-7`** | Nifty Range Edge | Nifty | Wed | 4DTE | Option Buy | Bullish | 61.0% | 2.16x | -₹9,099 | +100% | +70% |
| **`IA-8`** | Sensex Momentum Surge | Sensex | Wed | 1DTE | Option Buy | Bullish | 44.0% | 2.18x | -₹17,547 | +68% | +49% |
| **`IA-9`** | Nifty Drift Edge | Nifty | Fri | 2DTE | Option Buy | Bearish | 37.1% | 3.94x | -₹8,912 | +69% | +57% |
| **`IA-10`**| Nifty Bear Pivot | Nifty | Fri | 2DTE | Option Buy | Bearish | 37.4% | 3.49x | -₹3,417 | +137% | +102% |
| **`IA-11`**| Nifty Trend Rider | Nifty | Fri | 2DTE | Option Buy | Bearish | 25.0% | 7.56x | -₹5,245 | +168% | +143% |

---

## 3. The Cherry-Picked Top 3 for Pilot Testing

When launching on a new test account, **do not deploy all 11 strategies at once**. Deploy these 3 mathematically superior setups:

### Setup 1: `IA-7` — Nifty Range Edge (Mid-Week Bullish Buyer)
* **Schedule**: Wednesday | 09:30 AM Entry Window
* **Underlying**: Nifty 50 Weekly (Current Expiry / 1-2 DTE)
* **Instrument**: Slightly OTM Call Option (Closest strike with premium between ₹100 – ₹140)
* **Capital Needed**: ₹15,000 per lot
* **Quantitative Edge**: 
  - **61.02% Win Rate** with **2.16x Reward-to-Risk** (rare consistency for option buying).
  - Max Drawdown is capped at **-₹9,099**.
  - Catches the mid-week institutional trend continuation.

### Setup 2: `IA-10` — Nifty Bear Pivot (Friday Rejection Put Buyer)
* **Schedule**: Friday | 10:15 AM – 11:00 AM Entry Window
* **Underlying**: Nifty 50 Weekly (Next Expiry / 2DTE)
* **Instrument**: ATM or 1 Strike OTM Put Option (Premium between ₹90 – ₹130)
* **Capital Needed**: ₹10,000 per lot
* **Quantitative Edge**:
  - **37.37% Win Rate** with **3.49x Reward-to-Risk**.
  - **Lowest Max Drawdown in the entire lineup: just -₹3,417**.
  - Capitalizes on pre-weekend de-risking and Friday institutional hedging.
  - **Optimal Pair Synergy**: Combining `IA-7 + IA-10` produces an extraordinary **23.34x Return-to-Max-Drawdown (R/MDD)** on under ₹25,000 capital.

### Setup 3: `IA-4` — Nifty Premium Harvester (Defined-Risk Bearish Spread)
* **Schedule**: Expiry Day (Thursday under current SEBI rules) | 09:20 AM Entry
* **Underlying**: Nifty 50 Weekly Expiry (0DTE)
* **Structure**: Bear Call Spread or Bear Put Spread
  - Sell 1 Lot ATM / 0.5% OTM Option
  - Buy 1 Lot 1.5% OTM Option (Hedge Wing for margin reduction & black-swan cap)
* **Capital Needed**: ₹35,000 – ₹45,000 (with margin benefit via Dhan/broker basket order)
* **Quantitative Edge**:
  - **61.87% Win Rate** across 139 trades.
  - Generates the cash-flow anchor (+₹1.98L cumulative profit) to subsidize the small stop-losses of directional buyers.

---

## 4. Master Capital Allocation Matrix (Direct from Production v39)

Use this sizing table based on the capital allocated to the test account:

| Capital Tier | Conservative | Balanced | Aggressive |
| :--- | :--- | :--- | :--- |
| **₹50,000** *(Option Buyers Only)* | 1 Lot each (6 Active)<br>Peak Margin: ₹10,000 (20%)<br>Cash Buffer: 80% | 1 Lot each (8 Active)<br>Peak Margin: ₹20,000 (40%)<br>Cash Buffer: 60% | 1-2 Lots (8 Active)<br>Peak Margin: ₹25,000 (50%)<br>Cash Buffer: 50% |
| **₹1,00,000** *(Option Buyers Only)* | 1-2 Lots<br>Peak Margin: ₹25,000 (25%)<br>Cash Buffer: 75% | 2-5 Lots<br>Peak Margin: ₹40,000 (40%)<br>Cash Buffer: 60% | 3-7 Lots<br>Peak Margin: ₹55,000 (55%)<br>Cash Buffer: 45% |
| **₹5,00,000** *(Full Spreads + Buyers)* | 1 Spread + 6-10 Buyers<br>Peak Margin: ₹2,05,000<br>Cash Buffer: 59% | 1 Spread + 10-20 Buyers<br>Peak Margin: ₹3,35,500<br>Cash Buffer: 33% | 1 Spread + 14-25 Buyers<br>Peak Margin: ₹3,40,000<br>Cash Buffer: 32% |

---

## 5. AlgoTest Configuration Specification

To configure these strategies in AlgoTest (`algotest.in`) or your custom Dhan API bot:

### A. General Engine Settings
* **Execution Price**: LTP (Last Traded Price) — enables rapid execution on momentum breakouts.
* **Market Price Protection (MPP)**: **1.0%** (prevents freak tick slippage on market orders).
* **Square-Off Time**: **15:15 IST** (strict intraday exit, zero overnight carry).

### B. Option Buying Parameters (`IA-7`, `IA-10`, `IA-5`, `IA-1`)
1. **Strike Selection**:
   - Strike Selection: Closest Premium to **₹110** (range ₹90–₹140).
   - Premium Type: Weekly Options.
2. **Stop Loss (SL)**:
   - Initial Stop Loss: **-28% to -30%** on entry premium.
   - Example: If Call purchased at ₹100, Stop Loss placed at ₹70. Max loss per lot: ₹750 (Nifty 25 lot size).
3. **Lock & Trail Logic (The Key Alpha Driver)**:
   - **Step 1 (Breakeven Lock)**: When profit reaches **+30%** (1.0R), move SL to **Cost Price (₹100)**.
   - **Step 2 (Profit Lock)**: When profit reaches **+50%** (₹150), lock profit at **+25%** (₹125).
   - **Step 3 (Trailing Runner)**: For every subsequent **+15%** move above ₹150, trail SL by **+10%**.
   - This exact mechanism explains how `IA-11` achieves a **7.56x Reward-to-Risk** while keeping average losses under ₹500.

### C. Spread Parameters (`IA-4`, `IA-2`)
1. **Strike Selection**:
   - Short Leg: 0.5% OTM Strike (Sell).
   - Long Leg: 1.5% OTM Strike (Buy Hedge).
2. **Stop Loss**:
   - Combined Stop Loss on Spread: **-30% of net premium received** (or fixed ₹1,500 per lot).
   - Target: **80% of net premium decay**.

---

## 6. How to Replicate Without Paying Any Subscription

1. **Free AlgoTest Strategy Builder**:
   - Go to `https://algotest.in` and log in.
   - Click **Strategy Builder** $\rightarrow$ Create Strategy.
   - Set Index to **NIFTY**, Intraday MIS, Entry 09:30, Exit 15:15.
   - Add Leg: BUY Call/Put, Closest Premium ₹100.
   - Add SL: Percentage 30%.
   - Add Trailing SL: Lock profit at 30 pts, trail 10 pts for every 15 pts.
   - Save and Backtest (125 free backtest credits included by default).
2. **Dhan Webhook Automation**:
   - Generate Dhan API access token.
   - Connect AlgoTest to Dhan broker profile via API Key + Client ID.
   - Enable **Paper Trading Mode** on AlgoTest for the first 15–20 trading sessions to verify real-time fills, slippage, and trail behavior before toggling Live Execution.
