"""
Enhanced Zero Lag Trading Bot - Optimized for Maximum Performance
Author: AI Trading Expert - Donna
Version: 2.0 - Performance Optimized

Key Enhancements:
- Improved signal generation with momentum focus
- Enhanced position sizing with dynamic risk management  
- Advanced market regime detection
- Optimized entry/exit timing
- Real-time performance monitoring
"""

import os
import logging
from logging.handlers import RotatingFileHandler
import time
import json
import traceback
import numpy as np
import pandas as pd
from datetime import datetime
from binance.client import Client
from binance.exceptions import BinanceAPIException
from dotenv import load_dotenv
import ta
from decimal import Decimal, ROUND_DOWN
from typing import Any, Dict, List, Optional, Tuple
# warnings.filterwarnings('ignore')  # Avoid suppressing all warnings globally

# Enhanced logging configuration with rotation
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.handlers = []
logger.propagate = False
_file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler = RotatingFileHandler('enhanced_bot.log', maxBytes=10_000_000, backupCount=5)
file_handler.setFormatter(_file_formatter)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(_file_formatter)
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

# Helper functions for API resiliency and precision handling

def api_call_with_retries(fn, *args, max_attempts: int = 3, base_delay: float = 1.0, **kwargs):
    for attempt in range(1, max_attempts + 1):
        try:
            return fn(*args, **kwargs)
        except BinanceAPIException as e:
            status = getattr(e, 'status_code', None)
            if getattr(e, 'code', None) == -1021:
                client = getattr(fn, '__self__', None)
                if client is not None:
                    try:
                        offset = sync_client_time(client)
                        logger.info(f"Resynced server time offset: {offset}ms")
                    except Exception as sync_error:
                        logger.warning(f"Time resync failed after timestamp error: {sync_error}")
                delay = base_delay * (2 ** (attempt - 1))
                time.sleep(delay)
                continue
            if status == 429 or e.code in (-1003,):
                delay = base_delay * (2 ** (attempt - 1))
                logger.warning(f"Rate limit or server busy (attempt {attempt}/{max_attempts}). Sleeping {delay:.1f}s")
                time.sleep(delay)
                continue
            if attempt == max_attempts:
                raise
            delay = base_delay * (2 ** (attempt - 1))
            time.sleep(delay)
        except Exception:
            if attempt == max_attempts:
                raise
            delay = base_delay * (2 ** (attempt - 1))
            time.sleep(delay)


def sync_client_time(client: Client) -> int:
    server_time = client.get_server_time()
    local_time = int(time.time() * 1000)
    client.timestamp_offset = server_time['serverTime'] - local_time
    return client.timestamp_offset


def quantize_step(value: float, step: float) -> float:
    if step <= 0:
        return value
    step_dec = Decimal(str(step))
    return float((Decimal(str(value)) / step_dec).quantize(Decimal('1'), rounding=ROUND_DOWN) * step_dec)


def quantize_tick(price: float, tick: float) -> float:
    if tick <= 0:
        return price
    tick_dec = Decimal(str(tick))
    return float((Decimal(str(price)) / tick_dec).quantize(Decimal('1'), rounding=ROUND_DOWN) * tick_dec)


class EnhancedMarketAnalyzer:
    """Advanced market analysis with regime detection and momentum scoring"""

    def __init__(self):
        self.lookback_periods = {
            'short': 20,
            'medium': 50,
            'long': 200
        }
        self.regime_threshold = 0.02  # 2% threshold for regime changes

    def calculate_momentum_score(self, df: pd.DataFrame) -> float:
        """Calculate comprehensive momentum score (0-100)"""
        if len(df) < 50:
            return 0

        close = df['close']
        volume = df['volume']

        # Price momentum (40 points max)
        returns_1d = close.pct_change(1).iloc[-1] * 100
        returns_3d = close.pct_change(3).iloc[-1] * 100
        returns_7d = close.pct_change(7).iloc[-1] * 100

        momentum_score = 0
        momentum_score += min(15, max(-15, returns_1d * 3))  # Recent momentum
        momentum_score += min(15, max(-15, returns_3d * 2))  # Short term
        momentum_score += min(10, max(-10, returns_7d))      # Medium term

        # Volume momentum (30 points max) - handle division by zero securely
        vol_mean20 = volume.rolling(20).mean().iloc[-1]
        vol_mean5 = volume.rolling(5).mean().iloc[-1]
        vol_current = volume.iloc[-1]

        volume_score = 0
        if pd.notna(vol_current) and pd.notna(vol_mean20) and vol_mean20 > 0:
            vol_ratio_current = vol_current / vol_mean20
            volume_score += min(20, (vol_ratio_current - 1) * 20)  # Current vs average

        if pd.notna(vol_mean5) and pd.notna(vol_mean20) and vol_mean20 > 0:
            vol_ratio_trend = vol_mean5 / vol_mean20
            volume_score += min(10, (vol_ratio_trend - 1) * 15)    # Trending volume

        # Technical momentum (30 points max)
        if len(close) >= 14:
            rsi = ta.momentum.RSIIndicator(close, window=14).rsi().iloc[-1]
        else:
            rsi = 50  # Default neutral RSI

        if len(close) >= 26:
            macd = ta.trend.MACD(close).macd_diff().iloc[-1]
        else:
            macd = 0  # Default neutral MACD

        rsi_score = 15 if 50 < rsi < 80 else (10 if 40 < rsi < 90 else 0)
        macd_score = min(15, max(-15, macd * 1000))

        technical_score = rsi_score + macd_score

        total_score = momentum_score + volume_score + technical_score
        return max(0, min(100, total_score + 50))  # Normalize to 0-100

    def detect_market_regime(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Enhanced market regime detection"""
        if len(df) < 50:
            return {'regime': 'neutral', 'strength': 0, 'confidence': 0}

        close = df['close']

        if len(close) < 50:
            return {'regime': 'neutral', 'strength': 0, 'confidence': 0}

        # Calculate multiple EMAs
        ema_12 = ta.trend.EMAIndicator(close, window=12).ema_indicator()
        ema_26 = ta.trend.EMAIndicator(close, window=26).ema_indicator()
        ema_50 = ta.trend.EMAIndicator(close, window=50).ema_indicator()

        # Current values
        price = close.iloc[-1]
        ema12_val = ema_12.iloc[-1] if len(ema_12) > 0 else price
        ema26_val = ema_26.iloc[-1] if len(ema_26) > 0 else price
        ema50_val = ema_50.iloc[-1] if len(ema_50) > 0 else price

        # Trend alignment
        uptrend_aligned = price > ema12_val > ema26_val > ema50_val
        downtrend_aligned = price < ema12_val < ema26_val < ema50_val

        # ADX for trend strength
        if len(df) >= 50:
            adx = ta.trend.ADXIndicator(df['high'], df['low'], df['close']).adx().iloc[-1]
        else:
            adx = 25  # Neutral ADX

        # Determine regime
        if uptrend_aligned and adx > 25:
            regime = 'strong_uptrend'
            strength = min(100, adx * 1.5)
        elif uptrend_aligned:
            regime = 'weak_uptrend'
            strength = min(100, adx)
        elif downtrend_aligned and adx > 25:
            regime = 'strong_downtrend'
            strength = min(100, adx * 1.5)
        elif downtrend_aligned:
            regime = 'weak_downtrend'
            strength = min(100, adx)
        else:
            regime = 'ranging'
            strength = max(0, 50 - adx)

        # Confidence based on alignment and strength
        confidence = (strength / 100) * (1 if 'strong' in regime else 0.7)

        return {
            'regime': regime,
            'strength': strength,
            'confidence': confidence,
            'adx': adx,
            'trend_alignment': uptrend_aligned or downtrend_aligned
        }


class IntelligentEntryExit:
    """Intelligent entry and exit system with advanced decision making"""

    def __init__(self, bot_instance):
        self.bot = bot_instance
        self.entry_score_weights = {
            'trend_alignment': 25,
            'momentum_power': 20,
            'volume_confirmation': 15,
            'regime_support': 15,
            'technical_confluence': 10,
            'volatility_filter': 8,
            'price_location': 7
        }

        self.exit_strategies = {
            'trailing_stop': {'enabled': True, 'trailing_percent': 0.5},
            'partial_exits': {'enabled': True, 'first_exit_percent': 0.25, 'price_target_buffer': 0.3},
            'time_based_exit': {'enabled': True, 'max_hold_hours': 48, 'min_hold_hours': 0.5},
            'regime_change_exit': {'enabled': True, 'regime_threshold': 0.7},
            'profit_protection': {'enabled': True, 'min_profit_percent': 1.0, 'scale_up_stops': True}
        }

        # Advanced entry criteria thresholds
        self.entry_thresholds = {
            'minimum_signal_strength': 55,  # Further reduced to allow more entries
            'max_concurrent_positions': 999999,  # No max position limit per user instruction
            'min_regime_confidence': 0.35,  # Slightly reduced
            'min_momentum_score': 40,     # Slightly reduced
            'max_volatility': 0.12,  # Relaxed max volatility
            'min_volume_ratio': 0.9,  # Relaxed volume confirmation
            'atr_filter': {'min': 0.005, 'max': 0.12}  # Relaxed ATR as % of price
        }

        logger.info("Intelligent Entry/Exit system initialized")

    def calculate_comprehensive_entry_score(self, symbol: str) -> Dict[str, Any]:
        """Calculate comprehensive entry score with multiple factors"""
        try:
            # Get multi-timeframe data (15m is now the primary signal timeframe)
            df_1m = self.bot.get_klines_data(symbol, '1m', 60)
            df_5m = self.bot.get_klines_data(symbol, '5m', 50)
            df_15m = self.bot.get_klines_data(symbol, '15m', 200)  # Primary signal TF — 200 bars for EMA stability
            df_1h = self.bot.get_klines_data(symbol, '1h', 50)     # Higher-TF context only
            df_4h = self.bot.get_klines_data(symbol, '4h', 20)

            if any(df.empty for df in [df_15m, df_4h]):
                return {'score': 0, 'signal': None, 'confidence': 0, 'recommendation': 'WAIT'}

            current_price = df_15m['close'].iloc[-1]

            # Component scoring
            scores = {}

            # 1. Trend Alignment Score (0-25 points) — uses 1h+4h for higher-TF trend context
            scores['trend_alignment'] = self._calculate_trend_alignment_score(df_1h, df_4h)

            # 2. Momentum Power Score (0-20 points) — primary on 15m now
            scores['momentum_power'] = self._calculate_momentum_power_score(df_15m, df_5m)

            # 3. Volume Confirmation Score (0-15 points) — on 15m trading TF
            scores['volume_confirmation'] = self._calculate_volume_confirmation_score(df_15m)

            # 4. Market Regime Support Score (0-15 points) — 4h regime context (unchanged)
            scores['regime_support'] = self._calculate_regime_support_score(df_4h)

            # 5. Technical Confluence Score (0-10 points) — on 15m trading TF
            scores['technical_confluence'] = self._calculate_technical_confluence_score(df_15m, current_price)

            # 6. Volatility Filter Score (0-8 points) — on 15m trading TF
            scores['volatility_filter'] = self._calculate_volatility_filter_score(df_15m, current_price)

            # 7. Price Location Score (0-7 points) — on 15m trading TF
            scores['price_location'] = self._calculate_price_location_score(df_15m, current_price)

            # Calculate total score directly from components (components are already weighted to sum to 100 max)
            total_score = float(sum(scores.values()))

            # Determine signal type and strength
            signal_type, strength = self._determine_entry_signal_and_strength(scores, total_score)

            # ── Entry guard filters (15m timeframe) ────────────────────────────
            # These are hard gates: if any fails we do NOT enter regardless of score.
            if not df_15m.empty and len(df_15m) >= 20:
                try:
                    rsi_15m = ta.momentum.RSIIndicator(df_15m['close'], window=14).rsi().iloc[-1]
                    ema20_15m = ta.trend.EMAIndicator(df_15m['close'], window=20).ema_indicator().iloc[-1]
                    vol_sma20_15m = df_15m['volume'].rolling(20).mean().iloc[-1]
                    current_vol_15m = df_15m['volume'].iloc[-1]
                    prev_vol_15m = df_15m['volume'].iloc[-2] if len(df_15m) >= 2 else 0
                    prev_sma20_15m = df_15m['volume'].rolling(20).mean().iloc[-2] if len(df_15m) >= 21 else vol_sma20_15m
                    close_15m = df_15m['close'].iloc[-1]

                    # Volume surge check (>= 1.5x SMA20 on forming bar or last completed bar)
                    has_strong_volume = (
                        (pd.notna(vol_sma20_15m) and vol_sma20_15m > 0 and current_vol_15m >= vol_sma20_15m * 1.5) or
                        (prev_vol_15m > 0 and pd.notna(prev_sma20_15m) and prev_sma20_15m > 0 and prev_vol_15m >= prev_sma20_15m * 1.5)
                    )

                    # Dynamic RSI ceiling: allow up to 85 on high-volume breakouts, up to 78 for standard setups
                    max_allowed_rsi = 85.0 if has_strong_volume else 78.0
                    guard_rsi_ok    = rsi_15m <= max_allowed_rsi

                    # Structural gate: Ensure price is coiled near EMA20 support (<= 2.5% extension) to avoid buying climax wicks
                    guard_ext_ok    = close_15m <= ema20_15m * 1.025

                    # Volume confirmation: either current forming bar has already surged >= 1.25x SMA20,
                    # OR the most recently completed 15m candle confirmed the volume surge (>= 1.25x prior SMA20).
                    guard_volume_ok = (pd.isna(vol_sma20_15m) or vol_sma20_15m <= 0 or
                                       current_vol_15m >= vol_sma20_15m * 1.25 or
                                       (prev_vol_15m > 0 and prev_vol_15m >= prev_sma20_15m * 1.25))

                    if not guard_rsi_ok:
                        logger.debug(f"{symbol}: GUARD FAIL — RSI 15m={rsi_15m:.1f} > max allowed {max_allowed_rsi:.1f}")
                        return {'score': 0, 'signal': None, 'confidence': 0, 'recommendation': 'WAIT'}
                    if not guard_ext_ok:
                        logger.debug(f"{symbol}: GUARD FAIL — price {close_15m:.6f} > EMA20 {ema20_15m:.6f} * 1.025 (extended)")
                        return {'score': 0, 'signal': None, 'confidence': 0, 'recommendation': 'WAIT'}
                    if not guard_volume_ok:
                        logger.debug(f"{symbol}: GUARD FAIL — vol curr {current_vol_15m:.0f} / prev {prev_vol_15m:.0f} < 1.25x SMA20 {vol_sma20_15m:.0f}")
                        return {'score': 0, 'signal': None, 'confidence': 0, 'recommendation': 'WAIT'}
                except Exception as guard_e:
                    logger.debug(f"{symbol}: Entry guard check error (skipping): {guard_e}")
            # ── End entry guard filters ─────────────────────────────────────────

            return {
                'symbol': symbol,
                'score': total_score,
                'signal': signal_type,
                'strength': strength,
                'confidence': min(1.0, total_score / 85),  # Max confidence at score 85+
                'components': scores,
                'current_price': current_price,
                'recommendation': 'ENTRY' if total_score >= self.entry_thresholds['minimum_signal_strength'] else 'WAIT'
            }

        except Exception as e:
            logger.error(f"Error calculating entry score for {symbol}: {e}")
            return {'score': 0, 'signal': None, 'confidence': 0, 'recommendation': 'WAIT'}

    def _calculate_trend_alignment_score(self, df_1h, df_4h) -> float:
        """Calculate trend alignment score based on EMA structure"""
        try:
            price = df_1h['close'].iloc[-1]

            # Calculate EMAs
            ema_8 = ta.trend.EMAIndicator(df_1h['close'], window=8).ema_indicator().iloc[-1]
            ema_21 = ta.trend.EMAIndicator(df_1h['close'], window=21).ema_indicator().iloc[-1]
            ema_50 = ta.trend.EMAIndicator(df_1h['close'], window=50).ema_indicator().iloc[-1]

            # 4-hour trend
            ema_4h = ta.trend.EMAIndicator(df_4h['close'], window=8).ema_indicator().iloc[-1]
            ema_4h_21 = ta.trend.EMAIndicator(df_4h['close'], window=21).ema_indicator().iloc[-1]

            # Strong uptrend alignment (15 points)
            if price > ema_8 > ema_21 > ema_50:
                base_score = 15
                # Higher timeframe confirmation (+5)
                if df_4h['close'].iloc[-1] > ema_4h > ema_4h_21:
                    base_score += 5
                # Extreme bullish alignment (+5)
                if ema_8 > ema_21 and ema_21 > ema_50 and (ema_8 - ema_50) / ema_50 > 0.02:
                    base_score += 5
                return min(25, base_score)
            # Weak uptrend alignment (8 points)
            elif price > ema_8 > ema_21:
                base_score = 8
                if df_4h['close'].iloc[-1] > ema_4h:
                    base_score += 4
                return base_score
            # Neutral/sideways (3 points)
            elif abs(price - ema_21) / ema_21 < 0.01:
                return 3
            # Downtrend (0 points)
            else:
                return 0

        except Exception as e:
            logger.debug(f"Error in trend alignment calculation: {e}")
            return 0

    def _calculate_momentum_power_score(self, df_1h, df_15m) -> float:
        """Calculate momentum power score across timeframes"""
        try:
            # RSI momentum (8 points max)
            rsi_1h = ta.momentum.RSIIndicator(df_1h['close'], window=14).rsi().iloc[-1]
            rsi_score = 0
            if rsi_1h > 70:
                rsi_score = 8
            elif rsi_1h > 60:
                rsi_score = 6
            elif rsi_1h > 50:
                rsi_score = 4

            # MACD momentum (6 points max)
            macd = ta.trend.MACD(df_1h['close']).macd_diff().iloc[-1]
            macd_score = min(6, max(0, (macd + 0.5) * 10))  # Scale positive MACD

            # Volume-price momentum (6 points max) - handle division by zero securely
            vol_5ma = df_1h['volume'].rolling(5).mean().iloc[-1]
            vol_20ma = df_1h['volume'].rolling(20).mean().iloc[-1]
            volume_score = 0

            if pd.notna(vol_5ma) and pd.notna(vol_20ma) and vol_20ma > 0:
                volume_trend = vol_5ma / vol_20ma
                volume_score = min(6, (volume_trend - 1) * 10) if volume_trend > 1 else 0

            # 15m momentum confirmation (optional bonus +2)
            if not df_15m.empty:
                recent_momentum = self.calculate_momentum_score(df_15m)
                momentum_bonus = 2 if recent_momentum > 60 else 0
            else:
                momentum_bonus = 0

            total = rsi_score + macd_score + volume_score + momentum_bonus
            return min(20, total)

        except Exception as e:
            logger.debug(f"Error in momentum calculation: {e}")
            return 0

    def _calculate_volume_confirmation_score(self, df_1h) -> float:
        """Calculate volume confirmation score"""
        try:
            # Recent volume vs historical
            current_volume = df_1h['volume'].iloc[-1]
            avg_volume_20 = df_1h['volume'].rolling(20).mean().iloc[-1]

            if pd.isna(avg_volume_20) or avg_volume_20 <= 0:
                return 0

            volume_ratio = current_volume / avg_volume_20

            # Volume score based on ratio
            if volume_ratio > 2.0:
                base_score = 15  # Very high volume
            elif volume_ratio > 1.5:
                base_score = 12  # High volume
            elif volume_ratio > 1.2:
                base_score = 8   # Moderate volume increase
            elif volume_ratio > 1.0:
                base_score = 5   # Slight volume increase
            else:
                base_score = 0   # Below average volume

            # Volume trend bonus (up to +3 points)
            recent_avg = df_1h['volume'].rolling(5).mean().iloc[-1]
            if pd.notna(recent_avg) and recent_avg > avg_volume_20 * 1.1:
                base_score += 3
            elif pd.notna(recent_avg) and recent_avg > avg_volume_20:
                base_score += 1

            return min(15, base_score)

        except Exception as e:
            logger.debug(f"Error in volume confirmation calculation: {e}")
            return 0

    def _calculate_regime_support_score(self, df_4h) -> float:
        """Calculate market regime support score"""
        try:
            regime_data = self.bot.market_analyzer.detect_market_regime(df_4h)

            # Base score from regime strength
            base_score = regime_data['strength'] * 0.075  # Scale to max 15 points

            # Bonus for strong, aligned regimes
            if regime_data['regime'] in ['strong_uptrend', 'strong_downtrend']:
                base_score += 5

            # Confidence bonus
            confidence_bonus = regime_data['confidence'] * 3

            return min(15, base_score + confidence_bonus)

        except Exception as e:
            logger.debug(f"Error in regime support calculation: {e}")
            return 0

    def _calculate_technical_confluence_score(self, df_1h, current_price) -> float:
        """Calculate technical confluence score"""
        try:
            score = 0

            # Support/resistance levels (up to 4 points)
            highs_20 = df_1h['high'].rolling(20).max().iloc[-1]
            lows_20 = df_1h['low'].rolling(20).min().iloc[-1]

            # Near support level
            if current_price <= lows_20 * 1.02 and current_price >= lows_20:
                score += 2
            # Broke above resistance
            if current_price >= highs_20:
                score += 2

            # Moving average confluence (up to 4 points)
            ema_8 = ta.trend.EMAIndicator(df_1h['close'], window=8).ema_indicator().iloc[-1]
            ema_21 = ta.trend.EMAIndicator(df_1h['close'], window=21).ema_indicator().iloc[-1]

            # Price aligned with EMAs
            if abs(current_price - ema_8) / ema_8 < 0.01:
                score += 2
            if abs(current_price - ema_21) / ema_21 < 0.01:
                score += 2

            # RSI levels (up to 2 points)
            rsi = ta.momentum.RSIIndicator(df_1h['close'], window=14).rsi().iloc[-1]
            if 45 < rsi < 75:  # Favorable RSI zone
                score += 2

            return min(10, score)

        except Exception as e:
            logger.debug(f"Error in technical confluence calculation: {e}")
            return 0

    def _calculate_volatility_filter_score(self, df_1h, current_price) -> float:
        """Calculate volatility filter score"""
        try:
            # Calculate ATR as % of price
            atr = ta.volatility.AverageTrueRange(df_1h['high'], df_1h['low'], df_1h['close'], window=14).average_true_range().iloc[-1]
            atr_percent = (atr / current_price) * 100

            # Ideal volatility range for 15m crypto candles (0.25% - 2.5% ATR)
            if 0.3 <= atr_percent <= 2.5:
                base_score = 8
            elif 0.15 <= atr_percent <= 4.0:
                base_score = 6
            elif 0.10 <= atr_percent <= 6.0:
                base_score = 4
            else:
                base_score = 0  # Too low or high volatility

            return base_score

        except Exception as e:
            logger.debug(f"Error in volatility filter calculation: {e}")
            return 0

    def _calculate_price_location_score(self, df_1h, current_price) -> float:
        """Calculate price location score relative to ranges"""
        try:
            # Bollinger Band position
            bb = ta.volatility.BollingerBands(df_1h['close'], window=20)
            bb_upper = bb.bollinger_hband().iloc[-1]
            bb_lower = bb.bollinger_lband().iloc[-1]

            if pd.isna(bb_upper) or pd.isna(bb_lower):
                return 0

            # Price position in bands
            band_width = bb_upper - bb_lower
            if band_width > 0:
                position_in_band = (current_price - bb_lower) / band_width

                if position_in_band > 0.8:
                    return 7  # Near upper band - potential resistance
                elif position_in_band < 0.2:
                    return 5  # Near lower band - potential support
                elif 0.3 <= position_in_band <= 0.7:
                    return 3  # Middle range - consolidation
                else:
                    return 1  # Extreme ends
            else:
                return 0

        except Exception as e:
            logger.debug(f"Error in price location calculation: {e}")
            return 0

    def _determine_entry_signal_and_strength(self, scores: Dict[str, float], total_score: float) -> Tuple[str, float]:
        """Determine entry signal type and strength"""
        try:
            # Analyze score components to determine bias
            trend_score = scores.get('trend_alignment', 0)
            momentum_score = scores.get('momentum_power', 0)

            # Strong bullish conditions
            if trend_score >= 15 and momentum_score >= 12 and total_score >= 70:
                return 'LONG', total_score

            # Moderate bullish conditions
            elif trend_score >= 8 and total_score >= 55:
                return 'LONG', total_score

            # No clear signal
            return None, 0

        except Exception as e:
            logger.debug(f"Error determining entry signal: {e}")
            return None, 0

    def should_enter_position(self, symbol: str) -> Dict[str, Any]:
        """Determine if we should enter a position"""
        try:
            entry_analysis = self.calculate_comprehensive_entry_score(symbol)

            # Check all entry criteria
            if entry_analysis.get('recommendation') == 'ENTRY':
                # Additional checks
                strength_ok = entry_analysis.get('strength', 0) >= self.entry_thresholds['minimum_signal_strength']
                confidence_ok = entry_analysis.get('confidence', 0) >= self.entry_thresholds['min_regime_confidence']

                if strength_ok and confidence_ok:
                    # Check position limits
                    current_positions = len(self.bot.positions)
                    if current_positions < self.entry_thresholds.get('max_concurrent_positions', 999999):
                        return {
                            'enter': True,
                            'symbol': symbol,
                            'signal': entry_analysis['signal'],
                            'strength': entry_analysis['strength'],
                            'confidence': entry_analysis['confidence'],
                            'entry_price': entry_analysis['current_price'],
                            'analysis': entry_analysis
                        }

            return {'enter': False, 'reason': 'Conditions not met'}

        except Exception as e:
            logger.error(f"Error in position entry check for {symbol}: {e}")
            return {'enter': False, 'reason': 'Analysis error'}

    def calculate_intelligent_exits(self, position_data: Dict) -> Dict[str, Any]:
        """Calculate intelligent exit levels with multiple strategies"""
        try:
            symbol = position_data.get('symbol')
            entry_price = position_data.get('entry_price', 0)
            direction = position_data.get('direction', 'LONG')

            if entry_price <= 0:
                return {'stop_loss': entry_price * 0.95, 'take_profit': entry_price * 1.05}

            # Get current market data
            df_1h = self.bot.get_klines_data(symbol, '15m', 200)  # Use 15m for exit decisions
            if df_1h.empty:
                return {'stop_loss': entry_price * 0.95, 'take_profit': entry_price * 1.05}

            current_price = df_1h['close'].iloc[-1]
            atr = ta.volatility.AverageTrueRange(df_1h['high'], df_1h['low'], df_1h['close'], window=14).average_true_range().iloc[-1]

            # Calculate trailing stop if enabled
            trailing_stops = {}
            if self.exit_strategies['trailing_stop']['enabled']:
                trailing_stops = self._calculate_trailing_stops(position_data, df_1h, direction)

            # Calculate partial exit levels
            partial_exits = {}
            if self.exit_strategies['partial_exits']['enabled']:
                partial_exits = self._calculate_partial_exits(entry_price, current_price, direction)

            # Calculate time-based exits
            time_based_exits = {}
            if self.exit_strategies['time_based_exit']['enabled']:
                time_based_exits = self._calculate_time_based_exits(position_data)

            # Calculate regime-based exits
            regime_exits = {}
            if self.exit_strategies['regime_change_exit']['enabled']:
                regime_exits = self._calculate_regime_change_exits(df_1h, direction)

            # Choose optimal exit strategy
            optimal_exits = self._choose_optimal_exit_strategy({
                'trailing': trailing_stops,
                'partial': partial_exits,
                'time': time_based_exits,
                'regime': regime_exits
            }, entry_price, direction)

            return optimal_exits

        except Exception as e:
            logger.error(f"Error calculating intelligent exits for {position_data}: {e}")
            # Return conservative defaults
            return {
                'stop_loss': entry_price * 0.95,
                'take_profit': entry_price * 1.05,
                'partial_exits': [],
                'exit_strategy': 'conservative'
            }

    def _calculate_trailing_stops(self, position_data: Dict, df: pd.DataFrame, direction: str) -> Dict[str, Any]:
        """Calculate trailing stop levels"""
        try:
            symbol = position_data.get('symbol')
            entry_price = position_data.get('entry_price', 0)
            trailing_percent = self.exit_strategies['trailing_stop']['trailing_percent']

            # Calculate trailing stop based on highest/lowest point since entry
            if direction == 'LONG':
                highest_since_entry = df['high'][df.index >= pd.to_datetime(position_data.get('entry_time'))].max()
                trailing_stop = highest_since_entry * (1 - trailing_percent / 100)
            else:  # SHORT
                lowest_since_entry = df['low'][df.index >= pd.to_datetime(position_data.get('entry_time'))].min()
                trailing_stop = lowest_since_entry * (1 + trailing_percent / 100)

            return {
                'trailing_stop': max(trailing_stop, entry_price * 0.95),  # Don't go below entry
                'highest_point': highest_since_entry if direction == 'LONG' else None,
                'lowest_point': lowest_since_entry if direction == 'SHORT' else None
            }

        except Exception as e:
            logger.debug(f"Error calculating trailing stops: {e}")
            return {}

    def _calculate_partial_exits(self, entry_price: float, current_price: float, direction: str) -> List[Dict[str, Any]]:
        """Calculate partial exit levels for profit taking"""
        try:
            first_exit_percent = self.exit_strategies['partial_exits']['first_exit_percent']
            target_buffer = self.exit_strategies['partial_exits']['price_target_buffer']

            # Calculate first target
            if direction == 'LONG':
                first_target = entry_price * (1 + target_buffer)
            else:
                first_target = entry_price * (1 - target_buffer)

            # Only add partial exits if we're in profit
            partial_exits = []
            if direction == 'LONG' and current_price >= first_target:
                partial_exits.append({
                    'price': first_target,
                    'quantity_percent': first_exit_percent,
                    'reason': 'first_target'
                })
            elif direction == 'SHORT' and current_price <= first_target:
                partial_exits.append({
                    'price': first_target,
                    'quantity_percent': first_exit_percent,
                    'reason': 'first_target'
                })

            return partial_exits

        except Exception as e:
            logger.debug(f"Error calculating partial exits: {e}")
            return []

    def _calculate_time_based_exits(self, position_data: Dict) -> Dict[str, Any]:
        """Calculate time-based exit signals"""
        try:
            entry_time = pd.to_datetime(position_data.get('entry_time'))
            current_time = datetime.now()
            hours_held = (current_time - entry_time).total_seconds() / 3600

            max_hours = self.exit_strategies['time_based_exit']['max_hold_hours']

            if hours_held >= max_hours:
                return {'signal': 'close', 'reason': f'held_too_long_{hours_held:.1f}h'}
            else:
                return {}

        except Exception as e:
            logger.debug(f"Error calculating time-based exits: {e}")
            return {}

    def _calculate_regime_change_exits(self, df: pd.DataFrame, direction: str) -> Dict[str, Any]:
        """Calculate regime change based exits"""
        try:
            regime_data = self.bot.market_analyzer.detect_market_regime(df)

            # Exit if regime changes against our position
            if direction == 'LONG':
                if regime_data['regime'] in ['strong_downtrend', 'weak_downtrend'] and regime_data['confidence'] > 0.7:
                    return {'signal': 'close', 'reason': f'regime_changed_{regime_data["regime"]}'}
            else:  # SHORT
                if regime_data['regime'] in ['strong_uptrend', 'weak_uptrend'] and regime_data['confidence'] > 0.7:
                    return {'signal': 'close', 'reason': f'regime_changed_{regime_data["regime"]}'}

            return {}

        except Exception as e:
            logger.debug(f"Error calculating regime exits: {e}")
            return {}

    def _choose_optimal_exit_strategy(self, exit_strategies: Dict[str, Any], entry_price: float, direction: str) -> Dict[str, Any]:
        """Choose the optimal exit strategy based on current conditions"""
        try:
            # Default conservative exits
            optimal_exits = {
                'stop_loss': entry_price * 0.95,
                'take_profit': entry_price * 1.05,
                'partial_exits': [],
                'exit_strategy': 'conservative'
            }

            # Update with trailing stop if available and better
            if exit_strategies.get('trailing') and exit_strategies['trailing'].get('trailing_stop'):
                trailing_stop = exit_strategies['trailing']['trailing_stop']
                if direction == 'LONG' and trailing_stop > entry_price:
                    optimal_exits['stop_loss'] = max(optimal_exits['stop_loss'], trailing_stop)
                    optimal_exits['exit_strategy'] = 'trailing'
                elif direction == 'SHORT' and trailing_stop < entry_price:
                    optimal_exits['stop_loss'] = min(optimal_exits['stop_loss'], trailing_stop)
                    optimal_exits['exit_strategy'] = 'trailing'

            # Add partial exits if available
            if exit_strategies.get('partial'):
                optimal_exits['partial_exits'] = exit_strategies['partial']

            # Check for immediate exits
            if exit_strategies.get('time', {}).get('signal') == 'close':
                optimal_exits['immediate_exit'] = True
                optimal_exits['exit_reason'] = exit_strategies['time'].get('reason', 'time_based')
                optimal_exits['exit_strategy'] = 'time_based'

            if exit_strategies.get('regime', {}).get('signal') == 'close':
                optimal_exits['immediate_exit'] = True
                optimal_exits['exit_reason'] = exit_strategies['regime'].get('reason', 'regime_changed')
                optimal_exits['exit_strategy'] = 'regime_based'

            return optimal_exits

        except Exception as e:
            logger.debug(f"Error choosing optimal exit strategy: {e}")
            return {
                'stop_loss': entry_price * 0.95,
                'take_profit': entry_price * 1.05,
                'partial_exits': [],
                'exit_strategy': 'fallback'
            }
        
    def calculate_momentum_score(self, df: pd.DataFrame) -> float:
        """Calculate comprehensive momentum score (0-100)"""
        if len(df) < 50:
            return 0
            
        close = df['close']
        volume = df['volume']
        
        # Price momentum (40 points max)
        returns_1d = close.pct_change(1).iloc[-1] * 100
        returns_3d = close.pct_change(3).iloc[-1] * 100 
        returns_7d = close.pct_change(7).iloc[-1] * 100
        
        momentum_score = 0
        momentum_score += min(15, max(-15, returns_1d * 3))  # Recent momentum
        momentum_score += min(15, max(-15, returns_3d * 2))  # Short term
        momentum_score += min(10, max(-10, returns_7d))      # Medium term
        
        # Volume momentum (30 points max) - handle division by zero securely
        vol_mean20 = volume.rolling(20).mean().iloc[-1]
        vol_mean5 = volume.rolling(5).mean().iloc[-1]
        vol_current = volume.iloc[-1]

        volume_score = 0
        if pd.notna(vol_current) and pd.notna(vol_mean20) and vol_mean20 > 0:
            vol_ratio_current = vol_current / vol_mean20
            volume_score += min(20, (vol_ratio_current - 1) * 20)  # Current vs average

        if pd.notna(vol_mean5) and pd.notna(vol_mean20) and vol_mean20 > 0:
            vol_ratio_trend = vol_mean5 / vol_mean20
            volume_score += min(10, (vol_ratio_trend - 1) * 15)    # Trending volume
        
        # Technical momentum (30 points max)
        rsi = ta.momentum.RSIIndicator(close, window=14).rsi().iloc[-1]
        macd = ta.trend.MACD(close).macd_diff().iloc[-1]
        
        rsi_score = 15 if 50 < rsi < 80 else (10 if 40 < rsi < 90 else 0)
        macd_score = min(15, max(-15, macd * 1000))
        
        technical_score = rsi_score + macd_score
        
        total_score = momentum_score + volume_score + technical_score
        return max(0, min(100, total_score + 50))  # Normalize to 0-100
    
    def detect_market_regime(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Enhanced market regime detection"""
        if len(df) < 50:
            return {'regime': 'neutral', 'strength': 0, 'confidence': 0}
        
        close = df['close']
        
        # Calculate multiple EMAs
        ema_12 = ta.trend.EMAIndicator(close, window=12).ema_indicator()
        ema_26 = ta.trend.EMAIndicator(close, window=26).ema_indicator() 
        ema_50 = ta.trend.EMAIndicator(close, window=50).ema_indicator()
        
        # Current values
        price = close.iloc[-1]
        ema12_val = ema_12.iloc[-1]
        ema26_val = ema_26.iloc[-1] 
        ema50_val = ema_50.iloc[-1]
        
        # Trend alignment
        uptrend_aligned = price > ema12_val > ema26_val > ema50_val
        downtrend_aligned = price < ema12_val < ema26_val < ema50_val
        
        # ADX for trend strength
        adx = ta.trend.ADXIndicator(df['high'], df['low'], df['close']).adx().iloc[-1]
        
        # Determine regime
        if uptrend_aligned and adx > 25:
            regime = 'strong_uptrend'
            strength = min(100, adx * 1.5)
        elif uptrend_aligned:
            regime = 'weak_uptrend' 
            strength = min(100, adx)
        elif downtrend_aligned and adx > 25:
            regime = 'strong_downtrend'
            strength = min(100, adx * 1.5)
        elif downtrend_aligned:
            regime = 'weak_downtrend'
            strength = min(100, adx)
        else:
            regime = 'ranging'
            strength = max(0, 50 - adx)
        
        # Confidence based on alignment and strength
        confidence = (strength / 100) * (1 if 'strong' in regime else 0.7)
        
        return {
            'regime': regime,
            'strength': strength,
            'confidence': confidence,
            'adx': adx,
            'trend_alignment': uptrend_aligned or downtrend_aligned
        }

class EnhancedRiskManager:
    """Advanced risk management with dynamic position sizing"""
    
    def __init__(self, config: Dict = None):
        self.config = config or {}
        self.max_portfolio_risk = self.config.get('max_portfolio_risk', 8.0)  # Optimized for crypto volatility
        self.max_position_risk = float(os.getenv('MAX_POSITION_RISK', str(self.config.get('max_position_risk', 5.0))))    # Configurable via env, default 5%
        self.base_position_size = float(os.getenv('BASE_POSITION_SIZE', str(self.config.get('base_position_size', 1.0))))  # 1.0 = 1% of capital per position
        self.volatility_adjustment = True
        self.momentum_adjustment = True
        
    def calculate_dynamic_position_size(self, balance: float, signal_strength: float = 50,
                                      volatility: float = 0.02, momentum_score: float = 50) -> float:
        """Calculate position size: 1% of capital margin scaled by leverage for futures notional.
        Enforces Binance minimum notional (~5 USDT)."""
        leverage = float(os.getenv('MAX_LEVERAGE', '20'))
        # 1% of capital as initial margin
        margin_usd = balance * (self.base_position_size / 100.0)
        # Notional position value = margin * leverage
        notional_usd = margin_usd * leverage
        # Minimum notional to survive Binance exchange filter (typically 5 USDT + buffer)
        min_position_usd = float(self.config.get('min_position_usd', 5.5))
        position_size = max(notional_usd, min_position_usd)
        return position_size
    
    def calculate_dynamic_stops(self, entry_price: float, atr: float,
                              momentum_score: float, regime: str, signal_type: str = 'LONG') -> Tuple[float, float]:
        """Calculate stop loss and take profit levels.
        
        Strategy (per user instruction):
          - Hard SL = 3.5% from entry (LONG: below, SHORT: above)
          - No fixed TP — TP is set unreachably high so the trailing stop is the only real exit.
            The trailing stop logic in _manage_single_position handles:
              Stage 1: hold SL at -3.5% until profit >= 3.5%
              Stage 2: move SL to BE+0.2% when profit >= 3.5%
              Stage 3: when profit >= 7%, lock SL at +0.5% then trail 2.5% from high
        """
        sl_pct = 0.035  # Fixed 3.5% stop loss

        if signal_type == 'SHORT':
            stop_loss = entry_price * (1 + sl_pct)    # SL above entry for shorts
            take_profit = entry_price * 0.0001          # Effectively unreachable (never triggers)
        else:
            stop_loss = entry_price * (1 - sl_pct)    # SL below entry for longs
            take_profit = entry_price * 100.0           # Effectively unreachable (never triggers)

        return (stop_loss, take_profit)


class AutoCoinDiscovery:
    """Intelligent automated coin discovery system for identifying trading opportunities"""

    def __init__(self, bot_instance):
        """Initialize with bot instance for access to client and market analysis"""
        self.bot = bot_instance
        self.coin_selector = None
        self.last_discovery = 0
        self.discovery_interval = 3600  # Base interval between discoveries

        # Allocate processing budget for discovery (expanded to 500 coins)
        self.symbols_per_discovery = int(os.getenv('DISCOVERY_SYMBOLS', '500'))
        self.min_volume_usd = 500_000     # $500k 24h volume threshold to capture emerging pump coins
        self.min_price = 0.00001           # Avoid near-zero dead coins

        logger.info(f"Auto coin discovery initialized for top {self.symbols_per_discovery} coins")

    def discover_opportunities(self) -> List[str]:
        """Discover top 250 liquid trading opportunities ranked by 24h volume from Binance tickers"""
        try:
            current_time = time.time()
            if current_time - self.last_discovery < self.discovery_interval and hasattr(self, 'cached_opportunities'):
                return self.cached_opportunities

            logger.info("Starting automated coin discovery across all Binance futures (target: top 250 coins)...")
            tickers = api_call_with_retries(self.bot.client.futures_ticker, recvWindow=self.bot.recv_window)

            forbidden_patterns = [
                'USELESS', 'FARTCOIN', 'MOODENG', 'SKYAI', 'SOON', 'LISTA',
                'APE', 'MORPHO', 'TRB', 'TAO'
            ]

            valid_coins = []
            for t in tickers:
                s = t.get('symbol', '')
                if not s.endswith('USDT'):
                    continue
                if any(p in s for p in forbidden_patterns):
                    continue
                try:
                    vol = float(t.get('quoteVolume', 0))
                    price = float(t.get('lastPrice', 0))
                    if vol >= self.min_volume_usd and price > self.min_price:
                        valid_coins.append((s, vol))
                except Exception:
                    continue

            # Sort by 24h quote volume descending
            valid_coins.sort(key=lambda x: x[1], reverse=True)
            top_opportunities = [x[0] for x in valid_coins[:self.symbols_per_discovery]]

            if not top_opportunities:
                top_opportunities = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT']

            self.last_discovery = current_time
            self.cached_opportunities = top_opportunities
            logger.info(f"Discovered {len(top_opportunities)} high-volume trading opportunities (Top 250 Liquid Pairs)")
            return top_opportunities

        except Exception as e:
            logger.error(f"Error in coin discovery: {e}")
            return self.bot.symbols

    def _get_all_futures_symbols(self) -> List[str]:
        """Get all available futures trading symbols"""
        try:
            exchange_info = api_call_with_retries(
                self.bot.client.futures_exchange_info,
            )

            symbols = [
                s['symbol'] for s in exchange_info.get('symbols', [])
                if (s.get('status') == 'TRADING' and
                    s.get('contractType') == 'PERPETUAL' and
                    s['symbol'].endswith('USDT'))
            ]

            # Add some high-quality base symbols as fallback
            if not symbols:
                symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'XRPUSDT', 'SOLUSDT']

            return symbols

        except Exception as e:
            logger.error(f"Error retrieving futures symbols: {e}")
            return ['BTCUSDT', 'ETHUSDT']

    def _apply_initial_filters(self, symbols: List[str]) -> List[str]:
        """Apply baseline quality filters to reduce processing load"""
        try:
            # Filter problematic symbols
            forbidden_patterns = [
                'USELESS', 'FARTCOIN', 'MOODENG', 'SKYAI', 'SOON', 'LISTA',
                'APE', 'MORPHO', 'TRB', 'TAO'
            ]

            filtered = []
            for symbol in symbols:
                if any(pattern in symbol for pattern in forbidden_patterns):
                    continue

                # Apply minimum price filter
                filtered.append(symbol)

            # Limit to prevent excessive processing
            return filtered[:self.symbols_per_discovery]

        except Exception as e:
            logger.error(f"Error applying initial filters: {e}")
            return symbols[:50]  # Conservative fallback

    def _score_opportunities(self, symbols: List[str]) -> List[Tuple[str, float]]:
        """Score symbols based on trading opportunity potential"""
        try:
            scored_symbols = []

            for i, symbol in enumerate(symbols, 1):
                try:
                    if i % 20 == 0:
                        logger.debug(f"Scored {i}/{len(symbols)} symbols for opportunities")

                    score = self._calculate_opportunity_score(symbol)
                    if score >= self.score_threshold:
                        scored_symbols.append((symbol, score))

                    # Brief pause to avoid rate limiting
                    time.sleep(0.05)

                except Exception as e:
                    logger.warning(f"Error scoring {symbol}: {e}")
                    continue

            # Sort by score (descending)
            scored_symbols.sort(key=lambda x: x[1], reverse=True)

            logger.info(f"Scored {len(scored_symbols)} symbols above threshold {self.score_threshold}")

            return scored_symbols

        except Exception as e:
            logger.error(f"Error scoring opportunities: {e}")
            return []

    def _calculate_opportunity_score(self, symbol: str) -> float:
        """Calculate comprehensive opportunity score (0-100) for a symbol"""
        try:
            # Get multi-timeframe data
            df_1h = self.bot.get_klines_data(symbol, '15m', 200)  # Use 15m as primary (variable name kept for compat)
            df_4h = self.bot.get_klines_data(symbol, '4h', 100)

            if df_1h.empty:
                return 0

            # Volume and liquidity score (25 points max)
            volume_score = 0
            try:
                avg_volume = df_1h['volume'].mean() * df_1h['close'].iloc[-1]  # Convert to USD
                if avg_volume >= self.min_volume_usd:
                    volume_score = min(25, (avg_volume / 1e8) * 25)  # Scale with volume
            except:
                volume_score = 0

            # Trend alignment score (30 points max)
            trend_score = 0
            try:
                ema_12 = ta.trend.EMAIndicator(df_1h['close'], window=12).ema_indicator().iloc[-1]
                ema_26 = ta.trend.EMAIndicator(df_1h['close'], window=26).ema_indicator().iloc[-1]
                ema_50 = ta.trend.EMAIndicator(df_1h['close'], window=50).ema_indicator().iloc[-1]
                current_price = df_1h['close'].iloc[-1]

                # Multi-timeframe alignment bonus
                alignment_score = 0
                if current_price > ema_12 > ema_26:
                    alignment_score += 15
                if ema_12 > ema_26 > ema_50:
                    alignment_score += 10
                if not df_4h.empty:
                    ema_4h = ta.trend.EMAIndicator(df_4h['close'], window=12).ema_indicator().iloc[-1]
                    if df_4h['close'].iloc[-1] > ema_4h:
                        alignment_score += 5

                trend_score = alignment_score

            except Exception as e:
                logger.debug(f"Error calculating trend for {symbol}: {e}")
                trend_score = 0

            # Momentum and volatility score (30 points max)
            momentum_score = 0
            try:
                momentum_1h = self.bot.market_analyzer.calculate_momentum_score(df_1h)
                momentum_score = min(30, momentum_1h * 0.6)  # Scale down to 30 max

                # Add volatility bonus (reasonable, not excessive volatility)
                if len(df_1h) > 20:
                    returns = df_1h['close'].pct_change().dropna()
                    volatility = returns.std() * np.sqrt(365) * 100  # Annualized vol %
                    if 20 < volatility < 120:  # Reasonable volatility range
                        vol_bonus = min(10, (volatility - 20) * 0.25)
                        momentum_score += vol_bonus

            except:
                momentum_score = 0

            # Price stability and quality score (15 points max)
            quality_score = 0
            try:
                current_price = df_1h['close'].iloc[-1]
                if current_price >= self.min_price:
                    quality_score += 10  # Meets minimum price

                # Recent activity score
                recent_volume = df_1h['volume'].iloc[-5:].mean() * current_price
                if recent_volume >= self.min_volume_usd * 0.5:  # At least half of min volume
                    quality_score += 5

            except:
                quality_score = 0

            # Total opportunity score (normalized 0-100)
            total_score = volume_score + trend_score + momentum_score + quality_score
            total_score = min(100, max(0, total_score))

            return total_score

        except Exception as e:
            logger.warning(f"Error calculating score for {symbol}: {e}")
            return 0

    def _select_top_opportunities(self, scored_symbols: List[Tuple[str, float]]) -> List[str]:
        """Select top trading opportunities with diversification"""
        try:
            if not scored_symbols:
                logger.warning("No scored symbols to select from")
                return self.bot.symbols

            # Take top symbols but ensure some diversification
            top_symbols = [symbol for symbol, score in scored_symbols[:50]]

            # Always include some established coins for stability
            stable_coins = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT']
            for stable in stable_coins:
                if stable not in top_symbols:
                    top_symbols.append(stable)

            # Ensure we have at least some symbols
            if len(top_symbols) < 5:
                # Fallback to established top coins
                top_symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'XRPUSDT', 'SOLUSDT',
                             'ADAUSDT', 'AVAXUSDT', 'DOTUSDT', 'MATICUSDT', 'LINKUSDT']

            logger.info(f"Selected {len(top_symbols)} optimal trading opportunities")

            return top_symbols

        except Exception as e:
            logger.error(f"Error selecting top opportunities: {e}")
            return self.bot.symbols  # Safe fallback

class EnhancedZeroLagBot:
    """Enhanced trading bot with advanced signal generation and risk management"""
    
    def __init__(self):
        load_dotenv()
        
        # API Setup
        self.api_key = (os.getenv('BINANCE_API_KEY') or os.getenv('API_KEY', '')).strip()
        self.api_secret = (os.getenv('BINANCE_API_SECRET') or os.getenv('API_SECRET', '')).strip()
        
        if not self.api_key or not self.api_secret:
            raise ValueError("API keys not found in .env file (Please set BINANCE_API_KEY and BINANCE_API_SECRET, or API_KEY and API_SECRET)")
            
        self.testnet = os.getenv('TESTNET', 'false').strip().lower() in ('1', 'true', 'yes', 'y')
        self.recv_window = int(os.getenv('RECV_WINDOW', '5000'))
        self.client = Client(
            api_key=self.api_key,
            api_secret=self.api_secret,
            testnet=self.testnet
        )
        try:
            self.client.ping()
            # Sync with server time to prevent timestamp errors
            server_time = self.client.get_server_time()
            local_time = int(time.time() * 1000)
            self.client.timestamp_offset = server_time['serverTime'] - local_time
            offset_ms = self.client.timestamp_offset
            logger.info(f"Time sync completed. Offset: {offset_ms}ms")
        except Exception as e:
            logger.warning(f"Time sync failed: {e}")
        
        # Enhanced components
        self.market_analyzer = EnhancedMarketAnalyzer()
        self.risk_manager = EnhancedRiskManager()
        # Initialize intelligent entry/exit system
        self.intelligent_trader = IntelligentEntryExit(self)
        # Load persisted positions and set position mode info
        self._load_positions()
        try:
            pmode = api_call_with_retries(self.client.futures_get_position_mode, recvWindow=self.recv_window)
            self.hedge_mode = pmode.get('dualSidePosition', False)
            logger.info(f"Futures position mode (hedge): {self.hedge_mode}")
        except Exception as e:
            logger.warning(f"Could not retrieve position mode: {e}")
            self.hedge_mode = False
        
        # Enhanced trading parameters
        self.max_positions = int(os.getenv('MAX_POSITIONS', '999999'))  # No max position limit per user instruction
        self.min_signal_strength = 55  # Relaxed to allow more trades
        self.scan_interval = int(os.getenv('SCAN_INTERVAL', '30'))  # 30 seconds between batches
        self._scan_index = 0
        self._batch_size = int(os.getenv('SCAN_BATCH_SIZE', '50'))  # 50 coins per batch (scans 500 coins in 10 batches / 5 min)
        # Periodic reconciliation config
        self._reconcile_interval = int(os.getenv('RECONCILE_INTERVAL', '120'))
        self._last_reconcile = 0
        
        # Position tracking
        if not hasattr(self, 'positions') or not isinstance(self.positions, dict):
            self.positions = {}
        self.symbol_info = {}
        self.klines_cache = {}  # Cache for klines data: {symbol: {interval: (timestamp, df)}}
        self.cache_ttl = 60  # Cache TTL in seconds
        self.performance_metrics = {
            'total_trades': 0,
            'winning_trades': 0,
            'total_pnl': 0,
            'start_time': datetime.now()
        }
        
        # Load active symbols (top 250 liquid pairs across Binance)
        self.load_trading_symbols()
        self._load_symbol_info()
        # Reconcile any open exchange positions into local state
        self.reconcile_positions()

        # Initialize automated coin discovery
        self.auto_coin_discovery = AutoCoinDiscovery(self)
        self.coin_discovery_interval = 3600  # Check for new coins every hour
        self.last_coin_discovery = 0

        logger.info(f"Enhanced ZeroLag Bot initialized with {len(self.symbols)} symbols (Top 250 Universe) and auto-coin discovery")

    def refresh_trading_symbols(self):
        """Dynamically refresh trading symbols using automated coin discovery (top 250)"""
        try:
            current_time = time.time()
            if current_time - self.last_coin_discovery >= self.coin_discovery_interval:
                logger.info("Running automated coin discovery across Binance Futures (top 250)...")

                new_symbols = self.auto_coin_discovery.discover_opportunities()

                if new_symbols:
                    old_count = len(self.symbols)
                    self.symbols = new_symbols[:self.auto_coin_discovery.symbols_per_discovery]  # Full top 500 coins

                    # Re-load symbol info for new symbols
                    self._load_symbol_info()

                    logger.info(f"Updated trading symbols: {old_count} -> {len(self.symbols)} symbols (Top 500 Universe)")
                    for symbol in self.symbols[:5]:  # Log first few
                        logger.debug(f"Active symbol: {symbol}")

                self.last_coin_discovery = current_time

        except Exception as e:
            logger.error(f"Error refreshing trading symbols: {e}")
    
    def load_trading_symbols(self):
        """Load top 500 high-volume trading symbols across Binance Futures"""
        try:
            tickers = api_call_with_retries(self.client.futures_ticker, recvWindow=self.recv_window)
            forbidden_patterns = ['USELESS', 'FARTCOIN', 'MOODENG', 'SKYAI', 'SOON', 'LISTA', 'APE', 'MORPHO', 'TRB', 'TAO']
            valid_coins = []
            for t in tickers:
                s = t.get('symbol', '')
                if s.endswith('USDT') and not any(p in s for p in forbidden_patterns):
                    try:
                        vol = float(t.get('quoteVolume', 0))
                        price = float(t.get('lastPrice', 0))
                        if vol >= 500_000 and price > 0.00001:
                            valid_coins.append((s, vol))
                    except Exception:
                        continue
            valid_coins.sort(key=lambda x: x[1], reverse=True)
            self.symbols = [x[0] for x in valid_coins[:500]]
            if len(self.symbols) < 10:
                self.symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT']
            logger.info(f"Loaded {len(self.symbols)} active trading symbols (Top 500 Liquid Pairs)")
        except Exception as e:
            logger.error(f"Error loading symbols: {e}")
            self.symbols = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT']
    
    def _load_symbol_info(self):
        """Load symbol information for precision and filters for all USDT pairs"""
        try:
            exchange_info = self.client.futures_exchange_info()
            for symbol_data in exchange_info['symbols']:
                symbol = symbol_data['symbol']
                if symbol.endswith('USDT'):
                    filters = {f['filterType']: f for f in symbol_data.get('filters', [])}
                    self.symbol_info[symbol] = {
                        'filters': filters,
                        'price_precision': symbol_data['pricePrecision'],
                        'quantity_precision': symbol_data['quantityPrecision'],
                        'min_qty': float(filters.get('LOT_SIZE', {}).get('minQty', '0')),
                        'step_size': float(filters.get('LOT_SIZE', {}).get('stepSize', '0')),
                        'tick_size': float(filters.get('PRICE_FILTER', {}).get('tickSize', '0')),
                        'min_notional': float(filters.get('MIN_NOTIONAL', {}).get('notional', '5'))
                    }
            logger.info(f"Loaded symbol info for {len(self.symbol_info)} symbols")
        except Exception as e:
            logger.error(f"Error loading symbol info: {e}")

    def fmt_price(self, symbol: str, v: float) -> str:
        """Format price with exact tick size and precision"""
        symbol_info = self.symbol_info.get(symbol, {})
        tick_size = float(symbol_info.get('tick_size', 0) or 0)
        price_prec = int(symbol_info.get('price_precision', 8) or 8)
        p = quantize_tick(v, tick_size) if tick_size else v
        p = round(p, price_prec)
        return (f"{p:.{price_prec}f}").rstrip('0').rstrip('.')

    def fmt_qty(self, symbol: str, v: float) -> str:
        """Format quantity correctly — uses Decimal to avoid rstrip('0') corrupting integer quantities."""
        from decimal import Decimal, ROUND_DOWN as _RD
        symbol_info = self.symbol_info.get(symbol, {})
        step_size = float(symbol_info.get('step_size', 0) or 0)
        qty_prec = int(symbol_info.get('quantity_precision', 8) or 8)
        if step_size and step_size > 0:
            step_dec = Decimal(str(step_size))
            v_dec = (Decimal(str(v)) / step_dec).quantize(Decimal('1'), rounding=_RD) * step_dec
            step_str = f'{step_size:.10f}'.rstrip('0')
            decimals = len(step_str.split('.')[1]) if '.' in step_str else 0
        else:
            decimals = qty_prec
            v_dec = Decimal(str(v))
        if decimals == 0:
            return str(int(v_dec))
        return f'{v_dec:.{decimals}f}'
    
    def _save_positions(self) -> None:
        try:
            with open('positions.json', 'w') as f:
                json.dump(self.positions, f, default=str)
        except Exception as e:
            logger.error(f"Error saving positions: {e}")

    def _load_positions(self) -> None:
        try:
            if os.path.exists('positions.json'):
                with open('positions.json', 'r') as f:
                    self.positions = json.load(f)
        except Exception as e:
            logger.error(f"Error loading positions: {e}")

    def reconcile_positions(self) -> None:
        """Fetch open positions from exchange and reconcile local state, preserving trailing progress"""
        try:
            info = api_call_with_retries(self.client.futures_position_information, recvWindow=self.recv_window)
            new_positions: Dict[str, Dict[str, Any]] = {}
            open_count = 0
            for p in info:
                symbol = p.get('symbol')
                try:
                    qty = float(p.get('positionAmt', '0') or 0)
                    entry = float(p.get('entryPrice', '0') or 0)
                except Exception:
                    qty, entry = 0.0, 0.0
                if abs(qty) > 0 and symbol:
                    open_count += 1
                    direction = 'LONG' if qty > 0 else 'SHORT'
                    qty_abs = abs(qty)
                    # Always rebuild local position from exchange as source of truth
                    df_1h = self.get_klines_data(symbol, '15m', 200)  # Use 15m (variable name kept for compat)
                    if not df_1h.empty:
                        atr = ta.volatility.AverageTrueRange(
                            df_1h['high'], df_1h['low'], df_1h['close'], window=14
                        ).average_true_range().iloc[-1]
                        regime = self.market_analyzer.detect_market_regime(df_1h).get('regime', 'ranging')
                        momentum = self.market_analyzer.calculate_momentum_score(df_1h)
                        sl, tp = self.risk_manager.calculate_dynamic_stops(entry, atr, momentum, regime, signal_type=direction)
                    else:
                        # Fallback stops around entry depending on direction
                        if direction == 'SHORT':
                            sl, tp = entry * 1.02, entry * 0.98
                        else:
                            sl, tp = entry * 0.98, entry * 1.02

                    # Preserve existing trailing stop and peak price if we already track this position
                    old_pos = getattr(self, 'positions', {}).get(symbol, {})
                    peak_price = old_pos.get('_peak_price', entry)
                    sl_active = old_pos.get('_sl_order_active', False)
                    if old_pos.get('stop_loss'):
                        if direction == 'LONG':
                            sl = max(sl, old_pos['stop_loss'])
                        else:
                            sl = min(sl, old_pos['stop_loss'])

                    new_positions[symbol] = {
                        'entry_price': entry,
                        'quantity': qty_abs,
                        'stop_loss': sl,
                        'take_profit': tp,
                        'entry_time': old_pos.get('entry_time', datetime.now()),
                        'signal_strength': old_pos.get('signal_strength', 0),
                        'momentum_score': old_pos.get('momentum_score', 0),
                        'order_notional': entry * qty_abs,
                        'direction': direction,
                        '_peak_price': peak_price,
                        '_sl_order_active': sl_active
                    }
            # Replace local positions with reconciled set
            self.positions = new_positions
            logger.info(f"Reconciled positions: exchange open {open_count}, local {len(self.positions)}")
            self._save_positions()
        except Exception as e:
            logger.warning(f"Could not reconcile positions: {e}")

    def get_klines_data(self, symbol: str, interval: str = '15m', limit: int = 200) -> pd.DataFrame:
        """Fetch and process klines data with caching"""
        current_time = time.time()
        cache_key = f"{symbol}_{interval}"
        
        # Check cache
        if symbol in self.klines_cache and interval in self.klines_cache[symbol]:
            cache_time, cached_df = self.klines_cache[symbol][interval]
            if current_time - cache_time < self.cache_ttl:
                return cached_df
        
        try:
            klines = api_call_with_retries(
                self.client.futures_klines,
                symbol=symbol,
                interval=interval,
                limit=limit,
                recvWindow=self.recv_window
            )
            
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Convert to numeric
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col])
                
            # Cache the result
            if symbol not in self.klines_cache:
                self.klines_cache[symbol] = {}
            self.klines_cache[symbol][interval] = (current_time, df)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def generate_enhanced_signal(self, symbol: str) -> Optional[Dict]:
        """Generate enhanced trading signals with momentum focus"""
        try:
            # Get multi-timeframe data
            df_1h = self.get_klines_data(symbol, '1h', 200)
            df_4h = self.get_klines_data(symbol, '4h', 100)
            df_15m = self.get_klines_data(symbol, '15m', 100)
            
            if df_1h.empty or df_4h.empty or df_15m.empty:
                return None
            
            # Market regime analysis
            regime_4h = self.market_analyzer.detect_market_regime(df_4h)
            regime_1h = self.market_analyzer.detect_market_regime(df_1h)
            
            # Momentum scoring
            momentum_1h = self.market_analyzer.calculate_momentum_score(df_1h)
            momentum_15m = self.market_analyzer.calculate_momentum_score(df_15m)
            
            # Technical indicators (1h timeframe)
            close_1h = df_1h['close']
            
            # EMAs
            ema_12 = ta.trend.EMAIndicator(close_1h, window=12).ema_indicator().iloc[-1]
            ema_26 = ta.trend.EMAIndicator(close_1h, window=26).ema_indicator().iloc[-1]
            ema_50 = ta.trend.EMAIndicator(close_1h, window=50).ema_indicator().iloc[-1]
            
            # RSI and MACD
            rsi = ta.momentum.RSIIndicator(close_1h, window=14).rsi().iloc[-1]
            macd = ta.trend.MACD(close_1h).macd_diff().iloc[-1]
            
            # Current price and ATR
            current_price = close_1h.iloc[-1]
            atr = ta.volatility.AverageTrueRange(
                df_1h['high'], df_1h['low'], df_1h['close'], window=14
            ).average_true_range().iloc[-1]
            if pd.isna(atr) or atr <= 0 or not np.isfinite(atr):
                logger.info(f"{symbol}: skip signal - invalid ATR atr={atr}")
                return None
            
            # Volume analysis
            vol_mean20 = df_1h['volume'].rolling(20).mean().iloc[-1]
            if pd.isna(vol_mean20) or vol_mean20 <= 0:
                logger.info(f"{symbol}: skip signal - invalid volume mean")
                return None
            volume_ratio = df_1h['volume'].iloc[-1] / vol_mean20
            
            # Price sanity
            if pd.isna(current_price) or current_price <= 0:
                logger.info(f"{symbol}: skip signal - invalid current price {current_price}")
                return None

            # Enhanced signal conditions - more flexible criteria for longs and shorts
            long_conditions = {
                'regime_bullish': (regime_4h['regime'] in ['strong_uptrend', 'weak_uptrend']) or
                                (regime_1h['regime'] in ['strong_uptrend', 'weak_uptrend']),  # OR logic for flexibility
                'momentum_strong': momentum_1h > 55 and momentum_15m > 45,
                'price_above_emas': current_price > ema_12 > ema_26,
                'ema_alignment': ema_12 > ema_26 > ema_50,
                'rsi_favorable': 45 < rsi < 75,  # Tightened range for better entries
                'macd_positive': macd > -0.1,
                'volume_confirmation': volume_ratio >= 0.7,
                'volatility_reasonable': 0.005 < (atr / current_price) < 0.12  # Relaxed volatility bounds
            }

            short_conditions = {
                'regime_bearish': (regime_4h['regime'] in ['strong_downtrend', 'weak_downtrend']) or
                                (regime_1h['regime'] in ['strong_downtrend', 'weak_downtrend']),  # OR logic for flexibility
                'momentum_weak': momentum_1h < 45 and momentum_15m < 55,
                'price_below_emas': current_price < ema_12 < ema_26,
                'ema_alignment_short': ema_12 < ema_26 < ema_50,
                'rsi_oversold': 25 < rsi < 55,  # Optimized range for shorts
                'macd_negative': macd < 0.1,
                'volume_confirmation_short': volume_ratio >= 0.7,
                'volatility_reasonable_short': 0.005 < (atr / current_price) < 0.12  # Relaxed for shorts
            }

            # Calculate signal strength for longs
            long_weights = {
                'regime_bullish': 25,
                'momentum_strong': 20,
                'price_above_emas': 15,
                'ema_alignment': 15,
                'rsi_favorable': 10,
                'macd_positive': 5,
                'volume_confirmation': 3,
                'volatility_reasonable': 5
            }
            long_strength = sum(
                long_weights[condition] for condition, met in long_conditions.items() if met
            )

            # Calculate signal strength for shorts
            short_weights = {
                'regime_bearish': 25,
                'momentum_weak': 20,
                'price_below_emas': 15,
                'ema_alignment_short': 15,
                'rsi_oversold': 10,
                'macd_negative': 5,
                'volume_confirmation_short': 3,
                'volatility_reasonable_short': 5
            }
            short_strength = sum(
                short_weights[condition] for condition, met in short_conditions.items() if met
            )

            # Determine signal type
            if long_strength >= self.min_signal_strength:
                signal_type = 'LONG'
                strength = long_strength
            elif short_strength >= self.min_signal_strength:
                signal_type = 'SHORT'
                strength = short_strength
            else:
                return None

            # More flexible entry logic - require signal strength only
            core_conditions_met = sum([
                long_conditions.get('price_above_emas', False) if signal_type == 'LONG' else short_conditions.get('price_below_emas', False),
                long_conditions.get('ema_alignment', False) if signal_type == 'LONG' else short_conditions.get('ema_alignment_short', False)
            ])

            # Generate signal if we have good strength OR strong core conditions
            if strength >= self.min_signal_strength or (strength >= 50 and core_conditions_met >= 1):
                logger.info(f"{symbol}: SIGNAL {signal_type} strength={strength} vol_ratio={volume_ratio:.2f} price={current_price:.2f} rsi={rsi:.1f} macd={macd:.3f}")
                return {
                    'signal': signal_type,
                    'strength': strength,
                    'price': current_price,
                    'atr': atr,
                    'momentum_1h': momentum_1h,
                    'momentum_15m': momentum_15m,
                    'regime_4h': regime_4h,
                    'regime_1h': regime_1h,
                    'rsi': rsi,
                    'volume_ratio': volume_ratio,
                    'conditions': long_conditions if signal_type == 'LONG' else short_conditions,
                    'timestamp': datetime.now()
                }
            
        except Exception as e:
            logger.error(f"Error generating signal for {symbol}: {e}")
            
        return None
    
    def execute_enhanced_trade(self, symbol: str, signal: Dict) -> bool:
        """Execute trade with enhanced risk management and precision handling"""
        try:
            # Get account balance
            account = api_call_with_retries(self.client.futures_account, recvWindow=self.recv_window)
            usdt = next((x for x in account.get('assets', []) if x.get('asset') == 'USDT'), None)
            if not usdt:
                logger.warning("USDT asset not found in account assets.")
                return False
            balance = float(usdt.get('walletBalance', 0))
            available_balance = float(usdt.get('availableBalance', 0))

            if balance < 5 or available_balance < 1.0:
                logger.warning(f"Insufficient balance/margin: total=${balance:.2f}, available=${available_balance:.2f}")
                return False

            # Get symbol info for precision and limits
            symbol_info = self.symbol_info.get(symbol, {})
            if not symbol_info:
                logger.warning(f"No symbol info for {symbol}")
                return False

            current_price = signal['price']

            # Symbol-specific constraints
            min_qty = float(symbol_info.get('min_qty', 0))
            step_size = float(symbol_info.get('step_size', 0))
            tick_size = float(symbol_info.get('tick_size', 0))
            min_notional = float(symbol_info.get('min_notional', 5.0))

            # Minimum order value must satisfy exchange min notional & min qty
            min_order_value = max(5.2, min_notional + 0.2, min_qty * current_price)

            # Calculate dynamic position size (1% of capital margin scaled by leverage)
            volatility = signal['atr'] / signal['price']
            position_size_usd = self.risk_manager.calculate_dynamic_position_size(
                balance=balance,
                signal_strength=signal['strength'],
                volatility=volatility,
                momentum_score=signal['momentum_1h']
            )
            # Risk-on-stop sizing: determine maximum notional allowed by risk cap and stop distance
            try:
                sl_preview, tp_preview = self.risk_manager.calculate_dynamic_stops(
                    entry_price=current_price,
                    atr=signal['atr'],
                    momentum_score=signal['momentum_1h'],
                    regime=signal['regime_1h']['regime'],
                    signal_type=signal['signal']
                )
            except (TypeError, ValueError) as e:
                logger.info(f"Could not compute stops for risk sizing on {symbol}: {e}")
                return False
            stop_distance = abs(current_price - sl_preview)
            if not np.isfinite(stop_distance) or stop_distance <= 0:
                logger.info(f"Invalid stop distance for {symbol}. Skipping.")
                return False

            risk_cap_usd = balance * (self.risk_manager.max_position_risk / 100)
            max_notional_by_risk = (risk_cap_usd / stop_distance) * current_price
            if max_notional_by_risk < min_order_value:
                logger.info(f"{symbol}: risk capacity ${max_notional_by_risk:.2f} < min order ${min_order_value:.2f}. stop_distance={stop_distance:.6f}, balance={balance:.2f}, risk%={self.risk_manager.max_position_risk}")
                return False
            # Clamp target notional to exchange minimum and risk-on-stop capacity
            position_size_usd = min(max(position_size_usd, min_order_value), max_notional_by_risk)

            # Quantity calculation with step-size quantization
            quantity = position_size_usd / current_price
            quantity_rounded = quantize_step(quantity, step_size) if step_size else quantity
            if quantity_rounded < min_qty:
                quantity_rounded = quantize_step(min_qty, step_size) if step_size else min_qty
                position_size_usd = quantity_rounded * current_price

            # Verify order notional vs min_notional with buffer
            order_notional = quantity_rounded * current_price
            required_min_notional = max(5.0, min_notional + 0.2)
            # Do not exceed risk-on-stop capacity to satisfy minimum notional
            if required_min_notional > max_notional_by_risk:
                logger.info(f"{symbol}: required min notional ${required_min_notional:.2f} > risk capacity ${max_notional_by_risk:.2f}. Adjust risk settings or stop distance.")
                return False
            if order_notional < required_min_notional:
                min_qty_for_notional = required_min_notional / current_price
                min_qty_for_notional *= 1.02
                quantity_rounded = max(quantity_rounded, quantize_step(min_qty_for_notional, step_size) if step_size else min_qty_for_notional)
                order_notional = quantity_rounded * current_price

            # Final verification with safety margin
            if quantity_rounded < min_qty:
                logger.info(f"{symbol}: final qty too small {quantity_rounded} < min_qty {min_qty} (step_size={step_size})")
                return False
            
            required_notional = max(5.2, min_notional + 0.2)
            if order_notional < required_notional:
                bump_qty = (required_notional * 1.02) / current_price
                quantity_rounded = quantize_step(bump_qty, step_size) if step_size else bump_qty
                order_notional = quantity_rounded * current_price
                if order_notional < required_notional:
                    logger.info(f"{symbol}: final order notional too small ${order_notional:.2f} < ${required_notional:.2f}. Skipping.")
                    return False

            # Calculate stop loss and take profit
            try:
                stop_loss, take_profit = self.risk_manager.calculate_dynamic_stops(
                    entry_price=current_price,
                    atr=signal['atr'],
                    momentum_score=signal['momentum_1h'],
                    regime=signal['regime_1h']['regime'],
                    signal_type=signal['signal']
                )
            except (TypeError, ValueError) as e:
                logger.error(f"Error calculating stops for {symbol}: {e}")
                return False
            # Quantize SL/TP to tick size
            if tick_size:
                stop_loss = quantize_tick(stop_loss, tick_size)
                take_profit = quantize_tick(take_profit, tick_size)

            # Ensure isolated margin and conservative leverage before order
            try:
                api_call_with_retries(
                    self.client.futures_change_margin_type,
                    symbol=symbol,
                    marginType='ISOLATED',
                    recvWindow=self.recv_window
                )
            except Exception:
                pass
            try:
                desired_leverage = int(os.getenv('MAX_LEVERAGE', '20'))
                api_call_with_retries(
                    self.client.futures_change_leverage,
                    symbol=symbol,
                    leverage=desired_leverage,
                    recvWindow=self.recv_window
                )
            except Exception as _e:
                logger.debug(f"Leverage setup failed for {symbol}: {_e}")

            # Execute market order with proper precision
            side = 'BUY' if signal['signal'] == 'LONG' else 'SELL'
            qty_str = self.fmt_qty(symbol, quantity_rounded)
            logger.info(f"{symbol}: placing {side} market order qty={qty_str}, price~{current_price}, notional~${order_notional:.2f}, sl={stop_loss}")
            order = api_call_with_retries(
                self.client.futures_create_order,
                symbol=symbol,
                side=side,
                type='MARKET',
                quantity=qty_str,
                recvWindow=self.recv_window
            )

            # Place exchange-side SL/TP reduce-only orders using new single-exit management
            try:
                if signal['signal'] == 'SHORT':
                    # For shorts, SL is above entry (higher price), TP is below (lower price)
                    stop_loss = max(stop_loss, current_price * 1.01)  # Ensure SL > entry for shorts
                    take_profit = min(take_profit, current_price * 0.99)  # Ensure TP < entry for shorts
                    side_sl = 'BUY'  # Close short with buy
                    side_tp = 'BUY'  # Close short with buy
                else:
                    side_sl = 'SELL'  # Close long with sell
                    side_tp = 'SELL'  # Close long with sell

                # Re-quantize after any adjustments
                if tick_size:
                    stop_loss = quantize_tick(stop_loss, tick_size)
                    take_profit = quantize_tick(take_profit, tick_size)

                # Place exchange stop loss order (single-exit management; trailing SL is the active exit)
                self._place_exit_order(
                    symbol=symbol,
                    exit_type='stop',
                    side=side_sl,
                    stop_price=stop_loss,
                    quantity=quantity_rounded,
                    position_side='SHORT' if signal['signal'] == 'SHORT' else None  # Only specify for hedge mode
                )

            except Exception as e:
                logger.warning(f"Failed to place SL/TP orders for {symbol}: {e}")

            # Store position with direction and tracking
            self.positions[symbol] = {
                'entry_price': current_price,
                'quantity': quantity_rounded,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'entry_time': datetime.now(),
                'signal_strength': signal['strength'],
                'momentum_score': signal['momentum_1h'],
                'order_notional': order_notional,
                'direction': signal['signal'],  # 'LONG' or 'SHORT'
                '_peak_price': current_price,
                '_sl_order_active': True
            }
            self._save_positions()

            logger.info(f"ENTERED: {symbol} | Size: ${position_size_usd:.2f} | "
                       f"Entry: ${current_price:.6f} | Qty: {quantity_rounded} | "
                       f"Min Qty: {min_qty} | SL: ${stop_loss:.6f} | TP: ${take_profit:.6f} | "
                       f"Strength: {signal['strength']} | Notional: ${order_notional:.2f}")

            return True

        except BinanceAPIException as e:
            if e.code == -1111:
                logger.error(f"Precision error for {symbol}: {e}. Check quantity precision.")
            elif e.code == -4164:
                logger.error(f"Notional too small for {symbol}: {e}. Need minimum $5 order.")
            else:
                logger.error(f"Binance API error for {symbol}: {e}")
            return False
        except Exception as e:
            logger.error(f"Error executing trade for {symbol}: {e}")
            return False
    
    def scan_and_trade(self):
        """Main scanning and trading loop with periodic exit order reconciliation"""
        logger.info("Enhanced trading bot started")

        while True:
            try:
                # Periodic reconciliation to prevent stale local positions
                if time.time() - getattr(self, '_last_reconcile', 0) >= getattr(self, '_reconcile_interval', 120):
                    try:
                        self.reconcile_positions()
                        # Also reconcile exit orders to prevent buildup
                        self._reconcile_exit_orders()
                    finally:
                        self._last_reconcile = time.time()

                # 1. Update positions and check exits - ALWAYS runs every cycle first
                symbols_to_manage = list(self.positions.keys())
                for symbol in symbols_to_manage:
                    if symbol in self.positions:  # Check if still exists
                        try:
                            self._manage_single_position(symbol)
                        except Exception as e:
                            logger.error(f"Error managing position {symbol}: {e}")

                # 2. Check position limit before scanning for new entries
                current_positions = len(self.positions)
                if self.max_positions and current_positions >= self.max_positions:
                    logger.info(f"Max positions reached: {current_positions}/{self.max_positions}")
                    time.sleep(self.scan_interval)
                    continue

                # 3. Refresh trading symbols periodically using automated discovery
                self.refresh_trading_symbols()

                # 4. Scan symbols for signals
                # Batch symbols to reduce rate limits
                if self._scan_index >= len(self.symbols):
                    self._scan_index = 0
                end = min(len(self.symbols), self._scan_index + self._batch_size)
                symbols_batch = self.symbols[self._scan_index:end]
                self._scan_index = end

                # Use intelligent entry/exit system for trading decisions
                for symbol in symbols_batch:
                    if symbol in self.positions:
                        continue  # Skip if already have position

                    try:
                        # Use intelligent entry system to evaluate opportunities
                        entry_decision = self.intelligent_trader.should_enter_position(symbol)

                        if entry_decision.get('enter', False):
                            # Construct signal from intelligent analysis
                            signal = {
                                'signal': entry_decision['signal'],
                                'strength': entry_decision['strength'],
                                'price': entry_decision['entry_price'],
                                'atr': 0.02,  # Default ATR, will be calculated properly
                                'momentum_1h': entry_decision['analysis'].get('components', {}).get('momentum_power', 50),
                                'regime_1h': {'regime': 'ranging'},  # Will be updated
                                'timestamp': datetime.now()
                            }

                            # Get proper ATR and regime data
                            df_1h = self.get_klines_data(symbol, '1h', 100)
                            if not df_1h.empty:
                                signal['atr'] = ta.volatility.AverageTrueRange(
                                    df_1h['high'], df_1h['low'], df_1h['close'], window=14
                                ).average_true_range().iloc[-1] or 0.02
                                signal['regime_1h'] = self.market_analyzer.detect_market_regime(df_1h)

                            logger.info(f"INTELLIGENT SIGNAL: {symbol} | Strength: {signal['strength']:.1f} | "
                                       f"Confidence: {entry_decision['confidence']:.2f} | Type: {signal['signal']}")

                            if self.execute_enhanced_trade(symbol, signal):
                                self.performance_metrics['total_trades'] += 1
                                time.sleep(2)  # Brief pause after trade execution

                    except Exception as e:
                        logger.error(f"Error processing {symbol} with intelligent trader: {e}")
                        continue

                # Brief rest before next scan
                time.sleep(self.scan_interval)

            except KeyboardInterrupt:
                logger.info("Bot stopping...")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(60)  # Wait before retrying
    
    def _generate_client_order_id(self, symbol: str, exit_type: str, side: str, price: float, qty: float) -> str:
        """Generate deterministic client order ID for idempotent operations"""
        # Create a unique but deterministic ID based on symbol, type, side, and rounded price/quantity
        # This prevents duplicates while allowing retries with same parameters
        symbol_clean = symbol.lower()
        exit_type_clean = exit_type.lower()  # 'stop' or 'take_profit'
        side_clean = side.lower()  # 'buy' or 'sell'
        price_str = f"{price:.8f}".rstrip('0').rstrip('.')
        qty_str = f"{qty:.8f}".rstrip('0').rstrip('.')
        unique_str = f"{symbol_clean}_{exit_type_clean}_{side_clean}_{price_str}_{qty_str}"
        # Hash to keep under Binance's 32 char limit
        import hashlib
        hash_obj = hashlib.md5(unique_str.encode())
        return f"zl_{exit_type_clean[:1]}{side_clean[:1]}_{hash_obj.hexdigest()[:16]}"

    def _get_open_exit_orders(self, symbol: str = None) -> list:
        """Fetch all open exit orders including both regular and conditional/algo orders"""
        all_exits = []
        # 1. Regular open orders
        try:
            params = {'recvWindow': self.recv_window}
            if symbol:
                params['symbol'] = symbol
            reg_orders = api_call_with_retries(self.client.futures_get_open_orders, **params)
            for o in (reg_orders or []):
                if o.get('type') in ['STOP_MARKET', 'TAKE_PROFIT_MARKET', 'STOP', 'TAKE_PROFIT']:
                    all_exits.append({
                        'is_algo': False,
                        'order_id': o['orderId'],
                        'symbol': o['symbol'],
                        'type': o['type'],
                        'side': o['side'].upper(),
                        'position_side': o.get('positionSide', 'BOTH'),
                        'price': float(o.get('stopPrice', 0) or 0),
                        'qty': float(o.get('origQty', 0) or 0),
                        'update_time': o.get('updateTime', o.get('time', 0))
                    })
        except Exception as e:
            logger.debug(f"Error fetching regular open orders for {symbol}: {e}")

        # 2. Algo / conditional open orders
        try:
            algo_res = api_call_with_retries(self.client.futures_get_open_algo_orders, recvWindow=self.recv_window)
            algo_orders = algo_res if isinstance(algo_res, list) else (algo_res.get('orders', []) if isinstance(algo_res, dict) else [])
            for o in (algo_orders or []):
                o_sym = o.get('symbol')
                if symbol and o_sym != symbol:
                    continue
                o_type = o.get('orderType') or o.get('algoType')
                if o_type in ['STOP_MARKET', 'TAKE_PROFIT_MARKET', 'CONDITIONAL', 'STOP', 'TAKE_PROFIT']:
                    all_exits.append({
                        'is_algo': True,
                        'order_id': o['algoId'],
                        'symbol': o_sym,
                        'type': o.get('orderType', 'STOP_MARKET'),
                        'side': o.get('side', '').upper(),
                        'position_side': o.get('positionSide', 'BOTH'),
                        'price': float(o.get('triggerPrice', 0) or 0),
                        'qty': float(o.get('quantity', 0) or 0),
                        'update_time': o.get('updateTime', o.get('createTime', 0))
                    })
        except Exception as e:
            logger.debug(f"Error fetching algo open orders for {symbol}: {e}")

        return all_exits

    def _cancel_single_exit_order(self, order: dict) -> bool:
        """Cancel a single exit order whether regular or algo"""
        try:
            if order.get('is_algo'):
                api_call_with_retries(self.client.futures_cancel_algo_order, algoId=order['order_id'])
            else:
                api_call_with_retries(self.client.futures_cancel_order, symbol=order['symbol'], orderId=order['order_id'], recvWindow=self.recv_window)
            return True
        except Exception as e:
            logger.warning(f"Failed to cancel exit order {order.get('order_id')} for {order.get('symbol')}: {e}")
            return False

    def _enforce_single_exit_per_side(self, symbol: str, exit_type: str, side: str, new_price: float, qty: float, position_side: str = None) -> bool:
        """Enforce single exit order per side by checking for and canceling duplicates (handles both regular and algo orders)"""
        try:
            target_type = 'STOP_MARKET' if exit_type == 'stop' else 'TAKE_PROFIT_MARKET'
            open_exits = self._get_open_exit_orders(symbol=symbol)

            # Filter for orders of this type and side
            matching_orders = []
            for order in open_exits:
                if order['type'] == target_type and order['side'] == side.upper():
                    matching_orders.append(order)

            # Cancel excess duplicates, keeping only the most recent one
            if len(matching_orders) > 1:
                logger.warning(f"Found {len(matching_orders)} {exit_type} orders for {symbol} {side}, canceling duplicates")
                matching_orders.sort(key=lambda x: x.get('update_time', 0), reverse=True)
                for dup in matching_orders[1:]:
                    self._cancel_single_exit_order(dup)
                matching_orders = [matching_orders[0]]

            current_order = matching_orders[0] if matching_orders else None
            needs_update = True

            if current_order:
                current_price = current_order['price']
                current_qty = current_order['qty']
                price_threshold = abs(current_price) * 0.001  # 0.1% threshold for price changes
                qty_threshold = abs(current_qty) * 0.01      # 1% threshold for qty changes

                price_diff = abs(current_price - new_price)
                qty_diff = abs(current_qty - qty)

                if price_diff <= price_threshold and qty_diff <= qty_threshold:
                    needs_update = False
                    logger.debug(f"Existing {exit_type} order for {symbol} {side} is current ({current_price:.6f} vs {new_price:.6f})")

            if needs_update and current_order:
                # Cancel existing order before placing new one
                self._cancel_single_exit_order(current_order)

            return needs_update

        except Exception as e:
            logger.error(f"Error enforcing single exit for {symbol} {exit_type} {side}: {e}")
            return True

    def _place_exit_order(self, symbol: str, exit_type: str, side: str, stop_price: float,
                         quantity: float, position_side: str = None, client_order_id: str = None) -> bool:
        """Place a single exit order with duplicate prevention"""
        try:
            # Use provided client order ID or generate deterministic one
            if not client_order_id:
                client_order_id = self._generate_client_order_id(symbol, exit_type, side, stop_price, quantity)

            # Enforce single order per side (cancels old order if price changed, or skips if current)
            if not self._enforce_single_exit_per_side(symbol, exit_type, side, stop_price, quantity, position_side):
                return True  # Order already current, no need to place

            # Prepare order parameters
            order_params = {
                'symbol': symbol,
                'side': side.upper(),
                'type': 'STOP_MARKET' if exit_type == 'stop' else 'TAKE_PROFIT_MARKET',
                'stopPrice': self.fmt_price(symbol, stop_price),
                'quantity': self.fmt_qty(symbol, quantity),
                'reduceOnly': True,
                'timeInForce': 'GTC',
                'newClientOrderId': client_order_id,
                'recvWindow': self.recv_window
            }

            # Add positionSide for hedge mode
            if self.hedge_mode and position_side:
                order_params['positionSide'] = position_side

            # Place the order
            order = api_call_with_retries(
                self.client.futures_create_order,
                **order_params
            )

            logger.debug(f"Placed {exit_type} order for {symbol} {side} at {stop_price:.6f} (ID: {client_order_id[:16]}...)")
            return True

        except BinanceAPIException as e:
            if e.code == -2011:  # NO_SUCH_ORDER
                logger.debug(f"Order placement skipped for {symbol} {exit_type} {side} - order was cancelled concurrently")
                return True
            else:
                logger.error(f"Failed to place {exit_type} order for {symbol} {side}: {e}")
                return False
        except Exception as e:
            logger.error(f"Error placing {exit_type} order for {symbol} {exit_type} {side}: {e}")
            return False

    def _reconcile_exit_orders(self):
        """Reconcile exit orders periodically to prevent buildup of duplicates or orphaned orders"""
        try:
            all_exits = self._get_open_exit_orders()
            active_symbols = set(self.positions.keys())

            # 1. Cancel orphaned exit orders for closed positions
            for order in all_exits:
                if order['symbol'] not in active_symbols:
                    self._cancel_single_exit_order(order)
                    logger.debug(f"Cancelled orphaned exit order {order['order_id']} for {order['symbol']}")

            # 2. Group by symbol + side + type to eliminate duplicates
            orders_by_key = {}
            for order in all_exits:
                if order['symbol'] in active_symbols:
                    key = f"{order['symbol']}_{order['side']}_{order['type']}"
                    orders_by_key.setdefault(key, []).append(order)

            for key, group in orders_by_key.items():
                if len(group) > 1:
                    logger.warning(f"Reconciliation: found {len(group)} duplicates for {key}, cleaning up")
                    group.sort(key=lambda x: x.get('update_time', 0), reverse=True)
                    for dup in group[1:]:
                        self._cancel_single_exit_order(dup)

        except Exception as e:
            logger.error(f"Error during exit order reconciliation: {e}")

    def _manage_single_position(self, symbol):
        """Manage a single position with 3-stage trailing stop logic.

        Stage 1 (profit < 3.5%):  Hard SL at entry * 0.965 (−3.5%). No trailing.
        Stage 2 (profit >= 3.5%): Move SL to entry * 1.002 (breakeven + fees). Lock it in.
        Stage 3 (profit >= 7.0%): Lock SL at entry * 1.005 (+0.5%), then trail 2.5% behind
                                   the highest price seen since entry.
        TP order is set unreachably high — trailing SL is the only real exit.
        """
        if symbol not in self.positions:
            return

        try:
            # Get current price
            ticker = api_call_with_retries(self.client.futures_symbol_ticker, symbol=symbol, recvWindow=self.recv_window)
            current_price = float(ticker['price'])

            position = self.positions[symbol]
            direction = position.get('direction', 'LONG')
            entry_price = position['entry_price']
            quantity = position['quantity']

            # Retrieve tick_size for this symbol (for SL price quantization)
            sym_info = getattr(self, 'symbol_info', {}).get(symbol, {})
            tick_size = sym_info.get('tick_size', 0) or 0

            # ──────────────────────────────────────────────────
            # Compute current profit %
            # ──────────────────────────────────────────────────
            if direction == 'SHORT':
                pnl_pct = (entry_price - current_price) / entry_price * 100
            else:
                pnl_pct = (current_price - entry_price) / entry_price * 100

            # Track highest (LONG) / lowest (SHORT) price since entry
            if direction == 'LONG':
                position['_peak_price'] = max(position.get('_peak_price', entry_price), current_price)
                peak_price = position['_peak_price']
            else:
                position['_peak_price'] = min(position.get('_peak_price', entry_price), current_price)
                peak_price = position['_peak_price']

            # ──────────────────────────────────────────────────
            # Determine target SL based on stage
            # ──────────────────────────────────────────────────
            current_sl = position['stop_loss']

            if pnl_pct >= 15.0:
                # Stage 4 ("Big Pump Mode"): lock in >= +8.0% profit, trail 5.0% from peak to ride mega-moves without 15m shakeouts
                min_sl_long  = entry_price * 1.080
                min_sl_short = entry_price * 0.920
                if direction == 'LONG':
                    trail_sl = peak_price * (1 - 0.050)
                    new_sl = max(current_sl, trail_sl, min_sl_long)
                else:
                    trail_sl = peak_price * (1 + 0.050)
                    new_sl = min(current_sl, trail_sl, min_sl_short)
            elif pnl_pct >= 7.0:
                # Stage 3: lock in >= +1.5% profit, trail 3.5% from peak (breathing room for 15m candle wicks)
                min_sl_long  = entry_price * 1.015
                min_sl_short = entry_price * 0.985
                if direction == 'LONG':
                    trail_sl = peak_price * (1 - 0.035)
                    new_sl = max(current_sl, trail_sl, min_sl_long)
                else:
                    trail_sl = peak_price * (1 + 0.035)
                    new_sl = min(current_sl, trail_sl, min_sl_short)
            elif pnl_pct >= 3.5:
                # Stage 2: move SL to breakeven + fees (~+0.2% above entry)
                be_sl_long  = entry_price * 1.002
                be_sl_short = entry_price * 0.998
                if direction == 'LONG':
                    new_sl = max(current_sl, be_sl_long)
                else:
                    new_sl = min(current_sl, be_sl_short)
            else:
                # Stage 1: hold hard SL at -3.5%; never widen
                hard_sl_long  = entry_price * 0.965
                hard_sl_short = entry_price * 1.035
                if direction == 'LONG':
                    new_sl = max(current_sl, hard_sl_long)
                else:
                    new_sl = min(current_sl, hard_sl_short)

            # Quantize new SL to tick size
            if tick_size and tick_size > 0:
                new_sl = quantize_tick(new_sl, tick_size)

            # ──────────────────────────────────────────────────
            # If SL has improved or order has not yet been placed on exchange, update
            # ──────────────────────────────────────────────────
            sl_moved = (direction == 'LONG' and new_sl > current_sl + entry_price * 0.0001) or \
                       (direction == 'SHORT' and new_sl < current_sl - entry_price * 0.0001) or \
                       not position.get('_sl_order_active', False)

            if sl_moved:
                try:
                    side_sl = 'BUY' if direction == 'SHORT' else 'SELL'
                    placed = self._place_exit_order(
                        symbol=symbol,
                        exit_type='stop',
                        side=side_sl,
                        stop_price=new_sl,
                        quantity=quantity,
                        position_side='SHORT' if direction == 'SHORT' else None
                    )
                    if placed:
                        position['stop_loss'] = new_sl
                        position['_sl_order_active'] = True
                        stage = 4 if pnl_pct >= 15.0 else (3 if pnl_pct >= 7.0 else (2 if pnl_pct >= 3.5 else 1))
                        logger.info(
                            f"SL ORDER [{symbol}] Stage {stage} | pnl={pnl_pct:.2f}% | "
                            f"peak={peak_price:.6f} | SL {current_sl:.6f} -> {new_sl:.6f}"
                        )
                except Exception as e:
                    logger.warning(f"Failed to update SL for {symbol}: {e}")

            # ──────────────────────────────────────────────────
            # Check if SL/TP hit (price crossed stop)
            # ──────────────────────────────────────────────────
            should_close = False
            close_reason = ''

            if direction == 'SHORT':
                if current_price >= position['stop_loss']:
                    should_close = True
                    close_reason = 'STOP_LOSS' if pnl_pct <= 0 else 'TRAIL_EXIT'
            else:
                if current_price <= position['stop_loss']:
                    should_close = True
                    close_reason = 'STOP_LOSS' if pnl_pct <= 0 else 'TRAIL_EXIT'

            if should_close:
                self.close_position(symbol, current_price, close_reason)

        except Exception as e:
            logger.error(f"Error managing position {symbol}: {e}")
    
    def close_position(self, symbol: str, exit_price: float, reason: str):
        """Close a position and cancel any remaining SL/TP orders"""
        try:
            position = self.positions[symbol]
            direction = position.get('direction', 'LONG')
            
            # Cancel any open exit orders for this symbol first (both regular and algo)
            try:
                open_exits = self._get_open_exit_orders(symbol=symbol)
                for order in open_exits:
                    self._cancel_single_exit_order(order)
            except Exception as e:
                logger.warning(f"Error cancelling exit orders for {symbol}: {e}")
            
            # Execute market close order
            side = 'BUY' if direction == 'SHORT' else 'SELL'
            qty_str = self.fmt_qty(symbol, position['quantity'])
            api_call_with_retries(
                self.client.futures_create_order,
                symbol=symbol,
                side=side,
                type='MARKET',
                quantity=qty_str,
                reduceOnly=True,
                recvWindow=self.recv_window
            )
            
            # Calculate P&L with direction
            if direction == 'SHORT':
                gross_pnl = (position['entry_price'] - exit_price) * position['quantity']
            else:  # LONG
                gross_pnl = (exit_price - position['entry_price']) * position['quantity']
            
            entry_fee = position['entry_price'] * position['quantity'] * 0.0004
            exit_fee = exit_price * position['quantity'] * 0.0004
            net_pnl = gross_pnl - entry_fee - exit_fee
            pnl_pct = ((exit_price / position['entry_price']) - 1) * 100 if direction == 'LONG' else ((position['entry_price'] / exit_price) - 1) * 100
            
            # Update performance metrics
            if net_pnl > 0:
                self.performance_metrics['winning_trades'] += 1
            self.performance_metrics['total_pnl'] += net_pnl
            
            logger.info(f"CLOSED: {symbol} | {reason} | Direction: {direction} | "
                       f"Entry: ${position['entry_price']:.6f} | Exit: ${exit_price:.6f} | "
                       f"P&L: ${net_pnl:.2f} ({pnl_pct:.2f}%)")
            
            # Remove from positions
            if symbol in self.positions:
                del self.positions[symbol]
                self._save_positions()
            
        except BinanceAPIException as e:
            if getattr(e, 'code', None) == -2022:
                logger.info(f"Position for {symbol} was already closed on exchange (ReduceOnly rejected). Removing from local tracking.")
                if symbol in self.positions:
                    del self.positions[symbol]
                    self._save_positions()
                try:
                    open_exits = self._get_open_exit_orders(symbol=symbol)
                    for order in open_exits:
                        self._cancel_single_exit_order(order)
                except Exception:
                    pass
            else:
                logger.error(f"Binance API error closing position {symbol}: {e}")
        except Exception as e:
            logger.error(f"Error closing position {symbol}: {e}")
            # If we fail to close, try to cancel any open exit orders to prevent unwanted execution
            try:
                open_exits = self._get_open_exit_orders(symbol=symbol)
                for order in open_exits:
                    self._cancel_single_exit_order(order)
            except Exception as cancel_error:
                logger.error(f"Failed to cancel orders after close error: {cancel_error}")


def acquire_bot_lock():
    """Acquire exclusive file lock to ensure only one instance of the bot runs (Windows & Linux)"""
    import sys
    try:
        lock_file = open("bot.lock", "w")
        try:
            import msvcrt
            msvcrt.locking(lock_file.fileno(), msvcrt.LK_NBLCK, 1)
        except ImportError:
            import fcntl
            fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        lock_file.write(str(os.getpid()))
        lock_file.flush()
        return lock_file
    except (IOError, OSError):
        logger.error("Another bot instance is already running with exclusive lock. Exiting to prevent conflicts.")
        sys.exit(1)


if __name__ == "__main__":
    _lock = acquire_bot_lock()
    try:
        bot = EnhancedZeroLagBot()
        bot.scan_and_trade()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        traceback.print_exc()
