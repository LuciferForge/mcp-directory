# TheBull - Dhan 80/20 Hybrid Core-Satellite Trading Engine

![TheBull Banner](https://raw.githubusercontent.com/manjunathg-dev/thebull/main/thebull_banner.png)

> **Empirically Proven Algorithmic Trading Architecture for Indian Markets (NSE Cash Equities & F&O Options Debit Spreads) on Dhan.co.**

---

## 🏛️ Strategy Architecture (80/20 Core-Satellite)

Based on extensive microstructure audits and multi-year backtesting across Indian markets:

### 1. The Core Bucket (80% Capital — ₹80,000)
- **Asset Class:** NSE Midcap & Smallcap High-Momentum Cash Equities / MTF.
- **Diversification:** Exactly 4 firewalled slots of ₹20,000 each.
- **Selection Criteria:** Stage-2 Markup (Close > EMA10 > EMA20 > EMA50), Relative Strength vs NIFTY $\ge$ +4%, Proximity to 52-week highs.
- **Macro Regime Gate:** **Holds 100% Cash** when NIFTY 50 trades below its 20-Day EMA, protecting capital during bear markets and corrections.
- **Exits:**
  - **-4.5% Hard Stop-Loss:** Preserves capital rigorously.
  - **+12.0% Take-Profit 1 (TP1):** Scale out 50% shares, move stop-loss to +1.0% break-even cushion.
  - **20-EMA Trailing Stop:** Trails the remaining 50% position to ride multi-month momentum waves.
- **Evaluation Timing:** Evaluated strictly once daily at **3:15 PM IST** (closing auction confirmation).

### 2. The Satellite Bucket (20% Capital — ₹20,000)
- **"The Ather Sniper" Strategy:** Captures rare, high-conviction breakout runners.
- **Trigger:** Fresh All-Time High / 52-Week High breakout with Volume $\ge$ 2.2x to 2.5x 20-day SMA and ADX $\ge$ 25.
- **Instrument:** 1-Lot **Bull Call Debit Spread** (Buy ATM Call, Sell OTM Call +1 to +2 strikes, Monthly Expiry).
  - *Why spreads?* Selling the OTM Call funds theta decay and protects against gap-down opens.
- **Risk Firewall:** Maximum 1 or 2 concurrent setups (cost ₹7,000 to ₹12,000 each).
- **Exits:** Target +120% to +180% on spread debit, Hard SL at -30%, max 4-day time cut.

---

## 📦 Quick Start (Under 3 Minutes)

### Windows (1-Click Run)
1. Double-click `start_bot.bat`.
2. It creates the isolated virtual environment, installs dependencies, and opens `.env` for your Dhan credentials.
3. Save your `.env` file, press any key, and the bot launches in **Paper Trading Mode** by default!

### Linux / macOS
```bash
chmod +x start_bot.sh
./start_bot.sh
```

---

## 🛠️ Command-Line Interface (CLI)

The bot comes with versatile command-line tools:

```bash
# 1. Run in Paper Trading Daemon mode (monitors during NSE market hours 09:15 - 15:30 IST)
python dhan_bot.py --daemon

# 2. View current portfolio allocations, active cash trades, and option spreads
python dhan_bot.py --status

# 3. Scan top Core Cash momentum candidates right now
python dhan_bot.py --scan-core

# 4. Scan "Ather Sniper" option breakout candidates right now
python dhan_bot.py --scan-satellite

# 5. Enable LIVE order placement on your Dhan Demat account
python dhan_bot.py --daemon --live
```

---

## ⚙️ Configuration (`config.json`)

```json
{
  "bot_name": "TheBull Dhan 80/20 Hybrid Core-Satellite Trading Engine",
  "total_capital_inr": 100000.0,
  "core_allocation_pct": 0.80,
  "satellite_allocation_pct": 0.20,
  "core_slots": 4,
  "core_rules": {
    "hard_sl_pct": 4.5,
    "tp1_scale_out_pct": 12.0,
    "trail_ema_period": 20
  }
}
```

---

## 🔑 Obtaining Dhan API Credentials

1. Log into your [Dhan Web Portal](https://web.dhan.co).
2. Go to **Profile -> DhanHQ API & Access**.
3. Generate your **Client ID** and **Access Token**.
4. Paste them into `.env`:
   ```env
   DHAN_CLIENT_ID=1100XXXXXX
   DHAN_ACCESS_TOKEN=eyJhbGciOi...
   ```

---

## 🛡️ Risk Management & SEBI Regulations Notice

1. **Paper Trading First:** Always run in `--daemon` (paper mode) for at least 1-2 weeks to familiarize yourself with trade alerts and execution rhythms before switching to `--live`.
2. **SEBI Physical Delivery on F&O:**
   - Single-stock options in India have mandatory physical settlement if held to expiry.
   - **TheBull bot automatically enforces a strict 4-day time cut and exits all option positions at least 5 days prior to monthly expiry**, completely eliminating physical delivery risk.

---

## ⚠️ Disclaimer

*Equity and derivative trading in Indian stock markets involves substantial risk of loss. This software is provided for educational and automated execution purposes. The user assumes full responsibility for capital deployed and trading decisions.*
