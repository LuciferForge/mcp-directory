"""
Data models for Stripe EU E-Invoicing Engine.
Standardized representation for EN 16931 / ZUGFeRD 2.2 / Factur-X profiles.
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class Address(BaseModel):
    line1: str
    line2: Optional[str] = None
    city: str
    postal_code: str
    country_code: str  # ISO 3166-1 alpha-2 (e.g. 'FR', 'DE', 'NL')
    state: Optional[str] = None


class Party(BaseModel):
    name: str
    address: Address
    vat_id: Optional[str] = None  # e.g., 'FR12345678901'
    tax_registration_id: Optional[str] = None  # e.g. SIRET or German Steuernummer
    electronic_address: Optional[str] = None  # e.g. Leitweg-ID or Peppol Participant ID
    electronic_address_scheme: Optional[str] = None  # e.g. '0204' for Leitweg-ID, '9957' for FR SIRET
    contact_email: Optional[str] = None
    contact_phone: Optional[str] = None


class PaymentDetails(BaseModel):
    payment_means_code: str = "58"  # 58 = SEPA credit transfer, 42 = Payment to bank account, 48 = Credit Card
    payment_means_name: str = "SEPA Credit Transfer"
    iban: Optional[str] = None
    bic: Optional[str] = None
    payment_reference: Optional[str] = None


class TaxBreakdownItem(BaseModel):
    tax_category_code: str = "S"  # S = Standard, AE = Reverse charge, Z = Zero rated, E = Exempt
    tax_rate_percent: float = 0.0
    taxable_amount: float = 0.0
    tax_amount: float = 0.0
    exemption_reason: Optional[str] = None


class InvoiceLineItem(BaseModel):
    line_id: str
    name: str
    description: Optional[str] = None
    quantity: float = 1.0
    unit_code: str = "C62"  # UN/ECE Rec 20: C62 = One/Unit, HUR = Hour, DAY = Day
    unit_price_net: float
    net_total_amount: float
    tax_category_code: str = "S"
    tax_rate_percent: float = 0.0
    tax_amount: float = 0.0


class InvoiceData(BaseModel):
    invoice_number: str
    stripe_invoice_id: str
    issue_date: str  # YYYY-MM-DD
    due_date: Optional[str] = None  # YYYY-MM-DD
    currency: str  # ISO 4217, e.g. 'EUR'
    profile: str = "urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:en16931"  # EN 16931 / Comfort
    seller: Party
    buyer: Party
    payment_details: Optional[PaymentDetails] = None
    line_items: List[InvoiceLineItem] = Field(default_factory=list)
    tax_breakdown: List[TaxBreakdownItem] = Field(default_factory=list)
    total_net_amount: float = 0.0
    total_tax_amount: float = 0.0
    total_gross_amount: float = 0.0
    due_payable_amount: float = 0.0
    notes: List[str] = Field(default_factory=list)


class WebhookProcessingResult(BaseModel):
    status: str
    stripe_event_id: str
    stripe_invoice_id: Optional[str] = None
    invoice_number: Optional[str] = None
    xml_generated: bool = False
    xml_size_bytes: int = 0
    en16931_compliant: bool = False
    message: str
    xml_content: Optional[str] = None
