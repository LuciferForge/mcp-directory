import MetaTrader5 as mt5

def close_all():
    if not mt5.initialize():
        print(f"Failed to initialize MT5: {mt5.last_error()}")
        return

    positions = mt5.positions_get()
    if not positions:
        print("No open positions found.")
        mt5.shutdown()
        return

    print(f"Found {len(positions)} open positions. Closing each to lock profit...")
    for p in positions:
        tick = mt5.symbol_info_tick(p.symbol)
        if not tick:
            print(f"Failed to get tick for {p.symbol}")
            continue

        is_buy = (p.type == mt5.ORDER_TYPE_BUY)
        close_price = tick.bid if is_buy else tick.ask
        close_type = mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "position": p.ticket,
            "symbol": p.symbol,
            "volume": p.volume,
            "type": close_type,
            "price": close_price,
            "deviation": 20,
            "magic": p.magic,
            "comment": "USER_MANUAL_PROFIT_CLOSE",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        res = mt5.order_send(request)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            print(f"SUCCESS: Closed Ticket #{p.ticket} ({p.symbol} {'BUY' if is_buy else 'SELL'} {p.volume}) at {close_price} | PnL: +${p.profit:.2f}")
        else:
            err = res.comment if res else mt5.last_error()
            print(f"FAILED to close Ticket #{p.ticket} on {p.symbol}: {err} (retcode: {res.retcode if res else 'None'})")

    # Verify positions after close
    remaining = mt5.positions_get()
    print(f"\nRemaining open positions: {len(remaining) if remaining else 0}")
    acc = mt5.account_info()
    if acc:
        print(f"Updated Balance: ${acc.balance:,.2f} USD | Equity: ${acc.equity:,.2f} USD")
    mt5.shutdown()

if __name__ == "__main__":
    close_all()
