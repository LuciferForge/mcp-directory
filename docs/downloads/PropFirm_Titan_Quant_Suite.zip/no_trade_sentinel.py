#!/usr/bin/env python3
"""
Autonomous 24/7 No-Trade Zone Sentinel for Manual Trading
=========================================================
Monitors economic calendar, session open wicks, and broker rollover windows.
Sends Telegram alerts:
1. Exactly 15 minutes BEFORE any No-Trade Zone starts (with exact end time).
2. Once the No-Trade Zone is CLEARED and normal conditions resume.

Covered Assets:
- Indices: US30, NAS100, SPX500, GER40/DAX, FTSE100, NIFTY
- Precious Metals: Gold (XAUUSD), Silver (XAGUSD)
- Energy: Oil (USOIL / WTI / Brent)
- Crypto: BTC (BTCUSD)
"""

import os
import json
import time
import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple, Any

# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("no_trade_sentinel.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("NoTradeSentinel")

# Telegram Configuration
TELEGRAM_BOT_TOKEN = "8876734134:AAFBjmwE-KT9IDghZw994Wc3gPVFtuqUncs"
TELEGRAM_CHAT_ID = "257190241"
CACHE_FILE = "news_calendar_cache.json"

def send_telegram(text: str) -> bool:
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    try:
        r = requests.post(url, json=payload, timeout=10)
        return r.status_code == 200
    except Exception as e:
        logger.error(f"Telegram dispatch error: {e}")
        return False

def format_ist(dt: datetime) -> str:
    # Convert UTC to IST (+5:30)
    ist_tz = timezone(timedelta(hours=5, minutes=30))
    return dt.astimezone(ist_tz).strftime("%I:%M %p IST")

class NoTradeSentinel:
    def __init__(self):
        self.events: List[Dict[str, Any]] = []
        self.last_calendar_fetch = 0.0
        self.active_zones: Dict[str, Dict[str, Any]] = {}   # zone_id -> zone_dict
        self.warned_zones: set = set()                     # zone_ids that received the 15m warning
        self.cleared_zones: set = set()                    # zone_ids that received the cleared alert
        self.fetch_calendar()

    def fetch_calendar(self):
        url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
        headers = {"User-Agent": "Mozilla/5.0"}
        try:
            r = requests.get(url, headers=headers, timeout=10)
            if r.status_code == 200:
                self.events = r.json()
                self.last_calendar_fetch = time.time()
                with open(CACHE_FILE, "w", encoding="utf-8") as f:
                    json.dump(self.events, f, indent=2)
                logger.info(f"Loaded {len(self.events)} calendar events from ForexFactory.")
                return
        except Exception as e:
            logger.warning(f"Failed fetching calendar: {e}")

        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    self.events = json.load(f)
                logger.info(f"Loaded {len(self.events)} events from local cache.")
            except Exception as fe:
                logger.error(f"Cache load error: {fe}")

    def refresh_if_needed(self):
        if time.time() - self.last_calendar_fetch > 3600.0:
            self.fetch_calendar()

    def map_event_to_assets(self, currency: str, title: str, impact: str) -> List[str]:
        cur = currency.upper()
        t = title.upper()
        assets = []

        if cur == "USD":
            # US macro moves US Indices, Gold, Silver, BTC, Oil
            if impact in ("High", "Medium"):
                assets.extend(["US30", "NAS100", "SPX500", "GOLD (XAU)", "SILVER (XAG)", "BTC"])
            if "CRUDE" in t or "OIL" in t or "PETROLEUM" in t:
                assets.append("OIL (WTI/Brent)")
            if "INVENTORIES" in t or "GAS" in t:
                if "OIL (WTI/Brent)" not in assets:
                    assets.append("OIL (WTI/Brent)")
        elif cur == "EUR":
            if impact in ("High", "Medium"):
                assets.extend(["GER40 (DAX)", "EUROSTOXX50", "GOLD (XAU)"])
        elif cur == "GBP":
            if impact in ("High", "Medium"):
                assets.extend(["FTSE100", "GBP PAIRS", "GOLD (XAU)"])
        elif cur == "CAD":
            if impact == "High" or "RATE" in t or "BOC" in t:
                assets.extend(["CAD PAIRS", "OIL (WTI/Brent)"])

        return list(dict.fromkeys(assets)) # Remove duplicates

    def get_upcoming_zones(self, now_utc: datetime) -> List[Dict[str, Any]]:
        zones = []
        today_utc = now_utc.date()

        # 1. Economic Calendar Zones
        for e in self.events:
            impact = e.get("impact", "")
            if impact not in ("High", "Medium"):
                continue

            date_str = e.get("date", "")
            try:
                ev_dt = datetime.fromisoformat(date_str)
            except Exception:
                continue

            # Only look at events within [-1 hour, +12 hours]
            time_diff = (ev_dt - now_utc).total_seconds()
            if not (-3600 <= time_diff <= 43200):
                continue

            cur = e.get("country", "")
            title = e.get("title", "")
            assets = self.map_event_to_assets(cur, title, impact)
            if not assets:
                continue

            # Standard Blackout: -15 mins before to +15 mins after (or +30 for FOMC/NFP/CPI)
            buffer_pre = 15
            buffer_post = 30 if any(k in title.upper() for k in ["CPI", "NFP", "FOMC", "RATE", "PAYROLLS"]) else 15

            start_dt = ev_dt - timedelta(minutes=buffer_pre)
            end_dt = ev_dt + timedelta(minutes=buffer_post)

            zone_id = f"NEWS_{cur}_{ev_dt.strftime('%Y%m%d_%H%M')}_{title[:15]}"
            zones.append({
                "zone_id": zone_id,
                "type": "ECONOMIC_NEWS",
                "title": f"[{cur} {impact}] {title}",
                "assets": assets,
                "event_time": ev_dt,
                "start_time": start_dt,
                "end_time": end_dt
            })

        # 2. Daily US Cash Open Whipsaw Zone (09:30 - 09:45 EST / 14:30 - 14:45 UTC)
        # Weekdays only
        if now_utc.weekday() < 5:
            # 14:30 UTC = US Open
            us_open_dt = datetime(now_utc.year, now_utc.month, now_utc.day, 14, 30, tzinfo=timezone.utc)
            us_zone_start = us_open_dt - timedelta(minutes=15) # 14:15 UTC (19:45 IST)
            us_zone_end = us_open_dt + timedelta(minutes=15)   # 14:45 UTC (20:15 IST)

            if -1800 <= (us_open_dt - now_utc).total_seconds() <= 43200:
                zones.append({
                    "zone_id": f"US_OPEN_{now_utc.strftime('%Y%m%d')}",
                    "type": "SESSION_OPEN",
                    "title": "US Cash Market Open (NYSE & Nasdaq Bell Opening Wicks)",
                    "assets": ["US30", "NAS100", "SPX500", "GOLD (XAU)", "SILVER (XAG)", "OIL", "BTC"],
                    "event_time": us_open_dt,
                    "start_time": us_zone_start,
                    "end_time": us_zone_end
                })

        # 3. Daily Broker Rollover / Spread Widening (21:55 - 22:15 UTC / 03:25 - 03:45 AM IST)
        if now_utc.weekday() < 5:
            rollover_dt = datetime(now_utc.year, now_utc.month, now_utc.day, 22, 0, tzinfo=timezone.utc)
            roll_start = rollover_dt - timedelta(minutes=5)
            roll_end = rollover_dt + timedelta(minutes=15)

            if -1800 <= (rollover_dt - now_utc).total_seconds() <= 43200:
                zones.append({
                    "zone_id": f"ROLLOVER_{now_utc.strftime('%Y%m%d')}",
                    "type": "BROKER_ROLLOVER",
                    "title": "Daily Broker Rollover & Spread Expansion Hour",
                    "assets": ["ALL INDICES", "GOLD (XAU)", "SILVER (XAG)", "OIL (WTI/Brent)"],
                    "event_time": rollover_dt,
                    "start_time": roll_start,
                    "end_time": roll_end
                })

        # 4. Weekly EIA Crude Oil Inventories (Wednesdays 15:30 UTC / 21:00 IST)
        if now_utc.weekday() == 2: # Wednesday
            eia_dt = datetime(now_utc.year, now_utc.month, now_utc.day, 15, 30, tzinfo=timezone.utc)
            eia_start = eia_dt - timedelta(minutes=15)
            eia_end = eia_dt + timedelta(minutes=15)
            if -1800 <= (eia_dt - now_utc).total_seconds() <= 43200:
                zones.append({
                    "zone_id": f"EIA_OIL_{now_utc.strftime('%Y%m%d')}",
                    "type": "ENERGY_INVENTORY",
                    "title": "EIA Weekly Petroleum & Crude Oil Stock Report",
                    "assets": ["OIL (USOIL / WTI / Brent)", "USDCAD"],
                    "event_time": eia_dt,
                    "start_time": eia_start,
                    "end_time": eia_end
                })

        return zones

    def run_check(self):
        now_utc = datetime.now(timezone.utc)
        self.refresh_if_needed()
        zones = self.get_upcoming_zones(now_utc)

        for z in zones:
            zid = z["zone_id"]
            start_dt = z["start_time"]
            end_dt = z["end_time"]
            assets_str = ", ".join(z["assets"])

            # 1. 15-Minute Advance Warning
            # Check if now is between [start_dt - 16m, start_dt]
            time_to_start_sec = (start_dt - now_utc).total_seconds()
            
            if 0 <= time_to_start_sec <= 960 and zid not in self.warned_zones:
                mins_left = max(1, int(round(time_to_start_sec / 60.0)))
                
                msg = (
                    f"🚨 <b>NO-TRADE ZONE WARNING (Starts in {mins_left} Mins)</b>\n\n"
                    f"• <b>Affected Assets:</b> <code>{assets_str}</code>\n"
                    f"• <b>Catalyst:</b> <b>{z['title']}</b>\n"
                    f"• <b>No-Trade Window:</b> <code>{format_ist(start_dt)}</code> ➡️ <code>{format_ist(end_dt)}</code>\n"
                    f"• <b>Exact End Time:</b> <b>{format_ist(end_dt)}</b>\n\n"
                    f"⚠️ <i>Recommendation: Flatten short-term manual scalps, avoid placing market orders, and prepare for high spread volatility.</i>"
                )
                logger.info(f"Dispatching 15m Warning for {zid}")
                if send_telegram(msg):
                    self.warned_zones.add(zid)

            # 2. Active Zone Tracker
            if start_dt <= now_utc <= end_dt:
                self.active_zones[zid] = z

            # 3. Cleared Zone Alert
            if now_utc > end_dt and zid in self.warned_zones and zid not in self.cleared_zones:
                msg = (
                    f"🟢 <b>NO-TRADE ZONE CLEARED</b>\n\n"
                    f"• <b>Assets Resumed:</b> <code>{assets_str}</code>\n"
                    f"• <b>Event Completed:</b> {z['title']}\n"
                    f"• <b>Status:</b> Normal manual trading conditions restored. Spreads stabilizing.\n"
                    f"• <b>Time Cleared:</b> {format_ist(end_dt)}"
                )
                logger.info(f"Dispatching Cleared Alert for {zid}")
                if send_telegram(msg):
                    self.cleared_zones.add(zid)
                    self.active_zones.pop(zid, None)

def main():
    logger.info("Starting No-Trade Zone Sentinel Engine...")
    sentinel = NoTradeSentinel()
    
    # Broadcast startup digest for today
    now_utc = datetime.now(timezone.utc)
    today_zones = sentinel.get_upcoming_zones(now_utc)
    logger.info(f"Found {len(today_zones)} No-Trade Zones for today.")

    while True:
        try:
            sentinel.run_check()
            time.sleep(30) # Evaluate every 30 seconds
        except Exception as e:
            logger.error(f"Error in sentinel loop: {e}")
            time.sleep(15)

if __name__ == "__main__":
    main()
