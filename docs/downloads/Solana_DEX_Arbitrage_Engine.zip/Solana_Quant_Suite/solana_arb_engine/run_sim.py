"""CLI Paper-Trading and Live Simulation Runner for Solana Arbitrage Engine.

Streams pool events, evaluates safety filters against honeypots, executes optimal trade
sizing math, generates atomic Jito MEV bundles, and logs paper-trading PnL in real-time.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

# Ensure root workspace is on python path
WORKSPACE_ROOT = Path(__file__).resolve().parent
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))

from src.config import EngineConfig
from src.engine import ArbitrageEngine, EngineExecutionReport, EngineStats


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Solana Long-Tail & Migration Arbitrage Engine - Paper Trading Simulator"
    )
    parser.add_argument(
        "--events",
        type=int,
        default=20,
        help="Number of pool events to simulate before displaying final summary (default: 20, 0 for continuous)",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=0.8,
        help="Interval in seconds between synthetic/incoming event ticks (default: 0.8)",
    )
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="Path to custom JSON configuration file",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="Attempt live WebSocket connection to Solana RPC (fallback to synthetic stream if unavailable)",
    )
    parser.add_argument(
        "--initial-sol",
        type=float,
        default=None,
        help="Override initial paper wallet SOL balance (default: 10.0 SOL)",
    )
    return parser.parse_args()


def print_banner(config: EngineConfig, initial_balance: float) -> None:
    print("\n" + "=" * 95)
    print("      SOLANA LONG-TAIL & MIGRATION ARBITRAGE ENGINE (PAPER-TRADING MODE)      ")
    print("=" * 95)
    print(f" Initial Paper Wallet Balance : {initial_balance:.4f} SOL")
    print(f" Min Net Profit Threshold     : {config.min_profit_sol:.4f} SOL")
    print(f" Dynamic Jito Tip Formula     : min({config.tip_percentage * 100:.0f}% of Gross Profit, {config.max_tip_sol:.4f} SOL max)")
    print(f" Max Single Trade Size        : {config.max_trade_sol:.2f} SOL")
    print(f" Supported DEX Protocols      : Raydium AMM v4, Raydium CPMM, Meteora DLMM, Pump.fun")
    print(f" Audit Log Path               : {config.simulation.log_file}")
    print("=" * 95)
    print(f"{'TIME':<10} | {'TOKEN':<12} | {'ACTION':<20} | {'SPREAD':<8} | {'INPUT':<8} | {'NET PNL':<12} | {'BALANCE':<10}")
    print("-" * 95)


def console_event_logger(report: EngineExecutionReport, stats: EngineStats) -> None:
    now_str = time.strftime("%H:%M:%S", time.localtime())
    token_str = report.token_mint[:8] + ".."

    if report.decision == "BLOCKED_HONEYPOT":
        action_str = "\033[91mBLOCKED (Honeypot)\033[0m"
        spread_str = "---"
        input_str = "---"
        pnl_str = "\033[91m0.0000 SOL\033[0m"
    elif report.decision == "SKIPPED_UNPROFITABLE":
        action_str = "\033[93mSKIPPED (Low ROI)\033[0m"
        spread = f"{report.arb_opportunity.price_spread_pct:.2f}%" if report.arb_opportunity else "---"
        spread_str = spread
        input_str = "---"
        pnl_str = "0.0000 SOL"
    elif report.decision == "EXECUTED_PROFITABLE":
        action_str = "\033[92mEXECUTED (Bundle)\033[0m"
        arb = report.arb_opportunity
        sim = report.simulation_result
        spread_str = f"{arb.price_spread_pct:.2f}%"
        input_str = f"{arb.optimal_input_sol:.2f} SOL"
        pnl_str = f"\033[92m+{sim.net_profit_sol:.5f} SOL\033[0m"
    else:
        action_str = "\033[91mREVERTED\033[0m"
        spread_str = "---"
        input_str = "---"
        pnl_str = "0.0000 SOL"

    bal_str = f"{stats.current_sol_balance:.4f} SOL"
    print(f"{now_str:<10} | {token_str:<12} | {action_str:<29} | {spread_str:<8} | {input_str:<8} | {pnl_str:<21} | {bal_str:<10}")


def print_summary_card(stats: EngineStats, initial_balance: float) -> None:
    net_pnl = stats.current_sol_balance - initial_balance
    pnl_pct = (net_pnl / initial_balance) * 100.0

    print("-" * 95)
    print("\n" + "=" * 55)
    print("             PAPER-TRADING SESSION SUMMARY             ")
    print("=" * 55)
    print(f" Total Events Processed       : {stats.events_received}")
    print(f" Honeypots / Rugs Blocked     : {stats.safety_violations_blocked} (100% Capital Preserved)")
    print(f" Clean Opportunities Evaluated: {stats.clean_tokens_evaluated}")
    print(f" Opportunities Skipped        : {stats.unprofitable_skipped}")
    print(f" Jito MEV Bundles Dispatched  : {stats.bundles_generated}")
    print(f" Successful Arbitrage Trades  : {stats.successful_paper_trades}")
    print(f" Win Rate                     : {stats.win_rate_pct:.1f}%")
    print("-" * 55)
    print(f" Cumulative Gross Profit      : {stats.cumulative_gross_profit_sol:+.6f} SOL")
    print(f" Cumulative Jito Tips Paid    : {stats.cumulative_jito_tips_sol:.6f} SOL")
    print(f" Cumulative Net PnL           : {net_pnl:+.6f} SOL ({pnl_pct:+.2f}%)")
    print(f" Final Paper Balance          : {stats.current_sol_balance:.6f} SOL")
    print("=" * 55 + "\n")


async def main() -> None:
    args = parse_arguments()
    config = EngineConfig.load(args.config)
    if args.initial_sol is not None:
        config.simulation.initial_sol_balance = args.initial_sol

    initial_balance = config.simulation.initial_sol_balance
    engine = ArbitrageEngine(config=config)

    print_banner(config, initial_balance)

    max_events = args.events if args.events > 0 else None
    try:
        await engine.run_paper_trading_loop(
            max_events=max_events,
            event_interval=args.interval,
            print_callback=console_event_logger,
        )
    except KeyboardInterrupt:
        print("\n[!] Simulation interrupted by user.")
    finally:
        print_summary_card(engine.stats, initial_balance)


if __name__ == "__main__":
    asyncio.run(main())
