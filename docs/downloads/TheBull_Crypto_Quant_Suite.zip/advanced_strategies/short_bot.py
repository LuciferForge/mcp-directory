import os
import logging
import time
import json
import math
import signal
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

import pandas as pd
from binance.client import Client
from binance.exceptions import BinanceAPIException
from dotenv import load_dotenv

# Import our short strategy
from short_strategy import ShortStrategy

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('short_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ShortOnlyBot:
    """
    Short-only trading bot for Binance Futures.
    Implements aggressive short-selling strategy with strict risk management.
    """
    
    def __init__(self, paper_trading: bool = True, symbols: List[str] = None):
        """Initialize the bot with API keys and trading parameters"""
        # Load environment variables first
        from dotenv import load_dotenv
        load_dotenv(override=True)  # Force reload of .env file
        
        # Initialize logger
        self.logger = logging.getLogger('ShortOnlyBot')
        
        # API configuration - using the actual variable names from .env
        self.api_key = os.getenv('API_KEY', '').strip()
        self.api_secret = os.getenv('API_SECRET', '').strip()
        
        if not self.api_key or not self.api_secret:
            self.logger.error("API key or secret not found in environment variables")
            self.logger.error(f"API_KEY exists: {'Yes' if os.getenv('API_KEY') else 'No'}")
            self.logger.error(f"API_SECRET exists: {'Yes' if os.getenv('API_SECRET') else 'No'}")
            raise ValueError("API key and secret must be set in .env file")
        
        # Initialize Binance client
        self.client = Client(
            api_key=self.api_key,
            api_secret=self.api_secret,
            testnet=paper_trading,
            requests_params={'timeout': 30}
        )
        
        # Trading parameters - adjusted for high-volatility pairs
        self.paper_trading = paper_trading
        self.max_trades = 5  # Maximum number of concurrent short positions
        self.max_risk_per_trade = 0.01  # Reduced to 1% risk per trade due to higher volatility
        self.max_daily_loss = 0.03  # Reduced to 3% max daily loss
        self.position_size_pct = 0.15  # 15% of available balance per trade (reduced for safety)
        self.min_volume_usd = 500000  # $500K minimum 24h volume (reduced to include more opportunities)
        
        # Additional parameters for high-volatility pairs
        self.take_profit_multiplier = 2.5  # Take profit at 2.5x ATR (reduced from 3x)
        self.stop_loss_multiplier = 1.5    # Stop loss at 1.5x ATR (tighter)
        
        # Initialize strategy
        self.strategy = ShortStrategy()
        
        # Load symbols to trade
        self.symbols = symbols or self._load_default_symbols()
        self.symbol_info = {}
        
        # Track open positions and performance
        self.positions = {}
        self.daily_pnl = 0.0
        self.daily_start_balance = 0.0
        self.last_balance_check = datetime.utcnow()
        
        # Load symbol information
        self._load_symbol_info()
        
        # Register signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.logger.info("ShortOnlyBot initialized")
    
    def _load_default_symbols(self) -> List[str]:
        """Load default list of symbols with validation"""
        # Our top picks from analysis that we want to check
        desired_symbols = [
            'SPKUSDT',    # Highest score (99.29)
            'HYPERUSDT',  # 98.78
            'EPICUSDT',   # 97.96
            'SAHARAUSDT', # 95.20
            'MDTUSDT',    # 95.00
            'CFXUSDT',    # 94.49
            'PENGUUSDT',  # 91.84
            'IDEXUSDT',   # 91.43
            'NEWTUSDT',   # 90.61
            'INITUSDT',   # 89.80
            # Add some high-volume reliable pairs as fallback
            'BTCUSDT',
            'ETHUSDT',
            'BNBUSDT',
            'XRPUSDT',
            'SOLUSDT',
            'ADAUSDT',
            'DOGEUSDT',
            'DOTUSDT',
            'MATICUSDT',
            'AVAXUSDT'
        ]
        
        # Get all available futures symbols from Binance
        try:
            exchange_info = self.client.futures_exchange_info()
            valid_symbols = [s['symbol'] for s in exchange_info['symbols'] 
                           if s['status'] == 'TRADING' 
                           and s['symbol'].endswith('USDT')]
            
            # Filter our desired symbols to only include valid ones
            valid_desired = [s for s in desired_symbols if s in valid_symbols]
            
            # If we don't have enough valid symbols, add some high-volume ones
            if len(valid_desired) < 5:
                # Get top 10 USDT pairs by volume as fallback
                tickers = self.client.futures_ticker()
                top_volume = sorted(
                    [t for t in tickers if t['symbol'].endswith('USDT')],
                    key=lambda x: float(x['quoteVolume']),
                    reverse=True
                )[:10]
                top_symbols = [t['symbol'] for t in top_volume]
                valid_desired.extend(s for s in top_symbols if s not in valid_desired)
            
            self.logger.info(f"Loaded {len(valid_desired)} valid trading symbols")
            return valid_desired
            
        except Exception as e:
            self.logger.error(f"Error loading valid symbols: {e}")
            # Return a safe default list if there's an error
            return ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'XRPUSDT', 'SOLUSDT']
    
    def _load_symbol_info(self):
        """Load symbol information and filters from exchange"""
        try:
            self.logger.info(f"Loading info for symbols: {', '.join(self.symbols)}")
            exchange_info = self.client.futures_exchange_info()
            
            # Create a map of all valid symbols for quick lookup
            valid_symbols = {}
            for symbol in exchange_info['symbols']:
                if symbol['status'] == 'TRADING' and symbol['symbol'] in self.symbols:
                    try:
                        price_filter = next(f for f in symbol['filters'] if f['filterType'] == 'PRICE_FILTER')
                        lot_size = next(f for f in symbol['filters'] if f['filterType'] == 'LOT_SIZE')
                        min_notional = next((f for f in symbol['filters'] if f['filterType'] == 'MIN_NOTIONAL'), None)
                        
                        valid_symbols[symbol['symbol']] = {
                            'filters': symbol['filters'],
                            'base_asset': symbol['baseAsset'],
                            'quote_asset': symbol['quoteAsset'],
                            'tick_size': float(price_filter['tickSize']),
                            'step_size': float(lot_size['stepSize']),
                            'min_notional': float(min_notional['notional']) if min_notional else 10.0,  # Default to $10 if not found
                            'min_qty': float(lot_size['minQty'])
                        }
                    except (KeyError, StopIteration) as e:
                        self.logger.warning(f"Skipping symbol {symbol['symbol']} due to missing filters: {e}")
            
            # Update symbols to only include valid ones
            invalid_symbols = set(self.symbols) - set(valid_symbols.keys())
            if invalid_symbols:
                self.logger.warning(f"Removing invalid/unsupported symbols: {', '.join(invalid_symbols)}")
                self.symbols = [s for s in self.symbols if s in valid_symbols]
            
            self.symbol_info = valid_symbols
            self.logger.info(f"Successfully loaded info for {len(self.symbol_info)}/{len(self.symbols)} symbols")
            
            if not self.symbol_info:
                raise ValueError("No valid trading symbols found. Please check your symbol list.")
                
        except Exception as e:
            self.logger.error(f"Error loading symbol info: {str(e)}")
            # If we can't load symbol info, we can't trade safely
            raise
    
    def _get_historical_klines(self, symbol: str, interval: str = '1h', limit: int = 200) -> pd.DataFrame:
        """Get historical klines data"""
        try:
            klines = self.client.futures_klines(
                symbol=symbol,
                interval=interval,
                limit=limit
            )
            
            df = pd.DataFrame(klines, columns=[
                'open_time', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])
            
            # Convert string columns to float
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = df[col].astype(float)
                
            # Convert timestamp to datetime
            df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
            df['close_time'] = pd.to_datetime(df['close_time'], unit='ms')
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error getting klines for {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def _calculate_position_size(self, symbol: str, entry_price: float, stop_loss: float) -> float:
        """Calculate position size based on risk parameters"""
        try:
            # Get account balance
            account = self.client.futures_account_balance()
            usdt_balance = next((float(asset['balance']) for asset in account if asset['asset'] == 'USDT'), 0.0)
            
            if usdt_balance <= 0:
                self.logger.error("No USDT balance available")
                return 0.0
                
            # Calculate risk amount
            risk_amount = min(
                usdt_balance * self.max_risk_per_trade,  # Risk per trade
                usdt_balance * 0.1  # Max 10% of balance per trade
            )
            
            # Calculate position size in quote (USDT)
            risk_per_contract = abs(entry_price - stop_loss)
            if risk_per_contract <= 0:
                return 0.0
                
            position_value = (risk_amount / risk_per_contract) * entry_price
            
            # Apply position size limit
            max_position = usdt_balance * self.position_size_pct
            position_value = min(position_value, max_position)
            
            # Get symbol info for quantity precision
            symbol_info = self.symbol_info.get(symbol, {})
            if not symbol_info:
                self.logger.warning(f"No symbol info for {symbol}")
                return 0.0
                
            # Calculate quantity with proper precision
            quantity = position_value / entry_price
            step_size = symbol_info.get('step_size', 0.001)
            precision = int(round(-math.log10(step_size), 0)) if step_size < 1 else 0
            quantity = math.floor(quantity * (10 ** precision)) / (10 ** precision)
            
            # Ensure minimum quantity
            min_qty = symbol_info.get('min_qty', 0.001)
            if quantity < min_qty:
                self.logger.warning(f"Calculated quantity {quantity} is below minimum {min_qty} for {symbol}")
                return 0.0
                
            return quantity
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {str(e)}")
            return 0.0
    
    def _check_daily_loss_limit(self) -> bool:
        """Check if daily loss limit has been reached"""
        try:
            # Reset daily P&L at midnight UTC
            now = datetime.utcnow()
            if now.hour == 0 and now.minute < 5:  # Reset at midnight
                if self.daily_start_balance == 0:  # Only reset once
                    account = self.client.futures_account_balance()
                    usdt_balance = next((float(asset['balance']) for asset in account if asset['asset'] == 'USDT'), 0.0)
                    self.daily_start_balance = usdt_balance
                    self.daily_pnl = 0.0
                    self.last_balance_check = now
                    self.logger.info("Reset daily P&L tracking")
                return False
            
            # Check balance every hour
            if (now - self.last_balance_check).total_seconds() >= 3600:
                account = self.client.futures_account_balance()
                usdt_balance = next((float(asset['balance']) for asset in account if asset['asset'] == 'USDT'), 0.0)
                
                if self.daily_start_balance == 0:  # First check of the day
                    self.daily_start_balance = usdt_balance
                else:
                    self.daily_pnl = (usdt_balance - self.daily_start_balance) / self.daily_start_balance
                    
                self.last_balance_check = now
                
                # Check if daily loss limit reached
                if self.daily_pnl <= -self.max_daily_loss:
                    self.logger.warning(f"Daily loss limit reached: {self.daily_pnl*100:.2f}%")
                    return True
                    
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking daily loss limit: {str(e)}")
            return False
    
    def _check_symbol_volume(self, symbol: str) -> bool:
        """Check if symbol has sufficient trading volume"""
        try:
            ticker = self.client.futures_ticker(symbol=symbol)
            quote_volume = float(ticker.get('quoteVolume', 0))
            return quote_volume >= self.min_volume_usd
        except Exception as e:
            self.logger.error(f"Error checking volume for {symbol}: {str(e)}")
            return False
    
    def _open_short_position(self, symbol: str, signal: Dict) -> bool:
        """Open a short position"""
        try:
            # Check if we already have an open position
            if symbol in self.positions:
                self.logger.info(f"Position already open for {symbol}")
                return False
                
            # Check max open positions
            if len(self.positions) >= self.max_trades:
                self.logger.info(f"Max open positions reached ({self.max_trades})")
                return False
                
            # Calculate position size
            entry_price = signal['entry_price']
            stop_loss = signal['stop_loss']
            quantity = self._calculate_position_size(symbol, entry_price, stop_loss)
            
            if quantity <= 0:
                self.logger.warning(f"Invalid position size for {symbol}")
                return False
                
            # Place short order
            if not self.paper_trading:
                try:
                    order = self.client.futures_create_order(
                        symbol=symbol,
                        side='SELL',
                        type='MARKET',
                        quantity=quantity,
                        timestamp=int(time.time() * 1000)
                    )
                    
                    # Record position
                    self.positions[symbol] = {
                        'entry_price': entry_price,
                        'quantity': quantity,
                        'entry_time': int(time.time() * 1000),
                        'stop_loss': stop_loss,
                        'take_profit': signal.get('take_profit', entry_price * 0.97),  # Default 3% TP
                        'highest_price_since_entry': entry_price,  # For trailing stop
                        'status': 'OPEN',
                        'side': 'SHORT',
                        'signal_score': signal.get('score', 0)
                    }
                    
                    self.logger.info(f"Opened SHORT position: {symbol} | "
                                   f"Price: {entry_price:.8f} | "
                                   f"Qty: {quantity:.6f} | "
                                   f"SL: {stop_loss:.8f} | "
                                   f"TP: {self.positions[symbol]['take_profit']:.8f}")
                    
                    return True
                    
                except BinanceAPIException as e:
                    self.logger.error(f"Binance API error: {e.status_code} - {e.message}")
                    return False
                    
            else:  # Paper trading
                self.positions[symbol] = {
                    'entry_price': entry_price,
                    'quantity': quantity,
                    'entry_time': int(time.time() * 1000),
                    'stop_loss': stop_loss,
                    'take_profit': signal.get('take_profit', entry_price * 0.97),
                    'highest_price_since_entry': entry_price,
                    'status': 'OPEN',
                    'side': 'SHORT',
                    'signal_score': signal.get('score', 0)
                }
                
                self.logger.info(f"[PAPER] Opened SHORT position: {symbol} | "
                               f"Price: {entry_price:.8f} | "
                               f"Qty: {quantity:.6f} | "
                               f"SL: {stop_loss:.8f} | "
                               f"TP: {self.positions[symbol]['take_profit']:.8f}")
                
                return True
                
        except Exception as e:
            self.logger.error(f"Error opening short position: {str(e)}")
            return False
    
    def _close_position(self, symbol: str, reason: str = 'MANUAL') -> bool:
        """Close an open position"""
        try:
            if symbol not in self.positions:
                self.logger.warning(f"No open position found for {symbol}")
                return False
                
            position = self.positions[symbol]
            
            if not self.paper_trading:
                try:
                    # Place buy order to close the short
                    order = self.client.futures_create_order(
                        symbol=symbol,
                        side='BUY',
                        type='MARKET',
                        quantity=position['quantity'],
                        timestamp=int(time.time() * 1000)
                    )
                    
                    # Get current price for P&L calculation
                    ticker = self.client.futures_ticker(symbol=symbol)
                    exit_price = float(ticker['lastPrice'])
                    
                    # Calculate P&L
                    pnl_pct = ((position['entry_price'] - exit_price) / position['entry_price']) * 100
                    
                    # Log the close
                    self.logger.info(
                        f"Closed SHORT position: {symbol} | "
                        f"Entry: {position['entry_price']:.8f} | "
                        f"Exit: {exit_price:.8f} | "
                        f"P&L: {pnl_pct:.2f}% | "
                        f"Reason: {reason}"
                    )
                    
                    # Remove from positions
                    del self.positions[symbol]
                    return True
                    
                except BinanceAPIException as e:
                    self.logger.error(f"Binance API error: {e.status_code} - {e.message}")
                    return False
                    
            else:  # Paper trading
                # Get current price
                df = self._get_historical_klines(symbol, '1m', 1)
                if df.empty:
                    self.logger.error(f"Failed to get current price for {symbol}")
                    return False
                    
                exit_price = df['close'].iloc[-1]
                pnl_pct = ((position['entry_price'] - exit_price) / position['entry_price']) * 100
                
                self.logger.info(
                    f"[PAPER] Closed SHORT position: {symbol} | "
                    f"Entry: {position['entry_price']:.8f} | "
                    f"Exit: {exit_price:.8f} | "
                    f"P&L: {pnl_pct:.2f}% | "
                    f"Reason: {reason}"
                )
                
                # Remove from positions
                del self.positions[symbol]
                return True
                
        except Exception as e:
            self.logger.error(f"Error closing position: {str(e)}")
            return False
    
    def _check_exit_signals(self):
        """Check exit signals for all open positions"""
        try:
            for symbol in list(self.positions.keys()):
                position = self.positions[symbol]
                
                # Get latest market data
                df = self._get_historical_klines(symbol, '1h', 200)
                if df.empty:
                    self.logger.warning(f"No data for {symbol}, skipping exit check")
                    continue
                    
                # Calculate indicators
                df = self.strategy.calculate_indicators(df)
                
                # Get current price
                current_price = df['close'].iloc[-1]
                
                # Update highest price for trailing stop
                if 'highest_price_since_entry' in position:
                    position['highest_price_since_entry'] = max(
                        position['highest_price_since_entry'],
                        current_price
                    )
                
                # Check exit conditions
                exit_signal = self.strategy.should_exit_short(position, current_price, df)
                
                if exit_signal['signal'] == 'EXIT':
                    self.logger.info(
                        f"Exit signal for {symbol}: {exit_signal['reason']} | "
                        f"P&L: {exit_signal.get('pnl_pct', 0)*100:.2f}%"
                    )
                    self._close_position(symbol, exit_signal['reason'])
                    
        except Exception as e:
            self.logger.error(f"Error checking exit signals: {str(e)}")
    
    def _check_entry_signals(self):
        """Check for new entry signals"""
        try:
            # Skip if we've reached max positions
            if len(self.positions) >= self.max_trades:
                return
                
            # Check each symbol for entry signals
            for symbol in self.symbols:
                # Skip if we already have a position
                if symbol in self.positions:
                    continue
                    
                # Check volume
                if not self._check_symbol_volume(symbol):
                    continue
                    
                # Get historical data
                df = self._get_historical_klines(symbol, '1h', 200)
                if df.empty:
                    continue
                    
                # Calculate indicators
                df = self.strategy.calculate_indicators(df)
                
                # Check for entry signal
                signal = self.strategy.generate_short_signal(df)
                
                if signal.get('signal') == 'SHORT':
                    self.logger.info(
                        f"SHORT signal for {symbol} | "
                        f"Price: {signal['entry_price']:.8f} | "
                        f"Score: {signal.get('score', 0):.1f}/100 | "
                        f"RSI: {signal.get('rsi', 0):.1f} | "
                        f"ATR: {signal.get('atr', 0):.8f}"
                    )
                    
                    # Open position
                    self._open_short_position(symbol, signal)
                    
                    # Don't open multiple positions in the same iteration
                    if len(self.positions) >= self.max_trades:
                        break
                        
        except Exception as e:
            self.logger.error(f"Error checking entry signals: {str(e)}")
    
    def run(self):
        """Main trading loop"""
        self.logger.info("Starting ShortOnlyBot...")
        
        try:
            while True:
                try:
                    # Check if we should stop trading for the day
                    if self._check_daily_loss_limit():
                        self.logger.warning("Daily loss limit reached. Stopping trading for today.")
                        time.sleep(3600)  # Check again in 1 hour
                        continue
                    
                    # Check for exit signals
                    self._check_exit_signals()
                    
                    # Check for entry signals
                    self._check_entry_signals()
                    
                    # Log status
                    self.logger.info(
                        f"Active positions: {len(self.positions)}/{self.max_trades} | "
                        f"Daily P&L: {self.daily_pnl*100:.2f}%"
                    )
                    
                    # Sleep before next iteration
                    time.sleep(60)  # Check every minute
                    
                except KeyboardInterrupt:
                    self.logger.info("Keyboard interrupt received. Exiting...")
                    break
                    
                except Exception as e:
                    self.logger.error(f"Error in main loop: {str(e)}")
                    time.sleep(60)  # Wait before retrying
                    
        except Exception as e:
            self.logger.error(f"Fatal error: {str(e)}")
            
        finally:
            self.logger.info("Shutting down ShortOnlyBot...")
            # Close all positions on shutdown
            for symbol in list(self.positions.keys()):
                self._close_position(symbol, 'SHUTDOWN')
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals"""
        self.logger.info(f"Received signal {signum}. Shutting down gracefully...")
        sys.exit(0)


def main():
    """Main entry point"""
    # Load environment variables
    load_dotenv()
    
    # Initialize and run the bot
    try:
        bot = ShortOnlyBot(paper_trading=True)  # Set to False for live trading
        bot.run()
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
