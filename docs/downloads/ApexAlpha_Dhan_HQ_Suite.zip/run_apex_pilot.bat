@echo off
title ApexAlpha Dhan HQ Algorithmic Suite
echo [ApexAlpha] Launching Dhan HQ Top-3 Production Pilot...
python apexalpha_dhan_engine.py --mode live --config config.json
pause
