#!/usr/bin/env python3
"""
Polymarket 5-Minute Micro-Market Shadow Telemetry Engine
========================================================
Purpose:
- Monitors live Polymarket orderbooks without placing real financial bets.
- Tracks outcomes entering the "1-Cent Extreme" (0.5c - 1.5c) and "Panic Dump" (10c - 22c) bands.
- Records post-trigger trajectory: max bounce price, time to bounce, and resolution outcome.
- Computes empirical Expected Value (EV), bounce probability, and adverse selection drag.
"""

import time
import json
import sqlite3
import logging
import os
import requests
from datetime import datetime, timezone

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("polymarket_shadow_engine.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("PolyShadow")

DB_PATH = "polymarket_shadow_telemetry.db"
CLOB_URL = "https://clob.polymarket.com"
GAMMA_URL = "https://gamma-api.polymarket.com"

# Configuration Thresholds
PRICE_1C_MIN = 0.005
PRICE_1C_MAX = 0.015
PANIC_MIN = 0.10
PANIC_MAX = 0.22
BOUNCE_TARGET_1 = 0.45
BOUNCE_TARGET_2 = 0.65

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shadow_signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp_utc TEXT,
            condition_id TEXT,
            token_id TEXT,
            market_question TEXT,
            signal_type TEXT, -- 'ONE_CENT_LONGSHOT' or 'PANIC_DUMP'
            entry_price REAL,
            entry_ask_size REAL,
            max_price_reached REAL,
            did_bounce_45c INTEGER DEFAULT 0,
            did_bounce_65c INTEGER DEFAULT 0,
            resolved INTEGER DEFAULT 0,
            resolved_won INTEGER DEFAULT 0,
            final_pnl_est REAL DEFAULT 0.0
        )
    """)
    conn.commit()
    conn.close()
    logger.info("Initialized telemetry database: %s", DB_PATH)

def update_db_bounce(token_id: str, max_price: float, hit_45c: bool, hit_65c: bool):
    try:
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("""
            UPDATE shadow_signals
            SET max_price_reached = MAX(max_price_reached, ?),
                did_bounce_45c = CASE WHEN ? THEN 1 ELSE did_bounce_45c END,
                did_bounce_65c = CASE WHEN ? THEN 1 ELSE did_bounce_65c END
            WHERE token_id = ?
        """, (max_price, 1 if hit_45c else 0, 1 if hit_65c else 0, token_id))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error updating DB for {token_id}: {e}")

def fetch_sampling_markets():
    try:
        r = requests.get(f"{CLOB_URL}/sampling-simplified-markets", headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        if r.status_code == 200:
            return r.json().get("data", [])
    except Exception as e:
        logger.warning("Failed to fetch CLOB sampling markets: %s", e)
    return []

def run_shadow_telemetry_loop(poll_interval=15):
    logger.info("======================================================================")
    logger.info("POLYMARKET 5-MINUTE MICRO-MARKET SHADOW TELEMETRY ENGINE LAUNCHED")
    logger.info("MODE: ZERO-RISK REAL-TIME TELEMETRY & EMPIRICAL BOUNCE TRACKING")
    logger.info("======================================================================")
    
    init_db()
    tracked_tokens = {} # token_id -> {entry_price, signal_type, max_seen, condition_id, q}

    while True:
        try:
            markets = fetch_sampling_markets()
            active_markets = [m for m in markets if m.get("active") and not m.get("closed")]
            
            # Scan for candidate price bands
            for m in active_markets:
                tokens = m.get("tokens", [])
                cond_id = m.get("condition_id")
                
                for t in tokens:
                    tok_id = t.get("token_id")
                    price = float(t.get("price", 0.0))
                    
                    # 1. Check if token already tracked
                    if tok_id in tracked_tokens:
                        info = tracked_tokens[tok_id]
                        new_high = False
                        if price > info["max_seen"]:
                            info["max_seen"] = price
                            new_high = True
                        
                        # Check target reaches
                        new_45c = False
                        if price >= BOUNCE_TARGET_1 and not info.get("hit_45c"):
                            info["hit_45c"] = True
                            new_45c = True
                            logger.info(f"🎯 [BOUNCE HIT 45¢] Token: {tok_id[:12]}... Entry: {info['entry_price']:.3f} -> Now: {price:.3f} (+{(price/info['entry_price'] - 1)*100:.1f}%)")
                        
                        new_65c = False
                        if price >= BOUNCE_TARGET_2 and not info.get("hit_65c"):
                            info["hit_65c"] = True
                            new_65c = True
                            logger.info(f"🚀 [SUPER BOUNCE 65¢] Token: {tok_id[:12]}... Entry: {info['entry_price']:.3f} -> Now: {price:.3f} (+{(price/info['entry_price'] - 1)*100:.1f}%)")
                        
                        if new_high or new_45c or new_65c:
                            update_db_bounce(tok_id, info["max_seen"], info["hit_45c"], info["hit_65c"])
                        continue

                    # 2. Check 1-Cent Longshot Trigger
                    if PRICE_1C_MIN <= price <= PRICE_1C_MAX:
                        tracked_tokens[tok_id] = {
                            "condition_id": cond_id,
                            "entry_price": price,
                            "signal_type": "ONE_CENT_LONGSHOT",
                            "max_seen": price,
                            "first_seen": datetime.now(timezone.utc).isoformat(),
                            "hit_45c": False,
                            "hit_65c": False
                        }
                        logger.info(f"🎲 [1¢ TRIGGER] Token: {tok_id[:12]}... Odds: {price*100:.2f}¢ | Cond: {cond_id[:12]}...")
                        
                        conn = sqlite3.connect(DB_PATH)
                        conn.execute("""
                            INSERT INTO shadow_signals (timestamp_utc, condition_id, token_id, signal_type, entry_price, max_price_reached)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (datetime.now(timezone.utc).isoformat(), cond_id, tok_id, "ONE_CENT_LONGSHOT", price, price))
                        conn.commit()
                        conn.close()

                    # 3. Check Panic Dump Trigger (10c - 22c)
                    elif PANIC_MIN <= price <= PANIC_MAX:
                        tracked_tokens[tok_id] = {
                            "condition_id": cond_id,
                            "entry_price": price,
                            "signal_type": "PANIC_DUMP",
                            "max_seen": price,
                            "first_seen": datetime.now(timezone.utc).isoformat(),
                            "hit_45c": False,
                            "hit_65c": False
                        }
                        logger.info(f"⚡ [PANIC DUMP TRIGGER] Token: {tok_id[:12]}... Odds: {price*100:.2f}¢ | Cond: {cond_id[:12]}...")
                        
                        conn = sqlite3.connect(DB_PATH)
                        conn.execute("""
                            INSERT INTO shadow_signals (timestamp_utc, condition_id, token_id, signal_type, entry_price, max_price_reached)
                            VALUES (?, ?, ?, ?, ?, ?)
                        """, (datetime.now(timezone.utc).isoformat(), cond_id, tok_id, "PANIC_DUMP", price, price))
                        conn.commit()
                        conn.close()

            time.sleep(poll_interval)
            
        except Exception as e:
            logger.error(f"Error in shadow telemetry loop: {e}")
            time.sleep(10)

if __name__ == "__main__":
    run_shadow_telemetry_loop()
