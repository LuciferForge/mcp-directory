# TheBull Crypto Quantitative Trading Suite (Binance, Delta, Hyperliquid)
=============================================================================
Institutional-grade automated trading bots for cryptocurrency perpetuals and futures.
Includes 100-Point Confluence Momentum Engine, ZeroLag Trend Engine, Funding Rate Arbitrage,
L2 Orderbook Sniper, and Liquidation Cascade Hunter.
=============================================================================

## Included Production Bots & Strategies:
1. `thebull-binance-bot/`: Full 100-point confluence momentum bot on Binance Futures (117KB core engine).
2. `thebull-delta-bot/`: ZeroLag momentum & funding rate arbitrage on Delta Exchange India (32KB core engine).
3. `zero_lag_momentum_engine.py`: High-frequency multi-timeframe EMA + ATR trailing stop engine (181KB).
4. `crypto_cascade_surge_engine.py`: L2 orderbook depth imbalance & liquidation sniper (32KB).
5. `short_bot.py`: Systematic short-selling engine for overextended pump-and-dump coins (27KB).

## Quick Start:
- For Binance: Navigate to `thebull-binance-bot/`, configure `.env`, run `start_bot.bat`
- For Delta Exchange: Navigate to `thebull-delta-bot/`, configure `.env`, run `start_bot.bat`
- For ZeroLag Trend: Run `python zero_lag_momentum_engine.py`
