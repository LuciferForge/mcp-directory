"""Test suite package for Solana Arbitrage Engine."""
