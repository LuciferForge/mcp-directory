"""
Automated EN 16931 / ZUGFeRD 2.2 Test Suite.
Verifies payload extraction, tax rules, and XML compliance.
"""

import hmac
import hashlib
import time
import xml.etree.ElementTree as ET
from src.parser import parse_stripe_invoice
from src.zugferd_generator import generate_zugferd_xml, NAMESPACES
from src.webhook_handler import verify_stripe_signature, process_stripe_event
from tests.mock_payloads import (
    MOCK_DOMESTIC_FR_INVOICE,
    MOCK_REVERSE_CHARGE_EU_INVOICE,
    MOCK_MULTI_LINE_DE_INVOICE,
)


def test_domestic_french_invoice():
    """Verify domestic B2B invoice with 20% standard VAT."""
    invoice_data = parse_stripe_invoice(MOCK_DOMESTIC_FR_INVOICE)

    assert invoice_data.invoice_number == "INV-2026-FR-0042"
    assert invoice_data.currency == "EUR"
    assert invoice_data.total_net_amount == 1000.00
    assert invoice_data.total_tax_amount == 200.00
    assert invoice_data.total_gross_amount == 1200.00
    assert invoice_data.buyer.vat_id == "FR89987654321"
    assert len(invoice_data.tax_breakdown) == 1
    assert invoice_data.tax_breakdown[0].tax_category_code == "S"
    assert invoice_data.tax_breakdown[0].tax_rate_percent == 20.0

    # Generate XML and parse back
    xml_str = generate_zugferd_xml(invoice_data)
    assert "CrossIndustryInvoice" in xml_str
    assert "INV-2026-FR-0042" in xml_str
    assert "FR89987654321" in xml_str

    root = ET.fromstring(xml_str)
    # Check root namespace
    assert root.tag == f"{{{NAMESPACES['rsm']}}}CrossIndustryInvoice"


def test_reverse_charge_eu_invoice():
    """Verify intra-EU cross-border reverse charge (0% VAT, Art. 196)."""
    invoice_data = parse_stripe_invoice(MOCK_REVERSE_CHARGE_EU_INVOICE)

    assert invoice_data.invoice_number == "INV-2026-EU-0881"
    assert invoice_data.total_net_amount == 2500.00
    assert invoice_data.total_tax_amount == 0.00
    assert invoice_data.total_gross_amount == 2500.00
    assert invoice_data.buyer.vat_id == "NL854123456B01"
    
    # Must flag reverse charge category 'AE'
    assert len(invoice_data.tax_breakdown) == 1
    assert invoice_data.tax_breakdown[0].tax_category_code == "AE"
    assert invoice_data.tax_breakdown[0].tax_rate_percent == 0.0
    assert "Reverse charge" in invoice_data.tax_breakdown[0].exemption_reason

    xml_str = generate_zugferd_xml(invoice_data)
    assert "<ram:CategoryCode>AE</ram:CategoryCode>" in xml_str
    assert "Reverse charge" in xml_str


def test_multi_line_mixed_tax_invoice():
    """Verify multi-line invoice with 19% standard and 7% reduced VAT."""
    invoice_data = parse_stripe_invoice(MOCK_MULTI_LINE_DE_INVOICE)

    assert invoice_data.invoice_number == "INV-2026-DE-1049"
    assert invoice_data.total_net_amount == 3000.00
    assert invoice_data.total_tax_amount == 450.00
    assert invoice_data.total_gross_amount == 3450.00
    assert len(invoice_data.line_items) == 2

    # Two tax breakdown entries: 19% (380 tax) and 7% (70 tax)
    assert len(invoice_data.tax_breakdown) == 2
    rates = {tb.tax_rate_percent: tb.tax_amount for tb in invoice_data.tax_breakdown}
    assert rates[19.0] == 380.00
    assert rates[7.0] == 70.00

    xml_str = generate_zugferd_xml(invoice_data)
    assert "<ram:LineTotalAmount>3000.00</ram:LineTotalAmount>" in xml_str
    assert "<ram:TaxTotalAmount currencyID=\"EUR\">450.00</ram:TaxTotalAmount>" in xml_str
    assert "<ram:GrandTotalAmount>3450.00</ram:GrandTotalAmount>" in xml_str


def test_stripe_signature_verification():
    """Verify webhook cryptographic signature verification (HMAC-SHA256)."""
    secret = "whsec_test_secret_key_12345"
    payload = b'{"id":"evt_123","type":"invoice.paid"}'
    ts = str(int(time.time()))

    signed_payload = f"{ts}.".encode("utf-8") + payload
    sig = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    valid_header = f"t={ts},v1={sig}"

    # 1. Valid signature passes
    assert verify_stripe_signature(payload, valid_header, secret) is True

    # 2. Tampered payload fails
    tampered_payload = b'{"id":"evt_123","type":"invoice.paid","tampered":true}'
    assert verify_stripe_signature(tampered_payload, valid_header, secret) is False

    # 3. Wrong secret fails
    assert verify_stripe_signature(payload, valid_header, "whsec_wrong_key") is False

    # 4. Old expired timestamp fails (>300s)
    old_ts = str(int(time.time()) - 400)
    old_signed = f"{old_ts}.".encode("utf-8") + payload
    old_sig = hmac.new(secret.encode("utf-8"), old_signed, hashlib.sha256).hexdigest()
    assert verify_stripe_signature(payload, f"t={old_ts},v1={old_sig}", secret) is False


def test_process_stripe_event_e2e():
    """Verify end-to-end event dispatching."""
    result = process_stripe_event(MOCK_DOMESTIC_FR_INVOICE, save_to_disk=False)
    assert result.status == "success"
    assert result.xml_generated is True
    assert result.en16931_compliant is True
    assert result.invoice_number == "INV-2026-FR-0042"
    assert result.xml_size_bytes > 0
    assert "CrossIndustryInvoice" in result.xml_content

    # Ignored event type
    ignored_event = {"id": "evt_sub_001", "type": "customer.subscription.updated"}
    ign_res = process_stripe_event(ignored_event, save_to_disk=False)
    assert ign_res.status == "ignored"
    assert ign_res.xml_generated is False
