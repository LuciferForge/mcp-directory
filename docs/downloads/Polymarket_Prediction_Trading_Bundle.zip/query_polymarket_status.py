import os
import json
from dotenv import dotenv_values
from py_clob_client.client import ClobClient

ENV_PATH = "/tmp/poly.env"
env = dotenv_values(ENV_PATH)
key = env.get("POLY_PRIVATE_KEY")
host = "https://clob.polymarket.com"
chain_id = 137

client = ClobClient(host, key=key, chain_id=chain_id)
api_creds = client.create_or_derive_api_creds()
client.set_api_creds(api_creds)

print("=== POLYMARKET CLOB ACCOUNT STATUS ===")
# 1. Address
addr = client.get_address()
print(f"Signer Address: {addr}")

# 2. Balance & Allowance
try:
    from py_clob_client.clob_types import BalanceAllowanceParams, AssetType
    bal = client.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))
    print(f"Collateral Balance (USDC): ${float(bal.get('balance', 0)) / 1e6:.2f}")
except Exception as e:
    print(f"Error fetching balance via CLOB: {e}")

# 3. Open Orders
try:
    orders = client.get_orders()
    print(f"\nOpen Orders Count: {len(orders)}")
    for i, o in enumerate(orders):
        print(f"  {i+1}. ID: {o.get('id')[:12]}... | Side: {o.get('side')} | Price: ${float(o.get('price', 0)):.3f} | Size: {o.get('original_size')} | Status: {o.get('status')}")
except Exception as e:
    print(f"Error fetching orders: {e}")

# 4. Trades
try:
    trades = client.get_trades()
    print(f"\nRecent Executed Trades Count: {len(trades)}")
    for t in trades[:8]:
        print(f"  • Side: {t.get('side')} | Price: ${float(t.get('price', 0)):.3f} | Size: {t.get('size')} | Status: {t.get('status')} | Timestamp: {t.get('timestamp')}")
except Exception as e:
    print(f"Error fetching trades: {e}")
