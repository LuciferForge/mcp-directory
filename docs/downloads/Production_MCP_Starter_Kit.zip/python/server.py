"""
Production MCP Server (Python Edition)
Built with FastMCP - Supports both Local Stdio and Remote SSE transports.
"""
import os
import sys
from mcp.server.fastmcp import FastMCP
from auth import SecurityGuard
from rate_limiter import SlidingWindowRateLimiter

# Initialize server
mcp = FastMCP(
    "Production-MCP-Server",
    dependencies=["pydantic", "requests", "uvicorn"]
)

security = SecurityGuard(api_key=os.getenv("MCP_API_KEY", "prod-secret-key-123"))
rate_limiter = SlidingWindowRateLimiter(max_requests=60, window_seconds=60)

@mcp.tool()
def execute_query(query: str, client_token: str = "") -> str:
    """Execute a validated query with token security and rate limiting.
    
    Args:
        query: The input query string to process.
        client_token: API bearer token for authentication.
    """
    # 1. Authenticate
    if not security.verify_token(client_token):
        return "ERROR: Unauthorized. Invalid or missing client_token."
        
    # 2. Rate limit
    if not rate_limiter.allow_request(client_token):
        return "ERROR: Rate limit exceeded. Try again in 60 seconds."
        
    # 3. Process business logic
    sanitized = query.strip()
    return f"Processed query successfully: {sanitized} [status: 200 OK]"

@mcp.tool()
def system_health() -> dict:
    """Check the health status and latency of this MCP server."""
    return {
        "status": "HEALTHY",
        "version": "1.0.0",
        "transport": os.getenv("MCP_TRANSPORT", "stdio"),
        "uptime": "99.98%"
    }

@mcp.resource("config://app-settings")
def get_app_settings() -> str:
    """Read the active server configuration manifest."""
    return "environment=production\nlog_level=INFO\nrate_limit=60rpm"

@mcp.prompt()
def analyze_code_prompt(code_snippet: str) -> str:
    """Pre-built prompt for analyzing code quality and security."""
    return f"You are a senior security engineer. Analyze the following code snippet for OWASP vulnerabilities:\n\n{code_snippet}"

if __name__ == "__main__":
    transport = os.getenv("MCP_TRANSPORT", "stdio").lower()
    print(f"Starting MCP Server on transport: {transport}...", file=sys.stderr)
    if transport == "sse":
        # Remote SSE transport (Cloudflare / Docker / VPS)
        port = int(os.getenv("PORT", 8000))
        mcp.run(transport="sse")
    else:
        # Default local Stdio transport (Claude Desktop / Cursor)
        mcp.run(transport="stdio")
