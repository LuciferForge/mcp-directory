# Cross-Signal Dataset — Free Sample

500 most recent rows from each table. Same schema as the full dataset.

Tables:
- candles.csv         — BTC/ETH/SOL OHLCV (Binance, 15-min)
- funding_rates.csv   — BTC/ETH/SOL perp funding + mark price
- open_interest.csv   — perp OI (contracts + USD)
- gold.csv            — gold spot price (USD/oz)
- pm_crypto_signals.csv — Polymarket crypto markets: yes_price, volume_24h, category
- cross_metrics.csv   — pre-joined snapshot of the above

Full dataset: $29 at https://manja8.gumroad.com/l/cross-signal-dataset
Live bot using this data: https://protodex.io/live.html

Last refreshed: weekly via /Users/apple/Documents/LuciferForge/products/polymarket-data/export_cross_signals.sh
