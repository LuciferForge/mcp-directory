# 🇪🇺 Enterprise Stripe EU E-Invoicing Microservice
### Factur-X 1.0 & ZUGFeRD 2.2 Compliance Engine (EN 16931 / UN/CEFACT CII 16B)

A turnkey, production-grade microservice that automatically intercepts Stripe invoice events and generates standards-compliant **Factur-X / ZUGFeRD 2.2 XML** invoices required by European B2B electronic invoicing mandates (France Chorus Pro / PDP 2026, Germany E-Rechnung 2025/2026, Poland KSeF, Italy SDI).

---

## 📦 What's Inside:

- **Stripe Webhook Interceptor:** Validates webhook signatures (`invoice.paid`, `invoice.created`, `invoice.finalized`) with replay protection and automatic event dispatching.
- **Tax Classification & Reverse Charge Engine:** Automatically determines buyer/seller VAT IDs, VAT categories (S / AE / Z / E), Intra-EU B2B reverse charge exemptions, and standard European tax groupings.
- **Factur-X / ZUGFeRD 2.2 Generator:** Outputs valid UN/CEFACT CII 16B XML adhering to the official `urn:cen.eu:en16931:2017` profile with correct namespace mappings (`rsm`, `ram`, `udt`, `qdt`).
- **Turnkey Deployment:** Ready-to-deploy `Dockerfile`, `docker-compose.yml`, and `vercel.json` serverless adapter.
- **Testing & Verification Suite:** Built-in integration test suite (`verify.py`) with sample Stripe payload fixtures.

---

## ⚡ Quick Start (Under 3 Minutes)

```bash
# 1. Install dependencies
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Configure Environment
cp .env.example .env
# Fill in your Stripe Webhook Secret and Seller Legal Entity Info

# 3. Launch Server
uvicorn src.main:app --reload --port 8000

# 4. Or Run via Docker
docker-compose up --build
```

---

## 🛡️ Commercial License
Includes full commercial ownership rights for private SaaS platforms, client agencies, and internal enterprise systems.
