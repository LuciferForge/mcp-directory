# Cross-Signal Dataset — BTC/ETH/SOL + Gold + Polymarket Crypto Markets

Live-collected timeseries for cross-asset prediction-market analysis.

## Tables (parquet + csv)
| Table | Rows | Columns |
|-------|------|---------|
| candles | 9.5K+ | ts, symbol (BTCUSDT/ETHUSDT/SOLUSDT), open, high, low, close, volume |
| funding_rates | 1.5K+ | ts, symbol, rate, mark_price (Binance perps) |
| open_interest | 1.2K+ | ts, symbol, oi_contracts, oi_usd |
| gold | 400+ | ts, price_usd, source |
| pm_crypto_signals | 41K+ | ts, market_id, question, category, yes_price, volume_24h |
| cross_metrics | 400+ | ts, btc_price, eth_price, sol_price, gold_price, btc_funding |

## Update frequency
15-min cadence, collected by `cross_signal_daemon.py`. Re-export via `bash export_cross_signals.sh` weekly.

## Use cases
- Backtest crypto-PM correlation (does BTC funding flip predict PM resolution?)
- Build models that price PM crypto outcomes off perps + spot
- Analyze gold/crypto/PM regime co-movement

## License
Personal/research use. No redistribution.
