import os
import asyncio
import aiohttp
from concurrent.futures import ThreadPoolExecutor
import logging
from pathlib import Path

# Configure logging
log_dir = Path('logs')
log_dir.mkdir(exist_ok=True)
log_file = log_dir / 'trading_bot.log'

# Create a logger
logger = logging.getLogger('ZeroLagBot')
logger.setLevel(logging.DEBUG)

# Create file handler which logs even debug messages
fh = logging.FileHandler(log_file)
fh.setLevel(logging.DEBUG)

# Create console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)

# Create formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
ch.setFormatter(formatter)

# Add the handlers to the logger
logger.addHandler(fh)
logger.addHandler(ch)

# Disable noisy debug logs from urllib3
logging.getLogger('urllib3').setLevel(logging.WARNING)
logging.getLogger('ccxt').setLevel(logging.WARNING)
import time
import threading
import json
from typing import Dict, Optional, Tuple, Any, List
from dataclasses import asdict
import pandas as pd
import pandas_ta as ta

# Strategy imports
from strategy.regime import (
    StrategyRegime, 
    RegimeContext, 
    determine_regime
)
from strategy.regime_aware_signal import (
    RegimeAwareSignalGenerator,
    SignalDirection
)
import traceback
import socket
import urllib3
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.ssl_ import create_urllib3_context
import types

# Configure DNS over HTTPS (DoH) for reliable DNS resolution
import dns.resolver
dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ['8.8.8.8', '8.8.4.4']  # Google DNS
from datetime import datetime, time as dt_time, timedelta
import time
import logging
import json
import os
import schedule
import threading
import numpy as np
import pandas as pd
import traceback
from binance.client import Client
from binance.exceptions import BinanceAPIException
from dotenv import load_dotenv
from datetime import datetime, timedelta
import numpy as np
import ta
import pandas_ta as pta
import warnings
import math
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP
from coin_selector import CoinSelector
from signals import (
    SignalParameters,
    SignalResult,
    evaluate_long_signal,
    evaluate_short_signal,
    MultiTimeframeEvaluator,
)
from strategy.regime import determine_regime, StrategyRegime
from metrics.logger import ExecutionLogger, build_execution_record
import uuid

try:
    import pyarrow as pa
    import pyarrow.parquet as pq
except ImportError:
    pa = None
    pq = None

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pathlib import Path
from scipy.stats import zscore
from typing import Dict, List, Tuple, Optional, Any
import json
import traceback

# Import Telegram Bot Controller for remote control
from telegram_controller import TelegramBotController

# Constants
MAX_RETRIES = 3
MAX_WORKERS = 5
DEFAULT_TIMEFRAME = '15m'
RISK_FREE_RATE = 0.05  # 5% annual risk-free rate

import warnings

# Configure logging with more detailed format
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_bot_debug.log'),
        logging.StreamHandler()
    ]
)

# Enable debug logging for urllib3 and requests
logging.getLogger('urllib3').setLevel(logging.INFO)
logging.getLogger('requests').setLevel(logging.INFO)
logging.getLogger('binance').setLevel(logging.INFO)

# Create a custom logger for API calls
api_logger = logging.getLogger('binance_api')
api_logger.setLevel(logging.INFO)

# Disable propagation to avoid duplicate logs
for handler in logging.root.handlers:
    handler.addFilter(lambda record: 'binance.websockets' not in record.name)

logger = logging.getLogger(__name__)
logger = logging.getLogger(__name__)


def sync_client_time(client: Client) -> int:
    server_time = client.get_server_time()
    local_time = int(time.time() * 1000)
    offset = server_time['serverTime'] - local_time
    client.timestamp_offset = offset
    return offset

# Load environment variables
def load_api_keys():
    load_dotenv(dotenv_path=Path(__file__).parent / '.env')
    api_key = os.getenv('API_KEY', '').strip()
    api_secret = os.getenv('API_SECRET', '').strip()
    logging.info(f'API_KEY length: {len(api_key)}, API_SECRET length: {len(api_secret)}')
    logging.info(f'API_KEY starts with: {api_key[:5]}...')
    logging.info(f'API_SECRET starts with: {api_secret[:5]}...')
    if not api_key or not api_secret:
        raise ValueError("Missing Binance API keys in .env file")
    return api_key, api_secret

class MarketAnalyzer:
    def __init__(self):
        self.timeframe = DEFAULT_TIMEFRAME
        self.volume_profile = {}
        self.vwap_data = {}
        self.atr_period = 14
        self.volatility_threshold = 0.02  # 2% ATR threshold
        
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators for the given OHLCV data"""
        if df.empty or len(df) < 20:  # Ensure enough data points
            return df
            
        # Calculate ATR for volatility
        df['atr'] = pta.atr(df['high'], df['low'], df['close'], length=self.atr_period)
        
        # Calculate VWAP
        df['vwap'] = pta.vwap(df['high'], df['low'], df['close'], df['volume'])
        
        # Calculate volume profile
        df['volume_profile'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).rolling(20).mean()
        
        # Market regime detection
        df['trend'] = self._detect_market_regime(df)
        
        return df
    
    def _detect_market_regime(self, df: pd.DataFrame, window: int = 20) -> pd.Series:
        """Detect market regime (trending/ranging)"""
        if len(df) < window + 1:
            return pd.Series(index=df.index, data='neutral')
            
        # Use ADX for trend strength
        adx = pta.adx(df['high'], df['low'], df['close'], length=window)
        df['adx'] = adx[f'ADX_{window}']
        
        # Simple moving averages for trend direction
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        
        # Determine trend
        conditions = [
            (df['adx'] > 22) & (df['sma_20'] > df['sma_50']),  # Uptrend
            (df['adx'] > 22) & (df['sma_20'] < df['sma_50']),  # Downtrend
            (df['adx'] <= 22)  # Ranging
        ]
        choices = ['uptrend', 'downtrend', 'ranging']
        
        return pd.Series(np.select(conditions, choices, default='neutral'), index=df.index)

class RiskManager:
    def __init__(self, max_drawdown: float = 0.10, max_risk_per_trade: float = 0.01):
        self.max_drawdown = max_drawdown
        self.max_risk_per_trade = max_risk_per_trade
        self.peak_balance = 0
        self.current_drawdown = 0
        self.trade_history = []
        
    def update_balance(self, current_balance: float):
        """Update peak balance and calculate current drawdown"""
        # First update peak balance and calculate current drawdown
        self.peak_balance = max(self.peak_balance, current_balance)
        self.current_drawdown = (self.peak_balance - current_balance) / self.peak_balance
        
        # Log current drawdown status
        logger.debug(f"Current balance: {current_balance:.2f}, Peak balance: {self.peak_balance:.2f}, Drawdown: {self.current_drawdown:.2%}")
        
        # Reset peak balance if we've recovered from drawdown
        if self.current_drawdown <= self.max_drawdown:
            self.peak_balance = current_balance
            self.current_drawdown = 0
            logger.info(f"Drawdown cleared - resetting peak balance to {current_balance:.2f}")
        
    def get_position_size(self, atr: float, entry_price: float, stop_loss: float, balance: float) -> float:
        """Calculate position size based on risk parameters"""
        if atr <= 0 or entry_price <= 0 or stop_loss <= 0 or balance <= 0:
            return 0
            
        # Risk amount in quote currency (e.g., USDT)
        risk_amount = balance * self.max_risk_per_trade
        
        # Stop distance in price terms
        stop_distance = abs(entry_price - stop_loss)
        
        if stop_distance == 0:
            return 0
            
        # Position size in base currency (e.g., BTC)
        position_size = risk_amount / stop_distance
        
        # Adjust for leverage if needed
        return position_size
        
    def is_trade_allowed(self) -> bool:
        """Check if new trades are allowed based on drawdown"""
        return self.current_drawdown <= self.max_drawdown

class ZeroLagBot:
    def _get_session_with_retry(self):
        """Create a session with retry logic for API requests with detailed logging."""
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        import requests
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=5,  # Maximum number of retries
            backoff_factor=1,  # Wait 1, 2, 4, 8, 16 seconds between retries
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"]
        )
        
        # Create session with retry
        session = requests.Session()
        
        # Initialize session with default headers
        session.headers.update({
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Add API key to session headers if available
        if hasattr(self, 'api_key') and self.api_key:
            session.headers.update({
                'X-MBX-APIKEY': self.api_key.strip()
            })
        
        # Add minimal request/response logging (only warnings and errors)
        def log_request_response(response, *args, **kwargs):
            if response.status_code >= 400:
                request = response.request
                api_logger.warning(
                    "HTTP %s %s failed with status %s %s", 
                    request.method,
                    request.url,
                    response.status_code,
                    response.reason
                )
            return response
        session.hooks['response'] = [log_request_response]
        
        # Configure adapter with retry strategy
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session
        
    def _initialize_binance_client(self):
        client = Client(
            api_key=self.api_key,
            api_secret=self.api_secret,
            testnet=self.paper_trading,
            tld='com',
            requests_params={
                'timeout': 10,
                'proxies': {
                    'http': None,
                    'https': None
                }
            }
        )

        client.time_reference = 'local'
        client.timestamp_offset = 0

        return client

    def __init__(self, paper_trading=False, sync_time=True, account_label=None, metrics_dir=None, symbols=None):
        """Initialize the bot with API keys and trading parameters"""
        self.paper_trading = paper_trading
        self.sync_time = sync_time
        self.time_offset = 0  # Initialize time offset for server sync offset first
        self.time_offset = 0

        # Initialize last_scan_time to None
        self.last_scan_time = None
        
        # Load environment variables
        load_dotenv()

        # Get API keys
        if self.paper_trading:
            self.api_key = os.getenv('TESTNET_API_KEY', '').strip()
            self.api_secret = os.getenv('TESTNET_API_SECRET', '').strip()
        else:
            self.api_key = os.getenv('API_KEY', '').strip()
            self.api_secret = os.getenv('API_SECRET', '').strip()

        # Verify API keys are loaded
        if not self.api_key or not self.api_secret:
            key_type = 'TESTNET' if self.paper_trading else 'MAINNET'
            error_msg = f"{key_type} API_KEY and API_SECRET must be set in .env file"
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Log API key information
        logger.debug(f"API_KEY length: {len(self.api_key)}")
        logger.debug(f"API_KEY starts with: {self.api_key[:5]}...")
        logger.debug(f"API_SECRET length: {len(self.api_secret)}")
        logger.debug(f"API_SECRET starts with: {self.api_secret[:5]}...")
        
        # Verify key lengths
        if len(self.api_key) != 64 or len(self.api_secret) != 64:
            error_msg = "Invalid API key or secret length. Both should be 64 characters long."
            logger.error(error_msg)
            raise ValueError(error_msg)

        print("API Key format appears valid\n")

        env_label = "TESTNET" if self.paper_trading else "MAINNET"

        print(f"=== USING BINANCE {env_label} ===")
        if self.paper_trading:
            print("WARNING: PAPER TRADING MODE (TESTNET)\n")
        else:
            print("WARNING: REAL FUNDS WILL BE USED\n")

        # Clean API keys by stripping any whitespace
        self.api_key = self.api_key.strip()
        self.api_secret = self.api_secret.strip()

        
        # Print debug information about API keys
        print(f"\n=== API KEY DEBUG ===")
        print(f"API Key length: {len(self.api_key)}")
        print(f"API Key (first 10 chars): {self.api_key[:10]}...")
        print(f"API Secret length: {len(self.api_secret)}")
        print(f"API Secret (first 10 chars): {self.api_secret[:10]}...\n")
        
        try:
                # Initialize the Binance client with the API keys and detailed logging
            print("\n=== INITIALIZING BINANCE CLIENT ===")
            print(f"API Key: {self.api_key[:5]}...{self.api_key[-5:] if self.api_key else ''}")
            print(f"API Secret: {self.api_secret[:3]}...{self.api_secret[-3:] if self.api_secret else ''}")

            self.client = self._initialize_binance_client()

            # Set up our custom session with retry logic
            print("\n=== SETTING UP SESSION ===")
            self.session = self._get_session_with_retry()

            # Configure client with our session and timeout settings
            self.client.session = self.session
            self.client.timeout = 30  # 30 second timeout
            print("✅ Session configuration complete")

            # Wrap client request method to auto-handle timestamp drift BEFORE first API call
            self._wrap_client_with_time_sync()

            # Time synchronization
            if not self.sync_binance_time():
                logger.error("Failed to synchronize time with Binance server")
                raise RuntimeError("Failed to synchronize time with Binance server")

            # Test the API key by making a simple request (AFTER time sync)
            print("\n=== TESTING API CONNECTION ===")
            if not self._test_api_connection():
                raise RuntimeError("API connection test failed")

        except Exception as e:
            print(f"\n=== API KEY TEST FAILED ===")
            print(f"Error: {str(e)}")
            print(f"API Key: {self.api_key[:5]}...{self.api_key[-5:] if self.api_key else ''}")
            print("Please verify your API key and secret in the .env file")
            print("Make sure the keys are correct and have the necessary permissions")
            print("Also ensure your system clock is synchronized with NTP")
            raise
        self.time_offset = getattr(self, 'time_offset', 0)
        
        # Initialize trading parameters - Enhanced Long Only Strategy
        self.max_margin = 0.5  # 50% max margin utilization
        self.trade_size = 0.50  # 50% of available margin per trade
        self.base_trade_size = 0.50  # Base trade size (50% of available margin)
        self.take_profit = 0.10  # 10% take profit target
        self.stop_loss = 0.02  # 2% stop loss
        
        # Initialize state management
        self.save_state = self._save_state  # Assign the save_state method
        self.min_hold_time = 4 * 60 * 60  # 4 hours in seconds (minimum hold time)
        self.max_hold_time = 24 * 60 * 60  # 24 hours in seconds (maximum hold time)
        self.max_trades = 10  # Maximum number of concurrent trades
        self.position_sizes = {}  # Track position sizes by symbol
        self.entry_times = {}  # Track entry times for minimum hold time
        self.volatility_multiplier = 1.0  # Dynamic position sizing based on volatility
        self.min_volume_usd = 5000000  # $5M minimum 24h volume

        self.positions = {}  # Track all open positions
        self.symbol_info = {}  # Store symbol information
        self.coin_update_interval = timedelta(hours=6)
        self.last_coin_update = None
        # Initialize coin selector with our minimum volume threshold
        self.coin_selector = CoinSelector(self.client, min_24h_volume=self.min_volume_usd)
        
        # Initialize coin_metrics dictionary to store coin metrics
        self.coin_metrics = {}

        # Initialize market analyzer for technical indicators
        self.market_analyzer = MarketAnalyzer()

        # Initialize signal generation system
        self.enable_regime_switching = False  # DISABLE regime switching - only trade in bullish markets
        self.enable_multi_timeframe = True   # Enable multi-timeframe confirmation
        self.enable_trailing_stop = True     # Enable trailing stops
        self.trailing_stop_distance = 0.02   # 2% trailing stop distance
        self.enable_risk_parity = False      # Disable risk parity allocation by default

        # Initialize signal generator and parameters
        self.signal_generator = RegimeAwareSignalGenerator()
        self.signal_params = SignalParameters()

        # Initialize execution logger
        self.execution_logger = ExecutionLogger(Path('metrics/executions'))
        self.account_label = "MAIN" if not paper_trading else "PAPER"

        # Initialize diagnostics system
        self.diagnostics_enabled = True
        self.signal_diagnostics = []
        self.diagnostics_dir = Path('diagnostics')
        self.diagnostics_last_flush = time.time()
        self.diagnostics_flush_size = 100
        self.diagnostics_flush_interval = 300  # 5 minutes

        # Initialize Telegram Bot Controller for remote control
        self.telegram_controller = TelegramBotController(bot_instance=self)

        # Performance optimization features
        self.market_data_cache = {}  # Cache for market data
        self.cache_ttl = 300  # 5 minutes cache TTL
        self.last_cache_cleanup = time.time()

        # Batch processing settings
        self.batch_size = 20  # Process symbols in batches
        self.max_concurrent_api_calls = 5

        # Coin selection caching to prevent constant rescanning
        self.cached_symbols = []  # Cached list of symbols for trading
        self.last_symbol_refresh = 0  # Initialize to 0 for first run
        self.symbol_cache_duration = 21600  # Cache symbols for 6 hours (exactly matching original 6-hour behavior)

        # Smart filtering to reduce unnecessary checks
        self.symbol_performance_scores = {}  # Track symbol performance
        self.min_signal_strength = 0.6  # Minimum signal strength to consider

        # Rate limiting and throttling
        self.api_call_timestamps = []
        self.min_api_interval = 0.1  # Minimum 100ms between API calls

        # Consecutive losses tracking for Telegram alerts
        self.consecutive_losses = 0
        self.last_loss_alert_time = None
        self.max_consecutive_losses_alert = 3  # Alert after 3 consecutive losses

        # Volume reversal cooldown tracking - prevent re-entry after volume exits
        self.volume_reversal_cooldown = {}  # symbol -> cooldown_end_time
        self.volume_reversal_cooldown_hours = 2  # Cooldown period in hours

        # Async processing initialization
        self._executor = ThreadPoolExecutor(max_workers=10, thread_name_prefix='async_bot')
        self._async_initialized = False

        # Dynamic Risk Management
        self.volatility_regime = {}  # symbol -> current_volatility_regime
        self.risk_scaling_factors = {}  # symbol -> risk_multiplier

        # Portfolio-level correlation tracking
        self.correlation_matrix = {}  # symbol1_symbol2 -> correlation_coefficient
        self.correlation_cooldown = {}  # Track when correlation limits were breached
        self.max_exposure_cluster = 0.4  # Max 40% exposure to highly correlated symbols
        self.correlation_window = 50  # Lookback period for correlation calculation

        self._initialize_symbol_universe(symbols)

        # Initialize async processing
        self._init_async_processing()

        # Load symbol information
        self._load_symbol_info()

        # Start health check server
        self.start_health_check_server()

    def _init_async_processing(self):
        """Initialize async processing infrastructure"""
        try:
            if self._async_initialized:
                return
            self._async_initialized = True
            logger.info("Async processing initialized for concurrent API calls")
        except Exception as e:
            logger.error(f"Error initializing async processing: {e}")
            # Fallback to synchronous processing
            self._async_initialized = False

    def calculate_dynamic_risk(self, symbol: str, regime_volatility: float) -> float:
        """Calculate dynamic risk adjustment based on market volatility"""
        try:
            base_risk = 0.04  # 4% base risk - increased from 1% to account for trading fees
            volatility_adjustment = regime_volatility

            # Store current volatility regime for this symbol
            self.volatility_regime[symbol] = volatility_adjustment

            if volatility_adjustment > 0.5:  # High volatility
                risk_multiplier = 0.6  # Reduce to 2.4% effective risk (was 0.5%)
            elif volatility_adjustment < 0.1:  # Low volatility
                risk_multiplier = 1.8  # Can afford 7.2% effective risk (was 1.5%)
            else:
                risk_multiplier = 1.2  # Can use 4.8% effective risk (was 1.0%)

            adjusted_risk = base_risk * risk_multiplier
            self.risk_scaling_factors[symbol] = risk_multiplier

            logger.debug(f"Dynamic risk for {symbol}: {adjusted_risk:.4f} (volatility: {volatility_adjustment:.3f}, multiplier: {risk_multiplier:.2f})")
            return adjusted_risk

        except Exception as e:
            logger.error(f"Error calculating dynamic risk for {symbol}: {e}")
            return 0.04  # Return base risk on error (increased from 0.01)

    def calculate_portfolio_correlation(self, symbol: str) -> float:
        """Calculate correlation coefficient between symbol and current portfolio positions"""
        try:
            if len(self.positions) < 2:
                return 0.0  # No correlation if less than 2 positions

            # Get correlation data for this symbol against portfolio
            correlation_window = self.correlation_window
            price_changes = {}

            # Get recent price data for symbol
            try:
                df_symbol = self.get_klines_data(symbol, '1h', limit=correlation_window)
                if df_symbol is None or df_symbol.empty:
                    return 0.0
                price_changes[symbol] = df_symbol['close'].pct_change().dropna()
            except Exception as e:
                logger.debug(f"Error getting price data for correlation calculation: {symbol}")
                return 0.0

            # Get price data for positions in portfolio
            portfolio_symbols = [s for s in self.positions.keys() if s != symbol]
            portfolio_changes = []

            for pos_symbol in portfolio_symbols[:5]:  # Limit to top 5 positions for performance
                try:
                    df_pos = self.get_klines_data(pos_symbol, '1h', limit=correlation_window)
                    if df_pos is not None and not df_pos.empty:
                        changes = df_pos['close'].pct_change().dropna()
                        portfolio_changes.append(changes)
                except Exception as e:
                    logger.debug(f"Error getting price data for portfolio symbol: {pos_symbol}")
                    continue

            if not portfolio_changes:
                return 0.0

            # Calculate average correlation with portfolio
            correlations = []
            for changes in portfolio_changes:
                try:
                    # Align data by timestamp and calculate correlation
                    combined = pd.concat([price_changes[symbol], changes], axis=1, keys=['symbol', 'portfolio']).dropna()
                    if len(combined) > 10:  # Need minimum data points
                        corr = combined.corr().iloc[0, 1]
                        correlations.append(corr)
                except Exception as e:
                    continue

            if correlations:
                avg_correlation = np.mean(correlations)
                self.correlation_matrix[symbol] = avg_correlation
                logger.debug(f"Portfolio correlation for {symbol}: {avg_correlation:.3f}")
                return abs(avg_correlation)  # Return absolute value
            else:
                return 0.0

        except Exception as e:
            logger.error(f"Error calculating portfolio correlation for {symbol}: {e}")
            return 0.0

    def check_correlation_limits(self, symbol: str) -> bool:
        """Check if adding this symbol would violate correlation limits"""
        try:
            if self.max_exposure_cluster <= 0:
                return True  # No correlation limits

            correlation = self.calculate_portfolio_correlation(symbol)
            current_exposure = len([s for s in self.positions.keys()
                                   if self.correlation_matrix.get(s, 0.0) > 0.7])  # Highly correlated positions

            # Check if this would exceed correlation limits
            if correlation > 0.7:  # Highly correlated
                if current_exposure >= 3:  # Max 3 highly correlated positions
                    # Check cooldown period
                    last_breach = self.correlation_cooldown.get('high_correlation_breach', 0)
                    if time.time() - last_breach < 3600:  # 1-hour cooldown
                        logger.warning(f"Correlation limit exceeded for {symbol} (correlation: {correlation:.3f}). Blocking trade.")
                        return False

                    # Set cooldown and allow trade
                    self.correlation_cooldown['high_correlation_breach'] = time.time()
                    logger.warning(f"Allowing high correlation trade for {symbol} with cooldown applied")

            return True

        except Exception as e:
            logger.error(f"Error checking correlation limits for {symbol}: {e}")
            return True  # Allow trade on error

    def stream_signal_diagnostics(self, symbol: str, result: SignalResult, force_flush: bool = False):
        """Stream signal diagnostics data for real-time monitoring

        Args:
            symbol: Trading symbol
            result: SignalResult object containing diagnostic data
            force_flush: Force immediate flush to disk
        """
        try:
            if not hasattr(self, 'diagnostics_enabled') or not self.diagnostics_enabled:
                return

            # Prepare streaming diagnostic data
            stream_data = {
                'timestamp': int(time.time() * 1000),
                'symbol': symbol,
                'signal_outcome': result.reason if result else 'unknown',
                'regime': result.metadata.get('regime', 'unknown') if result else 'unknown',
                'confidence': result.metadata.get('score', 0.0) if result else 0.0,
                'volume_indicator': result.checks.get('volume', False) if result and result.checks else False,
                'trend_indicator': result.checks.get('trend', False) if result and result.checks else False,
                'momentum_indicator': result.checks.get('momentum', False) if result and result.checks else False,
                'volatility_atr': result.metadata.get('atr_percent', 0.0) if result else 0.0,
                'volume_ratio': result.metadata.get('volume_ratio', 1.0) if result else 1.0,
                'price_at_signal': result.signal_payload.get('price', 0.0) if result and result.signal_payload else 0.0,
                'position_count': len(self.positions),
                'avg_portfolio_pnl': self._calculate_avg_portfolio_pnl(),
                'correlation_warning': bool(self.correlation_cooldown.get('high_correlation_breach', 0) > 0),
                'volatility_regime': self.volatility_regime.get(symbol, 0.0),
                'risk_multiplier': self.risk_scaling_factors.get(symbol, 1.0)
            }

            # Queue for streaming (could be sent to monitoring service)
            # For now, we'll use the existing diagnostics system but with higher frequency
            self.signal_diagnostics.append(stream_data)

            # Force flush if requested or if buffer is getting large
            if force_flush or len(self.signal_diagnostics) >= 50:
                self._flush_signal_diagnostics(force=True)
                logger.debug(f"Streaming diagnostics flushed for {symbol}: {len(self.signal_diagnostics)} records")

        except Exception as e:
            logger.error(f"Error streaming diagnostics for {symbol}: {e}")

    def _calculate_avg_portfolio_pnl(self) -> float:
        """Calculate average portfolio PnL percentage"""
        try:
            if not self.positions:
                return 0.0

            total_pnl_pct = 0.0
            valid_positions = 0

            for symbol, position in self.positions.items():
                try:
                    entry_price = position.get('entry_price', 0)
                    current_price = position.get('current_price', 0)
                    side = position.get('side', 'LONG')

                    if entry_price > 0 and current_price > 0:
                        if side == 'LONG':
                            pnl_pct = ((current_price - entry_price) / entry_price) * 100
                        else:
                            pnl_pct = ((entry_price - current_price) / entry_price) * 100

                        total_pnl_pct += pnl_pct
                        valid_positions += 1
                except Exception as e:
                    continue

            return total_pnl_pct / valid_positions if valid_positions > 0 else 0.0

        except Exception as e:
            logger.debug(f"Error calculating average portfolio PnL: {e}")
            return 0.0

    def _cleanup_cache(self):
        """Clean up expired cache entries"""
        current_time = time.time()
        if current_time - self.last_cache_cleanup > 300:  # Clean every 5 minutes
            expired_keys = [
                key for key, (_, timestamp) in self.market_data_cache.items()
                if current_time - timestamp > self.cache_ttl
            ]
            for key in expired_keys:
                del self.market_data_cache[key]
            self.last_cache_cleanup = current_time
            if expired_keys:
                logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")

    def _rate_limit_api_call(self):
        """Enforce rate limiting for API calls"""
        current_time = time.time()
        # Remove old timestamps (older than 1 second)
        self.api_call_timestamps = [
            ts for ts in self.api_call_timestamps
            if current_time - ts < 1.0
        ]

        # Check if we're under the rate limit
        if len(self.api_call_timestamps) >= 10:  # Max 10 calls per second
            sleep_time = 1.0 - (current_time - self.api_call_timestamps[0])
            if sleep_time > 0:
                time.sleep(sleep_time)

        self.api_call_timestamps.append(current_time)

    def get_cached_market_data(self, symbol: str, interval: str, limit: int) -> Optional[pd.DataFrame]:
        """Get market data from cache if available and not expired"""
        cache_key = f"{symbol}_{interval}_{limit}"
        current_time = time.time()

        if cache_key in self.market_data_cache:
            data, timestamp = self.market_data_cache[cache_key]
            if current_time - timestamp < self.cache_ttl:
                logger.debug(f"Cache hit for {cache_key}")
                return data
            else:
                # Expired, remove from cache
                del self.market_data_cache[cache_key]

        return None

    def cache_market_data(self, symbol: str, interval: str, limit: int, data: pd.DataFrame):
        """Cache market data with timestamp"""
        cache_key = f"{symbol}_{interval}_{limit}"
        self.market_data_cache[cache_key] = (data.copy(), time.time())
        logger.debug(f"Cached market data for {cache_key}")

    def _test_api_connection(self):
        """Test API connection with a simple call before full initialization"""
        print("Testing basic API connectivity...")

        try:
            # First try a simple unsigned call (server time)
            server_time = self.client.get_server_time()
            if 'serverTime' in server_time:
                print(f"✅ Server time retrieved: {server_time['serverTime']}")
            else:
                print("❌ Invalid server time response")
                return False

            # Then try a signed call (account info) but with better error handling
            print("Testing futures account access...")
            account_info = self.client.futures_account()
            print("✅ Successfully connected to Binance Futures API!")
            print(f"Account Status: {account_info.get('canTrade') and 'READY' or 'NOT READY'}")
            print(f"Account Balance: {account_info.get('totalWalletBalance', 'N/A')} USDT")
            return True

        except BinanceAPIException as e:
            if e.code == -1022:
                print(f"❌ API signature validation failed: {str(e)}")
                print("This indicates your API key or secret is invalid or lacks permissions")
            else:
                print(f"❌ API connection failed: {str(e)}")
            return False
        except Exception as e:
            print(f"❌ Unexpected API error: {str(e)}")
            return False

    def _wrap_client_with_time_sync(self):
        original_request = self.client._request

        def request_with_time_sync(client_self, method, uri, signed=False, force_params=False, *extra_args, **kwargs):
            max_attempts = 3
            last_exception = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return original_request(method, uri, signed, force_params, *extra_args, **kwargs)
                except BinanceAPIException as e:
                    last_exception = e
                    if e.code == -1021:  # Timestamp drift
                        logger.warning("Detected Binance timestamp drift (-1021). Resynchronizing time...")
                        try:
                            offset = sync_client_time(client_self)
                            self.time_offset = offset
                            logger.debug(f"Resynced Binance time offset: {offset} ms")
                        except Exception as sync_error:
                            logger.warning(f"Time resynchronization attempt failed: {sync_error}")
                        time.sleep(min(1.0, 0.2 * attempt))
                        continue
    def _wrap_client_with_time_sync(self):
        original_request = self.client._request

        def request_with_time_sync(client_self, method, uri, signed=False, force_params=False, *extra_args, **kwargs):
            max_attempts = 3
            last_exception = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return original_request(method, uri, signed, force_params, *extra_args, **kwargs)
                except BinanceAPIException as e:
                    last_exception = e
                    if e.code == -1021:  # Timestamp drift
                        logger.warning("Detected Binance timestamp drift (-1021). Resynchronizing time...")
                        try:
                            offset = sync_client_time(client_self)
                            self.time_offset = offset
                            logger.debug(f"Resynced Binance time offset: {offset} ms")
                        except Exception as sync_error:
                            logger.warning(f"Time resynchronization attempt failed: {sync_error}")
                        time.sleep(min(1.0, 0.2 * attempt))
                        continue
                    elif e.code == -1022:  # Signature validation error - often due to timestamp issues
                        logger.warning(f"API signature validation failed (-1022). This may be due to timestamp drift. Resynchronizing time...")
                        try:
                            offset = sync_client_time(client_self)
                            self.time_offset = offset
                            logger.debug(f"Resynced Binance time offset for signature error: {offset} ms")
                            # Retry the request after time sync
                            time.sleep(min(1.0, 0.2 * attempt))
                            continue
                        except Exception as sync_error:
                            logger.warning(f"Time resynchronization attempt failed: {sync_error}")
                            # If time sync fails, this is likely a real API key issue
                            logger.error("Signature validation failed after time sync attempt. This indicates invalid API credentials.")
                            break
                    if attempt == max_attempts:
                        raise
                    time.sleep(min(1.0, 0.2 * attempt))
            if last_exception is not None:
                raise last_exception

        self.client._request = types.MethodType(request_with_time_sync, self.client)


    def sync_time_with_server(self, max_retries=3, initial_delay=1):
        if not self.sync_time:
            logger.info("Time synchronization is disabled")
            return True

        logger.info("Synchronizing time with Binance server...")

        for attempt in range(1, max_retries + 1):
            try:
                server_time = self.client.get_server_time()
                if 'serverTime' not in server_time:
                    logger.warning(f"Invalid server time response: {server_time}")
                    continue

                local_time = int(time.time() * 1000)
                server_time_ms = server_time['serverTime']
                self.time_offset = server_time_ms - local_time
                self.client.timestamp_offset = self.time_offset

                abs_offset = abs(self.time_offset)
                if abs_offset > 1000:
                    logger.warning(f"Significant time difference detected: {self.time_offset}ms")

                logger.info(f"Time synchronized with Binance server. Offset: {self.time_offset}ms")
                return True

            except Exception as e:
                wait_time = initial_delay * (2 ** (attempt - 1))
                logger.warning(f"Failed to sync time (attempt {attempt}/{max_retries}): {str(e)}")

                if attempt < max_retries:
                    logger.info(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)

        error_msg = f"Failed to synchronize time with Binance server after {max_retries} attempts"
        if not self.paper_trading:
            error_msg += " - Running with potentially unsynchronized time"
            logger.error(error_msg)
            return False

        logger.warning(error_msg)
        return False

    def sync_binance_time(self):
        """Synchronize local time with Binance server.
        
        Returns:
            bool: True if synchronization was successful, False otherwise
        """
        success = self.sync_time_with_server()

        if not success:
            return False

        if abs(self.time_offset) > 5000:
            logger.warning(f"Large time offset detected: {self.time_offset} ms. Check system time.")
            return False

        logger.debug(f"Time synchronized with Binance. Offset: {self.time_offset} ms")
        return True

    def _load_symbol_info(self):
        """Load symbol information including filters and precision"""
        try:
            # ... (rest of the code remains the same)
            logger.debug("Loading symbol information from exchange...")
            exchange_info = self.client.futures_exchange_info()
            
            for symbol_data in exchange_info['symbols']:
                symbol = symbol_data['symbol']
                if symbol not in self.symbols:
                    continue
                    
                # Extract relevant filters
                filters = {f['filterType']: f for f in symbol_data.get('filters', [])}
                
                # Store symbol info
                self.symbol_info[symbol] = {
                    'base_asset': symbol_data['baseAsset'],
                    'quote_asset': symbol_data['quoteAsset'],
                    'filters': filters,
                    'price_precision': symbol_data['pricePrecision'],
                    'quantity_precision': symbol_data['quantityPrecision'],
                    'min_qty': float(next((f['minQty'] for f in symbol_data['filters'] 
                                        if f['filterType'] == 'LOT_SIZE'), '0')),
                    'tick_size': float(next((f['tickSize'] for f in symbol_data['filters'] 
                                          if f['filterType'] == 'PRICE_FILTER'), '0'))
                }
                
            logger.debug(f"Loaded info for {len(self.symbol_info)} symbols")
            
        except Exception as e:
            logger.error(f"Error loading symbol info: {str(e)}")
            logger.error(traceback.format_exc())
            raise

    def _initialize_symbol_universe(self, initial_symbols):
        if initial_symbols is not None:
            self.symbols = initial_symbols
            return
        updated_symbols = self._update_coin_data(force=True)
        if updated_symbols:
            self.symbols = updated_symbols
            return
        try:
            with open('top_20_coins.json', 'r') as f:
                coins = json.load(f)
            loaded_symbols = [coin['symbol'] for coin in coins if isinstance(coin, dict) and 'symbol' in coin]
            if loaded_symbols:
                self.symbols = loaded_symbols[:50]
                return
        except Exception as load_error:
            print(f"Error loading coin list: {load_error}")
        self.symbols = [
            'SUNUSDT', '1000000BOBUSDT', 'BIDUSDT', 'JSTUSDT', 'STGUSDT',
            'ACTUSDT', 'SOPHUSDT', 'SIGNUSDT', 'BANANAS31USDT', 'CVCUSDT',
            'HIFIUSDT', 'HFTUSDT', 'UXLINKUSDT', 'PORT3USDT', 'OMUSDT',
            'BDXNUSDT', 'TUSDT', 'MELANIAUSDT', 'TONUSDT', 'APEUSDT'
        ]

    def _update_coin_data(self, force=False):
        if not hasattr(self, 'coin_selector') or self.coin_selector is None:
            return []
        now = datetime.utcnow()
        if not force and self.last_coin_update and now - self.last_coin_update < self.coin_update_interval:
            return []
        coins = self._update_coin_list()
        symbols = [coin['symbol'] for coin in coins if isinstance(coin, dict) and 'symbol' in coin]
        if not symbols:
            return []
        top_symbols = self._update_coin_metrics(symbols)
        if top_symbols:
            self.last_coin_update = now
            return top_symbols
        return symbols

    def _update_coin_list(self):
        try:
            exchange_info = self.client.futures_exchange_info()
            all_symbols = [symbol['symbol'] for symbol in exchange_info['symbols'] if symbol.get('status') == 'TRADING' and symbol.get('symbol', '').endswith('USDT')]
            trading_coins = []

            # Process all symbols - all coins are treated equally now
            for symbol in all_symbols:
                try:
                    ticker = self.client.futures_ticker(symbol=symbol)
                    coin_data = {
                        'symbol': symbol,
                        'name': symbol.replace('USDT', ''),
                        'market_cap': 0,
                        'volume_24h': float(ticker.get('quoteVolume', 0)),
                        'price': float(ticker.get('lastPrice', 0)),
                        'price_change_24h': float(ticker.get('priceChangePercent', 0))
                    }

                    # Add all coins that meet volume threshold
                    if coin_data['volume_24h'] >= self.min_volume_usd:
                        trading_coins.append(coin_data)

                except Exception as ticker_error:
                    logger.warning(f"Error processing {symbol}: {ticker_error}")

            # Log the results
            logger.info(f"Found {len(trading_coins)} coins meeting ${self.min_volume_usd/1e6:.1f}M volume threshold")

            data = {
                'last_updated': datetime.utcnow().isoformat(),
                'coins': trading_coins
            }
            with open('top_coins.json', 'w') as f:
                json.dump(data, f, indent=2)

            return trading_coins
        except Exception as e:
            logger.error(f"Error updating coin list: {e}")
            logger.error(traceback.format_exc())
            return []

    def _update_coin_metrics(self, symbols):
        if not symbols:
            return []
        try:
            selector = self.coin_selector
            selector.symbols = symbols
            selector.update_all_metrics()
            selector.save_coin_data()
            top_coins = selector.get_top_coins(n=min(500, len(symbols)))
            if top_coins:
                with open('top_20_coins.json', 'w') as f:
                    json.dump(top_coins[:50], f, indent=2)
                return [coin['symbol'] for coin in top_coins[:50]]
            return symbols[:50]
        except Exception as e:
            logger.error(f"Error updating coin metrics: {e}")
            logger.error(traceback.format_exc())
            return []

    def _maybe_refresh_coin_data(self):
        updated_symbols = self._update_coin_data()
        if updated_symbols:
            self.symbols = updated_symbols
            self._load_symbol_info()

    def _sanitize_numeric(self, value: Any) -> Optional[float]:
        try:
            if value is None:
                return None
            if isinstance(value, (np.generic, np.ndarray)):
                value = np.asarray(value).item()
            numeric = float(value)
            if math.isnan(numeric) or math.isinf(numeric):
                return None
            return numeric
        except (ValueError, TypeError):
            return None

    def _record_signal_diagnostics(self, symbol: str, result: SignalResult):
        # Check if diagnostics are enabled and initialized
        if not hasattr(self, 'diagnostics_enabled') or not self.diagnostics_enabled:
            return

        metadata = result.metadata or {}
        checks = result.checks or {}
        latest = result.latest or {}
        signal_payload = result.signal_payload or {}

        timestamp = metadata.get('timestamp') or signal_payload.get('timestamp') or latest.get('timestamp')
        if timestamp is None:
            timestamp = int(time.time() * 1000)

        snapshot = {
            'id': str(uuid.uuid4()),
            'symbol': symbol,
            'event_time_ms': timestamp,
            'timeframe': metadata.get('timeframe', '1h'),
            'outcome': result.reason,
            'failed_conditions': '|'.join(sorted([name for name, passed in checks.items() if not passed])) if checks else '',
            'volume_condition': bool(checks.get('volume', False)),
            'volatility_condition': bool(checks.get('volatility', False)),
            'trend_condition': bool(checks.get('trend', False)),
            'momentum_condition': bool(checks.get('momentum', False)),
            'atr_percent': self._sanitize_numeric(metadata.get('atr_percent')),
            'volume_ratio': self._sanitize_numeric(metadata.get('volume_ratio')),
            'score': self._sanitize_numeric(metadata.get('score')),
        }

        snapshot.update({
            'close': self._sanitize_numeric(latest.get('close')),
            'atr': self._sanitize_numeric(latest.get('atr')),
            'rsi': self._sanitize_numeric(latest.get('rsi')),
            'adx': self._sanitize_numeric(latest.get('adx')),
            'macd': self._sanitize_numeric(latest.get('macd')),
            'macd_signal': self._sanitize_numeric(latest.get('macd_signal')),
            'macd_hist': self._sanitize_numeric(latest.get('macd_hist')),
            'sma_20': self._sanitize_numeric(latest.get('sma_20')),
            'sma_50': self._sanitize_numeric(latest.get('sma_50')),
            'ema_50': self._sanitize_numeric(metadata.get('ema_50')),
            'ema_200': self._sanitize_numeric(metadata.get('ema_200')),
            'volume': self._sanitize_numeric(latest.get('volume')),
            'volume_ma': self._sanitize_numeric(metadata.get('volume_ma')),
        })

        self.signal_diagnostics.append(snapshot)
        self._flush_signal_diagnostics()

    def _flush_signal_diagnostics(self, force: bool = False):
        # Check if diagnostics are enabled and initialized
        if not hasattr(self, 'diagnostics_enabled') or not self.diagnostics_enabled:
            return
        if not self.signal_diagnostics:
            return
        time_elapsed = time.time() - self.diagnostics_last_flush
        if not force and len(self.signal_diagnostics) < self.diagnostics_flush_size and time_elapsed < self.diagnostics_flush_interval:
            return

        try:
            df = pd.DataFrame(self.signal_diagnostics)
            df = df.replace({np.nan: None})

            # Check if PyArrow is available
            if pa is not None and pq is not None:
                table = pa.Table.from_pandas(df, preserve_index=False)
                root_path = self.diagnostics_dir / 'signals'
                root_path.mkdir(parents=True, exist_ok=True)
                file_uuid = uuid.uuid4().hex
                pq.write_to_dataset(
                    table,
                    root_path=str(root_path),
                    basename_template=f'signals-{file_uuid}-{{i}}.parquet'
                )
                logger.debug(f"Flushed {len(self.signal_diagnostics)} signal diagnostics rows to {root_path}")
            else:
                # Fallback to JSON if PyArrow is not available
                import json
                root_path = self.diagnostics_dir / 'signals'
                root_path.mkdir(parents=True, exist_ok=True)
                file_uuid = uuid.uuid4().hex
                json_file = root_path / f'signals-{file_uuid}.json'

                # Convert data to JSON-serializable format
                json_data = []
                for row in self.signal_diagnostics:
                    json_row = {}
                    for key, value in row.items():
                        if pd.isna(value) or value is None:
                            json_row[key] = None
                        elif isinstance(value, (pd.Timestamp, datetime)):
                            json_row[key] = value.isoformat()
                        else:
                            json_row[key] = value
                    json_data.append(json_row)

                with open(json_file, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=2, ensure_ascii=False)

                logger.debug(f"Flushed {len(self.signal_diagnostics)} signal diagnostics rows to {json_file} (JSON fallback)")

            self.signal_diagnostics.clear()
            self.diagnostics_last_flush = time.time()
        except Exception as diag_error:
            logger.error(f"Error flushing signal diagnostics: {diag_error}")
            logger.error(traceback.format_exc())
            # Disable diagnostics to avoid repeated failures
            self.diagnostics_enabled = False
            
    def _save_state(self):
        """Save the current bot state to a file"""
        try:
            state = {
                'positions': self.positions,
                'position_sizes': self.position_sizes,
                'entry_times': {k: v.isoformat() for k, v in self.entry_times.items()},
                'last_scan_time': self.last_scan_time.isoformat() if self.last_scan_time else None
            }
            with open('bot_state.json', 'w') as f:
                json.dump(state, f, indent=2)
            logger.debug("Bot state saved successfully")
            return True
        except Exception as e:
            logger.error(f"Error saving bot state: {str(e)}")
            logger.error(traceback.format_exc())
            return False

    def cleanup(self):
        """Clean up resources before shutting down"""
        try:
            logger.debug("Cleaning up resources...")
            
            # Cancel all open orders
            for symbol in self.symbols:
                try:
                    self.client.futures_cancel_all_open_orders(symbol=symbol)
                except Exception as e:
                    logger.warning(f"Error cancelling orders for {symbol}: {str(e)}")
            
            # Close WebSocket connections if any
            if hasattr(self, 'bsm') and self.bsm:
                self.bsm.close()
                
            # Stop the health check server if running
            if hasattr(self, 'health_check_thread') and self.health_check_thread:
                import requests
                try:
                    requests.get(f'http://localhost:{self.health_check_port}/shutdown', timeout=1)
                except:
                    pass
                self.health_check_thread.join(timeout=2)
                
            logger.info("Cleanup completed")
            
        except Exception as e:
            logger.error(f"Error during cleanup: {str(e)}")
            logger.error(traceback.format_exc())
        
    def update_account_info(self):
        """Update account balance and other information"""
        try:
            # Get account information
            account_info = self.client.futures_account()
            
            # Update available balance
            self.balance = float(account_info['availableBalance'])
            self.total_balance = float(account_info['totalWalletBalance'])
            
            # Calculate available margin for trading
            self.available_margin = self.total_balance * self.max_margin
            
            # Log account information
            logger.debug(f"Account Balance: ${self.balance:.2f}")
            logger.debug(f"Total Balance: ${self.total_balance:.2f}")
            logger.debug(f"Available Margin: ${self.available_margin:.2f}")
            
        except Exception as e:
            logger.error(f"Error updating account info: {str(e)}")
            logger.error(traceback.format_exc())
            raise
    
    def check_entry_signals(self):
        """Check for new entry signals using optimized batch processing"""
        try:
            # Clean up cache periodically
            self._cleanup_cache()

            # Get current open positions from exchange (with caching)
            positions_result = self.get_cached_market_data('positions', 'info', 1)
            if positions_result is None:
                try:
                    exchange_positions = self.client.futures_position_information()
                    # Count only positions with non-zero amount
                    open_positions = [p for p in exchange_positions if float(p.get('positionAmt', 0)) != 0]
                    current_position_count = len(open_positions)

                    # Update self.positions to match exchange state
                    self.positions = {}
                    for pos in open_positions:
                        symbol = pos.get('symbol')
                        if not symbol:
                            continue
                        try:
                            leverage_value = pos.get('leverage', 1)
                            leverage = int(float(leverage_value)) if leverage_value not in (None, '') else 1
                        except (ValueError, TypeError):
                            leverage = 1
                        try:
                            position_amt = float(pos.get('positionAmt', 0))
                        except (ValueError, TypeError):
                            position_amt = 0.0
                        try:
                            entry_price = float(pos.get('entryPrice', 0))
                        except (ValueError, TypeError):
                            entry_price = 0.0
                        try:
                            unrealized_profit = float(pos.get('unRealizedProfit', 0))
                        except (ValueError, TypeError):
                            unrealized_profit = 0.0

                        self.positions[symbol] = {
                            'symbol': symbol,
                            'position_amt': position_amt,
                            'entry_price': entry_price,
                            'side': 'LONG' if position_amt > 0 else 'SHORT',
                            'status': 'OPEN',
                            'leverage': leverage,
                            'unrealized_profit': unrealized_profit
                        }

                    # Cache the positions data
                    self.cache_market_data('positions', 'info', 1, pd.DataFrame())

                except Exception as e:
                    logger.error(f"Error getting open positions from exchange: {str(e)}")
                    # Fall back to local positions if exchange query fails
                    if len(self.positions) >= self.max_trades:
                        logger.debug(f"Max trades (local: {len(self.positions)}/{self.max_trades}) reached. Skipping signal check.")
                        return
            else:
                # Use cached positions
                current_position_count = len(self.positions)

            # Skip if we've reached max trades
            if current_position_count >= self.max_trades:
                logger.debug(f"Max trades ({current_position_count}/{self.max_trades}) reached. Skipping signal check.")
                return

            # Smart filtering: prioritize symbols based on performance and recent activity
            filtered_symbols = self._filter_symbols_for_analysis()

            # Batch processing for efficiency
            for i in range(0, len(filtered_symbols), self.batch_size):
                batch = filtered_symbols[i:i + self.batch_size]

                # Process batch
                for symbol in batch:
                    # Skip if we already have a position in this symbol
                    if symbol in self.positions:
                        continue

                    try:
                        # Use the optimized check_entry_signal method
                        signal = self.check_entry_signal(symbol)
                        if signal and signal.get('signal') in ('LONG', 'SHORT'):
                            position_size = self.calculate_position_size(symbol, signal)
                            if position_size > 0:
                                self.enter_position(symbol, signal, position_size)
                                time.sleep(0.2)  # Small delay between trades

                    except Exception as e:
                        logger.error(f"Error checking entry signal for {symbol}: {str(e)}")
                        time.sleep(1)  # Delay on error

                # Delay between batches to avoid rate limits
                if i + self.batch_size < len(filtered_symbols):
                    time.sleep(1)

        except Exception as e:
            logger.error(f"Error in check_entry_signals: {str(e)}")
            logger.error(traceback.format_exc())
            time.sleep(30)

    def _filter_symbols_for_analysis(self) -> List[str]:
        """Enhanced coin selection with intelligent caching to prevent constant rescanning"""
        if not self.symbols:
            return []

        try:
            current_time = time.time()

            # Check if cached symbols are still fresh (within cache duration)
            if (self.cached_symbols and
                self.last_symbol_refresh and
                current_time - self.last_symbol_refresh < self.symbol_cache_duration):

                # Use cached symbols, but filter out positions we already have
                filtered_cached = [s for s in self.cached_symbols if s not in self.positions]
                logger.debug(f"Using cached symbols: {len(filtered_cached)} available (from {len(self.cached_symbols)} total)")

                # If we still have enough symbols, return them
                if len(filtered_cached) >= 100:
                    return filtered_cached[:500]

            # Cache is stale or insufficient - need to refresh
            logger.info("Refreshing coin selection cache (cached symbols expired or insufficient)")

            # Use enhanced coin selector with batch processing for larger universe scanning
            # Scan up to 2000 coins in batches for better returns capture
            enhanced_candidates = self.coin_selector.get_top_coins(
                n=2000,  # Significantly expanded universe compared to previous ~50-100
                min_score=60.0,  # Lower threshold to include more promising coins
                batch_size=100  # Process in efficient batches
            )

            if not enhanced_candidates:
                logger.warning("No enhanced candidates found, falling back to basic filtering")
                # Fallback to simple filtering if enhanced selection fails
                candidates = [s for s in list(self.symbols) if s not in self.positions]
                self.cached_symbols = candidates[:100]
                self.last_symbol_refresh = current_time
                return self.cached_symbols[:100]

            # Extract symbols from enhanced selection, preserving ranking order
            candidates = []
            seen_symbols = set()

            for coin in enhanced_candidates:
                symbol = coin.get('symbol')
                if symbol and symbol not in self.positions and symbol in self.symbols and symbol not in seen_symbols:
                    candidates.append(symbol)
                    seen_symbols.add(symbol)

                    # Log some top candidates for transparency (only on refresh)
                    if len(candidates) <= 10:
                        momentum_score = coin.get('momentum_score', 0)
                        volume_growth = coin.get('volume_growth', False)
                        logger.info(f"Enhanced candidate {len(candidates)}: {symbol} (score: {momentum_score:.1f}, volume_growth: {volume_growth})")

            # Cache the results for next time
            self.cached_symbols = candidates
            self.last_symbol_refresh = current_time

            # Return enhanced selection (up to 500 best candidates)
            final_candidates = candidates[:500]
            logger.info(f"Enhanced coin selection refreshed: {len(final_candidates)} candidates from {len(enhanced_candidates)} analyzed. Cache valid for {self.symbol_cache_duration//60} minutes.")

            return final_candidates

        except Exception as e:
            logger.error(f"Error in enhanced coin filtering, falling back to basic filtering: {e}")

            # Conservative fallback - cache basic results too
            current_time = time.time()
            candidates = [s for s in list(self.symbols) if s not in self.positions]
            basic_candidates = candidates[:100]
            self.cached_symbols = basic_candidates
            self.last_symbol_refresh = current_time
            return basic_candidates
    
    def calculate_position_size(self, symbol: str, signal: dict) -> float:
        """Calculate notional position size with dynamic risk adjustment and portfolio correlation controls.

        Args:
            symbol: Trading pair symbol (e.g., 'BTCUSDT')
            signal: Dictionary containing signal details including 'price', 'atr', and 'signal' keys

        Returns:
            float: Position size in quote currency (USDT) or 0 if position should not be taken
        """
        try:
            # Check correlation limits first
            if not self.check_correlation_limits(symbol):
                logger.warning(f"Trade rejected for {symbol} due to correlation limits")
                return 0.0

            # Get account balance and validate
            account = self.client.futures_account()
            usdt_asset = next((x for x in account['assets'] if x['asset'] == 'USDT'), None)
            if not usdt_asset:
                logger.error("USDT asset info missing from futures account response")
                return 0.0

            usdt_balance = float(usdt_asset.get('walletBalance', 0.0))
            if usdt_balance <= 10.0:
                logger.warning(f"Insufficient balance: ${usdt_balance:.2f}")
                return 0.0

            # Extract signal parameters
            entry_price = float(signal['price'])
            atr = float(signal.get('atr', 0.0))
            side = signal.get('signal', 'LONG').upper()

            if atr <= 0 or entry_price <= 0:
                logger.warning(f"Invalid ATR ({atr}) or entry price ({entry_price}) for {symbol}")
                return 0.0

            # Get market regime volatility for dynamic risk adjustment
            regime_volatility = 0.2  # Default neutral volatility
            if hasattr(signal, 'regime_volatility'):
                regime_volatility = signal.get('regime_volatility', 0.2)

            # Calculate dynamic risk based on market volatility
            base_risk = self.calculate_dynamic_risk(symbol, regime_volatility)

            # Calculate stop distance using ATR
            atr_stop_mult = 1.5
            stop_distance = max(atr * atr_stop_mult, entry_price * 0.005)

            # Apply dynamic risk scaling
            risk_amount = usdt_balance * self.max_margin * base_risk
            base_position_size = min(risk_amount / (stop_distance / entry_price), usdt_balance * self.max_margin)

            # Apply risk parity allocation if enabled
            if self.enable_risk_parity and hasattr(self, 'risk_allocator'):
                try:
                    # Get risk parity weights for all symbols in our universe
                    risk_weights = self.risk_allocator.allocations_for_universe(self.symbols)
                    symbol_weight = risk_weights.get(symbol, 0.0)

                    if symbol_weight <= 0:
                        logger.debug(f"Symbol {symbol} has zero weight in risk parity allocation")
                        return 0.0

                    # Scale position size by risk parity weight
                    total_weight = sum(risk_weights.values())
                    if total_weight > 0:
                        weight_ratio = symbol_weight / total_weight
                        position_notional = base_position_size * weight_ratio * len(self.symbols)
                        logger.debug(f"Applied risk parity weight {symbol_weight:.4f} to {symbol}")
                    else:
                        position_notional = base_position_size
                except Exception as e:
                    logger.error(f"Error in risk parity allocation for {symbol}: {e}")
                    logger.error(traceback.format_exc())
                    position_notional = base_position_size
            else:
                position_notional = base_position_size

            # Apply symbol-specific adjustments and validate
            symbol_info = self.symbol_info.get(symbol, {})
            if symbol_info:
                # Round to symbol's quantity precision
                quantity_precision = int(symbol_info.get('quantityPrecision', 3))
                position_notional = round(position_notional, quantity_precision)

                # Check minimum notional requirement
                min_notional = 5.0
                filters = symbol_info.get('filters', {})
                for filter_type, f in filters.items():
                    if filter_type == 'MIN_NOTIONAL':
                        min_notional = float(f.get('minNotional', min_notional))
                        break

                if position_notional < min_notional:
                    logger.debug(
                        f"Position notional too small for {symbol}: ${position_notional:.2f} < ${min_notional:.2f}"
                    )
                    return 0.0

            logger.debug(
                f"Calculated {side} position size for {symbol}: ${position_notional:.2f} "
                f"(dynamic risk: {base_risk:.4f}, volatility: {regime_volatility:.3f})"
            )
            return position_notional

        except Exception as e:
            logger.error(f"Error calculating position size for {symbol}: {e}")
            logger.error(traceback.format_exc())
            return 0.0
            
    def update_positions(self):
        """Update and manage open positions"""
        try:
            # Get current positions
            positions = self.get_open_positions()
            
            for symbol, position in positions.items():
                try:
                    # Get current market price
                    ticker = self.client.futures_symbol_ticker(symbol=symbol)
                    current_price = float(ticker['price'])
                    
                    position['current_price'] = current_price
                    entry_price = float(position['entry_price'])
                    side = position.get('side', 'LONG').upper()

                    if side == 'SHORT':
                        pnl_pct = (entry_price / current_price - 1) * 100
                        take_profit_hit = pnl_pct >= self.take_profit * 100
                        stop_loss_hit = pnl_pct <= -self.stop_loss * 100
                    else:
                        pnl_pct = (current_price / entry_price - 1) * 100
                        take_profit_hit = pnl_pct >= self.take_profit * 100
                        stop_loss_hit = pnl_pct <= -self.stop_loss * 100

                    position['pnl_pct'] = pnl_pct

                    # Check for take profit or stop loss hits
                    if take_profit_hit:
                        self.close_position(symbol, "Take Profit", current_price)
                        continue
                    elif stop_loss_hit:
                        self.close_position(symbol, "Stop Loss", current_price)
                        continue

                    if side == 'SHORT':
                        if 'lowest_price' not in position or current_price < position['lowest_price']:
                            position['lowest_price'] = current_price
                        low_ref = position.get('lowest_price', current_price)
                        if low_ref > 0:
                            retrace = (current_price - low_ref) / low_ref
                            if retrace >= self.trailing_stop_distance:
                                self.close_position(symbol, "Trailing Stop", current_price)
                    else:
                        if 'highest_price' not in position or current_price > position['highest_price']:
                            position['highest_price'] = current_price
                        high_ref = position.get('highest_price', current_price)
                        if high_ref > 0:
                            drawdown = (high_ref - current_price) / high_ref
                            if drawdown >= self.trailing_stop_distance:
                                self.close_position(symbol, "Trailing Stop", current_price)

                    # SuperTrend-based exit on 5m timeframe
                    try:
                        st_data = self.get_klines_data(symbol, interval='5m', limit=100)
                        if st_data is not None and not st_data.empty and len(st_data) >= 10:
                            supertrend = pta.supertrend(
                                st_data['high'],
                                st_data['low'],
                                st_data['close'],
                                length=7,
                                multiplier=3.0
                            )

                            if supertrend is not None and not supertrend.empty:
                                st_col = 'SUPERT_7_3.0'
                                if st_col in supertrend.columns:
                                    st_value = float(supertrend[st_col].iloc[-1])
                                    if np.isfinite(st_value):
                                        recent_close = float(st_data['close'].iloc[-1])
                                        side = position.get('side', 'LONG')

                                        if side == 'LONG' and recent_close < st_value:
                                            if self.close_position(symbol, "SUPER_TREND_BREAKDOWN", current_price):
                                                continue
                                        elif side == 'SHORT' and recent_close > st_value:
                                            if self.close_position(symbol, "SUPER_TREND_BREAKOUT", current_price):
                                                continue
                    except Exception as st_error:
                        logger.debug(f"SuperTrend exit check failed for {symbol}: {st_error}")

                except Exception as e:
                    logger.error(f"Error updating position for {symbol}: {str(e)}")
                    logger.error(traceback.format_exc())
                    continue
                    
        except Exception as e:
            logger.error(f"Error in update_positions: {str(e)}")
            logger.error(traceback.format_exc())
    
    def get_open_positions(self):
        """
        Get all open positions from the exchange and ensure they have all required fields.
        
        Returns:
            dict: Dictionary of open positions with all required fields
        """
        try:
            # Get positions from exchange
            positions = self.client.futures_position_information()
            open_positions = {}
            
            # Define all required fields with their default values
            required_fields = {
                'entry_price': 0.0,
                'quantity': 0.0,
                'entry_time': int(time.time() - 3600),  # Default to 1 hour ago
                'stop_loss': 0.0,
                'take_profit': 0.0,
                'status': 'OPEN',
                'side': 'LONG',  # Default to LONG for safety
                'initial_atr': 0.0,
                'trailing_stop': False,
                'highest_price': 0.0,
                'last_check': int(time.time()),
                'current_price': 0.0,
                'mark_price': 0.0,
                'unrealized_pnl': 0.0,
                'leverage': 1,
                'liquidation_price': 0.0,
                'margin_type': 'ISOLATED',
                'position_side': 'BOTH',
                'update_time': int(time.time() * 1000)  # Timestamp in milliseconds
            }
            
            for p in positions:
                try:
                    position_size = float(p.get('positionAmt', 0))
                    if position_size == 0:
                        continue
                        
                    symbol = p.get('symbol')
                    if not symbol:
                        logger.warning("Position missing symbol, skipping")
                        continue
                    
                    # Get current price data
                    try:
                        ticker = self.client.futures_symbol_ticker(symbol=symbol)
                        current_price = float(ticker.get('price', 0))
                    except Exception as e:
                        logger.error(f"Error getting ticker for {symbol}: {str(e)}")
                        current_price = 0
                    
                    # Parse position data with error handling
                    entry_price = float(p.get('entryPrice', 0))
                    leverage = int(p.get('leverage', 1))
                    liquidation_price = float(p.get('liquidationPrice', 0))
                    unrealized_profit = float(p.get('unRealizedProfit', 0))
                    position_side = 'LONG' if position_size > 0 else 'SHORT'
                    
                    # Create position template with all required fields
                    position_template = {
                        'entry_price': entry_price,
                        'quantity': abs(position_size),
                        'entry_time': int(time.time() - 3600) if 'entry_time' not in self.positions.get(symbol, {}) else self.positions[symbol]['entry_time'],
                        'stop_loss': entry_price * (0.98 if position_size > 0 else 1.02),  # 2% stop loss
                        'take_profit': entry_price * ((1 + self.take_profit) if position_size > 0 else (1 - self.take_profit)),  # 10% take profit
                        'status': 'OPEN',
                        'side': position_side,  # Explicitly set side based on position amount
                        'initial_atr': 0.0,
                        'trailing_stop': False,
                        'highest_price': max(entry_price, current_price) if current_price > 0 else entry_price,
                        'last_check': int(time.time()),
                        'current_price': current_price,
                        'mark_price': float(p.get('markPrice', 0)),
                        'unrealized_pnl': unrealized_profit,
                        'leverage': leverage,
                        'liquidation_price': liquidation_price,
                        'margin_type': p.get('marginType', 'ISOLATED'),
                        'position_side': p.get('positionSide', 'BOTH'),
                        'update_time': int(time.time() * 1000)
                    }
                    
                    # Initialize or update position
                    if symbol not in self.positions:
                        # New position - initialize with all required fields
                        self.positions[symbol] = position_template
                        logger.info(f"Initialized new position for {symbol}: {position_side} {abs(position_size)} @ {entry_price}")
                    else:
                        # Existing position - update fields while preserving any existing data
                        existing = self.positions[symbol]
                        
                        # Ensure all required fields exist in the existing position
                        for field, default_value in required_fields.items():
                            if field not in existing or existing[field] is None:
                                existing[field] = position_template.get(field, default_value)
                                logger.warning(f"Added missing field '{field}' to position {symbol}")
                        
                        # Update critical fields from the exchange
                        for field in ['entry_price', 'quantity', 'current_price', 'mark_price', 
                                    'unrealized_pnl', 'leverage', 'liquidation_price', 'margin_type',
                                    'position_side', 'update_time']:
                            if field in position_template:
                                existing[field] = position_template[field]
                        
                        # Update highest price for trailing stop
                        if 'highest_price' in existing and 'current_price' in existing:
                            existing['highest_price'] = max(existing.get('highest_price', 0), existing['current_price'])
                    
                    # Add to open positions return value
                    open_positions[symbol] = {
                        'symbol': symbol,
                        'position_amt': position_size,
                        'entry_price': entry_price,
                        'leverage': leverage,
                        'liquidation_price': liquidation_price,
                        'unrealized_profit': unrealized_profit,
                        'side': position_side,
                        'current_price': current_price,
                        'mark_price': float(p.get('markPrice', 0)),
                        'status': 'OPEN',
                        'update_time': int(time.time() * 1000)
                    }
                    
                    # Log position update
                    logger.debug(f"Updated position {symbol}: {position_side} {abs(position_size)} @ {entry_price}, "
                                f"Current: {current_price}, PnL: {unrealized_profit:.2f} USDT")
                    
                except Exception as pos_error:
                    logger.error(f"Error processing position {p.get('symbol', 'unknown')}: {str(pos_error)}")
                    logger.error(traceback.format_exc())
                    continue
            
            # Log summary of open positions
            if open_positions:
                logger.info(f"Successfully updated {len(open_positions)} open positions")
            else:
                logger.debug("No open positions found")
                
            return open_positions
            
        except Exception as e:
            logger.error(f"Error in get_open_positions: {str(e)}")
            logger.error(traceback.format_exc())
            # Return empty dict on error to prevent crashes
            return {}
    
    def enter_position(self, symbol: str, signal: dict, position_size: float) -> bool:
        """Enter a position according to signal direction."""
        try:
            side = signal.get('signal', 'LONG')
            is_short = side == 'SHORT'

            ticker = self.client.futures_symbol_ticker(symbol=symbol)
            entry_price = float(ticker['price'])

            quantity = position_size / entry_price

            symbol_info = self.symbol_info.get(symbol, {})
            if not symbol_info:
                logger.error(f"No symbol info for {symbol}")
                return False

            step_size = float(symbol_info.get('filters', {}).get('LOT_SIZE', {}).get('stepSize', '0.000001'))
            if step_size > 0:
                quantity = math.floor(quantity / step_size) * step_size

            submit_time = time.time()

            if not self.paper_trading:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side='SELL' if is_short else 'BUY',
                    type='MARKET',
                    quantity=quantity
                )
                fill_time = time.time()
                logger.info(f"Entered {side} position: {symbol} | Qty: {quantity:.6f} @ ${entry_price:.8f}")

                try:
                    fill_price = float(order.get('avgPrice') or order.get('price') or entry_price)
                    record = build_execution_record(
                        symbol=symbol,
                        side=side,
                        signal_price=signal['price'],
                        fill_price=fill_price,
                        quantity=quantity,
                        submit_time=submit_time,
                        fill_time=fill_time,
                        status='FILLED',
                        account=self.account_label,
                        extra={
                            'entry': True,
                            'signal_score': signal.get('score'),
                        }
                    )
                    self.execution_logger.log(record)
                except Exception as metrics_error:
                    logger.error(f"Error logging entry execution for {symbol}: {metrics_error}")
                    logger.debug(traceback.format_exc())
            else:
                fill_time = time.time()
                logger.info(f"[PAPER] Enter {side} {quantity:.6f} {symbol} @ {entry_price:.8f}")
                try:
                    record = build_execution_record(
                        symbol=symbol,
                        side=side,
                        signal_price=signal['price'],
                        fill_price=entry_price,
                        quantity=quantity,
                        submit_time=submit_time,
                        fill_time=fill_time,
                        status='PAPER_FILLED',
                        account=self.account_label,
                        extra={
                            'entry': True,
                            'signal_score': signal.get('score'),
                        }
                    )
                    self.execution_logger.log(record)
                except Exception as metrics_error:
                    logger.error(f"Error logging paper entry for {symbol}: {metrics_error}")
                    logger.debug(traceback.format_exc())

            self.positions[symbol] = {
                'entry_price': entry_price,
                'quantity': quantity,
                'entry_time': int(time.time()),
                'status': 'OPEN',
                'side': side,
                'highest_price': entry_price if not is_short else None,
                'lowest_price': entry_price if is_short else None,
            }

            return True

        except Exception as e:
            logger.error(f"Error entering position for {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            return False
    
    def ensure_position_has_side(self, symbol: str) -> bool:
        """Ensure the position has a 'side' key, defaulting to 'LONG' if missing"""
        if symbol in self.positions and 'side' not in self.positions[symbol]:
            self.positions[symbol]['side'] = 'LONG'  # Default to LONG for backward compatibility
            self.logger.warning(f"Added missing 'side' key to position {symbol}, defaulting to 'LONG'")
            return True
        return False
    
    def close_position(self, symbol: str, reason: str, current_price: float) -> bool:
        """
        Close an open position with comprehensive error handling and validation.
        
        Args:
            symbol: The trading pair symbol (e.g., 'BTCUSDT')
            reason: Reason for closing the position (e.g., 'STOP_LOSS', 'TAKE_PROFIT')
            current_price: Current market price for the symbol
            
        Returns:
            bool: True if position was successfully closed, False otherwise
        """
        try:
            # Initialize logging context
            log_prefix = f"[CLOSE_POSITION] {symbol} - "
            logger.info(f"{log_prefix}Closing position (reason: {reason})")
            logger.debug(f"{log_prefix}Current price: {current_price}")
            
            # Validate inputs
            if not isinstance(symbol, str) or not symbol:
                logger.error(f"{log_prefix}Invalid symbol: {symbol}")
                return False
                
            try:
                current_price = float(current_price)
            except (ValueError, TypeError):
                logger.error(f"{log_prefix}Invalid current_price: {current_price}")
                return False
            
            # Check if position exists in our tracking
            if symbol not in self.positions:
                logger.warning(f"{log_prefix}Position not found in self.positions")
                # Try to sync with exchange
                try:
                    logger.info(f"{log_prefix}Attempting to sync position from exchange...")
                    self.get_open_positions()  # This will update self.positions
                    
                    if symbol not in self.positions:
                        logger.error(f"{log_prefix}Position not found after syncing with exchange")
                        return False
                        
                    logger.info(f"{log_prefix}Successfully synced position from exchange")
                except Exception as e:
                    logger.error(f"{log_prefix}Error syncing position from exchange: {str(e)}")
                    logger.error(traceback.format_exc())
                    return False
            
            # Get position with thread-safe access and create a working copy
            position = dict(self.positions.get(symbol, {}))  # Create a copy to avoid modifying the original
            logger.debug(f"{log_prefix}Initial position data: {json.dumps(position, indent=2, default=str)}")
            
            # Define all possible fields with their default values
            default_values = {
                'entry_price': current_price,
                'quantity': 0.0,
                'entry_time': int(time.time() - 3600),
                'status': 'OPEN',
                'side': position.get('side', 'LONG') if symbol in self.positions else 'LONG',
                'stop_loss': 0.0,
                'take_profit': 0.0,
                'initial_atr': 0.0,
                'trailing_stop': False,
                'highest_price': current_price,
                'last_check': int(time.time()),
                'pnl': 0.0,
                'pnl_percent': 0.0,
                'leverage': 1.0,
                'initial_margin': 0.0,
                'liquidation_price': 0.0,
                'mark_price': current_price,
                'unrealized_pnl': 0.0,
                'realized_pnl': 0.0,
                'margin_type': 'ISOLATED',
                'is_auto_add_margin': False,
                'position_side': 'BOTH',
                'is_isolated': True,
                'update_time': int(time.time() * 1000)
            }
            
            # Update position with default values for any missing fields
            updated = False
            for field, default_value in default_values.items():
                if field not in position or position[field] is None:
                    position[field] = default_value
                    updated = True
                    logger.warning(f"{log_prefix}Added missing field '{field}' with default: {default_value}")
            
            # If we updated the position, save it back
            if updated:
                self.positions[symbol] = position
                try:
                    self.save_state()
                    logger.info(f"{log_prefix}Updated and saved position data")
                except Exception as e:
                    logger.error(f"{log_prefix}Error saving updated position: {str(e)}")
            
            # Verify we have the minimum required fields
            required_fields = {
                'entry_price': (float, float(position.get('entry_price', current_price))),
                'quantity': (float, float(position.get('quantity', 0.0))),
                'entry_time': (int, int(position.get('entry_time', time.time()))),
                'status': (str, 'OPEN'),
                'side': (str, str(position.get('side', 'LONG')).upper())
            }
            
            # Validate and fix required fields
            validation_errors = []
            for field, (field_type, default_value) in required_fields.items():
                if field not in position or position[field] is None:
                    validation_errors.append(f"missing {field}")
                    position[field] = default_value
                else:
                    try:
                        # Convert to the expected type
                        if field_type == float:
                            position[field] = float(position[field])
                        elif field_type == int:
                            position[field] = int(position[field])
                        elif field_type == str:
                            position[field] = str(position[field]).strip().upper()
                    except (ValueError, TypeError) as e:
                        validation_errors.append(f"invalid {field} type")
                        position[field] = default_value
            
            if validation_errors:
                logger.warning(f"{log_prefix}Position validation issues: {', '.join(validation_errors)}")
                # Save the fixed position
                self.positions[symbol] = position
                try:
                    self.save_state()
                except Exception as e:
                    logger.error(f"{log_prefix}Error saving fixed position: {str(e)}")
            
            # Ensure position status is valid
            if position['status'] != 'OPEN':
                logger.warning(f"{log_prefix}Position is not open (status: {position['status']})")
                return False
            
            # Validate position side
            side_str = str(position.get('side', 'LONG')).strip().upper()
            if side_str not in ['LONG', 'SHORT']:
                logger.warning(f"{log_prefix}Invalid side '{side_str}', defaulting to 'LONG'")
                side_str = 'LONG'
                position['side'] = 'LONG'
                self.positions[symbol] = position
                try:
                    self.save_state()
                except Exception as e:
                    logger.error(f"{log_prefix}Error saving position with fixed side: {str(e)}")
            
            # Determine order side (opposite of position side)
            order_side = 'SELL' if side_str == 'LONG' else 'BUY'
            logger.info(f"{log_prefix}Closing {side_str} position with {order_side} order")
            
            # Calculate position metrics
            entry_price = float(position['entry_price'])
            quantity = float(position['quantity'])
            entry_time = int(position['entry_time'])
            time_in_trade_min = (int(time.time()) - entry_time) / 60  # in minutes
            
            # Calculate PnL
            price_diff = (current_price - entry_price) * (1 if side_str == 'LONG' else -1)
            pnl = price_diff * quantity
            pnl_percent = (price_diff / entry_price) * 100 if entry_price > 0 else 0
            
            # Log position close details
            logger.info(f"{log_prefix}Position Close Details:")
            logger.info(f"  Entry Price: {entry_price:.8f}")
            logger.info(f"  Exit Price:  {current_price:.8f}")
            logger.info(f"  Quantity:    {quantity:.8f}")
            logger.info(f"  PnL:         {pnl:.8f} ({pnl_percent:.2f}%)")
            logger.info(f"  Duration:    {time_in_trade_min:.1f} minutes")
            logger.info(f"  Reason:      {reason}")
            
            submit_time = time.time()

            # Execute the close order (if not in paper trading mode)
            if not self.paper_trading:
                try:
                    order_side = 'SELL' if position.get('side') == 'LONG' else 'BUY'
                    quantity = abs(float(position.get('position_amt', 0)))

                    if quantity <= 0:
                        logger.error(f"Invalid quantity {quantity} for {symbol}")
                        return False

                    logger.info(f"Placing {order_side} order for {quantity:.8f} {symbol} at market price")

                    # Place the order with reduceOnly flag
                    order = self.client.futures_create_order(
                        symbol=symbol,
                        side=order_side,
                        type='MARKET',
                        quantity=quantity,
                        reduceOnly=True,
                        timestamp=int(time.time() * 1000)
                    )

                    logger.info(f"Order executed: {order}")

                except Exception as e:
                    error_msg = str(e)
                    if 'ReduceOnly Order is rejected' in error_msg:
                        logger.warning(f"Position already closed on exchange for {symbol}, cleaning up local state")
                        # Mark as closed in our records
                        position.update({
                            'status': 'CLOSED',
                            'exit_price': current_price,
                            'exit_time': int(time.time() * 1000),
                            'close_reason': 'ALREADY_CLOSED_ON_EXCHANGE',
                            'pnl_pct': pnl_pct
                        })
                        return True
                    else:
                        logger.error(f"Error executing {order_side} order for {symbol}: {error_msg}")
                        logger.error(traceback.format_exc())
                        return False
            else:
                logger.info(f"[PAPER] Would {order_side} {abs(float(position.get('position_amt', 0))):.8f} {symbol} @ {current_price:.8f}")

            # Update position status and close details
            position.update({
                'status': 'CLOSED',
                'exit_price': current_price,
                'exit_time': int(time.time() * 1000),
                'close_reason': reason,
                'pnl_percent': pnl_percent
            })

            # Cancel any associated OCO orders
            try:
                self.cancel_oco_orders(symbol)
            except Exception as e:
                logger.error(f"Error cancelling OCO orders for {symbol}: {str(e)}")
                # Continue even if OCO cancel fails

            # Track consecutive losses for Telegram alerts
            if pnl_percent < 0:
                self.consecutive_losses += 1
                logger.warning(f"Consecutive loss #{self.consecutive_losses} for {symbol}: {pnl_percent:.2f}%")

                # Send alert to Telegram if configured and threshold reached
                if (self.telegram_controller and
                    self.telegram_controller.is_configured() and
                    self.consecutive_losses >= self.max_consecutive_losses_alert):

                    try:
                        self.telegram_controller.send_loss_alert(
                            symbol=symbol,
                            pnl_percent=pnl_percent,
                            total_consecutive=self.consecutive_losses
                        )
                        logger.info(f"Sent loss alert for {symbol} via Telegram (consecutive losses: {self.consecutive_losses})")
                    except Exception as telegram_error:
                        logger.error(f"Failed to send Telegram loss alert: {telegram_error}")
            else:
                # Reset consecutive losses counter on profit
                if self.consecutive_losses > 0:
                    logger.info(f"Loss streak ended - reset consecutive losses counter (was: {self.consecutive_losses})")
                self.consecutive_losses = 0

            # SET COOLDOWN FOR VOLUME REVERSAL EXITS - Prevent immediate re-entry
            if reason == 'HIGH_VOLUME_REVERSAL' and hasattr(self, 'volume_reversal_cooldown') and hasattr(self, 'volume_reversal_cooldown_hours'):
                cooldown_end = time.time() + (self.volume_reversal_cooldown_hours * 60 * 60)  # hours to seconds
                self.volume_reversal_cooldown[symbol] = cooldown_end
                logger.warning(f"🚫 Set volume reversal cooldown for {symbol} until {datetime.fromtimestamp(cooldown_end).strftime('%Y-%m-%d %H:%M:%S')} (PnL: {pnl_percent:.2f}%)")

            logger.info(f"Successfully closed {symbol} position: {reason}")
            return True
            
        except Exception as e:
            logger.error(f"Error in close_position for {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            return False
            
    def run(self):
        """Main trading loop"""
        logger.info("Starting main trading loop...")
        self.is_running = True
        last_reconciliation = 0
        reconciliation_interval = 180  # 3 minutes in seconds
        
        try:
            while self.is_running:
                cycle_start = time.time()
                current_time = time.time()
                
                try:
                    # Update account information
                    try:
                        self.update_account_info()
                    except Exception as e:
                        logger.error(f"Error updating account info: {str(e)}")
                        time.sleep(30)
                        continue

                    # Refresh coin universe periodically
                    try:
                        self._maybe_refresh_coin_data()
                    except Exception as coin_update_error:
                        logger.error(f"Error refreshing coin data: {coin_update_error}")
                        logger.error(traceback.format_exc())

                    # Reconcile positions with exchange (every reconciliation_interval seconds)
                    if current_time - last_reconciliation >= reconciliation_interval:
                        try:
                            logger.info("Running position reconciliation...")
                            self.reconcile_positions()
                            last_reconciliation = current_time
                        except Exception as e:
                            logger.error(f"Error during position reconciliation: {str(e)}")
                            logger.error(traceback.format_exc())
                    
                    # Check for entry signals
                    try:
                        self.check_entry_signals()
                    except Exception as e:
                        logger.error(f"Error in check_entry_signals: {str(e)}")
                        logger.error(traceback.format_exc())
                    
                    # Update and manage open positions
                    try:
                        self.update_positions()
                    except Exception as e:
                        logger.error(f"Error in update_positions: {str(e)}")
                        logger.error(traceback.format_exc())
                    
                    # Calculate cycle time and sleep if needed
                    cycle_time = time.time() - cycle_start
                    min_cycle_time = 60  # 1 minute between full cycles
                    if cycle_time < min_cycle_time:
                        sleep_time = min_cycle_time - cycle_time
                        logger.debug(f"Cycle completed in {cycle_time:.1f}s. Sleeping for {sleep_time:.1f}s")
                        time.sleep(sleep_time)
                    else:
                        logger.debug(f"Cycle took {cycle_time:.1f}s (no sleep needed)")
                    
                except KeyboardInterrupt:
                    logger.info("Shutdown signal received. Cleaning up...")
                    self.is_running = False
                    break
                    
                except Exception as e:
                    logger.error(f"Unexpected error in trading loop: {str(e)}")
                    logger.error(traceback.format_exc())
                    time.sleep(60)  # Wait longer on unexpected errors
                    
        except Exception as e:
            logger.critical(f"Critical error in main loop: {str(e)}")
            logger.critical(traceback.format_exc())
            
        finally:
            self.cleanup()
            logger.info("Trading bot fully stopped.")
    
    def ensure_position_has_required_fields(self, symbol: str, position: dict) -> bool:
        """Ensure a position has all required fields with proper defaults"""
        try:
            if 'entry_price' not in position:
                logger.warning(f"Position for {symbol} missing entry_price, marking as invalid")
                return False
                
            # Set default values for required fields
            current_time = int(time.time())
            position.setdefault('symbol', symbol)
            position.setdefault('status', 'OPEN')
            position.setdefault('side', 'LONG')  # Default to LONG for backward compatibility
            position.setdefault('entry_time', current_time)
            position.setdefault('highest_price', position['entry_price'])
            position.setdefault('stop_loss', position['entry_price'] * (1 - self.stop_loss))
            position.setdefault('take_profit', position['entry_price'] * (1 + self.take_profit))
            position.setdefault('initial_atr', 0)
            position.setdefault('leverage', 10)  # Default leverage if not set
            position.setdefault('position_amt', 0)
            position.setdefault('unrealized_pnl', 0)
            
            return True
            
        except Exception as e:
            logger.error(f"Error ensuring position fields for {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            return False
            
    def _validate_position(self, position: dict, symbol: str) -> bool:
        """Validate position data and ensure all required fields are present.
        
        Args:
            position: Position dictionary to validate
            symbol: Symbol for logging purposes
            
        Returns:
            bool: True if position is valid, False otherwise
        """
        required_fields = {
            'entry_price': (float, 0.0),
            'quantity': (float, 0.0),
            'entry_time': (int, int(time.time() * 1000)),
            'status': (str, 'OPEN'),
            'side': (str, 'LONG'),
            'mark_price': (float, 0.0),
            'unrealized_pnl': (float, 0.0),
            'leverage': (int, 1),
            'liquidation_price': (float, 0.0),
            'position_amt': (float, 0.0)
        }
        
        try:
            # Ensure all required fields exist and are of correct type
            valid = True
            for field, (field_type, default) in required_fields.items():
                if field not in position or position[field] is None:
                    position[field] = default
                    logger.warning(f"Added missing field '{field}' to position {symbol}")
                
                # Type conversion
                try:
                    if field_type == float:
                        position[field] = float(position[field])
                    elif field_type == int:
                        position[field] = int(float(position[field]))
                    elif field_type == str:
                        position[field] = str(position[field]).strip().upper()
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid {field} value for {symbol}: {position[field]}. Using default: {default}")
                    position[field] = default
            
            # Additional validation
            if position['status'] == 'OPEN' and abs(position['position_amt']) < 1e-8:
                logger.warning(f"Invalid position amount for {symbol}. Marking as closed.")
                position['status'] = 'CLOSED'
                position['close_reason'] = 'INVALID_AMOUNT'
                return False
                
            return True
            
        except Exception as e:
            logger.error(f"Error validating position {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            return False

    def reconcile_positions(self) -> dict:
        """Reconcile bot's position tracking with exchange
        
        This method ensures the bot's internal position tracking matches the actual
        positions on the exchange. It handles cases where positions exist in one place
        but not the other, and ensures all required fields are present.
        
        Returns:
            dict: Dictionary with reconciliation results including:
                - added_positions: List of symbols added to bot
                - removed_positions: List of symbols removed from bot
                - updated_positions: List of symbols updated in bot
                - errors: List of error messages if any occurred
        """
        result = {
            'added_positions': [],
            'removed_positions': [],
            'updated_positions': [],
            'errors': [],
            'status': 'error',  # Will be updated to 'success' if everything goes well
            'missing_on_exchange': [],
            'missing_in_bot': [],
            'total_positions': 0,
            'valid_positions': []
        }
        
        try:
            # Get positions from exchange with retry logic and exponential backoff
            max_retries = 5
            retry_delay = 1  # seconds
            exchange_positions = []
            
            for attempt in range(max_retries):
                try:
                    # Use the existing session with retry logic
                    if not hasattr(self, 'client') or not hasattr(self.client, 'session'):
                        raise RuntimeError("Binance client or session not properly initialized")
                        
                    # Make the API request using the existing session
                    exchange_positions = self.client.futures_position_information(recvWindow=10000)
                    
                    # Validate the response
                    if not isinstance(exchange_positions, list):
                        raise ValueError(f"Unexpected response format: {type(exchange_positions)}")
                    
                    # Log successful fetch
                    logger.info(f"Successfully fetched {len(exchange_positions)} positions from exchange")
                    break
                    
                except (requests.exceptions.RequestException, BinanceAPIException, Exception) as e:
                    wait_time = retry_delay * (2 ** attempt)  # Exponential backoff
                    if attempt < max_retries - 1:
                        logger.warning(f"Attempt {attempt + 1} failed: {str(e)}. Retrying in {wait_time} seconds...")
                        time.sleep(wait_time)
                        continue
                        
                    error_msg = f"Failed to fetch positions from exchange after {max_retries} attempts: {str(e)}"
                    logger.error(error_msg, exc_info=True)
                    result['errors'].append(error_msg)
                    return result
                        
                    logger.warning(f"Attempt {attempt + 1} failed: {str(e)}. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    retry_delay = min(retry_delay * 2, 30)  # Cap at 30 seconds
                
                except Exception as e:
                    error_msg = f"Unexpected error fetching positions: {str(e)}"
                    logger.error(error_msg)
                    logger.error(traceback.format_exc())
                    result['errors'].append(error_msg)
                    time.sleep(retry_delay)
                    retry_delay = min(retry_delay * 2, 30)
                    
                    if attempt == max_retries - 1:
                        error_msg = f"Failed to fetch positions from exchange after {max_retries} attempts: {str(e)}"
                        logger.error(error_msg)
                        result['errors'].append(error_msg)
                        return result
            
            # Process exchange positions with validation
            valid_exchange_positions = []
            for p in exchange_positions:
                try:
                    # Skip if position amount is effectively zero
                    position_amt = float(p.get('positionAmt', 0))
                    if abs(position_amt) < 1e-8:
                        continue
                        
                    # Ensure required fields exist
                    if 'symbol' not in p or not p['symbol']:
                        logger.warning(f"Position missing symbol: {p}")
                        continue
                        
                    # Convert numeric fields
                    try:
                        p['entryPrice'] = float(p.get('entryPrice', 0))
                        p['positionAmt'] = position_amt
                        p['unRealizedProfit'] = float(p.get('unRealizedProfit', 0))
                        p['leverage'] = int(float(p.get('leverage', 1)))
                        p['liquidationPrice'] = float(p.get('liquidationPrice', 0))
                        p['markPrice'] = float(p.get('markPrice', 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid numeric value in position {p.get('symbol')}: {str(e)}")
                        continue
                        
                    valid_exchange_positions.append(p)
                    
                except Exception as e:
                    logger.error(f"Error processing position: {str(e)}")
                    logger.error(traceback.format_exc())
                    continue
            
            exchange_positions = valid_exchange_positions
            exchange_symbols = {p['symbol'] for p in exchange_positions}
            logger.info(f"Found {len(exchange_positions)} valid open positions on exchange")
            
            # Get positions from bot and validate them
            valid_positions = {}
            for symbol, pos in list(self.positions.items()):
                try:
                    if not isinstance(pos, dict):
                        logger.warning(f"Invalid position data type for {symbol}: {type(pos)}")
                        result['removed_positions'].append(symbol)
                        continue
                    
                    # Make a copy to avoid modifying the original
                    pos_copy = pos.copy()
                    
                    # Validate the position
                    if self._validate_position(pos_copy, symbol):
                        valid_positions[symbol] = pos_copy
                        
                        # If position was previously marked as closed but is now valid, log it
                        if pos.get('status') == 'CLOSED' and pos_copy.get('status') == 'OPEN':
                            logger.info(f"Reopened position {symbol} after validation")
                            result['updated_positions'].append(symbol)
                    else:
                        # If validation fails, mark as closed if not already
                        if pos_copy.get('status') != 'CLOSED':
                            pos_copy.update({
                                'status': 'CLOSED',
                                'close_reason': 'VALIDATION_FAILED',
                                'exit_time': int(time.time() * 1000)
                            })
                            logger.warning(f"Marking invalid position as closed: {symbol}")
                            
                        result['removed_positions'].append(symbol)
                        
                except Exception as e:
                    error_msg = f"Error validating position {symbol}: {str(e)}"
                    logger.error(error_msg)
                    logger.error(traceback.format_exc())
                    result['errors'].append(error_msg)
                    continue
            
            # Update bot positions with only valid ones
            self.positions = valid_positions
            bot_symbols = set(self.positions.keys())
            
            # Find discrepancies between bot and exchange
            missing_on_exchange = set()
            missing_in_bot = set()
            
            # Check positions in bot against exchange
            for symbol in bot_symbols:
                if symbol not in exchange_symbols:
                    # Double check with a fresh API call to confirm
                    try:
                        # Get fresh position data for this symbol only
                        try:
                            fresh_pos = next((p for p in self.client.futures_position_information(
                                symbol=symbol, 
                                recvWindow=10000
                            ) if p['symbol'] == symbol), None)
                        except Exception as pos_err:
                            logger.warning(f"Error fetching position info for {symbol}: {str(pos_err)}")
                            fresh_pos = None
                        
                        if fresh_pos and abs(float(fresh_pos.get('positionAmt', 0))) > 1e-8:
                            # Position exists on exchange, add to exchange positions
                            exchange_positions.append(fresh_pos)
                            exchange_symbols.add(symbol)
                            logger.info(f"Verified position {symbol} exists on exchange")
                            continue
                            
                        missing_on_exchange.add(symbol)
                        logger.warning(f"Confirmed position {symbol} missing on exchange")
                        
                    except Exception as e:
                        logger.error(f"Error verifying position {symbol}: {str(e)}")
                        # If we can't verify, assume it's missing
                        missing_on_exchange.add(symbol)
            
            # Check for positions on exchange but not in bot
            for symbol in exchange_symbols:
                if symbol not in bot_symbols:
                    missing_in_bot.add(symbol)
            
            # Log and handle positions in bot but not on exchange
            if missing_on_exchange:
                self._handle_missing_on_exchange(missing_on_exchange, result)
            
            # Add positions that exist on exchange but not in bot
            if missing_in_bot:
                self._handle_missing_in_bot(missing_in_bot, exchange_positions, result)
            
            # Update existing positions with latest data from exchange
            self._update_existing_positions(exchange_positions, exchange_symbols, result)
            
            # Add final status to result
            result.update({
                'missing_on_exchange': list(missing_on_exchange),
                'missing_in_bot': list(missing_in_bot),
                'total_positions': len(self.positions),
                'valid_positions': list(self.positions.keys()),
                'status': 'success'
            })
            
            # Log summary of reconciliation
            logger.info(f"Reconciliation complete. {len(self.positions)} positions active. "
                      f"Added: {len(result['added_positions'])}, "
                      f"Removed: {len(result['removed_positions'])}, "
                      f"Updated: {len(result['updated_positions'])}")
            
            # Save the updated state
            try:
                self._save_state()
            except Exception as e:
                error_msg = f"Error saving state after reconciliation: {str(e)}"
                logger.error(error_msg)
                result['errors'].append(error_msg)
                result['status'] = 'error'
            
            return result
            
        except Exception as e:
            # Handle any unexpected errors
            error_msg = f"Error during position reconciliation: {str(e)}"
            logger.error(error_msg)
            logger.error(traceback.format_exc())
            result['errors'].append(error_msg)
            result['status'] = 'error'
            return result

    def _handle_missing_on_exchange(self, symbols: set, result: dict):
        """Mark positions missing on exchange as closed locally."""
        for symbol in symbols:
            position = self.positions.get(symbol)
            if position:
                position.update({
                    'status': 'CLOSED',
                    'close_reason': 'MISSING_ON_EXCHANGE',
                    'exit_time': int(time.time() * 1000)
                })
                result['removed_positions'].append(symbol)
        self.positions = {s: p for s, p in self.positions.items() if s not in symbols}

    def _handle_missing_in_bot(self, symbols: set, exchange_positions: list, result: dict):
        """Add positions found on exchange but missing locally."""
        for symbol in symbols:
            exchange_position = next((p for p in exchange_positions if p['symbol'] == symbol), None)
            if not exchange_position:
                continue
            side = 'LONG' if exchange_position['positionAmt'] > 0 else 'SHORT'
            position_data = {
                'entry_price': float(exchange_position.get('entryPrice', 0)),
                'quantity': abs(float(exchange_position.get('positionAmt', 0))),
                'entry_time': int(time.time() * 1000),
                'stop_loss': float(exchange_position.get('entryPrice', 0)) * (0.98 if side == 'LONG' else 1.02),
                'take_profit': float(exchange_position.get('entryPrice', 0)) * (1.05 if side == 'LONG' else 0.95),
                'status': 'OPEN',
                'side': side,
                'unrealized_profit': float(exchange_position.get('unRealizedProfit', 0)),
                'leverage': int(exchange_position.get('leverage', 1)),
                'mark_price': float(exchange_position.get('markPrice', 0)),
                'liquidation_price': float(exchange_position.get('liquidationPrice', 0)),
                'position_amt': float(exchange_position.get('positionAmt', 0)),
                'last_check': int(time.time()),
            }
            self.positions[symbol] = position_data
            result['added_positions'].append(symbol)

    def _update_existing_positions(self, exchange_positions: list, exchange_symbols: set, result: dict):
        """Refresh data for positions tracked both locally and on exchange."""
        for exchange_position in exchange_positions:
            symbol = exchange_position['symbol']
            if symbol not in self.positions:
                continue
            position = self.positions[symbol]
            side = 'LONG' if exchange_position['positionAmt'] > 0 else 'SHORT'
            position.update({
                'side': side,
                'entry_price': float(exchange_position.get('entryPrice', position.get('entry_price', 0))),
                'quantity': abs(float(exchange_position.get('positionAmt', position.get('quantity', 0)))),
                'unrealized_profit': float(exchange_position.get('unRealizedProfit', position.get('unrealized_profit', 0))),
                'leverage': int(exchange_position.get('leverage', position.get('leverage', 1))),
                'mark_price': float(exchange_position.get('markPrice', position.get('mark_price', 0))),
                'liquidation_price': float(exchange_position.get('liquidationPrice', position.get('liquidation_price', 0))),
                'last_check': int(time.time()),
                'status': 'OPEN'
            })
            result['updated_positions'].append(symbol)
            
    def start_health_check_server(self):
        """Start the Flask health check server in a separate thread"""
        from flask import Flask, jsonify, request
        import threading
        import requests
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        
        # Define retry strategy for the health check server
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504],
            allowed_methods=["GET", "POST"]
        )
        
        # Create a session with retry strategy
        session = requests.Session()
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        app = Flask(__name__)
        
        @app.route('/health')
        def health_check():
            """Health check endpoint for monitoring"""
            status = {
                'status': 'running' if self.is_running else 'stopped',
                'timestamp': datetime.utcnow().isoformat(),
                'positions': len(self.positions),
                'last_scan': getattr(self, 'last_scan_time', None),
                'reconcile_positions': self.reconcile_positions()
            }
            
            # Configure retry strategy
            retry_strategy = Retry(
                total=5,  # Maximum number of retries
                backoff_factor=1,  # Wait 1, 2, 4, 8, 16 seconds between retries
                status_forcelist=[408, 429, 500, 502, 503, 504],
                allowed_methods=["HEAD", "GET", "PUT", "DELETE", "OPTIONS", "TRACE", "POST"]
            )
        
        # Create adapter with retry strategy
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,
            pool_maxsize=10
        )
        
        # Mount the adapter
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set timeout
        session.timeout = 30  # 30 seconds default timeout
        
        # Configure DNS cache
        import requests_cache
        requests_cache.install_cache('binance_cache', expire_after=300)  # 5 minute cache
        
        return session

    def get_klines_data(self, symbol: str, interval: str = '15m', limit: int = 100) -> pd.DataFrame:
        """Get historical klines data with caching and rate limiting"""
        try:
            # Check cache first
            cached_data = self.get_cached_market_data(symbol, interval, limit)
            if cached_data is not None:
                return cached_data

            # Rate limiting
            self._rate_limit_api_call()

            klines = self.client.futures_klines(symbol=symbol, interval=interval, limit=limit)
            df = pd.DataFrame(klines, columns=[
                'open_time', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_asset_volume', 'number_of_trades',
                'taker_buy_base_asset_volume', 'taker_buy_quote_asset_volume', 'ignore'
            ])

            # Convert columns to appropriate types
            numeric_columns = ['open', 'high', 'low', 'close', 'volume']
            df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric, axis=1)
            df['open_time'] = pd.to_datetime(df['open_time'], unit='ms')
            df.set_index('open_time', inplace=True)

            # Cache the data
            self.cache_market_data(symbol, interval, limit, df)

            # Only apply technical indicators if market_analyzer is available
            if hasattr(self, 'market_analyzer') and self.market_analyzer:
                return self.market_analyzer.calculate_technical_indicators(df)
            else:
                return df

        except Exception as e:
            logger.error(f"Error getting klines data for {symbol}: {e}")
            return pd.DataFrame()
    
    def check_entry_signal(self, symbol: str) -> Optional[Dict]:
        """
        Check for entry signal using regime-aware evaluation with multi-timeframe confirmation.

        Args:
            symbol: Trading pair symbol to check for signals

        Returns:
            Dict containing signal details if a valid signal is found, None otherwise
        """
        try:
            # CHECK VOLUME REVERSAL COOLDOWN - Prevent re-entry after recent volume exits
            if hasattr(self, 'volume_reversal_cooldown') and hasattr(self, 'volume_reversal_cooldown_hours'):
                cooldown_end = self.volume_reversal_cooldown.get(symbol, 0)
                if cooldown_end and time.time() < cooldown_end:
                    remaining_hours = (cooldown_end - time.time()) / 3600
                    logger.debug(f"Skipping {symbol} due to volume reversal cooldown (remaining: {remaining_hours:.1f}h)")
                    return None
            # Get 1h data for primary signal and regime detection
            df_1h = self.get_klines_data(symbol, interval='1h', limit=200)

            if df_1h is None or df_1h.empty:
                logger.warning(f"Insufficient 1h data for {symbol}, skipping signal check")
                result = SignalResult(
                    triggered=False,
                    reason='insufficient_1h_data',
                    metadata={'symbol': symbol, 'timeframe': '1h'}
                )
                self._record_signal_diagnostics(symbol, result)
                return None

            if not isinstance(df_1h, pd.DataFrame) or 'close' not in df_1h.columns:
                logger.warning(f"Invalid 1h DataFrame structure for {symbol}")
                result = SignalResult(
                    triggered=False,
                    reason='invalid_1h_dataframe',
                    metadata={'symbol': symbol, 'timeframe': '1h'}
                )
                self._record_signal_diagnostics(symbol, result)
                return None

            try:
                # Calculate technical indicators on 1h data - with safety checks
                if hasattr(self, 'market_analyzer') and self.market_analyzer:
                    df_1h = self.market_analyzer.calculate_technical_indicators(df_1h)
                if df_1h is None or df_1h.empty:
                    logger.warning(f"No indicators calculated for {symbol} 1h")
                    result = SignalResult(
                        triggered=False,
                        reason='1h_indicators_error',
                        metadata={'symbol': symbol, 'timeframe': '1h'}
                    )
                    self._record_signal_diagnostics(symbol, result)
                    return None
            except Exception as indicator_error:
                logger.error(f"Error calculating 1h indicators for {symbol}: {indicator_error}")
                logger.error(traceback.format_exc())
                result = SignalResult(
                    triggered=False,
                    reason='1h_indicator_error',
                    metadata={'symbol': symbol, 'timeframe': '1h'}
                )
                self._record_signal_diagnostics(symbol, result)
                return None

            # Determine market regime using 1h data
            regime = determine_regime(df_1h)
            if regime is None:
                logger.debug(f"Could not determine regime for {symbol}")
                result = SignalResult(
                    triggered=False,
                    reason='regime_undetermined',
                    metadata={'symbol': symbol, 'timeframe': '1h'}
                )
                self._record_signal_diagnostics(symbol, result)
                return None

            # If regime switching is disabled, only trade in bullish regime
            # EXCEPT for coins with score > 95 (ultra-high quality override)
            coin_score = self.coin_metrics.get(symbol, {}).get('score', 0)
            high_score_override = coin_score >= 95.0

            if not high_score_override and not self.enable_regime_switching and regime.regime != StrategyRegime.BULLISH:
                logger.debug(f"Skipping {symbol} - regime switching disabled and market is {regime.regime.value} (score: {coin_score:.1f})")
                result = SignalResult(
                    triggered=False,
                    reason=f'regime_{regime.regime.value}_disabled',
                    metadata={
                        'symbol': symbol,
                        'timeframe': '1h',
                        'regime': regime.regime.value,
                        'adx': regime.adx,
                        'volatility': regime.volatility,
                        'coin_score': coin_score
                    }
                )
                self._record_signal_diagnostics(symbol, result)
                return None

            # Get 15m data for multi-timeframe confirmation
            df_15m = None
            if self.enable_multi_timeframe:
                try:
                    df_15m = self.get_klines_data(symbol, interval='15m', limit=200)
                    if df_15m is not None and not df_15m.empty:
                        if hasattr(self, 'market_analyzer') and self.market_analyzer:
                            df_15m = self.market_analyzer.calculate_technical_indicators(df_15m)
                except Exception as mtf_error:
                    logger.warning(f"Error processing 15m data for {symbol}: {mtf_error}")
                    df_15m = None

            # Generate regime-aware signal - with safety checks
            signal = None
            if hasattr(self, 'signal_generator') and self.signal_generator:
                signal = self.signal_generator.generate_signal(symbol, df_1h, regime)

            # Check if we have a valid signal
            if signal is None or signal.confidence < getattr(self.signal_generator, 'min_confidence', 0.7):
                logger.debug(f"No high-confidence regime-aware signal for {symbol}, falling back to legacy signal")
                if regime.regime == StrategyRegime.BULLISH:
                    result = evaluate_long_signal(symbol, df_1h, self.signal_params)
                elif regime.regime == StrategyRegime.BEARISH:
                    result = evaluate_short_signal(symbol, df_1h, self.signal_params)
                else:
                    result = SignalResult(triggered=False, reason='neutral_regime')
            else:
                # Convert RegimeSignal to SignalResult
                result = SignalResult(
                    triggered=True,
                    signal_payload={
                        'symbol': symbol,
                        'side': signal.direction.name.upper(),
                        'price': signal.entry_price,
                        'stop_loss': signal.stop_loss,
                        'take_profit': signal.take_profit,
                        'regime': signal.regime.value,
                        'confidence': signal.confidence,
                        'indicators': signal.indicators,
                        'timestamp': signal.timestamp.isoformat()
                    },
                    metadata={
                        'symbol': symbol,
                        'timeframe': '1h',
                        'regime': signal.regime.value,
                        'confidence': signal.confidence,
                        'confirmed_15m': df_15m is not None and not df_15m.empty
                    }
                )

            self._record_signal_diagnostics(symbol, result)

            if result.triggered and result.signal_payload:
                return result.signal_payload

            return None

        except Exception as e:
            logger.error(f"Error checking entry signal for {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            result = SignalResult(
                triggered=False,
                reason='unexpected_error',
                metadata={'symbol': symbol, 'timeframe': '1h'}
            )
            self._record_signal_diagnostics(symbol, result)
            return None
            
    def calculate_unrealized_pnl(self, position: dict, current_price: float) -> float:
        """Calculate unrealized P&L for a position
        
        Args:
            position: Dictionary containing position details
            current_price: Current market price
            
        Returns:
            float: Unrealized P&L in quote currency
        """
        try:
            entry_price = position.get('entry_price', 0)
            position_amt = abs(position.get('position_amt', 0))
            
            if not entry_price or not position_amt:
                return 0.0
                
            if position.get('side') == 'LONG':
                return (current_price - entry_price) * position_amt
            else:  # SHORT
                return (entry_price - current_price) * position_amt
                
        except Exception as e:
            logger.error(f"Error calculating unrealized P&L: {str(e)}")
            logger.error(traceback.format_exc())
            return 0.0
            
    def update_positions(self):
        """Update open positions and manage exits with enhanced logic"""
        if not self.positions:
            logger.debug("No open positions to update")
            return
            
        current_time = int(time.time())
        logger.debug(f"Updating {len(self.positions)} positions...")
        
        for symbol, position in list(self.positions.items()):
            try:
                # Skip non-OPEN positions
                if position.get('status') != 'OPEN':
                    logger.debug(f"Skipping non-OPEN position: {symbol}")
                    continue
                    
                # Ensure position has all required fields
                if 'entry_price' not in position:
                    logger.warning(f"Position for {symbol} missing entry_price, removing")
                    del self.positions[symbol]
                    continue
                    
                # Ensure position has a side (default to LONG for backward compatibility)
                position.setdefault('side', 'LONG')
                
                # Initialize all required position fields with defaults
                position.setdefault('entry_time', int(time.time()))
                position.setdefault('highest_price', position.get('entry_price', 0))
                position.setdefault('lowest_price', position.get('entry_price', float('inf')))
                position.setdefault('stop_loss', 0)
                position.setdefault('take_profit', 0)
                position.setdefault('initial_atr', 0)
                position.setdefault('atr_percent', 0)
                position.setdefault('current_price', 0)
                position.setdefault('unrealized_pnl', 0)
                position.setdefault('last_updated', 0)
                position.setdefault('last_logged', 0)
                position.setdefault('last_check', 0)
                
                # Get current price and position details
                ticker = self.client.futures_symbol_ticker(symbol=symbol)
                current_price = float(ticker['price'])
                
                # Ensure we have a valid entry price
                if 'entry_price' not in position or position['entry_price'] <= 0:
                    logger.warning(f"Invalid entry price for {symbol}, using current price")
                    position['entry_price'] = current_price
                        
                entry_price = position['entry_price']
                
                # Update position metrics
                position['current_price'] = current_price
                position['unrealized_pnl'] = self.calculate_unrealized_pnl(position, current_price)
                position['last_updated'] = int(time.time())
                
                # Ensure we have valid stop loss level (no fixed TP - exits are based on SuperTrend)
                if position.get('stop_loss', 0) <= 0:
                        # Default to 2% stop loss (no fixed take profit)
                        if position.get('side') == 'LONG':
                            position['stop_loss'] = entry_price * 0.98
                        else:  # SHORT
                            position['stop_loss'] = entry_price * 1.02

                        logger.info(f"Initialized SL for {symbol}: SL={position['stop_loss']:.8f}")
                
                time_in_trade = current_time - position['entry_time']
                
                # Update highest price for trailing stop
                position['highest_price'] = max(position['highest_price'], current_price)
                
                # Get latest market data for indicators
                try:
                    # Get market data with error handling
                    market_data = self.get_klines_data(symbol, '1h', limit=100)
                    if market_data is not None and not market_data.empty:
                        latest = market_data.iloc[-1]
                        
                        # Safely get ATR and other indicators with defaults
                        atr = latest.get('atr', 0) if hasattr(latest, 'get') else 0
                        close = latest.get('close', current_price) if hasattr(latest, 'get') else current_price
                        
                        # Only update indicators if we have valid values
                        if atr and close and atr > 0 and close > 0:
                            atr_percent = (atr / close) * 100
                            position['atr_percent'] = atr_percent
                            
                            # Update initial ATR if not set
                            if position.get('initial_atr', 0) == 0:
                                position['initial_atr'] = atr
                                
                            # Dynamic trailing stop based on ATR
                            if self.enable_trailing_stop and 'initial_atr' in position:
                                atr_multiplier = 1.5  # Adjust this based on your risk tolerance
                                trail_amount = position['initial_atr'] * atr_multiplier
                                
                                if position.get('side') == 'LONG':
                                    # For long positions, trail below the highest price
                                    new_stop = position['highest_price'] - trail_amount
                                    if new_stop > position.get('stop_loss', 0):
                                        position['stop_loss'] = new_stop
                                        logger.info(f"Updated trailing stop for {symbol}: {position['stop_loss']:.8f}")
                                else:  # SHORT
                                    # For short positions, trail above the lowest price
                                    position.setdefault('lowest_price', current_price)
                                    position['lowest_price'] = min(position['lowest_price'], current_price)
                                    new_stop = position['lowest_price'] + trail_amount
                                    if new_stop < position.get('stop_loss', float('inf')) or position.get('stop_loss', 0) == 0:
                                        position['stop_loss'] = new_stop
                                        logger.info(f"Updated trailing stop for {symbol}: {position['stop_loss']:.8f}")
                except Exception as e:
                    logger.error(f"Error getting market data for {symbol}: {str(e)}")
                    logger.error(traceback.format_exc())
                
                # Check stop loss only (TP replaced by SuperTrend exits to avoid re-entry issues during bullish trends)
                # Force close position if absolute stop loss is hit
                side = position.get('side', 'LONG').upper()
                entry_price = position.get('entry_price', 0)
                stop_loss = position.get('stop_loss', 0)

                if entry_price <= 0:
                    logger.warning(f"Invalid entry price {entry_price} for {symbol}, skipping stop loss check")
                    continue

                # Calculate loss percentage
                if side == 'LONG':
                    loss_pct = ((current_price / entry_price) - 1) * 100
                    sl_hit = current_price <= stop_loss
                else:  # SHORT
                    loss_pct = ((entry_price / current_price) - 1) * 100
                    sl_hit = current_price >= stop_loss

                # Force emergency exit if loss exceeds safe threshold (8% in this case)
                emergency_exit = loss_pct <= -8.0  # Emergency exit at 8% loss to prevent huge losses

                if sl_hit or emergency_exit:
                    reason = "EMERGENCY_STOP_LOSS" if emergency_exit else "Stop Loss"
                    logger.critical(f"🚨 {symbol}: {reason} triggered - Loss: {loss_pct:.2f}% (Entry: {entry_price:.8f}, Current: {current_price:.8f}, SL: {stop_loss:.8f})")
                    try:
                        success = self.close_position(symbol, reason, current_price)
                        if success:
                            logger.info(f"✅ Successfully closed {symbol} on {reason}")
                            continue
                        else:
                            logger.error(f"❌ Failed to close {symbol} on {reason}")
                            # Continue trying to close - don't skip position
                    except Exception as close_error:
                        logger.error(f"❌ Critical error closing {symbol}: {str(close_error)}")
                        logger.error(traceback.format_exc())
                        continue
                        # Continue trying to close - don't skip position

                # Log excessive losses for monitoring (even if not at SL yet)
                if loss_pct <= -10.0:  # Warn at 10% loss
                    logger.warning(f"⚠️ {symbol}: Excessive loss {loss_pct:.2f}% (Entry: {entry_price:.8f}, Current: {current_price:.8f}, SL: {stop_loss:.8f})")
                elif loss_pct <= -5.0:  # Info at 5% loss
                    logger.info(f"📊 {symbol}: Significant loss {loss_pct:.2f}% (Entry: {entry_price:.8f}, Current: {current_price:.8f}, SL: {stop_loss:.8f})")
                
                # Update position metrics
                position['current_price'] = current_price
                position['unrealized_pnl'] = self.calculate_unrealized_pnl(position, current_price)
                position['last_updated'] = current_time
                
                # Log position update
                if current_time - position.get('last_logged', 0) > 300:  # Log every 5 minutes
                    pnl_pct = ((current_price / entry_price) - 1) * 100
                    if position.get('side') == 'SHORT':
                        pnl_pct = -pnl_pct  # Invert for short positions
                    logger.info(
                        f"Position Update - {symbol}: {position['side']} | "
                        f"Entry: {entry_price:.8f} | Current: {current_price:.8f} | "
                        f"P&L: {position['unrealized_pnl']:.2f} ({pnl_pct:.2f}%) | "
                        f"SL: {position['stop_loss']:.8f}"
                    )
                    position['last_logged'] = current_time
                
                    # Only check for adjustments every 15 minutes to reduce API calls
                    if current_time - position.get('last_check', 0) < 900:  # 15 minutes
                        continue
                        
                    position['last_check'] = current_time
                    
                    # Calculate current PnL
                    pnl_pct = (current_price / entry_price - 1) * 100
                    
                    # Advanced Exit Strategies
                    exit_reason = self._check_advanced_exit_conditions(symbol, position, current_price, pnl_pct, time_in_trade)
                    if exit_reason:
                        self.close_position(symbol, exit_reason, current_price)
                        continue
                    
                    # Only consider adjusting stops after minimum hold time
                    if time_in_trade < self.min_hold_time:
                        logger.debug(f"{symbol} in cooldown period: {time_in_trade/60:.1f} minutes elapsed")
                        continue
                    
                    # Dynamic trailing stop logic after minimum hold time
                    if pnl_pct > 1.0:  # Only trail if in profit
                        # Calculate dynamic trailing stop based on ATR and price movement
                        atr = position.get('initial_atr', 0)
                        atr_multiplier = 1.5  # Base ATR multiplier
                        
                        # Increase trailing distance as profit increases
                        if pnl_pct > 5.0:
                            atr_multiplier = 1.0
                        elif pnl_pct > 3.0:
                            atr_multiplier = 1.2
                            
                        # Calculate new trailing stop level
                        new_stop = current_price - (atr * atr_multiplier)
                        
                        # Only move stop up, never down
                        if new_stop > position['stop_loss']:
                            old_stop = position['stop_loss']
                            position['stop_loss'] = new_stop
                            position['trailing_stop'] = True
                            
                            # Log the adjustment
                            logger.info(
                                f"Trailing stop updated for {symbol}: "
                                f"{old_stop:.8f} → {new_stop:.8f} "
                                f"(Current: {current_price:.8f}, ATR: {atr:.8f}, PnL: {pnl_pct:.2f}%)"
                            )
                            
                            # Update OCO orders with new stop
                            self.adjust_oco_orders(
                                symbol=symbol,
                                new_stop_loss=new_stop,
                                new_take_profit=position['take_profit']  # Keep original TP
                            )
                    
                    # Time-based profit protection (move stop to breakeven + small buffer)
                    elif time_in_trade > self.min_hold_time * 2:  # After 8 hours
                        breakeven_price = entry_price * 1.001  # 0.1% above entry
                        if current_price > breakeven_price and position['stop_loss'] < breakeven_price:
                            position['stop_loss'] = breakeven_price
                            logger.info(f"Moved stop to breakeven for {symbol} at {breakeven_price:.8f}")
                
            except Exception as e:
                logger.error(f"Error updating position for {symbol}: {str(e)}")
                import traceback
                logger.error(traceback.format_exc())
                continue

    def _check_advanced_exit_conditions(self, symbol: str, position: dict, current_price: float, pnl_pct: float, time_in_trade: float) -> Optional[str]:
        """Check advanced exit conditions using multiple strategies"""
        try:
            entry_price = position.get('entry_price', 0)
            side = position.get('side', 'LONG')

            if entry_price <= 0:
                return None

            # Strategy 1: RSI Divergence Exit (commented out - method not implemented)
            # if hasattr(self, '_check_rsi_divergence_exit'):
            #     rsi_exit = self._check_rsi_divergence_exit(symbol, position, current_price)
            #     if rsi_exit:
            #         return rsi_exit

            # Strategy 2: Volume Profile Exit
            volume_exit = self._check_volume_profile_exit(symbol, position, current_price)
            if volume_exit:
                return volume_exit

            # Strategy 3: Supertrend Exit (15m timeframe trend reversals)
            st_exit = self._check_supertrend_exit(symbol, position, current_price)
            if st_exit:
                return st_exit

            # Strategy 4: Support/Resistance Break Exit (method not implemented)
            # if hasattr(self, '_check_support_resistance_exit'):
            #     sr_exit = self._check_support_resistance_exit(symbol, position, current_price)
            #     if sr_exit:
            #         return sr_exit

            # Strategy 5: Multiple Timeframe Exit
            mtf_exit = self._check_multi_timeframe_exit(symbol, position, current_price)
            if mtf_exit:
                return mtf_exit

            # Strategy 6: Time-based exits with different strategies
            time_exit = self._check_time_based_exits(symbol, position, pnl_pct, time_in_trade)
            if time_exit:
                return time_exit

            return None

        except Exception as e:
            logger.error(f"Error checking advanced exit conditions for {symbol}: {str(e)}")
            return None

    def _check_supertrend_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check for Supertrend trend reversal exit signals on 15m timeframe"""
        try:
            # Get 15m data for Supertrend analysis
            df_15m = self.get_klines_data(symbol, '15m', limit=100)
            if df_15m is None or df_15m.empty or len(df_15m) < 10:
                return None

            # Calculate SuperTrend
            supertrend = pta.supertrend(
                df_15m['high'],
                df_15m['low'],
                df_15m['close'],
                length=7,
                multiplier=3.0
            )

            if supertrend is None or supertrend.empty:
                return None

            st_col = 'SUPERT_7_3.0'
            if st_col not in supertrend.columns:
                return None

            # Get current Supertrend value
            st_value = float(supertrend[st_col].iloc[-1])
            if not np.isfinite(st_value):
                return None

            recent_close = float(df_15m['close'].iloc[-1])
            side = position.get('side', 'LONG')

            # Check for Supertrend breaks indicating trend reversal
            if side == 'LONG' and recent_close < st_value:
                # Price broke below Supertrend in uptrend - bearish reversal
                return 'SUPER_TREND_BREAKDOWN_15M'
            elif side == 'SHORT' and recent_close > st_value:
                # Price broke above Supertrend in downtrend - bullish reversal
                return 'SUPER_TREND_BREAKOUT_15M'

            # Additional check: recent cross confirmation
            # Look for a more recent cross within last few candles
            recent_trend_changes = 0
            for i in range(-3, 0):  # Check last 3 candles (excluding current)
                if i >= -len(supertrend):
                    prev_close = float(df_15m['close'].iloc[i])
                    prev_st = float(supertrend[st_col].iloc[i])
                    if np.isfinite(prev_close) and np.isfinite(prev_st):
                        if side == 'LONG' and prev_close >= prev_st and recent_close < st_value:
                            # Crossed from above to below Supertrend
                            return 'SUPER_TREND_CROSS_DOWN_15M'
                        elif side == 'SHORT' and prev_close <= prev_st and recent_close > st_value:
                            # Crossed from below to above Supertrend
                            return 'SUPER_TREND_CROSS_UP_15M'

            return None

        except Exception as e:
            logger.debug(f"Error checking Supertrend for {symbol}: {e}")
            return None

    def _check_volume_profile_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check volume profile based exit signals with stricter conditions to prevent re-entry"""
        try:
            # Get 4h data for volume analysis
            df_4h = self.get_klines_data(symbol, '4h', limit=100)
            if df_4h.empty or len(df_4h) < 20:
                return None

            side = position.get('side', 'LONG')
            entry_price = position.get('entry_price', 0)
            close_reason = position.get('close_reason', '')

            # STRONG COOLDOWN: Skip volume checks if recently closed due to volume reversal (last 2 hours)
            if 'HIGH_VOLUME_REVERSAL' in close_reason:
                exit_time = position.get('exit_time', 0)
                if exit_time and (time.time() * 1000 - exit_time) < (2 * 60 * 60 * 1000):  # 2 hours
                    return None

            # Volume declining while price moves against position
            recent_volume = df_4h['volume'].tail(5).mean()
            earlier_volume = df_4h['volume'].head(20).tail(15).mean()

            volume_ratio = recent_volume / earlier_volume if earlier_volume > 0 else 1

            # Exit if volume is declining significantly
            if volume_ratio < 0.3:  # Volume dropped by 70% - stricter condition
                price_move_against = (entry_price - current_price) / entry_price if side == 'LONG' else (current_price - entry_price) / entry_price
                if price_move_against > 0.01:  # Price moved 1% against position - stricter
                    return 'VOLUME_DECLINE'

            # High volume reversal - STRONGER validation required
            current_volume = df_4h['volume'].iloc[-1]
            avg_volume = df_4h['volume'].tail(20).mean()

            # REQUIRE much higher volume spike: 3x average (was 1.5x)
            volume_multiplier = 3.0
            if current_volume > avg_volume * volume_multiplier:
                # Check for significant price reversal - 0.5% change (was 0.1%)
                price_change = (current_price - df_4h['close'].iloc[-2]) / df_4h['close'].iloc[-2]

                # Require the reversal to be sustained for multiple candles
                recent_prices = df_4h['close'].tail(3)  # Last 3 candles
                trend_consistent = True

                if side == 'LONG':
                    # All candles should be falling for strong reversal signal
                    trend_consistent = all(recent_prices.iloc[i] < recent_prices.iloc[i-1] for i in range(1, len(recent_prices)))
                    if price_change < -0.005 and trend_consistent:  # 0.5% drop AND consistent downward trend
                        return 'HIGH_VOLUME_REVERSAL'
                else:  # SHORT
                    # All candles should be rising for strong reversal signal
                    trend_consistent = all(recent_prices.iloc[i] > recent_prices.iloc[i-1] for i in range(1, len(recent_prices)))
                    if price_change > 0.005 and trend_consistent:  # 0.5% rise AND consistent upward trend
                        return 'HIGH_VOLUME_REVERSAL'

            return None

        except Exception as e:
            logger.debug(f"Error checking volume profile for {symbol}: {e}")
            return None

    def _check_support_resistance_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check support/resistance level breaks"""
        try:
            # Get daily data for support/resistance
            df_1d = self.get_klines_data(symbol, '1d', limit=100)
            if df_1d.empty or len(df_1d) < 20:
                return None

            side = position.get('side', 'LONG')
            entry_price = position.get('entry_price', 0)

            # Find recent support/resistance levels (simplified)
            recent_highs = df_1d['high'].tail(20)
            recent_lows = df_1d['low'].tail(20)

            resistance_level = recent_highs.max()
            support_level = recent_lows.min()

            # Exit if key levels are broken
            if side == 'LONG':
                # Exit if support level is broken
                if current_price < support_level * 1.002:  # 0.2% buffer
                    return 'SUPPORT_BREAK'
                # Exit if resistance level is far above and we're not making progress
                if resistance_level > current_price * 1.05 and (current_price - entry_price) / entry_price < 0.01:
                    return 'RESISTANCE_STALL'
            else:  # SHORT
                # Exit if resistance level is broken upward
                if current_price > resistance_level * 0.998:  # 0.2% buffer
                    return 'RESISTANCE_BREAK'
                # Exit if support level is far below and we're not making progress
                if support_level < current_price * 0.95 and (entry_price - current_price) / entry_price < 0.01:
                    return 'SUPPORT_STALL'

            return None

        except Exception as e:
            logger.debug(f"Error checking support/resistance for {symbol}: {e}")
            return None

    def _check_rsi_divergence_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check for RSI divergence exit signals"""
        try:
            # Get 15m data for RSI analysis
            df_15m = self.get_klines_data(symbol, '15m', limit=100)
            if df_15m is None or df_15m.empty or len(df_15m) < 20:
                return None

            # Calculate RSI
            if not hasattr(df_15m, 'rsi') or df_15m['rsi'].isna().all():
                df_15m['rsi'] = pta.rsi(df_15m['close'], length=14)

            if df_15m['rsi'].isna().all():
                return None

            # Check if we have both price and RSI data
            if len(df_15m) < 20 or df_15m['rsi'].isna().iloc[-1]:
                return None

            recent_rsi = df_15m['rsi'].dropna()
            if len(recent_rsi) < 10:
                return None

            side = position.get('side', 'LONG')
            entry_price = position.get('entry_price', current_price)

            # Simple divergence detection - if price is rising but RSI is falling (bearish divergence) for longs
            if side == 'LONG':
                recent_prices = df_15m['close'].tail(10)
                recent_rsi_values = recent_rsi.tail(10)

                # Check for bearish divergence (price up, RSI down)
                price_trend = recent_prices.iloc[-1] > recent_prices.iloc[0]  # Price increased
                rsi_trend = recent_rsi_values.iloc[-1] < recent_rsi_values.iloc[0]  # RSI decreased

                if price_trend and rsi_trend:
                    return 'RSI_BEARISH_DIVERGENCE'

            elif side == 'SHORT':
                recent_prices = df_15m['close'].tail(10)
                recent_rsi_values = recent_rsi.tail(10)

                # Check for bullish divergence (price down, RSI up) for shorts
                price_trend = recent_prices.iloc[-1] < recent_prices.iloc[0]  # Price decreased
                rsi_trend = recent_rsi_values.iloc[-1] > recent_rsi_values.iloc[0]  # RSI increased

                if price_trend and rsi_trend:
                    return 'RSI_BULLISH_DIVERGENCE'

            return None

        except Exception as e:
            logger.debug(f"Error checking RSI divergence for {symbol}: {e}")
            return None

    def _check_support_resistance_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check support/resistance level breaks"""
        try:
            # Get 4h data for support/resistance
            df_4h = self.get_klines_data(symbol, '4h', limit=50)
            if df_4h is None or df_4h.empty or len(df_4h) < 30:
                return None

            # Find recent swing highs and lows
            highs = df_4h['high'].rolling(10, center=True).max()
            lows = df_4h['low'].rolling(10, center=True).min()

            # Get recent resistance/support levels
            recent_high_resistance = highs.tail(20).max()
            recent_low_support = lows.tail(20).min()

            side = position.get('side', 'LONG')

            # Exit if current price breaks key levels
            if side == 'LONG':
                # Exit if price drops below recent support level
                if current_price < recent_low_support * 1.005:  # 0.5% buffer
                    return 'SUPPORT_BREAK_4H'
            else:  # SHORT
                # Exit if price rises above recent resistance level
                if current_price > recent_high_resistance * 0.995:  # 0.5% buffer
                    return 'RESISTANCE_BREAK_4H'

            return None

        except Exception as e:
            logger.debug(f"Error checking support/resistance for {symbol}: {e}")
            return None

    def _check_multi_timeframe_exit(self, symbol: str, position: dict, current_price: float) -> Optional[str]:
        """Check multiple timeframe alignment for exits"""
        try:
            side = position.get('side', 'LONG')

            # Get multiple timeframes
            timeframes = ['15m', '1h', '4h']
            trend_alignment = []

            for tf in timeframes:
                df = self.get_klines_data(symbol, tf, limit=50)
                if df.empty or len(df) < 10:
                    continue

                # Simple trend determination using moving averages
                df['sma_10'] = df['close'].rolling(10).mean()
                df['sma_20'] = df['close'].rolling(20).mean()

                if len(df) >= 20:
                    current_sma10 = df['sma_10'].iloc[-1]
                    current_sma20 = df['sma_20'].iloc[-1]

                    if side == 'LONG':
                        trend_alignment.append(current_sma10 > current_sma20)
                    else:
                        trend_alignment.append(current_sma10 < current_sma20)

            # Exit if majority of timeframes show opposing trend
            if len(trend_alignment) >= 2:
                opposing_trends = sum(1 for x in trend_alignment if not x)
                if opposing_trends >= 2:  # 2 out of 3 timeframes opposing
                    return 'MULTI_TIMEFRAME_DIVERGENCE'

            return None

        except Exception as e:
            logger.debug(f"Error checking multi-timeframe for {symbol}: {e}")
            return None

    def _check_time_based_exits(self, symbol: str, position: dict, pnl_pct: float, time_in_trade: float) -> Optional[str]:
        """Check various time-based exit strategies"""
        try:
            # Exit at market close (if applicable) - 15 minutes before
            current_hour = datetime.now().hour
            if time_in_trade > 3600 and current_hour >= 22:  # After 1 hour and near market close
                return 'MARKET_CLOSE_PROTECTION'

            # Weekend exit protection
            current_weekday = datetime.now().weekday()
            if current_weekday >= 5 and time_in_trade > 1800:  # Weekend and held for 30 minutes
                return 'WEEKEND_PROTECTION'

            # Profit taking at specific intervals
            if pnl_pct > 0:
                # Take profits at fibonacci levels
                fib_levels = [0.236, 0.382, 0.618, 1.0, 1.618]
                for level in fib_levels:
                    if pnl_pct >= level * 100:  # Convert to percentage
                        return f'FIBONACCI_PROFIT_{level}'

            # Emergency exit if held too long without profit
            if time_in_trade > self.max_hold_time * 0.8 and pnl_pct < 0.5:
                return 'EMERGENCY_TIME_EXIT'

            return None

        except Exception as e:
            logger.debug(f"Error checking time-based exits for {symbol}: {e}")
            return None
            
    def cancel_oco_orders(self, symbol: str, oco_id: str = None) -> bool:
        """Cancel OCO orders for a symbol.
        
        Args:
            symbol: Trading pair symbol
            oco_id: Optional base ID of the OCO group to cancel
            
        Returns:
            bool: True if all orders were cancelled successfully, False otherwise
        """
        try:
            if oco_id:
                # Cancel specific OCO group
                orders = self.client.futures_get_open_orders(symbol=symbol)
                for order in orders:
                    client_id = order.get('clientOrderId', '')
                    if client_id and client_id.startswith(oco_id):
                        self.client.futures_cancel_order(
                            symbol=symbol,
                            orderId=order['orderId']
                        )
                logger.info(f"Cancelled OCO group {oco_id} for {symbol}")
            else:
                # Cancel all OCO orders for the symbol
                orders = self.client.futures_get_open_orders(symbol=symbol)
                for order in orders:
                    if order.get('clientOrderId', '').startswith('oco_'):
                        self.client.futures_cancel_order(
                            symbol=symbol,
                            orderId=order['orderId']
                        )
                logger.info(f"Cancelled all OCO orders for {symbol}")
                
            return True
            
        except Exception as e:
            logger.error(f"Error cancelling OCO orders for {symbol}: {e}")
            return False
    
    def adjust_oco_orders(self, symbol: str, new_stop_loss: float, new_take_profit: float) -> bool:
        """Adjust OCO orders for a symbol with new stop loss and take profit levels.
        
        Args:
            symbol: Trading pair symbol
            new_stop_loss: New stop loss price
            new_take_profit: New take profit price
            
        Returns:
            bool: True if orders were adjusted successfully, False otherwise
        """
        try:
            # Cancel existing OCO orders first
            self.cancel_oco_orders(symbol)
            
            # Get current position
            if symbol not in self.positions:
                logger.warning(f"No position found for {symbol}, cannot adjust OCO orders")
                return False
                
            position = self.positions[symbol]
            quantity = abs(position.get('position_amt', 0))
            side = position.get('side', 'LONG')
            
            if quantity <= 0:
                logger.warning(f"Invalid quantity {quantity} for {symbol}, cannot adjust OCO orders")
                return False
            
            if not self.paper_trading:
                try:
                    # Create new OCO order with updated levels
                    oco_id = f"oco_{symbol}_{int(time.time())}"
                    
                    order_side = 'SELL' if side == 'LONG' else 'BUY'
                    
                    # Place stop loss order
                    stop_order = self.client.futures_create_order(
                        symbol=symbol,
                        side=order_side,
                        type='STOP_MARKET',
                        quantity=quantity,
                        stopPrice=new_stop_loss,
                        reduceOnly=True,
                        clientOrderId=f"{oco_id}_sl"
                    )
                    
                    # Place take profit order  
                    tp_order = self.client.futures_create_order(
                        symbol=symbol,
                        side=order_side,
                        type='TAKE_PROFIT_MARKET',
                        quantity=quantity,
                        stopPrice=new_take_profit,
                        reduceOnly=True,
                        clientOrderId=f"{oco_id}_tp"
                    )
                    
                    logger.info(f"Adjusted OCO orders for {symbol}: SL={new_stop_loss:.8f}, TP={new_take_profit:.8f}")
                    return True
                    
                except Exception as e:
                    logger.error(f"Error adjusting OCO orders for {symbol}: {str(e)}")
                    logger.error(traceback.format_exc())
                    return False
            else:
                logger.info(f"[PAPER] Would adjust OCO for {symbol}: SL={new_stop_loss:.8f}, TP={new_take_profit:.8f}")
                return True
                
        except Exception as e:
            logger.error(f"Error in adjust_oco_orders for {symbol}: {str(e)}")
            logger.error(traceback.format_exc())
            return False
    
    def _check_exchange_connection(self) -> bool:
        """Check if we can connect to the exchange."""
        try:
            # Simple ping to check connection
            self.client.futures_ping()
            return True
        except Exception as e:
            logger.error(f"Exchange connection check failed: {e}")
            return False
def cleanup_resources():
    """Clean up any global resources"""
    try:
        # Close any open database connections, file handles, etc.
        # This is a good place to add any global cleanup code
        
        # Flush logger to ensure all messages are written
        for handler in logging.root.handlers:
            handler.flush()
            
    except Exception as e:
        # Use print here since the logger might be closed
        print(f"Error during cleanup: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    bot = None
    try:
        # Parse command line arguments
        import argparse
        parser = argparse.ArgumentParser(description='Zero Lag Trading Bot')
        parser.add_argument('--paper', action='store_true', help='Run in paper trading mode (no real trades)')
        parser.add_argument('--symbols', type=str, help='Comma-separated list of symbols to trade')
        parser.add_argument('--sync-time', action='store_true', help='Synchronize local clock with Binance server before connecting')
        parser.add_argument('--no-sync-time', action='store_true', help='Disable time synchronization with Binance server')
        args = parser.parse_args()

        # Initialize and run the bot
        try:
            # Default to live trading (real trades) unless --paper is set
            bot = ZeroLagBot(paper_trading=args.paper, sync_time=args.sync_time)

            if args.sync_time:
                try:
                    offset = sync_client_time(bot.client)
                    logger.info(f"Time synchronized with Binance server. Offset: {offset} ms")
                except Exception as sync_error:
                    logger.warning(f"Failed to sync time with Binance: {sync_error}")

            # Override symbols if provided
            if args.symbols:
                bot.symbols = [s.strip().upper() for s in args.symbols.split(',') if s.strip()]

            print(f"\n=== TRADING CONFIGURATION ===")
            print(f"Mode: {'PAPER TRADING' if args.paper else 'LIVE TRADING'}")
            print(f"Trading symbols: {', '.join(bot.symbols)}")
            print(f"Max margin: {bot.max_margin*100}%")
            print(f"Trade size: {bot.trade_size*100}%")
            print(f"Take profit: {bot.take_profit*100}%")
            print(f"Stop loss: {bot.stop_loss*100}%")
            print("\n=== STARTING BOT ===\n")

            # Start Telegram bot controller if configured
            try:
                if bot.telegram_controller.is_configured():
                    print("Starting Telegram bot controller...")
                    bot.telegram_controller.start()
                    print("✅ Telegram bot controller started successfully")
                else:
                    print("⚠️  Telegram bot not configured - check TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env")
            except Exception as telegram_error:
                print(f"❌ Failed to start Telegram bot: {telegram_error}")
                print("Bot will continue running without Telegram control")

            # Start the bot
            bot.run()

        except Exception as e:
            logger.critical(f"Failed to initialize bot: {str(e)}", exc_info=True)
            raise

    except KeyboardInterrupt:
        logger.info("Shutdown requested by user...")
    except Exception as e:
        logger.critical(f"Fatal error: {str(e)}", exc_info=True)
        import traceback
        traceback.print_exc()
    finally:
        print("\n=== Bot shutdown complete ===")
