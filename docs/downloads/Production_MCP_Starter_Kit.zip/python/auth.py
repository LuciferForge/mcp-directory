"""
Security middleware: API key validation and authorization.
"""
import hmac

class SecurityGuard:
    def __init__(self, api_key: str):
        self.api_key = api_key

    def verify_token(self, token: str) -> bool:
        if not token:
            return False
        return hmac.compare_digest(self.api_key, token.strip())
