# ClawGuard Prompt-Shield Middleware Pro
Turnkey zero-trust AI security proxy. Run python sanitizer.py to test input inspection.
