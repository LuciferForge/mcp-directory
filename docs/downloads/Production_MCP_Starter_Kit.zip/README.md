# Production MCP Server Starter Kit & Boilerplate (Python & TypeScript)
**Architected by Protodex (https://protodex.io)**

## What Is Included
1. **Python Production Stack (`python/`)**:
   - `server.py`: Complete FastMCP server implementation supporting both Local Stdio (Claude/Cursor) and Remote SSE (Server-Sent Events) network transports.
   - `auth.py`: Token & HMAC authentication interceptor.
   - `rate_limiter.py`: Sliding-window client rate limiter.
2. **TypeScript / Node Stack (`typescript/`)**:
   - Full `@modelcontextprotocol/sdk` implementation with type-safe tool definitions and zod schema validation.
3. **Deployment Assets (`deploy/`)**:
   - Production `Dockerfile` and `docker-compose.yml`.
   - `cloudflare-worker.js` Remote MCP proxy for Cloudflare edge deployment.

## Quickstart (Python)
```bash
cd python
pip install -r requirements.txt

# Run locally with Claude Desktop / Cursor (Stdio mode):
python server.py

# Run remotely in Docker / Cloud (SSE mode):
MCP_TRANSPORT=sse PORT=8000 python server.py
```

## Quickstart (TypeScript)
```bash
cd typescript
npm install
npm run build
npm start
```

## Configuring in Claude Desktop
Add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "my-production-server": {
      "command": "python",
      "args": ["/path/to/python/server.py"]
    }
  }
}
```

## Commercial License
Commercial use is included. You may freely use, modify, and deploy this codebase to build and sell your own proprietary MCP servers.
