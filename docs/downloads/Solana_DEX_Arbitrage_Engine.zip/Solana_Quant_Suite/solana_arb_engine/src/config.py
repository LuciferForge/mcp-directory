"""Configuration loader for the Solana Arbitrage Engine."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Any


@dataclass
class DexPrograms:
    raydium_amm_v4: str = "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"
    raydium_cpmm: str = "CPMDWBwJDtYvt9BwfNBF2Cg9qecHMVUQuAn37utE445q"
    meteora_dlmm: str = "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"
    pump_fun: str = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
    spl_token: str = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
    token_2022: str = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


@dataclass
class SimulationConfig:
    initial_sol_balance: float = 10.0
    log_file: str = "logs/simulation_pnl.jsonl"
    synthetic_event_interval_sec: float = 1.0
    mock_network_latency_ms: int = 45


@dataclass
class EngineConfig:
    rpc_url: str = "https://api.mainnet-beta.solana.com"
    ws_url: str = "wss://api.mainnet-beta.solana.com"
    min_profit_sol: float = 0.005
    max_trade_sol: float = 5.0
    min_trade_sol: float = 0.1
    max_tip_sol: float = 0.05
    tip_percentage: float = 0.50
    slippage_tolerance_bps: int = 50
    dex_programs: DexPrograms = field(default_factory=DexPrograms)
    simulation: SimulationConfig = field(default_factory=SimulationConfig)

    @classmethod
    def load(cls, config_path: str | Path | None = None) -> EngineConfig:
        """Load engine configuration from a JSON file or environment variables."""
        if config_path is None:
            # Look in parent of src or current working directory
            candidate_paths = [
                Path(__file__).resolve().parent.parent / "config.json",
                Path("config.json"),
            ]
            for p in candidate_paths:
                if p.is_file():
                    config_path = p
                    break

        if config_path and Path(config_path).is_file():
            with open(config_path, "r", encoding="utf-8") as f:
                raw_data: Dict[str, Any] = json.load(f)

            dex_data = raw_data.get("dex_programs", {})
            sim_data = raw_data.get("simulation", {})

            return cls(
                rpc_url=os.getenv("SOLANA_RPC_URL", raw_data.get("rpc_url", cls.rpc_url)),
                ws_url=os.getenv("SOLANA_WS_URL", raw_data.get("ws_url", cls.ws_url)),
                min_profit_sol=float(raw_data.get("min_profit_sol", cls.min_profit_sol)),
                max_trade_sol=float(raw_data.get("max_trade_sol", cls.max_trade_sol)),
                min_trade_sol=float(raw_data.get("min_trade_sol", cls.min_trade_sol)),
                max_tip_sol=float(raw_data.get("max_tip_sol", cls.max_tip_sol)),
                tip_percentage=float(raw_data.get("tip_percentage", cls.tip_percentage)),
                slippage_tolerance_bps=int(raw_data.get("slippage_tolerance_bps", cls.slippage_tolerance_bps)),
                dex_programs=DexPrograms(
                    raydium_amm_v4=dex_data.get("raydium_amm_v4", DexPrograms.raydium_amm_v4),
                    raydium_cpmm=dex_data.get("raydium_cpmm", DexPrograms.raydium_cpmm),
                    meteora_dlmm=dex_data.get("meteora_dlmm", DexPrograms.meteora_dlmm),
                    pump_fun=dex_data.get("pump_fun", DexPrograms.pump_fun),
                    spl_token=dex_data.get("spl_token", DexPrograms.spl_token),
                    token_2022=dex_data.get("token_2022", DexPrograms.token_2022),
                ),
                simulation=SimulationConfig(
                    initial_sol_balance=float(sim_data.get("initial_sol_balance", SimulationConfig.initial_sol_balance)),
                    log_file=sim_data.get("log_file", SimulationConfig.log_file),
                    synthetic_event_interval_sec=float(sim_data.get("synthetic_event_interval_sec", SimulationConfig.synthetic_event_interval_sec)),
                    mock_network_latency_ms=int(sim_data.get("mock_network_latency_ms", SimulationConfig.mock_network_latency_ms)),
                ),
            )
        return cls()
