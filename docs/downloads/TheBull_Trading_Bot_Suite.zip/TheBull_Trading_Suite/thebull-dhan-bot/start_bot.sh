#!/usr/bin/env bash
# ==============================================================================
# TheBull Dhan 80/20 Hybrid Trading Bot - Linux / macOS Launcher
# ==============================================================================

set -e

echo "=============================================================================="
echo "                THEBULL - DHAN 80/20 HYBRID TRADING BOT"
echo "=============================================================================="
echo ""

# 1. Check Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 is not installed!"
    echo "Please install Python 3.10+ (e.g. sudo apt install python3 python3-venv)"
    exit 1
fi

# 2. Virtual Environment
if [ ! -d ".venv" ]; then
    echo "[SETUP] Creating isolated Python virtual environment (.venv)..."
    python3 -m venv .venv
fi

# 3. Activate
source .venv/bin/activate

# 4. Install dependencies
echo "[SETUP] Checking and installing dependencies..."
pip install --upgrade pip > /dev/null 2>&1
pip install -r requirements.txt

# 5. Check .env
if [ ! -f ".env" ]; then
    echo "[SETUP] Creating .env from .env.example..."
    cp .env.example .env
    echo ""
    echo "=============================================================================="
    echo "[ACTION REQUIRED] Please edit '.env' with your Dhan API credentials:"
    echo "  nano .env  or  vim .env"
    echo "=============================================================================="
    echo ""
    read -p "Press Enter after you have saved your credentials in .env to proceed..."
fi

# 6. Run Bot
echo ""
echo "=============================================================================="
echo "[LAUNCHING] Starting TheBull Dhan 80/20 Hybrid Daemon..."
echo "Press CTRL+C at any time to safely stop the bot."
echo "=============================================================================="
echo ""
python3 dhan_bot.py --daemon "$@"
