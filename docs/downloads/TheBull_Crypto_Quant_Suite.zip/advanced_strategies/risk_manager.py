"""
Risk Management Module for Graphiti Trading Bot
"""
import logging
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

@dataclass
class Position:
    symbol: str
    entry_price: float
    quantity: float
    side: str  # 'long' or 'short'
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    timestamp: float = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now().timestamp()
        if self.metadata is None:
            self.metadata = {}
    
    def to_dict(self) -> Dict:
        """Convert position to dictionary for serialization"""
        return {
            'symbol': self.symbol,
            'entry_price': self.entry_price,
            'quantity': self.quantity,
            'side': self.side,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit,
            'timestamp': self.timestamp,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Position':
        """Create Position from dictionary"""
        return cls(**data)

class RiskManager:
    """Manages risk across the trading portfolio"""
    
    def __init__(self, config: Dict = None):
        """
        Initialize the risk manager
        
        Args:
            config: Risk management configuration
        """
        self.config = config or {}
        self.positions: Dict[str, Position] = {}
        self.trade_history: List[Dict] = []
        self.portfolio_value = self.config.get('initial_balance', 10000.0)
        self.max_drawdown_pct = self.config.get('max_drawdown_pct', 10.0)
        self.max_position_risk = self.config.get('max_position_risk', 1.0)  # % of portfolio
        self.max_portfolio_risk = self.config.get('max_portfolio_risk', 10.0)  # % of portfolio
        self.risk_reward_ratio = self.config.get('risk_reward_ratio', 2.0)
        self.volatility_lookback = self.config.get('volatility_lookback', 14)  # days
        self.position_sizing_method = self.config.get('position_sizing_method', 'fixed_fractional')
        
        # Load state if exists
        self._load_state()
    
    def _load_state(self, filepath: str = 'risk_manager_state.json') -> bool:
        """Load risk manager state from file"""
        try:
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    state = json.load(f)
                    
                self.portfolio_value = state.get('portfolio_value', self.portfolio_value)
                self.positions = {
                    k: Position.from_dict(v) 
                    for k, v in state.get('positions', {}).items()
                }
                self.trade_history = state.get('trade_history', [])
                return True
            return False
        except Exception as e:
            logger.error(f"Error loading risk manager state: {e}")
            return False
    
    def save_state(self, filepath: str = 'risk_manager_state.json') -> bool:
        """Save risk manager state to file"""
        try:
            state = {
                'portfolio_value': self.portfolio_value,
                'positions': {k: v.to_dict() for k, v in self.positions.items()},
                'trade_history': self.trade_history[-1000:],  # Keep last 1000 trades
                'timestamp': datetime.now().isoformat()
            }
            
            with open(filepath, 'w') as f:
                json.dump(state, f, indent=2)
                
            return True
        except Exception as e:
            logger.error(f"Error saving risk manager state: {e}")
            return False
    
    def calculate_position_size(
        self, 
        symbol: str, 
        entry_price: float, 
        stop_loss: float, 
        side: str = 'long'
    ) -> Tuple[float, Dict]:
        """
        Calculate position size based on risk parameters
        
        Args:
            symbol: Trading pair symbol
            entry_price: Entry price
            stop_loss: Stop loss price
            side: 'long' or 'short'
            
        Returns:
            Tuple of (quantity, risk_metrics)
        """
        try:
            # Calculate risk per share
            if side == 'long':
                risk_per_share = entry_price - stop_loss
            else:  # short
                risk_per_share = stop_loss - entry_price
                
            if risk_per_share <= 0:
                logger.warning(f"Invalid stop loss for {symbol}: {stop_loss}")
                return 0.0, {}
            
            # Calculate position risk
            position_risk = self.portfolio_value * (self.max_position_risk / 100.0)
            
            # Calculate position size
            if self.position_sizing_method == 'fixed_fractional':
                quantity = position_risk / risk_per_share
            elif self.position_sizing_method == 'volatility_adjusted':
                # Implement volatility-based sizing if needed
                quantity = position_risk / risk_per_share
            else:
                quantity = position_risk / risk_per_share
            
            # Calculate position value
            position_value = quantity * entry_price
            
            # Ensure position doesn't exceed available balance
            max_position_value = self.portfolio_value * 0.1  # Max 10% per position
            if position_value > max_position_value:
                quantity = max_position_value / entry_price
                position_value = quantity * entry_price
            
            # Calculate risk metrics
            risk_metrics = {
                'risk_per_share': risk_per_share,
                'position_risk': position_risk,
                'position_value': position_value,
                'position_value_pct': (position_value / self.portfolio_value) * 100,
                'risk_reward_ratio': self.risk_reward_ratio,
                'take_profit': self._calculate_take_profit(entry_price, stop_loss, side),
                'stop_loss': stop_loss
            }
            
            return quantity, risk_metrics
            
        except Exception as e:
            logger.error(f"Error calculating position size for {symbol}: {e}")
            return 0.0, {}
    
    def _calculate_take_profit(
        self, 
        entry_price: float, 
        stop_loss: float, 
        side: str
    ) -> float:
        """Calculate take profit price based on risk-reward ratio"""
        if side == 'long':
            return entry_price + (entry_price - stop_loss) * self.risk_reward_ratio
        else:  # short
            return entry_price - (stop_loss - entry_price) * self.risk_reward_ratio
    
    def check_position_risk(self, position: Position, current_price: float) -> Dict:
        """
        Check if a position is within risk limits
        
        Args:
            position: Position to check
            current_price: Current market price
            
        Returns:
            Dict with risk assessment
        """
        try:
            if position.side == 'long':
                pnl_pct = (current_price / position.entry_price - 1) * 100
                drawdown_pct = ((position.entry_price - current_price) / position.entry_price) * 100
            else:  # short
                pnl_pct = (1 - current_price / position.entry_price) * 100
                drawdown_pct = ((current_price - position.entry_price) / position.entry_price) * 100
            
            # Check stop loss
            stop_loss_triggered = False
            if position.stop_loss is not None:
                if (position.side == 'long' and current_price <= position.stop_loss) or \
                   (position.side == 'short' and current_price >= position.stop_loss):
                    stop_loss_triggered = True
            
            # Check take profit
            take_profit_triggered = False
            if position.take_profit is not None:
                if (position.side == 'long' and current_price >= position.take_profit) or \
                   (position.side == 'short' and current_price <= position.take_profit):
                    take_profit_triggered = True
            
            return {
                'pnl_pct': pnl_pct,
                'drawdown_pct': drawdown_pct,
                'stop_loss_triggered': stop_loss_triggered,
                'take_profit_triggered': take_profit_triggered,
                'current_price': current_price,
                'timestamp': datetime.now().timestamp()
            }
            
        except Exception as e:
            logger.error(f"Error checking position risk: {e}")
            return {}
    
    def check_portfolio_risk(self, positions: Dict[str, Position], prices: Dict[str, float]) -> Dict:
        """
        Check portfolio-wide risk metrics
        
        Args:
            positions: Dictionary of positions
            prices: Dictionary of current prices
            
        Returns:
            Dict with portfolio risk metrics
        """
        try:
            total_value = self.portfolio_value
            total_risk = 0.0
            total_drawdown = 0.0
            position_metrics = {}
            
            for symbol, position in positions.items():
                if symbol not in prices:
                    continue
                    
                current_price = prices[symbol]
                metrics = self.check_position_risk(position, current_price)
                
                if not metrics:
                    continue
                    
                position_value = position.quantity * current_price
                position_risk = abs(metrics['drawdown_pct']) * position_value / 100.0
                
                total_risk += position_risk
                total_drawdown += position_value * (metrics['drawdown_pct'] / 100.0)
                
                position_metrics[symbol] = {
                    **metrics,
                    'position_value': position_value,
                    'position_value_pct': (position_value / total_value) * 100,
                    'position_risk': position_risk,
                    'position_risk_pct': (position_risk / total_value) * 100
                }
            
            portfolio_risk_pct = (total_risk / total_value) * 100 if total_value > 0 else 0.0
            portfolio_drawdown_pct = (abs(total_drawdown) / total_value) * 100 if total_value > 0 else 0.0
            
            return {
                'total_value': total_value,
                'total_risk': total_risk,
                'total_risk_pct': portfolio_risk_pct,
                'total_drawdown': total_drawdown,
                'total_drawdown_pct': portfolio_drawdown_pct,
                'max_drawdown_pct': self.max_drawdown_pct,
                'max_portfolio_risk_pct': self.max_portfolio_risk,
                'positions': position_metrics,
                'timestamp': datetime.now().timestamp()
            }
            
        except Exception as e:
            logger.error(f"Error checking portfolio risk: {e}")
            return {}
    
    def update_portfolio_value(self, new_value: float) -> None:
        """Update the portfolio value"""
        self.portfolio_value = new_value
        self.save_state()
    
    def add_position(self, position: Position) -> bool:
        """Add a new position to the portfolio"""
        try:
            if position.symbol in self.positions:
                logger.warning(f"Position for {position.symbol} already exists")
                return False
                
            self.positions[position.symbol] = position
            
            # Add to trade history
            self.trade_history.append({
                'type': 'open',
                'symbol': position.symbol,
                'side': position.side,
                'price': position.entry_price,
                'quantity': position.quantity,
                'timestamp': position.timestamp,
                'metadata': position.metadata
            })
            
            self.save_state()
            return True
            
        except Exception as e:
            logger.error(f"Error adding position: {e}")
            return False
    
    def close_position(self, symbol: str, exit_price: float, reason: str = 'manual') -> Optional[Position]:
        """Close an existing position"""
        try:
            if symbol not in self.positions:
                logger.warning(f"No position found for {symbol}")
                return None
                
            position = self.positions.pop(symbol)
            
            # Calculate P&L
            if position.side == 'long':
                pnl_pct = (exit_price / position.entry_price - 1) * 100
            else:  # short
                pnl_pct = (1 - exit_price / position.entry_price) * 100
            
            pnl_amount = position.quantity * exit_price - position.quantity * position.entry_price
            if position.side == 'short':
                pnl_amount = -pnl_amount
            
            # Update portfolio value
            self.portfolio_value += pnl_amount
            
            # Add to trade history
            self.trade_history.append({
                'type': 'close',
                'symbol': symbol,
                'side': position.side,
                'price': exit_price,
                'quantity': position.quantity,
                'pnl_pct': pnl_pct,
                'pnl_amount': pnl_amount,
                'reason': reason,
                'timestamp': datetime.now().timestamp(),
                'entry_price': position.entry_price,
                'hold_time': (datetime.now().timestamp() - position.timestamp) / 3600  # in hours
            })
            
            self.save_state()
            return position
            
        except Exception as e:
            logger.error(f"Error closing position {symbol}: {e}")
            return None
    
    def get_performance_metrics(self, days: int = 30) -> Dict:
        """Get performance metrics for the specified period"""
        try:
            end_time = datetime.now().timestamp()
            start_time = end_time - (days * 24 * 3600)
            
            # Filter trades within the period
            recent_trades = [
                t for t in self.trade_history 
                if t.get('type') == 'close' and start_time <= t.get('timestamp', 0) <= end_time
            ]
            
            if not recent_trades:
                return {}
            
            # Calculate metrics
            winning_trades = [t for t in recent_trades if t.get('pnl_pct', 0) > 0]
            losing_trades = [t for t in recent_trades if t.get('pnl_pct', 0) <= 0]
            
            total_trades = len(recent_trades)
            win_rate = (len(winning_trades) / total_trades * 100) if total_trades > 0 else 0
            
            avg_win = np.mean([t.get('pnl_pct', 0) for t in winning_trades]) if winning_trades else 0
            avg_loss = abs(np.mean([t.get('pnl_pct', 0) for t in losing_trades])) if losing_trades else 0
            
            profit_factor = (len(winning_trades) * avg_win) / (len(losing_trades) * avg_loss) \
                if losing_trades and avg_loss != 0 else float('inf')
            
            return {
                'period_days': days,
                'total_trades': total_trades,
                'winning_trades': len(winning_trades),
                'losing_trades': len(losing_trades),
                'win_rate': win_rate,
                'avg_win_pct': avg_win,
                'avg_loss_pct': avg_loss,
                'profit_factor': profit_factor,
                'total_pnl_pct': sum(t.get('pnl_pct', 0) for t in recent_trades),
                'start_time': start_time,
                'end_time': end_time,
                'timestamp': datetime.now().timestamp()
            }
            
        except Exception as e:
            logger.error(f"Error calculating performance metrics: {e}")
            return {}
    
    def get_position(self, symbol: str) -> Optional[Position]:
        """Get position by symbol"""
        return self.positions.get(symbol)
    
    def get_all_positions(self) -> Dict[str, Position]:
        """Get all open positions"""
        return self.positions
    
    def get_trade_history(self, limit: int = 100) -> List[Dict]:
        """Get recent trade history"""
        return self.trade_history[-limit:] if self.trade_history else []
    
    def get_portfolio_summary(self) -> Dict:
        """Get portfolio summary"""
        return {
            'portfolio_value': self.portfolio_value,
            'open_positions': len(self.positions),
            'total_trades': len(self.trade_history),
            'last_updated': datetime.now().isoformat()
        }
