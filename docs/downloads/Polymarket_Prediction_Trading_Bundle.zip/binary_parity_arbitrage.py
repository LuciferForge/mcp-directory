#!/usr/bin/env python3
"""
Polymarket Binary Parity Arbitrage Scanner
Scans all active CLOB orderbooks for Yes + No < $0.985 (Guaranteed Risk-Free Spread)
"""
import requests
import time

CLOB_URL = "https://clob.polymarket.com"
GAMMA_URL = "https://gamma-api.polymarket.com"

def scan_parity():
    print("[ParityArb] Scanning active prediction markets for mispriced binary pairs...")
    r = requests.get(f"{GAMMA_URL}/events?limit=50&active=true&closed=false", timeout=10)
    if r.status_code != 200:
        return
    events = r.json()
    for ev in events:
        for m in ev.get("markets", []):
            try:
                outcomes = json.loads(m.get("outcomePrices", "[]"))
                if len(outcomes) == 2:
                    p_yes, p_no = float(outcomes[0]), float(outcomes[1])
                    total = p_yes + p_no
                    if total < 0.985 and total > 0.5:
                        print(f"  [ARBITRAGE FOUND] {m.get('question')} | Yes={p_yes} + No={p_no} = {total:.3f} | Net Spread: {(1.0-total)*100:.2f}%")
            except Exception:
                continue

if __name__ == "__main__":
    scan_parity()
