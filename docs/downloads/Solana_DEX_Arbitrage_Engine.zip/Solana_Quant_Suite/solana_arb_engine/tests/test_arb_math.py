"""Unit tests for AMM, Concentrated Liquidity, and Arbitrage Routing Math."""

import unittest
from src.arb_math import (
    AMMMath,
    DLMMMath,
    PumpFunMath,
    ArbCalculator,
    PoolState,
)


class TestArbMath(unittest.TestCase):
    def test_amm_constant_product_output(self):
        """Verify AMM constant-product get_amount_out math matches exact x*y=k formula."""
        # 100 SOL reserve, 1,000,000 Token reserve, 0.25% fee (25 bps)
        reserve_in = 100_000_000_000     # 100 SOL (lamports)
        reserve_out = 1_000_000_000_000  # 1M tokens
        amount_in = 1_000_000_000        # 1 SOL

        result = AMMMath.get_amount_out(
            amount_in=amount_in,
            reserve_in=reserve_in,
            reserve_out=reserve_out,
            fee_bps=25,
        )

        self.assertGreater(result.amount_out, 0)
        self.assertLess(result.amount_out, reserve_out)
        self.assertEqual(result.amount_in, amount_in)
        self.assertGreater(result.fee_paid, 0)

        # Invariant check: (x + dx_net) * (y - dy) >= x * y
        dx_net = amount_in - result.fee_paid
        k_before = reserve_in * reserve_out
        k_after = (reserve_in + dx_net) * (reserve_out - result.amount_out)
        self.assertGreaterEqual(k_after, k_before)

    def test_amm_get_amount_in_matches_amount_out(self):
        """Verify get_amount_in yields the required input for a given amount_out."""
        reserve_in = 50_000_000_000
        reserve_out = 500_000_000_000
        desired_out = 1_000_000_000

        calculated_in = AMMMath.get_amount_in(
            amount_out=desired_out,
            reserve_in=reserve_in,
            reserve_out=reserve_out,
            fee_bps=25,
        )

        # Execute get_amount_out with that calculated_in
        res = AMMMath.get_amount_out(
            amount_in=calculated_in,
            reserve_in=reserve_in,
            reserve_out=reserve_out,
            fee_bps=25,
        )
        self.assertGreaterEqual(res.amount_out, desired_out)

    def test_price_impact_increases_with_trade_size(self):
        """Larger trades should induce higher slippage / price impact."""
        reserve_in = 10_000_000_000   # 10 SOL
        reserve_out = 100_000_000_000 # 100 tokens

        res_small = AMMMath.get_amount_out(100_000_000, reserve_in, reserve_out, 25)  # 0.1 SOL
        res_large = AMMMath.get_amount_out(2_000_000_000, reserve_in, reserve_out, 25) # 2.0 SOL

        self.assertGreater(res_large.price_impact_pct, res_small.price_impact_pct)

    def test_dlmm_bin_crossing_simulation(self):
        """Verify concentrated liquidity multi-bin crossing simulation."""
        # 3 Bins: (bin_id, reserve_x, reserve_y)
        bins = [
            (0, 10_000_000, 20_000_000),
            (1, 10_000_000, 25_000_000),
            (2, 10_000_000, 30_000_000),
        ]
        out_amount, fee = DLMMMath.simulate_dlmm_swap(
            amount_in=15_000_000,
            bins=bins,
            swap_x_to_y=True,
            fee_bps=20,
        )
        self.assertGreater(out_amount, 0)
        self.assertGreater(fee, 0)

    def test_pump_fun_graduation_threshold(self):
        """Verify pump.fun graduation detection at 85 SOL."""
        self.assertFalse(PumpFunMath.is_graduated(84_999_999_999))
        self.assertTrue(PumpFunMath.is_graduated(85_000_000_000))
        self.assertTrue(PumpFunMath.is_graduated(100_000_000_000))

    def test_optimal_trade_size_optimization(self):
        """Verify analytical optimal trade sizing accurately finds positive profit trade size."""
        # Pool A (Cheaper): 40 SOL, 100M tokens -> Price: 0.0000004 SOL/token
        pool_a = PoolState(
            pool_id="pool_a",
            dex_name="Raydium AMM v4",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=40_000_000_000,
            reserve_b=100_000_000_000_000,
            fee_bps=25,
        )
        # Pool B (Expensive): 48 SOL, 100M tokens -> Price: 0.00000048 SOL/token (~20% dislocation)
        pool_b = PoolState(
            pool_id="pool_b",
            dex_name="Meteora DLMM",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=48_000_000_000,
            reserve_b=100_000_000_000_000,
            fee_bps=20,
        )

        opt_lamports, opt_sol = ArbCalculator.calculate_optimal_trade_size(
            pool_buy=pool_a,
            pool_sell=pool_b,
            max_sol=5.0,
            min_sol=0.05,
        )

        self.assertGreater(opt_lamports, 0)
        self.assertGreater(opt_sol, 0.0)
        self.assertLessEqual(opt_sol, 5.0)

    def test_arb_opportunity_positive_and_profitable(self):
        """Ensure full 2-leg arbitrage produces positive gross and net profit on wide spread."""
        pool_buy = PoolState(
            pool_id="raydium_buy",
            dex_name="Raydium AMM v4",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=30_000_000_000,
            reserve_b=100_000_000_000_000,
            fee_bps=25,
        )
        pool_sell = PoolState(
            pool_id="meteora_sell",
            dex_name="Meteora DLMM",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=36_000_000_000, # 20% price dislocation
            reserve_b=100_000_000_000_000,
            fee_bps=20,
        )

        arb = ArbCalculator.evaluate_arbitrage(
            pool_a=pool_buy,
            pool_b=pool_sell,
            min_profit_sol=0.005,
            max_trade_sol=5.0,
        )

        self.assertIsNotNone(arb)
        self.assertTrue(arb.is_profitable)
        self.assertGreater(arb.gross_profit_sol, 0)
        self.assertGreater(arb.net_profit_sol, 0.005)
        self.assertGreater(arb.estimated_jito_tip_sol, 0)
        self.assertLess(arb.estimated_jito_tip_sol, arb.gross_profit_sol)

    def test_arb_opportunity_unprofitable_on_zero_spread(self):
        """Identical pool prices must yield None or unprofitable result due to swap fees."""
        pool_a = PoolState(
            pool_id="pool_1",
            dex_name="Raydium",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=50_000_000_000,
            reserve_b=100_000_000_000_000,
            fee_bps=25,
        )
        pool_b = PoolState(
            pool_id="pool_2",
            dex_name="Meteora",
            token_mint_a="SOL",
            token_mint_b="MEME",
            reserve_a=50_000_000_000, # identical
            reserve_b=100_000_000_000_000,
            fee_bps=25,
        )

        arb = ArbCalculator.evaluate_arbitrage(
            pool_a=pool_a,
            pool_b=pool_b,
            min_profit_sol=0.005,
        )
        self.assertIsNone(arb)


if __name__ == "__main__":
    unittest.main()
