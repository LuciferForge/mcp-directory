# TheBull Crypto Quantitative Trading Suite (2026 Edition)

High-performance, institutional-grade automated trading bots for **Binance Futures**, **Delta Exchange Perpetuals & Options**, and **Hyperliquid / Bybit**.

## 5 Battle-Tested Crypto Strategies Included:
1. **Delta-Neutral Funding Rate Arbitrage (Cash & Carry)**:
   - Scans 150+ perpetual contracts for funding rate anomalies.
   - Long spot + short perpetual futures when funding > 0.03% (8h).
   - Generates 15%–45% APR annualized yield with zero directional market exposure.
2. **Orderbook Imbalance & Microsecond Breakout Sniper**:
   - Analyzes L2 orderbook bid/ask depth ratios and trade velocity.
   - Enters high-conviction breakout momentum before price moves.
3. **Multi-Timeframe Trend Breakout (EMA 20/50 + ATR Trailing Stops)**:
   - Identifies institutional trend regimes across 15m and 1h intervals.
   - Dynamic ATR trailing stop-loss to let winners run while clipping drawdowns.
4. **Dynamic Bollinger & RSI Volatility Mean-Reversion Grid**:
   - Ideal for sideways, choppy consolidation markets.
   - Places automated laddered grid orders with volatility kill-switches.
5. **Liquidation Cascade & Forced Close Wick Hunter**:
   - Detects forced liquidation spikes across overleveraged perp markets.
   - Executes sharp counter-trend sniper limit orders at extreme wick exhaustion points.

## Quickstart:
1. Copy `config.example.json` to `config.json` and insert your API keys.
2. Run `run_binance.bat` or `run_delta.bat` on Windows (or `docker-compose up -d` on Linux).
3. Connect your Telegram bot token to receive real-time execution alerts.
