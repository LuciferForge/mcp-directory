#!/usr/bin/env python3
"""
Dhan 80/20 Hybrid Core-Satellite Live Trading Engine
====================================================
Portfolio Capital: Rs. 1,00,000 INR
Architecture:
1. 80% Core Bucket (Rs. 80,000):
   - 4 Slots of Rs. 20,000 each in NSE Cash Equities / MTF.
   - 5-Pillar Multi-Day Swing Momentum Screener.
   - Exit rules: -4.5% Hard SL, +12% TP1 (50% scale-out, move SL to +1% breakeven),
     20-EMA trailing on remaining 50% shares.
   - Evaluated daily at 3:15 PM IST.
2. 20% Satellite Bucket (Rs. 20,000):
   - "The Ather Sniper" — Ultra-high conviction All-Time High / 52-Week High Breakouts.
   - Requires Volume >= 2.5x SMA20, 20-day breakout, ADX >= 25.
   - Instrument: 1-Lot Bull Call Debit Spread (ATM Call + OTM Call +100/200 pts, Monthly Expiry).
   - Target: +120% to +180% on spread debit, Hard SL: -30%, Max hold: 4 days.
   - Evaluated intraday (09:30, 11:30, 13:30, 15:15 IST).
"""

import os
import sys
import json
import time
import argparse
import subprocess
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, time as dt_time, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import yfinance as yf
import requests
from dotenv import load_dotenv

# Ensure local imports
SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

try:
    from black_scholes import BlackScholesEngine
except ImportError:
    import math
    from scipy.stats import norm
    class BlackScholesEngine:
        @staticmethod
        def option_price(S, K, T, option_type="CE", r=0.07, sigma=0.30):
            if T <= 0.0001:
                return max(S - K, 0.0) if option_type == "CE" else max(K - S, 0.0)
            d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T))
            d2 = d1 - sigma * math.sqrt(T)
            if option_type == "CE":
                return S * norm.cdf(d1) - K * math.exp(-r * T) * norm.cdf(d2)
            else:
                return K * math.exp(-r * T) * norm.cdf(-d2) - S * norm.cdf(-d1)

# Ensure UTF-8 output on Windows
if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if sys.stderr and hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

# Setup Logging
log_dir = SCRIPT_DIR / 'logs'
log_dir.mkdir(exist_ok=True)
log_file = log_dir / 'dhan_hybrid.log'

logger = logging.getLogger('DhanHybridBot')
logger.setLevel(logging.INFO)
logger.handlers = []

_fmt = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
fh = RotatingFileHandler(log_file, maxBytes=5_000_000, backupCount=3, encoding='utf-8')
fh.setFormatter(_fmt)
sh = logging.StreamHandler(sys.stdout)
sh.setFormatter(_fmt)

logger.addHandler(fh)
logger.addHandler(sh)

# Environment & Credentials
ENV_PATH = Path(r'C:\Users\ManjunathG\.gemini\antigravity\scratch\ZeroLag\.env')
if not ENV_PATH.exists():
    ENV_PATH = Path(r'C:\Users\ManjunathG\Documents\Clawd\.env')
load_dotenv(ENV_PATH)

DHAN_CLIENT_ID = os.environ.get('DHAN_CLIENT_ID', '')
DHAN_ACCESS_TOKEN = os.environ.get('DHAN_ACCESS_TOKEN', '')
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "").strip()
if ':' in TELEGRAM_CHAT_ID:
    TELEGRAM_CHAT_ID = TELEGRAM_CHAT_ID.split(':')[-1].strip()

def send_telegram_alert(text: str):
    """Send immediate trade alert to user's Telegram"""
    token = TELEGRAM_BOT_TOKEN or os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    chat = TELEGRAM_CHAT_ID or os.environ.get("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat:
        return
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {
            "chat_id": chat,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True
        }
        requests.post(url, json=payload, timeout=8)
    except Exception as e:
        logger.warning(f"Telegram alert delivery error: {e}")

def dhan_api_request(endpoint: str, method: str = 'GET', data: dict = None) -> dict:
    """Execute fast REST call to Dhan API v2 via curl with 6s timeout"""
    if ENV_PATH.exists():
        load_dotenv(ENV_PATH, override=True)
    client_id = os.environ.get('DHAN_CLIENT_ID', DHAN_CLIENT_ID)
    token = os.environ.get('DHAN_ACCESS_TOKEN', DHAN_ACCESS_TOKEN)
    if not client_id or not token:
        return {'status': 'error', 'message': 'Dhan credentials missing'}
        
    cmd = [
        'curl.exe', '-s', '--max-time', '6',
        '-H', f'access-token: {token}',
        '-H', f'client-id: {client_id}',
        '-H', 'Content-Type: application/json'
    ]
    if method == 'POST' and data:
        cmd.extend(['-X', 'POST', '-d', json.dumps(data)])
    cmd.append(f'https://api.dhan.co/v2/{endpoint}')
    
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=8)
        if res.stdout:
            return json.loads(res.stdout)
        return {'status': 'empty_response'}
    except Exception as e:
        return {'status': 'error', 'error': str(e)}

# Portfolio Configuration (Calibrated to Available Liquid Cash: Rs. 1,93,808)
TOTAL_CAPITAL = 193808.06
CORE_ALLOCATION_PCT = 0.80      # Rs. 1,55,046 Core (6 slots x Rs. 25,000)
SATELLITE_ALLOCATION_PCT = 0.20 # Rs. 38,761 Satellite (2 Option Spreads x Rs. 10k-15k)

CORE_SLOTS = 6                   # 6 slots x Rs. 25,000
CORE_SL_PCT = 0.035             # -3.5% Structural Stop
CORE_TP1_GAIN = 0.10            # +10.0% Scale-out 33%, move SL to Breakeven
TRANSACTION_FEE = 0.0015        # 0.15% round-trip

POSITIONS_FILE = SCRIPT_DIR / 'dhan_hybrid_positions.json'
TRADES_HISTORY_FILE = SCRIPT_DIR / 'dhan_hybrid_trades_history.json'
SCRIP_MASTER_FILE = SCRIPT_DIR / 'dhan_scrip_master.csv'

# NSE Trading Holidays 2026
NSE_HOLIDAYS_2026 = {
    "2026-01-26": "Republic Day",
    "2026-03-06": "Maha Shivratri",
    "2026-03-25": "Holi",
    "2026-04-03": "Good Friday",
    "2026-04-14": "Dr. Baba Saheb Ambedkar Jayanti",
    "2026-05-01": "Maharashtra Day",
    "2026-06-17": "Bakri Id",
    "2026-07-17": "Moharram",
    "2026-08-15": "Independence Day",
    "2026-09-14": "Ganesh Chaturthi",
    "2026-10-02": "Mahatma Gandhi Jayanti (Long Weekend: Fri-Sun)",
    "2026-10-20": "Dussehra",
    "2026-11-10": "Diwali-Balipratipada",
    "2026-11-24": "Prakash Gurpurb Sri Guru Nanak Dev",
    "2026-12-25": "Christmas (Long Weekend: Fri-Sun)",
}

def is_nse_holiday(dt: datetime) -> tuple[bool, str]:
    """Check if given date is an official NSE trading holiday"""
    date_str = dt.strftime("%Y-%m-%d")
    if date_str in NSE_HOLIDAYS_2026:
        return True, NSE_HOLIDAYS_2026[date_str]
    return False, ""

# Import 150+ Dynamic Liquid Universe
try:
    from nse_universe import NSE_LIQUID_UNIVERSE
    CORE_UNIVERSE = list(set(NSE_LIQUID_UNIVERSE + ["ARIES.NS"]))
except ImportError:
    CORE_UNIVERSE = [
        'TRENT.NS', 'DIXON.NS', 'KAYNES.NS', 'COCHINSHIP.NS', 'MAZDOCK.NS',
        'HAL.NS', 'BEL.NS', 'BDL.NS', 'SUZLON.NS', 'CDSL.NS',
        'BSE.NS', 'MCX.NS', 'IREDA.NS', 'HUDCO.NS', 'PFC.NS',
        'RECLTD.NS', 'RVNL.NS', 'IRFC.NS', 'BHARTIARTL.NS', 'SUNPHARMA.NS',
        'DIVISLAB.NS', 'CIPLA.NS', 'LUPIN.NS', 'TORNTPHARM.NS', 'PERSISTENT.NS',
        'COFORGE.NS', 'KPITTECH.NS', 'TATAELXSI.NS', 'TATAINVEST.NS', 'SOLARINDS.NS',
        'DMART.NS', 'TITAN.NS', 'TVSMOTOR.NS', 'KALYANKJIL.NS', 'MOTHERSON.NS',
        'JSWSTEEL.NS', 'HINDALCO.NS', 'VEDL.NS', 'JINDALSTEL.NS', 'POLICYBZR.NS',
        'COLPAL.NS', 'DEEPAKNTR.NS', 'CYIENTDLM.NS', 'ARIES.NS', 'SCHNEIDER.NS', 'WABAG.NS'
    ]

# High-Beta F&O Stocks for "Ather Sniper" Option Spreads (Includes Key Festive Outperformers)
SNIPER_STOCKS = [
    {"ticker": "TRENT.NS", "name": "Trent Ltd", "lot_size": 100, "strike_step": 50, "vol": 0.38},
    {"ticker": "DIXON.NS", "name": "Dixon Tech", "lot_size": 50, "strike_step": 100, "vol": 0.42},
    {"ticker": "TITAN.NS", "name": "Titan Ltd", "lot_size": 175, "strike_step": 50, "vol": 0.28},
    {"ticker": "TVSMOTOR.NS", "name": "TVS Motor", "lot_size": 175, "strike_step": 50, "vol": 0.32},
    {"ticker": "MAZDOCK.NS", "name": "Mazagon Dock", "lot_size": 125, "strike_step": 50, "vol": 0.50},
    {"ticker": "COCHINSHIP.NS", "name": "Cochin Shipyard", "lot_size": 175, "strike_step": 25, "vol": 0.55},
    {"ticker": "BSE.NS", "name": "BSE Ltd", "lot_size": 200, "strike_step": 50, "vol": 0.48},
    {"ticker": "BEL.NS", "name": "Bharat Electronics", "lot_size": 750, "strike_step": 5, "vol": 0.32},
    {"ticker": "HAL.NS", "name": "Hindustan Aeronautics", "lot_size": 150, "strike_step": 50, "vol": 0.35},
    {"ticker": "MCX.NS", "name": "MCX India", "lot_size": 125, "strike_step": 50, "vol": 0.40},
    {"ticker": "PERSISTENT.NS", "name": "Persistent Systems", "lot_size": 100, "strike_step": 50, "vol": 0.35}
]


class DhanHybrid8020Bot:
    """80/20 Core-Satellite Engine for Indian Markets"""
    def __init__(self, paper_mode: bool = True):
        self.paper_mode = paper_mode
        self.total_capital = TOTAL_CAPITAL
        self.core_cash = TOTAL_CAPITAL * CORE_ALLOCATION_PCT           # Rs. 2,00,000 Core
        self.satellite_cash = TOTAL_CAPITAL * SATELLITE_ALLOCATION_PCT # Rs. 50,000 Satellite
        self.core_positions = {}           # sym -> dict (Cash/MTF Swings)
        self.satellite_positions = {}      # sym -> dict (F&O Option Spreads)
        self.intraday_short_positions = {} # sym -> dict (Bear Day MIS Shorts)
        self.scrip_map = {}
        self._load_scrip_master()
        self._load_state()
        self._verify_dhan_connection()

    def _load_scrip_master(self):
        """Load Dhan Scrip Master CSV for security ID mapping"""
        if not SCRIP_MASTER_FILE.exists():
            return
        try:
            df = pd.read_csv(SCRIP_MASTER_FILE, low_memory=False)
            nse_eq = df[(df['SEM_EXM_EXCH_ID'] == 'NSE') & (df['SEM_INSTRUMENT_NAME'] == 'EQUITY')]
            for _, r in nse_eq.iterrows():
                sym = str(r['SEM_TRADING_SYMBOL']).strip()
                sec_id = str(r['SEM_SMST_SECURITY_ID']).strip()
                self.scrip_map[sym] = sec_id
            logger.info(f"Loaded {len(self.scrip_map)} NSE Equity security IDs from Scrip Master.")
        except Exception as e:
            logger.warning(f"Note on loading scrip master: {e}")

    def _verify_dhan_connection(self):
        """Check Dhan account connection and report margin status"""
        if self.paper_mode:
            logger.info("Dhan Engine Initialized | Mode: PAPER TRADING (Safe Simulation)")
            return
        logger.info("Dhan Engine Initialized | Mode: LIVE REAL MONEY EXECUTION")
        resp = dhan_api_request('fundlimit')
        if 'availMargin' in resp or 'sodLimit' in resp:
            avail = resp.get('availMargin', resp.get('sodLimit', 0.0))
            logger.info(f"✅ Dhan API Connected! Client ID: {DHAN_CLIENT_ID} | Live Margin: ₹{avail:,.2f}")
        else:
            err = resp.get('errorMessage', str(resp))
            logger.warning(f"⚠️ Dhan API Notice: {err}")
            logger.info("ℹ️ Reminder: Daily Dhan 24-hr JWT access token can be updated in .env before Monday 09:15 AM IST.")

    def _execute_dhan_order(self, symbol: str, quantity: int, side: str, product_type: str = "CNC") -> str:
        """Place live order via Dhan REST API v2"""
        if self.paper_mode:
            return "PAPER_SIMULATED_ORDER"
        sec_id = self.scrip_map.get(symbol)
        if not sec_id:
            logger.error(f"Cannot place Dhan live order: Security ID for {symbol} not found in Scrip Master!")
            return ""
        order_payload = {
            "dhanClientId": DHAN_CLIENT_ID,
            "correlationId": f"THEBULL_{int(time.time())}_{symbol}",
            "transactionType": side.upper(),
            "exchangeSegment": "NSE_EQ",
            "productType": product_type,
            "orderType": "MARKET",
            "validity": "DAY",
            "securityId": str(sec_id),
            "quantity": int(quantity),
            "price": 0.0
        }
        resp = dhan_api_request('orders', method='POST', data=order_payload)
        if resp.get('orderStatus') or resp.get('orderId'):
            order_id = resp.get('orderId', 'SUBMITTED')
            logger.info(f"✅ Dhan LIVE ORDER PLACED: {side} {quantity} {symbol} ({product_type}) | Order ID: {order_id}")
            return order_id
        else:
            logger.error(f"❌ Dhan Live Order Failed for {symbol}: {resp}")
            return ""

    def _load_state(self):
        if POSITIONS_FILE.exists():
            try:
                with open(POSITIONS_FILE, 'r') as f:
                    state = json.load(f)
                    self.core_cash = state.get('core_cash', self.core_cash)
                    self.satellite_cash = state.get('satellite_cash', self.satellite_cash)
                    self.core_positions = state.get('core_positions', {})
                    self.satellite_positions = state.get('satellite_positions', {})
                    self.intraday_short_positions = state.get('intraday_short_positions', {})
                    logger.info(f"Loaded active state: {len(self.core_positions)} Core, {len(self.satellite_positions)} Satellite, {len(self.intraday_short_positions)} Intraday Short positions.")
            except Exception as e:
                logger.error(f"Error loading state from {POSITIONS_FILE}: {e}")

    def _save_state(self):
        try:
            state = {
                'updated_at': datetime.now().isoformat(),
                'paper_mode': self.paper_mode,
                'total_capital': TOTAL_CAPITAL,
                'core_cash': self.core_cash,
                'satellite_cash': self.satellite_cash,
                'core_positions': self.core_positions,
                'satellite_positions': self.satellite_positions,
                'intraday_short_positions': self.intraday_short_positions
            }
            with open(POSITIONS_FILE, 'w') as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving state: {e}")

    def _record_trade(self, trade_info: dict):
        history = []
        if TRADES_HISTORY_FILE.exists():
            try:
                with open(TRADES_HISTORY_FILE, 'r') as f:
                    history = json.load(f)
            except Exception:
                history = []
        history.append(trade_info)
        try:
            with open(TRADES_HISTORY_FILE, 'w') as f:
                json.dump(history, f, indent=2)
        except Exception as e:
            logger.error(f"Error recording trade: {e}")

    # =========================================================================
    # 1. CORE BUCKET (80% = Rs. 80,000) — CASH SWING MOMENTUM
    # =========================================================================
    def evaluate_market_regime(self) -> dict:
        """Evaluate NIFTY 50 regime for Core Equity Breakout Gate"""
        try:
            nifty = yf.download("^NSEI", period="3mo", interval="1d", progress=False)
            if isinstance(nifty.columns, pd.MultiIndex):
                nifty.columns = [c[0].lower() for c in nifty.columns]
            else:
                nifty.columns = [str(c).lower() for c in nifty.columns]
            
            c = float(nifty['close'].iloc[-1])
            e20 = float(nifty['close'].ewm(span=20).mean().iloc[-1])
            e50 = float(nifty['close'].ewm(span=50).mean().iloc[-1])
            
            # ADX(14) Trend Confirmation
            tr1 = nifty['high'] - nifty['low']
            tr2 = (nifty['high'] - nifty['close'].shift(1)).abs()
            tr3 = (nifty['low'] - nifty['close'].shift(1)).abs()
            tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
            atr = tr.rolling(14).mean()
            
            up_move = nifty['high'] - nifty['high'].shift(1)
            down_move = nifty['low'].shift(1) - nifty['low']
            plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
            minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
            plus_di = 100 * (pd.Series(plus_dm, index=nifty.index).rolling(14).mean() / atr)
            minus_di = 100 * (pd.Series(minus_dm, index=nifty.index).rolling(14).mean() / atr)
            dx = 100 * ((plus_di - minus_di).abs() / (plus_di + minus_di))
            adx = float(dx.rolling(14).mean().iloc[-1])
            
            is_bull = (c > e20) and (e20 > e50) and (adx >= 20.0)
            return {
                "nifty_close": c,
                "ema20": e20,
                "ema50": e50,
                "adx": adx,
                "is_bull": is_bull,
                "regime": "BULL MARKET" if is_bull else "CORRECTION / CHOP"
            }
        except Exception as e:
            logger.error(f"Error fetching NIFTY regime: {e}")
            return {"nifty_close": 0, "is_bull": False, "regime": "UNKNOWN"}

    def scan_core_breakouts(self) -> list:
        """Scan NSE universe for 5-Pillar Stage-2 Momentum Breakouts"""
        logger.info("Scanning NSE Core universe for Stage-2 Multi-Day Momentum...")
        logger.info(f"Scanning {len(CORE_UNIVERSE)} stocks for Institutional Stage-2 Breakouts...")
        data = yf.download(CORE_UNIVERSE, period="6mo", interval="1d", group_by="ticker", progress=False)
        
        # Download Nifty for relative strength benchmark
        try:
            nifty_df = yf.download("^NSEI", period="2mo", interval="1d", progress=False)
            if isinstance(nifty_df.columns, pd.MultiIndex):
                nifty_c = nifty_df['Close'].iloc[-1].item()
                nifty_c_21 = nifty_df['Close'].iloc[-22].item() if len(nifty_df) >= 22 else nifty_c
            else:
                nifty_c = float(nifty_df['Close'].iloc[-1])
                nifty_c_21 = float(nifty_df['Close'].iloc[-22]) if len(nifty_df) >= 22 else nifty_c
            nifty_21d_ret = ((nifty_c - nifty_c_21) / nifty_c_21) * 100.0
        except Exception:
            nifty_21d_ret = 0.0

        candidates = []
        
        for sym in CORE_UNIVERSE:
            clean_sym = sym.replace('.NS', '')
            if clean_sym in self.core_positions:
                continue
            try:
                if sym not in data:
                    continue
                df = data[sym].dropna()
                if len(df) < 55:
                    continue
                
                c = float(df['Close'].iloc[-1])
                o = float(df['Open'].iloc[-1])
                h = float(df['High'].iloc[-1])
                l = float(df['Low'].iloc[-1])
                v = float(df['Volume'].iloc[-1])
                
                # --- The 5 Institutional DNA Filters ---
                # 1. Moving Averages Stack (Stage 2 Markup)
                e10 = float(df['Close'].ewm(span=10).mean().iloc[-1])
                e20 = float(df['Close'].ewm(span=20).mean().iloc[-1])
                e50 = float(df['Close'].ewm(span=50).mean().iloc[-1])
                if not (c > e10 > e20 > e50):
                    continue
                    
                # 2. 20-EMA Respect (% of last 50 days Close > EMA20 >= 65%)
                past_50 = df.iloc[-51:-1]
                past_50_ema20 = past_50['Close'].ewm(span=20).mean()
                days_above_e20 = (past_50['Close'] > past_50_ema20).mean()
                if days_above_e20 < 0.65:
                    continue
                    
                # 3. Max Consecutive Red Days <= 4 in last 50 days
                daily_is_red = (past_50['Close'] < past_50['Open']).astype(int)
                max_red_streak = 0
                curr_streak = 0
                for r in daily_is_red:
                    if r == 1:
                        curr_streak += 1
                        if curr_streak > max_red_streak:
                            max_red_streak = curr_streak
                    else:
                        curr_streak = 0
                if max_red_streak > 4:
                    continue
                    
                # 4. Up/Down Volume Ratio >= 1.40x
                up_vol = past_50[past_50['Close'] > past_50['Open']]['Volume'].sum()
                down_vol = past_50[past_50['Close'] < past_50['Open']]['Volume'].sum()
                up_down_ratio = up_vol / down_vol if down_vol > 0 else 1.0
                if up_down_ratio < 1.40:
                    continue
                    
                # 5. Proximity to 52w / 6m High (within 12%)
                high_120 = float(df['High'].iloc[-120:].max())
                if c < high_120 * 0.88:
                    continue
                    
                # 6. Relative Strength vs NIFTY (21-day return >= Nifty + 8.0%)
                c_21d_ago = float(df['Close'].iloc[-22])
                stock_21d_ret = ((c - c_21d_ago) / c_21d_ago) * 100.0
                rs_vs_nifty = stock_21d_ret - nifty_21d_ret
                if rs_vs_nifty < 8.0:
                    continue
                    
                # 7. Volume surge on breakout day >= 1.25x SMA20
                v_sma20 = float(df['Volume'].iloc[-21:-1].mean())
                v_ratio = v / v_sma20 if v_sma20 > 0 else 1.0
                if v_ratio < 1.25:
                    continue
                    
                candidates.append({
                    "symbol": clean_sym,
                    "ticker": sym,
                    "price": c,
                    "ema20": e20,
                    "vol_ratio": v_ratio,
                    "up_down_ratio": up_down_ratio,
                    "rs_vs_nifty": rs_vs_nifty,
                    "ret_1m": stock_21d_ret
                })
            except Exception:
                pass
                
        # Rank by combined RS and Institutional Volume Thrust
        candidates.sort(key=lambda x: x['rs_vs_nifty'] * x['up_down_ratio'], reverse=True)
        return candidates

    def manage_core_positions(self):
        """Evaluate open Core positions: -4.5% Hard SL, +12% TP1, 20-EMA Trail"""
        if not self.core_positions:
            return
            
        logger.info(f"Evaluating {len(self.core_positions)} Core Cash positions...")
        tickers = [f"{s}.NS" for s in self.core_positions.keys()]
        data = yf.download(tickers, period="1mo", interval="1d", group_by="ticker", progress=False)
        
        for sym in list(self.core_positions.keys()):
            pos = self.core_positions[sym]
            t_sym = f"{sym}.NS"
            try:
                if t_sym not in data:
                    continue
                df = data[t_sym].dropna()
                if df.empty:
                    continue
                c = float(df['Close'].iloc[-1])
                h = float(df['High'].iloc[-1])
                l = float(df['Low'].iloc[-1])
                ema20 = float(df['Close'].ewm(span=20).mean().iloc[-1])
                entry_px = pos['entry_price']
                gain_pct = (c - entry_px) / entry_px
                
                # Check TP1 (+10% Scale-out 33% and de-risk trade)
                if gain_pct >= CORE_TP1_GAIN and not pos.get('tp1_taken'):
                    one_third_shs = pos['shares'] // 3
                    if one_third_shs > 0:
                        scale_px = entry_px * (1.0 + CORE_TP1_GAIN)
                        proceeds = one_third_shs * scale_px * (1.0 - TRANSACTION_FEE)
                        realized = one_third_shs * (scale_px - entry_px) * (1.0 - TRANSACTION_FEE)
                        if not self.paper_mode:
                            self._execute_dhan_order(sym, one_third_shs, 'SELL', product_type='CNC')
                        self.core_cash += proceeds
                        pos['shares'] -= one_third_shs
                        pos['tp1_taken'] = True
                        pos['sl_price'] = entry_px * 1.01 # Breakeven +1%
                        pos['realized_pnl'] = pos.get('realized_pnl', 0.0) + realized
                        logger.info(f"🎯 CORE TP1 HIT on {sym}! Gain: +{gain_pct*100:.1f}%. Scaled 33% ({one_third_shs} shs). Banked: Rs.{realized:+,.0f}")
                        send_telegram_alert(f"🎯 <b>DHAN CORE TP1 HIT</b>: <b>{sym}</b>\n• Scaled 33% ({one_third_shs} shares)\n• Realized Profit: <b>+₹{realized:,.0f}</b> (+10.0%)\n• Trailing SL moved to Break-Even (+1%)\n• Remaining 67% trailing 20-EMA")
                        self._save_state()
                        
                # Check Exits: Hard SL or 20-EMA Trail
                exit_reason = None
                exit_px = c
                if l <= pos['sl_price']:
                    exit_reason = "HARD_SL"
                    exit_px = pos['sl_price']
                elif pos.get('days_held', 0) >= 3 and c < ema20:
                    exit_reason = "EMA20_TRAIL"
                    exit_px = c
                    
                pos['days_held'] = pos.get('days_held', 0) + 1
                
                if exit_reason:
                    shs = pos['shares']
                    if not self.paper_mode:
                        self._execute_dhan_order(sym, shs, 'SELL', product_type='CNC')
                    proceeds = shs * exit_px * (1.0 - TRANSACTION_FEE)
                    total_pnl = pos.get('realized_pnl', 0.0) + shs * (exit_px - entry_px) * (1.0 - TRANSACTION_FEE)
                    ret_pct = (total_pnl / pos['initial_cost']) * 100.0
                    self.core_cash += proceeds
                    logger.info(f"🛑 CORE EXIT on {sym} [{exit_reason}] at Rs.{exit_px:.2f} | PnL: Rs.{total_pnl:+,.0f} ({ret_pct:+.1f}%)")
                    send_telegram_alert(f"🛑 <b>DHAN CORE EXIT</b>: <b>{sym}</b> [{exit_reason}]\n• Exit: ₹{exit_px:.2f}\n• PnL: <b>₹{total_pnl:+,.0f}</b> ({ret_pct:+.1f}%)")
                    self._record_trade({
                        "bucket": "CORE_CASH",
                        "symbol": sym,
                        "entry_date": pos['entry_date'],
                        "exit_date": datetime.now().isoformat(),
                        "entry_price": entry_px,
                        "exit_price": exit_px,
                        "pnl_inr": total_pnl,
                        "ret_pct": ret_pct,
                        "reason": exit_reason
                    })
                    del self.core_positions[sym]
                    self._save_state()
            except Exception as e:
                logger.error(f"Error managing core position {sym}: {e}")

    def execute_core_entries(self):
        """Allocate vacant Core slots (up to 8 slots in Bull market, or max 2 Scout slots in Correction)"""
        regime = self.evaluate_market_regime()
        is_bull = regime.get('is_bull', False)
        
        max_allowed_slots = CORE_SLOTS if is_bull else 2
        vacant = max_allowed_slots - len(self.core_positions)
        if vacant <= 0:
            if not is_bull:
                logger.info(f"NIFTY 50 ({regime['nifty_close']:,.0f}) is below EMA20. Max 2 Scout slots filled ({len(self.core_positions)} active). Capital safely protected in cash.")
            return
            
        candidates = self.scan_core_breakouts()
        if not candidates:
            logger.info("No Core candidates qualify today.")
            return
            
        # In Scout Mode (Bear market), require higher conviction: RS vs Nifty >= +10% and Up/Down Vol >= 1.50x
        if not is_bull:
            candidates = [c for c in candidates if c.get('rs_vs_nifty', 0) >= 10.0 and c.get('up_down_ratio', 0) >= 1.50]
            if not candidates:
                logger.info(f"NIFTY 50 is below EMA20. No candidates met the strict Scout criteria (RS >= +10%, Up/Down Vol >= 1.50x). Capital safely protected in Cash.")
                return
            logger.info(f"🛡️ SCOUT MODE: Found {len(candidates)} market-defying leaders during Nifty correction!")
            
        # Dynamic slot sizing based on current Core equity (enables true compounding)
        core_equity = self.core_cash + sum(p['shares'] * p['entry_price'] for p in self.core_positions.values())
        target_slot_size = max(core_equity / CORE_SLOTS, 20000.0)
        mode_label = "SCOUT ENTRY" if not is_bull else "CORE BUY"
        
        for cand in candidates[:vacant]:
            sym = cand['symbol']
            px = cand['price']
            alloc = min(self.core_cash, target_slot_size)
            if alloc < 8000:
                break
            shares = int(alloc / px)
            if shares <= 0:
                continue
            cost = shares * px * (1.0 + TRANSACTION_FEE)
            if self.core_cash < cost:
                continue
                
            if not self.paper_mode:
                order_id = self._execute_dhan_order(sym, shares, 'BUY', product_type='CNC')
                if not order_id:
                    logger.error(f"Live order failed on Dhan for {sym}, skipping position creation.")
                    continue

            self.core_cash -= cost
            self.core_positions[sym] = {
                "entry_date": datetime.now().isoformat(),
                "entry_price": px,
                "shares": shares,
                "initial_cost": cost,
                "sl_price": px * (1.0 - CORE_SL_PCT),
                "tp1_taken": False,
                "realized_pnl": 0.0,
                "days_held": 0,
                "is_scout": not is_bull,
                "is_live": not self.paper_mode
            }
            logger.info(f"🚀 {mode_label}: {sym} | {shares} shares @ Rs.{px:.2f} | Cost: Rs.{cost:,.0f} | RS: +{cand.get('rs_vs_nifty', 0):.1f}% | Up/Down Vol: {cand.get('up_down_ratio', 1.0):.2f}x")
            send_telegram_alert(
                f"🚀 <b>DHAN {mode_label}</b>: <b>{sym}</b>\n"
                f"• Shares: {shares} @ ₹{px:.2f}\n"
                f"• Investment: ₹{cost:,.0f}\n"
                f"• Hard SL: ₹{px*(1.0-CORE_SL_PCT):.2f} (-3.5%)\n"
                f"• Target 1: ₹{px*(1.0+CORE_TP1_GAIN):.2f} (+10.0% Scale 33%)\n"
                f"• Trailing: Daily 20-EMA\n"
                f"• RS vs Nifty: +{cand.get('rs_vs_nifty', 0):.1f}%\n"
                f"• Up/Down Vol: {cand.get('up_down_ratio', 1.0):.2f}x"
            )
            self._save_state()

    # =========================================================================
    # 1.5 BEARISH REGIME ENGINE — INTRADAY MIS BREAKDOWN SHORTS (0 OVERNIGHT)
    # =========================================================================
    def scan_bearish_intraday_breakdowns(self) -> list:
        """Scan NSE universe for high-volume breakdown candidates on Bear days"""
        logger.info("Scanning for Intraday Institutional Breakdown Anomalies (RVOL >= 2.0x, Below VWAP)...")
        candidates = []
        try:
            data = yf.download(CORE_UNIVERSE, period="5d", interval="1d", group_by="ticker", progress=False)
            for sym in CORE_UNIVERSE:
                clean_sym = sym.replace('.NS', '')
                if clean_sym in self.intraday_short_positions:
                    continue
                if sym not in data:
                    continue
                df = data[sym].dropna()
                if len(df) < 3:
                    continue
                c = float(df['Close'].iloc[-1])
                o = float(df['Open'].iloc[-1])
                lo = float(df['Low'].iloc[-1])
                prev_c = float(df['Close'].iloc[-2])
                prev_lo = float(df['Low'].iloc[-2])
                v = float(df['Volume'].iloc[-1])
                v_sma = float(df['Volume'].iloc[-20:].mean()) if len(df) >= 20 else float(df['Volume'].mean())
                rvol = v / v_sma if v_sma > 0 else 0
                
                # High-volume breakdown: opens below prev close or cracks prev day low
                if (lo < prev_lo or o < prev_c) and rvol >= 1.8:
                    drop_pct = ((prev_c - c) / prev_c) * 100.0
                    candidates.append({
                        "symbol": clean_sym,
                        "ticker": sym,
                        "price": c,
                        "open_px": o,
                        "rvol": rvol,
                        "drop_pct": drop_pct
                    })
        except Exception as e:
            logger.error(f"Error scanning breakdowns: {e}")
        candidates.sort(key=lambda x: x['rvol'], reverse=True)
        return candidates

    def execute_bearish_intraday_shorts(self):
        """Deploy up to 2 Intraday MIS short positions of Rs. 25,000 each (Zero overnight risk)"""
        now = datetime.now()
        # Only take intraday shorts between 09:30 and 13:30 IST
        if now.time() < dt_time(9, 30) or now.time() > dt_time(13, 30):
            return
        if len(self.intraday_short_positions) >= 2:
            return
            
        cands = self.scan_bearish_intraday_breakdowns()
        if not cands:
            return
            
        vacant = 2 - len(self.intraday_short_positions)
        slot_size = 25000.0 # Rs. 25,000 per slot
        for cand in cands[:vacant]:
            sym = cand['symbol']
            px = cand['price']
            shares = int(slot_size / px)
            if shares <= 0:
                continue
            cost = shares * px
            self.intraday_short_positions[sym] = {
                "entry_time": datetime.now().isoformat(),
                "entry_price": px,
                "shares": shares,
                "position_val": cost,
                "sl_price": px * 1.015, # -1.5% hard SL for shorts
                "tp_price": px * 0.965  # +3.5% TP
            }
            logger.info(f"🔴 INTRADAY MIS SHORT: {sym} | {shares} shares @ Rs.{px:.2f} | RVOL: {cand['rvol']:.1f}x | SL: Rs.{px*1.015:.2f}")
            send_telegram_alert(f"🔴 <b>DHAN INTRADAY MIS SHORT</b>: <b>{sym}</b>\n• Shares: {shares} @ ₹{px:.2f}\n• Value: ₹{cost:,.0f}\n• Volume Surge: {cand['rvol']:.1f}x\n• Hard SL: ₹{px*1.015:.2f} (-1.5%)\n• Target: ₹{px*0.965:.2f} (+3.5%)\n• Auto Square-off: 3:15 PM IST")
            self._save_state()

    def manage_intraday_shorts(self):
        """Monitor active MIS short positions: -1.5% SL, +3.5% TP, mandatory 3:15 PM square-off"""
        if not self.intraday_short_positions:
            return
        now = datetime.now()
        is_eod_squareoff = (now.time() >= dt_time(15, 15))
        
        tickers = [f"{s}.NS" for s in self.intraday_short_positions.keys()]
        data = yf.download(tickers, period="1d", interval="5m", group_by="ticker", progress=False)
        
        for sym in list(self.intraday_short_positions.keys()):
            pos = self.intraday_short_positions[sym]
            t_sym = f"{sym}.NS"
            try:
                c = pos['entry_price']
                h = pos['entry_price']
                l = pos['entry_price']
                if t_sym in data and not data[t_sym].dropna().empty:
                    df = data[t_sym].dropna()
                    c = float(df['Close'].iloc[-1])
                    h = float(df['High'].iloc[-1])
                    l = float(df['Low'].iloc[-1])
                
                entry_px = pos['entry_price']
                exit_reason = None
                exit_px = c
                
                if is_eod_squareoff:
                    exit_reason = "EOD_315PM_SQUAREOFF"
                    exit_px = c
                elif h >= pos['sl_price']:
                    exit_reason = "HARD_SL (-1.5%)"
                    exit_px = pos['sl_price']
                elif l <= pos['tp_price']:
                    exit_reason = "TARGET_HIT (+3.5%)"
                    exit_px = pos['tp_price']
                    
                if exit_reason:
                    shs = pos['shares']
                    pnl = shs * (entry_px - exit_px) * (1.0 - TRANSACTION_FEE)
                    ret_pct = (pnl / pos['position_val']) * 100.0
                    self.satellite_cash += pnl
                    logger.info(f"⚡ INTRADAY SHORT CLOSED on {sym} [{exit_reason}] at Rs.{exit_px:.2f} | PnL: Rs.{pnl:+,.0f} ({ret_pct:+.1f}%)")
                    send_telegram_alert(f"⚡ <b>DHAN INTRADAY SHORT CLOSED</b>: <b>{sym}</b> [{exit_reason}]\n• Exit: ₹{exit_px:.2f}\n• PnL: <b>₹{pnl:+,.0f}</b> ({ret_pct:+.1f}%)")
                    self._record_trade({
                        "bucket": "INTRADAY_MIS_SHORT",
                        "symbol": sym,
                        "entry_date": pos['entry_time'],
                        "exit_date": datetime.now().isoformat(),
                        "entry_price": entry_px,
                        "exit_price": exit_px,
                        "pnl_inr": pnl,
                        "ret_pct": ret_pct,
                        "reason": exit_reason
                    })
                    del self.intraday_short_positions[sym]
                    self._save_state()
            except Exception as e:
                logger.error(f"Error managing intraday short {sym}: {e}")

    # =========================================================================
    # 2. SATELLITE BUCKET (20% = Rs. 20,000) — "THE ATHER SNIPER" OPTION SPREAD
    # =========================================================================
    def scan_satellite_breakouts(self) -> list:
        """Detect Super-Breakouts: ATH / 52-Week High with Volume >= 2.2x"""
        logger.info("Scanning for 'Ather Sniper' Option Breakouts (ATH + 2.2x Volume)...")
        tickers = [s["ticker"] for s in SNIPER_STOCKS]
        data = yf.download(tickers, period="3mo", interval="1d", group_by="ticker", progress=False)
        sniper_cands = []
        
        for s in SNIPER_STOCKS:
            t = s["ticker"]
            sym = s["name"]
            if sym in self.satellite_positions:
                continue
            try:
                if t not in data:
                    continue
                df = data[t].dropna()
                if len(df) < 30:
                    continue
                c = float(df['Close'].iloc[-1])
                h = float(df['High'].iloc[-1])
                h_20 = float(df['High'].iloc[-21:-1].max())
                v = float(df['Volume'].iloc[-1])
                v_sma = float(df['Volume'].iloc[-21:-1].mean())
                v_ratio = v / v_sma if v_sma > 0 else 0
                
                # Condition: High-Volume 20-day / 52w Breakout
                if c >= h_20 and v_ratio >= 2.2:
                    sniper_cands.append({
                        "stock_info": s,
                        "price": c,
                        "vol_ratio": v_ratio
                    })
            except Exception:
                pass
                
        sniper_cands.sort(key=lambda x: x['vol_ratio'], reverse=True)
        return sniper_cands

    def manage_satellite_positions(self):
        """Manage active Bull Call Spreads: +120% Target, -25% SL, 4-day time cut"""
        if not self.satellite_positions:
            return
            
        logger.info(f"Evaluating {len(self.satellite_positions)} Satellite Option Spread positions...")
        for sym in list(self.satellite_positions.keys()):
            pos = self.satellite_positions[sym]
            t_info = pos['stock_info']
            try:
                df = yf.download(t_info['ticker'], period="5d", interval="1d", progress=False)
                if isinstance(df.columns, pd.MultiIndex):
                    df.columns = [c[0].lower() for c in df.columns]
                else:
                    df.columns = [str(c).lower() for c in df.columns]
                close_val = df['close'].iloc[-1]
                spot_px = float(close_val.item() if hasattr(close_val, 'item') else close_val)
                days_held = (datetime.now() - datetime.fromisoformat(pos['entry_date'])).days
                
                # Approximate Spread valuation
                initial_dte = pos.get('days_to_exp', 20)
                is_next_month = pos.get('is_next_month', False)
                T_years = max((initial_dte - days_held) / 365.0, 0.005)
                l_p = BlackScholesEngine.option_price(spot_px, pos['long_strike'], T_years, "CE", sigma=t_info['vol'])
                s_p = BlackScholesEngine.option_price(spot_px, pos['short_strike'], T_years, "CE", sigma=t_info['vol'])
                curr_spread_prem = max(l_p - s_p, 1.0)
                entry_spread_prem = pos['entry_spread_premium']
                
                gain_pct = (curr_spread_prem - entry_spread_prem) / entry_spread_prem
                now = datetime.now()
                exit_reason = None
                
                # SEBI Physical Delivery Defense: Force square-off by Wednesday 3:15 PM of Expiry Week ONLY for current-month contracts
                if not is_next_month and now.day >= 24 and now.weekday() >= 2:
                    exit_reason = "SEBI_PHYSICAL_DELIVERY_SQUAREOFF"
                    exit_prem = curr_spread_prem
                elif gain_pct >= 1.20:
                    exit_reason = "TARGET_EXPLOSION (+120%)"
                    exit_prem = curr_spread_prem
                elif gain_pct <= -0.25: # -25% Hard Stop on spread debit (max Rs. 2,500 loss)
                    exit_reason = "HARD_SL (-25%)"
                    exit_prem = entry_spread_prem * 0.75
                elif days_held >= 4:
                    exit_reason = "MOMENTUM_EXHAUSTION (4-Day Limit)"
                    exit_prem = curr_spread_prem
                    
                if exit_reason:
                    lot = t_info['lot_size']
                    total_pnl = (exit_prem - entry_spread_prem) * lot
                    ret_pct = gain_pct * 100.0
                    self.satellite_cash += (entry_spread_prem * lot) + total_pnl
                    logger.info(f"💥 SATELLITE OPTION EXIT on {sym} [{exit_reason}] | PnL: Rs.{total_pnl:+,.0f} ({ret_pct:+.1f}%)")
                    send_telegram_alert(f"💥 <b>DHAN ATHER SNIPER EXIT</b>: <b>{sym}</b> [{exit_reason}]\n• PnL: <b>₹{total_pnl:+,.0f}</b> ({ret_pct:+.1f}%)")
                    self._record_trade({
                        "bucket": "SATELLITE_OPTION",
                        "symbol": sym,
                        "entry_date": pos['entry_date'],
                        "exit_date": datetime.now().isoformat(),
                        "days_held": days_held,
                        "pnl_inr": total_pnl,
                        "ret_pct": ret_pct,
                        "reason": exit_reason
                    })
                    del self.satellite_positions[sym]
                    self._save_state()
            except Exception as e:
                logger.error(f"Error managing satellite position {sym}: {e}")

    def execute_satellite_entries(self):
        """Execute 1-Lot Bull Call Spread on ATH Super-Runners (Max 2 concurrent)"""
        if len(self.satellite_positions) >= 2 or self.satellite_cash < 7000.0:
            return

        # Intelligent Expiry Selection: If after 20th of month, auto-roll to NEXT MONTH'S expiry contract (35 DTE)
        # This guarantees 0% SEBI physical delivery margin risk while keeping sniper active 100% of the year!
        now = datetime.now()
        is_next_month = now.day >= 20
        days_to_exp = 35 if is_next_month else max(24 - now.day, 5)
        expiry_label = "NEXT_MONTH" if is_next_month else "CURRENT_MONTH"
        
        cands = self.scan_satellite_breakouts()
        if not cands:
            return
            
        for cand in cands[:1]:
            s = cand['stock_info']
            sym = s["name"]
            spot_px = cand['price']
            step = s["strike_step"]
            lot = s["lot_size"]
            vol = s["vol"]
            
            # Construct Bull Call Debit Spread: Long ATM Call + Short OTM Call (+200 pts)
            long_strike = round(spot_px / step) * step
            short_strike = long_strike + (2 * step)
            T_years = days_to_exp / 365.0
            
            l_prem = BlackScholesEngine.option_price(spot_px, long_strike, T_years, "CE", sigma=vol)
            s_prem = BlackScholesEngine.option_price(spot_px, short_strike, T_years, "CE", sigma=vol)
            # Apply realistic 10% bid-ask spread buffer to theoretical debit
            spread_debit = max(l_prem - s_prem, 5.0) * 1.10
            cost = spread_debit * lot
            
            # Max Risk Cap: Limit maximum capital risk per spread to Rs. 15,000 (SL -25% = Rs. 3,750 max loss)
            if cost > self.satellite_cash or cost > 15000.0:
                logger.warning(f"Spread cost Rs.{cost:,.0f} exceeds satellite risk limit (Rs. 15,000) for {sym}.")
                continue
                
            self.satellite_cash -= cost
            self.satellite_positions[sym] = {
                "stock_info": s,
                "entry_date": datetime.now().isoformat(),
                "spot_entry": spot_px,
                "long_strike": long_strike,
                "short_strike": short_strike,
                "entry_spread_premium": spread_debit,
                "cost": cost,
                "vol_ratio": cand['vol_ratio'],
                "is_next_month": is_next_month,
                "days_to_exp": days_to_exp,
                "expiry_label": expiry_label
            }
            logger.info(f"⚡ SATELLITE 'ATHER SNIPER' ENTERED: {sym} [{expiry_label} EXPIRY] {long_strike}/{short_strike} CE Spread | Cost: Rs.{cost:,.0f} | Vol: {cand['vol_ratio']:.1f}x")
            send_telegram_alert(f"⚡ <b>DHAN ATHER SNIPER ENTRY</b>: <b>{sym}</b>\n• Spread: {long_strike}/{short_strike} CE ({expiry_label})\n• Cost: ₹{cost:,.0f} (Debit: ₹{spread_debit:.2f})\n• Volume Surge: {cand['vol_ratio']:.1f}x\n• Target: +120% | Hard SL: -25%")
            self._save_state()

    # =========================================================================
    # 3. UNIFIED REPORTING & STATUS
    # =========================================================================
    def print_status(self):
        """Display live 80/20 portfolio dashboard"""
        core_val = self.core_cash + sum(p['shares'] * p['entry_price'] for p in self.core_positions.values())
        sat_val = self.satellite_cash + sum(p['cost'] for p in self.satellite_positions.values())
        short_val = sum(p['position_val'] for p in self.intraday_short_positions.values())
        total_val = core_val + sat_val
        total_ret = ((total_val - TOTAL_CAPITAL) / TOTAL_CAPITAL) * 100.0
        
        regime = self.evaluate_market_regime()
        
        print("\n" + "=" * 90)
        print(f"DHAN DUAL-MODE HYBRID PORTFOLIO DASHBOARD ({'PAPER TRADING' if self.paper_mode else 'LIVE'})")
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} | NIFTY 50: {regime['nifty_close']:,.1f} ({regime['regime']})")
        print("=" * 90)
        print(f"Total Portfolio Value:  Rs. {total_val:,.2f} ({total_ret:+.2f}%)")
        print(f"  * 80% Core Bucket:    Rs. {core_val:,.2f} (Cash: Rs.{self.core_cash:,.2f} | Slots Active: {len(self.core_positions)}/{CORE_SLOTS})")
        print(f"  * 20% Satellite:      Rs. {sat_val:,.2f} (Cash: Rs.{self.satellite_cash:,.2f} | Spreads Active: {len(self.satellite_positions)}/2)")
        if self.intraday_short_positions:
            print(f"  * Intraday MIS Shorts: Rs. {short_val:,.2f} ({len(self.intraday_short_positions)} Active Shorts, EOD 3:15 PM Square-off)")
        print("-" * 90)
        
        print("\n[CORE BUCKET: CASH SWING POSITIONS (Held 3-8 Weeks)]")
        if not self.core_positions:
            print("  -> No active cash swing positions. Ready for next 3:15 PM EOD scan.")
        else:
            print(f"  {'Symbol':<12} | {'Shares':<8} | {'Entry (Rs)':<10} | {'Stop Loss':<10} | {'Cost (Rs)':<12} | {'TP1 Done'}")
            for sym, p in self.core_positions.items():
                print(f"  {sym:<12} | {p['shares']:<8} | Rs.{p['entry_price']:<7.2f} | Rs.{p['sl_price']:<7.2f} | Rs.{p['initial_cost']:<9.2f} | {p.get('tp1_taken', False)}")
                
        print("\n[SATELLITE BUCKET: 'ATHER SNIPER' OPTION SPREADS (1-Lot Breakout)]")
        if not self.satellite_positions:
            print("  -> No active sniper option spreads. Monitoring for ATH + 2.2x volume runners.")
        else:
            print(f"  {'Stock':<16} | {'Spread Strikes':<16} | {'Spread Debit':<12} | {'Total Cost':<12} | {'Vol Surge'}")
            for sym, p in self.satellite_positions.items():
                print(f"  {sym:<16} | {p['long_strike']}/{p['short_strike']} CE  | Rs.{p['entry_spread_premium']:<9.2f} | Rs.{p['cost']:<9.2f} | {p.get('vol_ratio', 0):.1f}x")

        if self.intraday_short_positions:
            print("\n[BEAR REGIME: INTRADAY MIS SHORT POSITIONS (0 Overnight Risk)]")
            print(f"  {'Symbol':<12} | {'Shares':<8} | {'Entry (Rs)':<10} | {'Stop Loss':<10} | {'Target':<10} | {'Position Val'}")
            for sym, p in self.intraday_short_positions.items():
                print(f"  {sym:<12} | {p['shares']:<8} | Rs.{p['entry_price']:<7.2f} | Rs.{p['sl_price']:<7.2f} | Rs.{p['tp_price']:<7.2f} | Rs.{p['position_val']:<9.2f}")
        print("=" * 90 + "\n")

    def run_cycle(self):
        """Execute complete market check cycle"""
        logger.info("Executing Dhan Dual-Mode Hybrid Evaluation Cycle...")
        # 1. Always monitor and manage active positions
        self.manage_core_positions()
        self.manage_satellite_positions()
        self.manage_intraday_shorts()
        
        # 2. Evaluate market regime for new entries
        regime = self.evaluate_market_regime()
        if regime['is_bull']:
            logger.info(f"🟢 Regime: BULLISH (NIFTY > EMA20 at {regime['nifty_close']:,.0f}). Full Core Deployment & Option Spreads.")
            self.execute_core_entries()
            self.execute_satellite_entries()
        else:
            logger.info(f"🔴 Regime: CORRECTION / BEARISH (NIFTY < EMA20 at {regime['nifty_close']:,.0f}). Engaging Scout Sizing Mode (Max 2 Slots, Rs.2L+ Cash Protected).")
            self.execute_core_entries()
            self.execute_bearish_intraday_shorts()
            
        self.print_status()


def run_daemon(paper_mode: bool = False):
    """
    Dual-Speed Background Daemon during Indian market hours (09:15 to 15:30 IST):
    1. High-Speed Position Guardian (Every 60s): Monitors open positions for -3.5% SL, +10% TP1, trailing stops.
    2. Macro & Universe Scanner (Every 15 mins / 03:15 PM EOD): Scans the 155-stock pool for breakout entries.
    """
    mode_str = "PAPER TRADING" if paper_mode else "LIVE REAL MONEY TRADING"
    logger.info(f"Starting Dhan 80/20 Dual-Speed Daemon [{mode_str}].")
    logger.info("⚡ Position Guardian: Checking active stops & targets every 60 SECONDS.")
    logger.info("🔭 Universe Discovery: Scanning breakout candidates every 15 MINUTES.")
    bot = DhanHybrid8020Bot(paper_mode=paper_mode)
    
    last_universe_scan_time = 0.0
    POSITION_CHECK_INTERVAL_SEC = 60      # 1 minute high-speed stop/target guardian
    UNIVERSE_SCAN_INTERVAL_SEC = 15 * 60  # 15 minutes macro & candidate scanner
    
    while True:
        now = datetime.now()
        is_holiday, holiday_name = is_nse_holiday(now)
        if is_holiday:
            logger.info(f"🏛️ NSE Trading Holiday Today: {holiday_name}. Exchange is closed. Sleeping 2 hours...")
            time.sleep(7200)
            continue
            
        if now.weekday() < 5:
            mkt_open = now.replace(hour=9, minute=15, second=0, microsecond=0)
            mkt_close = now.replace(hour=15, minute=30, second=0, microsecond=0)
            
            if mkt_open <= now <= mkt_close:
                try:
                    # 1. High-Speed Guardian Loop (Every 60s): Stop-Loss & Target Monitoring
                    bot.manage_core_positions()
                    bot.manage_satellite_positions()
                    bot.manage_intraday_shorts()
                    
                    # 2. Periodic Macro & Universe Scanner (Every 15 mins or near 03:15 PM EOD)
                    current_ts = time.time()
                    if (current_ts - last_universe_scan_time) >= UNIVERSE_SCAN_INTERVAL_SEC:
                        logger.info("🔭 Running 15-Minute Macro & Universe Evaluation...")
                        regime = bot.evaluate_market_regime()
                        if regime['is_bull']:
                            logger.info(f"🟢 Regime: BULLISH (NIFTY > EMA20 at {regime['nifty_close']:,.0f}). Full Core & Option Spreads.")
                            bot.execute_core_entries()
                            bot.execute_satellite_entries()
                        else:
                            logger.info(f"🔴 Regime: CORRECTION / BEARISH (NIFTY < EMA20 at {regime['nifty_close']:,.0f}). Engaging Scout Sizing Mode (Max 2 Slots, Rs.1.44L+ Cash Protected).")
                            bot.execute_core_entries()
                            bot.execute_bearish_intraday_shorts()
                            
                        last_universe_scan_time = current_ts
                        bot.print_status()
                        
                except Exception as e:
                    logger.error(f"Error in dual-speed hybrid cycle: {e}")
                    
                time.sleep(POSITION_CHECK_INTERVAL_SEC)
            elif now < mkt_open:
                sleep_sec = (mkt_open - now).total_seconds()
                logger.info(f"Pre-market: Sleeping {sleep_sec/60:.1f} mins until 09:15 IST opening bell...")
                time.sleep(min(sleep_sec, 300))
            else:
                next_open = (now + timedelta(days=1)).replace(hour=9, minute=15, second=0, microsecond=0)
                sleep_sec = (next_open - now).total_seconds()
                logger.info(f"Market closed: Sleeping {sleep_sec/3600:.1f} hours until tomorrow morning...")
                time.sleep(min(sleep_sec, 3600))
        else:
            days_ahead = 7 - now.weekday()
            monday = (now + timedelta(days=days_ahead)).replace(hour=9, minute=15, second=0, microsecond=0)
            sleep_sec = (monday - now).total_seconds()
            logger.info(f"Weekend: Sleeping {sleep_sec/3600:.1f} hours until Monday 09:15 IST...")
            time.sleep(min(sleep_sec, 7200))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Dhan 80/20 Hybrid Core-Satellite Engine")
    parser.add_argument('--status', action='store_true', help='Print current portfolio status')
    parser.add_argument('--run', action='store_true', help='Run complete cycle right now')
    parser.add_argument('--scan-core', action='store_true', help='Scan Core Cash breakout candidates')
    parser.add_argument('--scan-satellite', action='store_true', help='Scan Satellite Sniper option candidates')
    parser.add_argument('--daemon', action='store_true', help='Run continuous background daemon')
    parser.add_argument('--live', action='store_true', help='Enable LIVE order execution')
    args = parser.parse_args()

    paper = not args.live
    bot = DhanHybrid8020Bot(paper_mode=paper)

    if args.daemon:
        run_daemon(paper_mode=paper)
    elif args.scan_core:
        cands = bot.scan_core_breakouts()
        print("\nTop Core Cash Breakout Candidates:")
        for idx, c in enumerate(cands[:10]):
            print(f"#{idx+1}: {c['symbol']} @ Rs.{c['price']:.2f} | 1M Ret: +{c['ret_1m']:.1f}% | Vol: {c['vol_ratio']:.1f}x")
    elif args.scan_satellite:
        cands = bot.scan_satellite_breakouts()
        print("\nTop 'Ather Sniper' Option Breakout Candidates (ATH + 2.2x Vol):")
        if not cands:
            print("  -> No stocks currently qualify with >= 2.2x volume ATH breakout.")
        for idx, c in enumerate(cands):
            print(f"#{idx+1}: {c['stock_info']['name']} @ Rs.{c['price']:.2f} | Vol Surge: {c['vol_ratio']:.1f}x")
    elif args.status:
        bot.print_status()
    else:
        bot.run_cycle()
