"""Automated token contract inspector for Solana SPL and Token-2022 mints.

Detects honeypots, unrevoked freeze/mint authorities, malicious transfer hooks,
predatory transfer taxes, permanent delegates, and supply concentration.
"""

from __future__ import annotations

import json
import logging
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)

SPL_TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


@dataclass
class SafetyReport:
    """Detailed outcome of a token security analysis."""
    mint: str
    is_safe: bool
    risk_score: float  # 0.0 (Safe) to 1.0 (Critical Risk / Honeypot)
    reasons: List[str] = field(default_factory=list)
    mint_authority: Optional[str] = None
    freeze_authority: Optional[str] = None
    program_id: str = SPL_TOKEN_PROGRAM_ID
    decimals: int = 9
    supply: int = 0
    extensions_detected: List[str] = field(default_factory=list)
    transfer_fee_bps: int = 0
    details: Dict[str, Any] = field(default_factory=dict)

    def add_violation(self, reason: str, risk_increment: float = 0.5) -> None:
        self.is_safe = False
        self.reasons.append(reason)
        self.risk_score = min(1.0, self.risk_score + risk_increment)


class TokenSafetyFilter:
    """Inspects Solana token mints to prevent interacting with honeypots or rugs."""

    def __init__(
        self,
        rpc_url: Optional[str] = None,
        max_allowed_transfer_fee_bps: int = 0,
        max_holder_concentration_pct: float = 25.0,
    ):
        self.rpc_url = rpc_url or "https://api.mainnet-beta.solana.com"
        self.max_allowed_transfer_fee_bps = max_allowed_transfer_fee_bps
        self.max_holder_concentration_pct = max_holder_concentration_pct

    def inspect_mint(
        self,
        mint: str,
        parsed_data: Optional[Dict[str, Any]] = None,
        program_id: Optional[str] = None,
        largest_accounts: Optional[List[Dict[str, Any]]] = None,
    ) -> SafetyReport:
        """Inspects token mint data from parsed dictionary or via RPC.

        Parameters
        ----------
        mint: Base58 string address of the mint.
        parsed_data: Parsed account JSON from getAccountInfo or mock payload.
        program_id: Owner program ID (SPL Token or Token-2022).
        largest_accounts: Optional list of top token holders for concentration check.
        """
        if parsed_data is None and self.rpc_url:
            parsed_data, fetched_program_id = self._fetch_mint_account(mint)
            if program_id is None:
                program_id = fetched_program_id

        program_id = program_id or SPL_TOKEN_PROGRAM_ID

        report = SafetyReport(
            mint=mint,
            is_safe=True,
            risk_score=0.0,
            program_id=program_id,
        )

        if not parsed_data:
            report.add_violation("Token mint account could not be found or loaded", 1.0)
            return report

        # Extract parsed info
        parsed_info = parsed_data.get("parsed", {}).get("info", parsed_data)
        
        # 1. Verify program validity
        if program_id not in (SPL_TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID):
            report.add_violation(f"Non-standard token program detected: {program_id}", 1.0)

        # 2. Check Mint Authority
        mint_auth = parsed_info.get("mintAuthority")
        report.mint_authority = mint_auth
        if mint_auth is not None and mint_auth != "" and mint_auth != "11111111111111111111111111111111":
            report.add_violation(
                f"Active mint authority detected: {mint_auth} (Risk: infinite supply inflation / rug)",
                0.7,
            )

        # 3. Check Freeze Authority (CRITICAL HONEYPOT VECTOR)
        freeze_auth = parsed_info.get("freezeAuthority")
        report.freeze_authority = freeze_auth
        if freeze_auth is not None and freeze_auth != "" and freeze_auth != "11111111111111111111111111111111":
            report.add_violation(
                f"Active freeze authority detected: {freeze_auth} (Critical honeypot: buyer can be blacklisted)",
                1.0,
            )

        # Basic token metrics
        report.decimals = int(parsed_info.get("decimals", 9))
        report.supply = int(parsed_info.get("supply", 0))

        # 4. Token-2022 Extension Audits
        extensions = parsed_info.get("extensions", [])
        if isinstance(extensions, list):
            for ext in extensions:
                ext_type = ext.get("extension")
                report.extensions_detected.append(ext_type)

                # Transfer Hook: malicious hook can execute arbitrary code on transfer
                if ext_type == "transferHook":
                    hook_program = ext.get("state", {}).get("programId")
                    report.add_violation(
                        f"Malicious transfer hook extension active (hook program: {hook_program}). Risk: transfer block on sell",
                        1.0,
                    )

                # Permanent Delegate: delegate can burn or transfer tokens out of any wallet
                elif ext_type == "permanentDelegate":
                    delegate = ext.get("state", {}).get("delegate")
                    report.add_violation(
                        f"Permanent delegate active: {delegate}. Risk: arbitrary balance confiscation",
                        1.0,
                    )

                # Default Account State: frozen accounts on creation
                elif ext_type == "defaultAccountState":
                    state = ext.get("state", {}).get("accountState")
                    if state in ("frozen", 2, "2"):
                        report.add_violation(
                            "Default account state is FROZEN. New buyer wallets will be immediately locked",
                            1.0,
                        )

                # Transfer Fee Config: predatory fees / taxes
                elif ext_type == "transferFeeConfig":
                    state = ext.get("state", {})
                    # fee basis points (e.g. 500 = 5%)
                    older_fee = state.get("olderTransferFee", {}).get("transferFeeBasisPoints", 0)
                    newer_fee = state.get("newerTransferFee", {}).get("transferFeeBasisPoints", 0)
                    fee_bps = max(int(older_fee), int(newer_fee))
                    report.transfer_fee_bps = fee_bps

                    fee_auth = state.get("transferFeeConfigAuthority")
                    if fee_bps > self.max_allowed_transfer_fee_bps:
                        report.add_violation(
                            f"Transfer fee of {fee_bps / 100:.2f}% exceeds allowable limit ({self.max_allowed_transfer_fee_bps / 100:.2f}%)",
                            0.8,
                        )
                    if fee_auth is not None and fee_auth != "" and fee_auth != "11111111111111111111111111111111":
                        report.add_violation(
                            f"Unrevoked transfer fee authority: {fee_auth} (can be raised to 100% honeypot)",
                            0.6,
                        )

                # Mint Close Authority
                elif ext_type == "mintCloseAuthority":
                    close_auth = ext.get("state", {}).get("closeAuthority")
                    if close_auth:
                        report.add_violation(f"Mint close authority active: {close_auth}", 0.3)

        # 5. Supply Concentration Check (if holder distribution provided)
        if largest_accounts and report.supply > 0:
            top_holders_share = 0.0
            for holder in largest_accounts[:3]:  # Top 3 non-pool holders
                amount = int(holder.get("amount", 0))
                top_holders_share += (amount / report.supply) * 100.0

            if top_holders_share > self.max_holder_concentration_pct:
                report.add_violation(
                    f"Top holders control {top_holders_share:.1f}% of supply (Threshold: {self.max_holder_concentration_pct}%)",
                    0.4,
                )

        report.details = {
            "mint": mint,
            "program_id": program_id,
            "decimals": report.decimals,
            "supply": report.supply,
            "mint_authority": report.mint_authority,
            "freeze_authority": report.freeze_authority,
            "extensions": report.extensions_detected,
            "transfer_fee_bps": report.transfer_fee_bps,
        }

        return report

    def _fetch_mint_account(self, mint: str) -> tuple[Optional[Dict[str, Any]], str]:
        """Fetch parsed account info via standard HTTP RPC JSON-RPC 2.0."""
        payload = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getAccountInfo",
            "params": [
                mint,
                {"encoding": "jsonParsed"},
            ],
        }).encode("utf-8")

        req = urllib.request.Request(
            self.rpc_url,
            data=payload,
            headers={"Content-Type": "application/json", "User-Agent": "SolanaArbEngine/1.0"},
        )

        try:
            with urllib.request.urlopen(req, timeout=5) as response:
                res_data = json.loads(response.read().decode("utf-8"))
                val = res_data.get("result", {}).get("value")
                if not val:
                    return None, SPL_TOKEN_PROGRAM_ID
                owner = val.get("owner", SPL_TOKEN_PROGRAM_ID)
                data = val.get("data")
                return data, owner
        except Exception as e:
            logger.warning("Failed to fetch mint %s from RPC: %s", mint, e)
            return None, SPL_TOKEN_PROGRAM_ID
