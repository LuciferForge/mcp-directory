"""
Serverless entry point for Vercel / AWS Lambda / Cloudflare Python Workers.
Wraps the FastAPI app for serverless invocation.
"""

from src.main import app

# Export default app handler
handler = app
