/**
 * Cloudflare Worker Remote MCP Proxy
 * Routes incoming SSE connections to your containerized server
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const originBackend = env.BACKEND_URL || "https://your-mcp-server.onrender.com";
    
    // Validate API Bearer token
    const authHeader = request.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response("Unauthorized: Bearer token required", { status: 401 });
    }
    
    // Proxy request to backend
    const targetUrl = `${originBackend}${url.pathname}${url.search}`;
    const proxyRequest = new Request(targetUrl, {
      method: request.method,
      headers: request.headers,
      body: request.body
    });
    
    return fetch(proxyRequest);
  }
};
