import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";

const server = new Server(
  {
    name: "production-mcp-typescript",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "calculate_roi",
        description: "Calculate expected ROI and break-even period for cloud resources",
        inputSchema: {
          type: "object",
          properties: {
            monthly_cost: { type: "number", description: "Monthly operating cost in USD" },
            monthly_revenue: { type: "number", description: "Expected monthly revenue in USD" }
          },
          required: ["monthly_cost", "monthly_revenue"]
        }
      }
    ]
  };
});

// Handle tool execution
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  if (request.params.name === "calculate_roi") {
    const cost = Number(request.params.arguments?.monthly_cost || 0);
    const revenue = Number(request.params.arguments?.monthly_revenue || 0);
    const net = revenue - cost;
    const margin = revenue > 0 ? ((net / revenue) * 100).toFixed(1) : "0.0";
    
    return {
      content: [
        {
          type: "text",
          text: `Monthly Net: $${net.toFixed(2)} | Profit Margin: ${margin}% | Status: ${net >= 0 ? "PROFITABLE" : "LOSS"}`
        }
      ]
    };
  }
  throw new Error(`Tool not found: ${request.params.name}`);
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Production TypeScript MCP Server running on Stdio");
}

main().catch((err) => {
  console.error("Fatal error:", err);
  process.exit(1);
});
