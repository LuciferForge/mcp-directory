#!/usr/bin/env python3
"""
==============================================================================
TheBull - NSE Institutional Anomaly & Breakout Scanner (Bidirectional)
==============================================================================
- Scans full liquid NSE Universe (Nifty 500 + High-Beta Mid/Small/Microcaps)
- Detects:
  1. 🟢 Institutional Upside Breakouts (ATH / 20D Breakout + RVOL >= 2.5x + > VWAP)
  2. 🔴 Institutional Downside Breakdowns (Policybazaar style selloffs + RVOL >= 3.0x + < VWAP)
- Dispatches instant actionable Telegram cards with Targets, SL & Option Spreads
==============================================================================
"""

import os
import sys
import time
import argparse
import logging
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
import numpy as np
import yfinance as yf
import requests
from dotenv import load_dotenv

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

# Load Environment & Telegram Credentials
ENV_PATH = SCRIPT_DIR / '.env'
if not ENV_PATH.exists():
    ENV_PATH = SCRIPT_DIR.parent / '.env'
if not ENV_PATH.exists():
    ENV_PATH = Path(r'C:\Users\ManjunathG\Documents\Clawd\.env')
load_dotenv(ENV_PATH)

TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '8876734134:AAFBjmwE-KT9IDghZw994Wc3gPVFtuqUncs').strip()
TELEGRAM_CHAT_ID = os.environ.get('TELEGRAM_CHAT_ID', '257190241').strip()
if ':' in TELEGRAM_CHAT_ID:
    TELEGRAM_CHAT_ID = TELEGRAM_CHAT_ID.split(':')[-1].strip()

# Import Universe
try:
    from nse_universe import NSE_LIQUID_UNIVERSE
except ImportError:
    NSE_LIQUID_UNIVERSE = [
        "HAL.NS", "BEL.NS", "BDL.NS", "COCHINSHIP.NS", "MAZDOCK.NS", "TITAGARH.NS",
        "TEXRAIL.NS", "GENUSPOWER.NS", "APARINDS.NS", "SKIPPER.NS", "ACE.NS",
        "CYIENTDLM.NS", "POLICYBZR.NS", "TRENT.NS", "DIXON.NS", "MCX.NS", "BSE.NS"
    ]

# Setup Logging with UTF-8 support
log_dir = SCRIPT_DIR / 'logs'
log_dir.mkdir(exist_ok=True)
_file_handler = logging.FileHandler(log_dir / 'anomaly_scanner.log', encoding='utf-8')
_stream_handler = logging.StreamHandler(sys.stdout)
_stream_handler.setStream(open(sys.stdout.fileno(), mode='w', encoding='utf-8', buffering=1))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        _file_handler,
        _stream_handler
    ]
)
logger = logging.getLogger("NSE_Anomaly_Scanner")

# Cache to avoid duplicate alerts on the same day
ALERTED_SYMBOLS_TODAY = set()


def send_telegram(text: str) -> bool:
    """Send formatted alert to user's Telegram channel"""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram credentials not configured!")
        return False
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": TELEGRAM_CHAT_ID,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True
        }
        r = requests.post(url, json=payload, timeout=10)
        return r.status_code == 200
    except Exception as e:
        logger.error(f"Error sending Telegram alert: {e}")
        return False


def calculate_vwap(df: pd.DataFrame) -> float:
    """Calculate intraday VWAP from intraday candles"""
    if df.empty or 'Volume' not in df or 'Close' not in df:
        return 0.0
    hlc3 = (df['High'] + df['Low'] + df['Close']) / 3.0
    cum_vol = df['Volume'].cumsum()
    cum_pv = (hlc3 * df['Volume']).cumsum()
    if cum_vol.iloc[-1] > 0:
        return float(cum_pv.iloc[-1] / cum_vol.iloc[-1])
    return float(df['Close'].iloc[-1])


def scan_single_stock(ticker: str) -> dict:
    """Analyze a single stock for institutional volume/price anomalies"""
    try:
        # Download both 15m intraday data and daily data
        df_15m = yf.download(ticker, period="5d", interval="15m", progress=False)
        if df_15m.empty or len(df_15m) < 15:
            return None
            
        df_daily = yf.download(ticker, period="3mo", interval="1d", progress=False)
        if df_daily.empty or len(df_daily) < 20:
            return None
            
        close_15m = df_15m['Close'].squeeze()
        open_15m = df_15m['Open'].squeeze()
        vol_15m = df_15m['Volume'].squeeze()
        
        curr_price = float(close_15m.dropna().iloc[-1])
        open_bar = float(open_15m.dropna().iloc[-1])
        curr_vol = float(vol_15m.dropna().iloc[-1])
        
        # 15m Volume SMA over last 20 bars
        vol_sma20 = float(vol_15m.dropna().iloc[-21:-1].mean()) if len(vol_15m.dropna()) >= 21 else 1.0
        rvol = curr_vol / (vol_sma20 + 1e-9)
        
        # Daily metrics
        close_d = df_daily['Close'].squeeze().dropna()
        high_20d = float(close_d.iloc[-21:-1].max()) if len(close_d) >= 21 else curr_price
        low_20d = float(close_d.iloc[-21:-1].min()) if len(close_d) >= 21 else curr_price
        high_52w = float(close_d.max())
        
        dist_52w = ((curr_price - high_52w) / high_52w) * 100.0
        dist_20d_high = ((curr_price - high_20d) / high_20d) * 100.0
        dist_20d_low = ((curr_price - low_20d) / low_20d) * 100.0
        
        # VWAP
        vwap = calculate_vwap(df_15m)
        
        # Bar price change %
        bar_return_pct = ((curr_price - open_bar) / open_bar) * 100.0
        
        # 🟢 UPSIDE BREAKOUT CRITERIA:
        # 1. Price breaking 20-day high or within 1.5% of 52w High
        # 2. Volume expansion >= 2.5x
        # 3. Holding above VWAP
        is_upside_breakout = (
            (curr_price >= high_20d or dist_52w >= -1.5) and
            (rvol >= 2.5) and
            (curr_price > vwap) and
            (bar_return_pct >= 0.5)
        )
        
        # 🔴 DOWNSIDE BREAKDOWN CRITERIA (The Policybazaar pattern):
        # 1. Price cracking 20-day low or dropping >= -2.5% in bar
        # 2. Volume expansion >= 3.0x on heavy institutional selling
        # 3. Trading below VWAP
        is_downside_breakdown = (
            (curr_price <= low_20d or bar_return_pct <= -2.5) and
            (rvol >= 3.0) and
            (curr_price < vwap) and
            (bar_return_pct <= -0.5)
        )
        
        if is_upside_breakout or is_downside_breakdown:
            return {
                "ticker": ticker,
                "price": curr_price,
                "rvol": rvol,
                "vwap": vwap,
                "bar_ret": bar_return_pct,
                "dist_52w": dist_52w,
                "high_20d": high_20d,
                "low_20d": low_20d,
                "direction": "UPSIDE_BREAKOUT" if is_upside_breakout else "DOWNSIDE_BREAKDOWN"
            }
        return None
    except Exception as e:
        return None


def run_market_scan(batch_size: int = 15, delay: float = 0.5):
    """Execute complete bidirectional scan across liquid universe"""
    logger.info(f"[SCAN] Starting Institutional Anomaly Scan across {len(NSE_LIQUID_UNIVERSE)} liquid NSE stocks...")
    anomalies = []
    
    # Process in batches
    for idx, ticker in enumerate(NSE_LIQUID_UNIVERSE):
        res = scan_single_stock(ticker)
        if res:
            anomalies.append(res)
            logger.info(f"[ANOMALY] [{res['direction']}] {res['ticker']} @ Rs.{res['price']:.2f} | RVOL: {res['rvol']:.1f}x | Bar: {res['bar_ret']:+.1f}%")
            
            # Dispatch to Telegram if not alerted today
            if ticker not in ALERTED_SYMBOLS_TODAY:
                ALERTED_SYMBOLS_TODAY.add(ticker)
                dispatch_anomaly_alert(res)
                
        if (idx + 1) % batch_size == 0:
            time.sleep(delay)
            
    logger.info(f"[SCAN COMPLETE] Found {len(anomalies)} active institutional anomalies.")
    return anomalies


def dispatch_anomaly_alert(data: dict):
    """Format and send Telegram notification card"""
    sym = data['ticker'].replace(".NS", "")
    px = data['price']
    rvol = data['rvol']
    vwap = data['vwap']
    bar_ret = data['bar_ret']
    dist_52w = data['dist_52w']
    dir_type = data['direction']
    
    now_str = datetime.now().strftime("%H:%M IST")
    
    if dir_type == "UPSIDE_BREAKOUT":
        sl_price = max(vwap * 0.985, px * 0.955)
        tp1 = px * 1.08
        tp2 = px * 1.15
        
        msg = f"""🟢 <b>INSTITUTIONAL UPSIDE BREAKOUT ALERT</b> ({now_str})

<b>Stock:</b> <b>{sym}</b>
<b>Price:</b> ₹{px:,.2f} (15m Bar: <b>{bar_ret:+.1f}%</b>)
<b>Relative Volume (RVOL):</b> <b>{rvol:.1f}x normal volume!</b>
<b>Intraday VWAP:</b> ₹{vwap:,.2f} (Above VWAP ✅)
<b>52-Week High Distance:</b> {dist_52w:+.1f}%

🎯 <b>ACTIONABLE EXECUTION PLAN:</b>
• <b>Buy / Accumulation Range:</b> ₹{px*0.995:,.2f} – ₹{px*1.005:,.2f}
• <b>Stop Loss:</b> ₹{sl_price:,.2f} (Below VWAP / -4.5%)
• <b>Target 1:</b> ₹{tp1:,.2f} (+8%)
• <b>Target 2:</b> ₹{tp2:,.2f} (+15%)
• <b>F&O Setup:</b> Bull Call Debit Spread (Buy ATM Call, Sell OTM Call +2 strikes)
"""
    else:
        sl_price = min(vwap * 1.015, px * 1.045)
        target1 = px * 0.92
        target2 = px * 0.85
        
        msg = f"""🔴 <b>INSTITUTIONAL DOWNSIDE BREAKDOWN ALERT</b> ({now_str})
<i>(Warning: Heavy Institutional Selling / Policy Dump Detected)</i>

<b>Stock:</b> <b>{sym}</b>
<b>Price:</b> ₹{px:,.2f} (15m Bar: <b>{bar_ret:+.1f}%</b>)
<b>Selling Volume (RVOL):</b> <b>{rvol:.1f}x normal volume!</b>
<b>Intraday VWAP:</b> ₹{vwap:,.2f} (Below VWAP 🔻)

⚠️ <b>ACTIONABLE DEFENSE & SHORT PLAN:</b>
• <b>Exit Longs / Avoid Fresh Buys:</b> Heavy distribution active.
• <b>Intraday Short (MIS) Zone:</b> ₹{px*0.998:,.2f} – ₹{px*1.002:,.2f}
• <b>Stop Loss:</b> ₹{sl_price:,.2f} (Above VWAP / +3.5%)
• <b>Downside Target 1:</b> ₹{target1:,.2f} (-8%)
• <b>Downside Target 2:</b> ₹{target2:,.2f} (-15%)
• <b>F&O Setup:</b> Bear Put Debit Spread (Buy ATM Put, Sell OTM Put -2 strikes)
"""

    send_telegram(msg)


def run_daemon(interval_mins: int = 10):
    """Background continuous daemon during NSE market hours"""
    logger.info(f"Starting NSE Institutional Anomaly Daemon. Scanning every {interval_mins} mins during market hours...")
    
    # Send startup confirmation
    send_telegram(f"🤖 <b>NSE INSTITUTIONAL ANOMALY SCANNER ACTIVATED</b>\n\n• Universe: <b>{len(NSE_LIQUID_UNIVERSE)} Liquid NSE Stocks</b>\n• Bidirectional Radar: Upside Breakouts + Downside Policy Dumps\n• Real-time Telegram alerting is active.")
    
    while True:
        now = datetime.now()
        if now.weekday() < 5:
            mkt_open = now.replace(hour=9, minute=15, second=0, microsecond=0)
            mkt_close = now.replace(hour=15, minute=30, second=0, microsecond=0)
            
            if mkt_open <= now <= mkt_close:
                try:
                    run_market_scan()
                except Exception as e:
                    logger.error(f"Error in anomaly scan cycle: {e}")
                time.sleep(interval_mins * 60)
            elif now < mkt_open:
                sleep_sec = (mkt_open - now).total_seconds()
                logger.info(f"Pre-market: Sleeping {sleep_sec/60:.1f} mins until 09:15 IST opening bell...")
                time.sleep(min(sleep_sec, 300))
            else:
                next_open = (now + timedelta(days=1)).replace(hour=9, minute=15, second=0, microsecond=0)
                sleep_sec = (next_open - now).total_seconds()
                ALERTED_SYMBOLS_TODAY.clear() # Reset cache for next trading day
                logger.info(f"Market closed: Sleeping {sleep_sec/3600:.1f} hours until tomorrow morning...")
                time.sleep(min(sleep_sec, 3600))
        else:
            days_ahead = 7 - now.weekday()
            monday = (now + timedelta(days=days_ahead)).replace(hour=9, minute=15, second=0, microsecond=0)
            sleep_sec = (monday - now).total_seconds()
            ALERTED_SYMBOLS_TODAY.clear()
            logger.info(f"Weekend: Sleeping {sleep_sec/3600:.1f} hours until Monday morning...")
            time.sleep(min(sleep_sec, 7200))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="NSE Institutional Anomaly & Breakout Scanner")
    parser.add_argument('--scan', action='store_true', help='Execute single market scan right now')
    parser.add_argument('--daemon', action='store_true', help='Run continuous background market scanner')
    parser.add_argument('--interval', type=int, default=10, help='Scan interval in minutes (default: 10)')
    args = parser.parse_args()

    if args.daemon:
        run_daemon(interval_mins=args.interval)
    else:
        run_market_scan()
