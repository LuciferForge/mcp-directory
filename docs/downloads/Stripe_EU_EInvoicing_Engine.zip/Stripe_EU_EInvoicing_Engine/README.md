# Stripe EU E-Invoicing Webhook Engine
### Factur-X 1.0 & ZUGFeRD 2.2 Compliance Engine (EN 16931 Profile)

[![Compliance](https://img.shields.io/badge/Compliance-EN_16931_%2F_Factur--X_2.2-blue.svg)](https://fnfe-mpe.org/factur-x/)
[![Standard](https://img.shields.io/badge/Syntax-UN%2FCEFACT_CII_16B-green.svg)](https://unece.org/trade/uncefact)
[![FastAPI](https://img.shields.io/badge/Framework-FastAPI_%26_Pydantic-brightgreen.svg)](https://fastapi.tiangolo.com)
[![Docker](https://img.shields.io/badge/Container-Docker_Ready-blue.svg)](https://docker.com)

A zero-touch, production-grade webhook ingestion and transformation microservice that converts Stripe invoice webhook events (`invoice.paid`, `invoice.created`, `invoice.finalized`) into standards-compliant **Factur-X / ZUGFeRD 2.2 XML** conforming to the European standard **EN 16931** (CrossIndustryInvoice 16B).

Mandatory across France (Chorus Pro / PDP 2026), Germany (E-Rechnung B2B 2025/2026), Poland, Italy, and broader EU B2B transactions.

---

## Architecture Overview

```
                      +-----------------------------+
                      |     Stripe Webhook Event    |
                      |  (invoice.paid / finalized) |
                      +--------------+--------------+
                                     |
                                     v
                 +---------------------------------------+
                 | POST /webhook                         |
                 | - HMAC-SHA256 Signature Verification  |
                 | - Tolerance / Replay Protection       |
                 +-------------------+-------------------+
                                     |
                                     v
                 +---------------------------------------+
                 | Ingestion & Transformation Engine     |
                 | - Extract Buyer & Seller VAT / Tax IDs|
                 | - Determine Tax Category (S/AE/Z/E)   |
                 | - Handle Intra-EU Reverse Charge      |
                 | - Calculate Monetary Summations       |
                 +-------------------+-------------------+
                                     |
                                     v
                 +---------------------------------------+
                 | Factur-X / ZUGFeRD 2.2 Generator      |
                 | - Format: UN/CEFACT CII 16B XML       |
                 | - Profile: urn:cen.eu:en16931:2017    |
                 | - Namespaces: rsm, ram, udt, qdt      |
                 +-------------------+-------------------+
                                     |
                 +-------------------+-------------------+
                 |                                       |
                 v                                       v
     +-----------------------+              +-----------------------+
     | Storage / Dispatch    |              | Direct API Response   |
     | (Local / S3 / Attach) |              | (POST /convert)       |
     +-----------------------+              +-----------------------+
```

---

## Directory Structure

```
stripe_einvoice_agent/
├── .env.example              # Configuration template (Stripe & Seller defaults)
├── Dockerfile                # Hardened, non-root production container
├── docker-compose.yml        # Docker compose setup
├── requirements.txt          # Python dependencies
├── stripe-app.json           # Official Stripe App manifest
├── vercel.json               # Serverless Vercel deployment spec
├── verify.py                 # Autonomous zero-dependency test runner
├── api/
│   └── index.py              # Serverless entry point
├── src/
│   ├── __init__.py
│   ├── main.py               # FastAPI application with /webhook and /convert
│   ├── models.py             # Pydantic schemas (Party, LineItem, InvoiceData)
│   ├── parser.py             # Ingestion & EN 16931 mapping logic
│   ├── webhook_handler.py    # Signature verification & dispatch
│   └── zugferd_generator.py  # Factur-X EN 16931 CII XML builder
└── tests/
    ├── __init__.py
    ├── mock_payloads.py      # Realistic Stripe webhook fixtures
    └── test_engine.py        # Automated test suite
```

---

## Quickstart & Local Setup

### 1. Installation

```bash
cd stripe_einvoice_agent
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run the Autonomous Test & Verification Suite

Execute the zero-touch test suite covering all tax regimes, reverse charges, signatures, and XML generation:

```bash
python verify.py
```
Or via pytest:
```bash
pytest -v tests/test_engine.py
```

### 3. Start the Webhook Engine

```bash
uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
```

---

## Testing with Stripe CLI

Forward Stripe test events directly to the local engine:

```bash
# 1. Start Stripe CLI listening on webhook endpoint
stripe listen --forward-to localhost:8000/webhook

# 2. Trigger an invoice.paid event in another terminal
stripe trigger invoice.paid
```

---

## Testing via Direct Conversion (`POST /convert`)

You can directly convert any Stripe invoice JSON into Factur-X XML without firing a webhook:

```bash
curl -X POST http://localhost:8000/convert?format=xml \
  -H "Content-Type: application/json" \
  -d @tests/sample_invoice.json \
  -o invoice_facturx.xml
```

---

## Docker Deployment

Build and run with Docker Compose:

```bash
docker-compose up --build -d
```

Check health:
```bash
curl http://localhost:8000/health
```

---

## Compliance & Standards Reference

- **Profile Identifier**: `urn:cen.eu:en16931:2017#compliant#urn:factur-x.eu:1p0:en16931` (Comfort Profile)
- **Syntax**: UN/CEFACT XML CrossIndustryInvoice (CII) version 16B
- **Reverse Charge Support**: Automatically emits Category `AE` and sets Article 196 EU VAT directive legal notices for intra-EU B2B transactions.
- **Payment Scheme**: UN/ECE 4461 Code 58 (SEPA Credit Transfer) with creditor IBAN/BIC mapping.
