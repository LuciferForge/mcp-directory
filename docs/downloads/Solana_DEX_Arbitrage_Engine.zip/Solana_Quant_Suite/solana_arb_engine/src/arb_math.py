"""Constant-Product, Concentrated Liquidity, and Arbitrage Routing Mathematics.

Includes exact swap formulas, price impact, DLMM bin crossing, optimal trade sizing,
and net arbitrage profit calculations with DEX fees and slippage.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, List, Tuple


@dataclass
class PoolState:
    """Represents a DEX pool state for calculation."""
    pool_id: str
    dex_name: str
    token_mint_a: str  # Usually SOL / WSOL (base)
    token_mint_b: str  # Target meme / long-tail token
    reserve_a: int     # Base reserve in raw units (lamports)
    reserve_b: int     # Target reserve in raw units
    fee_bps: int = 25  # Basis points (25 bps = 0.25%)
    decimals_a: int = 9
    decimals_b: int = 6
    is_concentrated: bool = False
    active_bin_id: Optional[int] = None
    bin_step_bps: int = 20

    @property
    def price_b_in_a(self) -> float:
        """Spot price: units of Token A (SOL) per 1 unit of Token B."""
        if self.reserve_b <= 0:
            return 0.0
        # normalized for decimals
        norm_a = self.reserve_a / (10 ** self.decimals_a)
        norm_b = self.reserve_b / (10 ** self.decimals_b)
        return norm_a / norm_b if norm_b > 0 else 0.0


@dataclass
class SwapResult:
    """Result of an exact AMM swap execution."""
    amount_in: int
    amount_out: int
    fee_paid: int
    price_impact_pct: float
    effective_price: float
    new_reserve_in: int
    new_reserve_out: int


@dataclass
class ArbOpportunity:
    """Represents a computed 2-leg or multi-hop arbitrage route."""
    pool_buy: PoolState
    pool_sell: PoolState
    optimal_input_sol: float
    optimal_input_lamports: int
    tokens_acquired: int
    final_sol_lamports: int
    gross_profit_sol: float
    net_profit_sol: float
    estimated_jito_tip_sol: float
    price_spread_pct: float
    roi_pct: float
    is_profitable: bool


class AMMMath:
    """Constant-Product (x * y = k) mathematical calculations."""

    @staticmethod
    def get_amount_out(
        amount_in: int,
        reserve_in: int,
        reserve_out: int,
        fee_bps: int = 25,
    ) -> SwapResult:
        """Calculate exact token out for a given token in using Constant Product formula.

        Formula:
            amount_in_with_fee = amount_in * (10000 - fee_bps)
            numerator = amount_in_with_fee * reserve_out
            denominator = (reserve_in * 10000) + amount_in_with_fee
            amount_out = numerator // denominator
        """
        if amount_in <= 0 or reserve_in <= 0 or reserve_out <= 0:
            return SwapResult(0, 0, 0, 0.0, 0.0, reserve_in, reserve_out)

        amount_in_with_fee = amount_in * (10000 - fee_bps)
        numerator = amount_in_with_fee * reserve_out
        denominator = (reserve_in * 10000) + amount_in_with_fee

        amount_out = numerator // denominator
        fee_paid = (amount_in * fee_bps + 9999) // 10000  # Ceiling division for fee

        # Effective price & price impact calculation
        effective_price = amount_in / amount_out if amount_out > 0 else 0.0
        initial_spot_price = reserve_in / reserve_out if reserve_out > 0 else 0.0
        price_impact_pct = (
            ((effective_price - initial_spot_price) / initial_spot_price * 100.0)
            if initial_spot_price > 0
            else 0.0
        )

        return SwapResult(
            amount_in=amount_in,
            amount_out=amount_out,
            fee_paid=fee_paid,
            price_impact_pct=max(0.0, price_impact_pct),
            effective_price=effective_price,
            new_reserve_in=reserve_in + amount_in,
            new_reserve_out=reserve_out - amount_out,
        )

    @staticmethod
    def get_amount_in(
        amount_out: int,
        reserve_in: int,
        reserve_out: int,
        fee_bps: int = 25,
    ) -> int:
        """Calculate required token in for an exact desired token out."""
        if amount_out <= 0 or reserve_out <= amount_out or reserve_in <= 0:
            return 0
        numerator = reserve_in * amount_out * 10000
        denominator = (reserve_out - amount_out) * (10000 - fee_bps)
        return (numerator + denominator - 1) // denominator  # Ceiling division


class DLMMMath:
    """Concentrated Liquidity & Bin Model (Meteora DLMM style)."""

    @staticmethod
    def get_bin_price(bin_id: int, bin_step_bps: int = 20) -> float:
        """Compute relative price of bin P(i) = (1 + bin_step)^bin_id."""
        step = bin_step_bps / 10000.0
        return math.pow(1.0 + step, bin_id)

    @staticmethod
    def simulate_dlmm_swap(
        amount_in: int,
        bins: List[Tuple[int, int, int]],  # List of (bin_id, reserve_x, reserve_y)
        swap_x_to_y: bool,
        fee_bps: int = 20,
    ) -> Tuple[int, int]:
        """Simulate consuming liquidity across multiple concentrated bins.

        Returns (total_amount_out, total_fee_paid).
        """
        remaining_in = amount_in
        total_out = 0
        total_fee = 0

        # Sort bins according to swap direction
        sorted_bins = sorted(bins, key=lambda b: b[0], reverse=not swap_x_to_y)

        for bin_id, bin_rx, bin_ry in sorted_bins:
            if remaining_in <= 0:
                break

            fee = (remaining_in * fee_bps + 9999) // 10000
            in_after_fee = remaining_in - fee

            if swap_x_to_y:
                # Trading X for Y: Y is consumed from bin
                if bin_ry <= 0:
                    continue
                price = DLMMMath.get_bin_price(bin_id)
                max_x_needed = int(bin_ry / price) if price > 0 else 0
                if in_after_fee >= max_x_needed and max_x_needed > 0:
                    # Drain this bin
                    total_out += bin_ry
                    total_fee += (max_x_needed * fee_bps + 9999) // 10000
                    remaining_in -= (max_x_needed + (max_x_needed * fee_bps + 9999) // 10000)
                else:
                    # Partial fill in this bin
                    out_y = int(in_after_fee * price)
                    out_y = min(out_y, bin_ry)
                    total_out += out_y
                    total_fee += fee
                    remaining_in = 0
            else:
                # Trading Y for X: X is consumed from bin
                if bin_rx <= 0:
                    continue
                price = DLMMMath.get_bin_price(bin_id)
                max_y_needed = int(bin_rx * price)
                if in_after_fee >= max_y_needed and max_y_needed > 0:
                    total_out += bin_rx
                    total_fee += (max_y_needed * fee_bps + 9999) // 10000
                    remaining_in -= (max_y_needed + (max_y_needed * fee_bps + 9999) // 10000)
                else:
                    out_x = int(in_after_fee / price) if price > 0 else 0
                    out_x = min(out_x, bin_rx)
                    total_out += out_x
                    total_fee += fee
                    remaining_in = 0

        return total_out, total_fee


class PumpFunMath:
    """Pump.fun bonding curve and migration graduation mathematics."""

    VIRTUAL_SOL_RESERVE = 30_000_000_000        # 30 SOL in lamports
    VIRTUAL_TOKEN_RESERVE = 1_073_000_000_000_000 # 1.073B tokens
    REAL_TOKEN_RESERVE = 793_100_000_000_000    # Initial tokens available for sale
    GRADUATION_SOL_THRESHOLD = 85_000_000_000   # 85 SOL target
    FEE_BPS = 100                               # 1% pump.fun fee

    @classmethod
    def get_quote_out(cls, sol_in: int, current_real_sol: int) -> int:
        """Calculate tokens received for buying on the bonding curve."""
        current_v_sol = cls.VIRTUAL_SOL_RESERVE + current_real_sol
        current_v_token = (cls.VIRTUAL_SOL_RESERVE * cls.VIRTUAL_TOKEN_RESERVE) // current_v_sol

        fee = (sol_in * cls.FEE_BPS + 9999) // 10000
        sol_in_after_fee = sol_in - fee

        new_v_sol = current_v_sol + sol_in_after_fee
        new_v_token = (current_v_sol * current_v_token) // new_v_sol
        tokens_out = current_v_token - new_v_token
        return max(0, tokens_out)

    @classmethod
    def is_graduated(cls, real_sol_lamports: int) -> bool:
        """Checks if bonding curve has hit graduation mark (>= 85 SOL)."""
        return real_sol_lamports >= cls.GRADUATION_SOL_THRESHOLD


class ArbCalculator:
    """Arbitrage router and mathematical optimizer."""

    @staticmethod
    def calculate_optimal_trade_size(
        pool_buy: PoolState,
        pool_sell: PoolState,
        max_sol: float = 5.0,
        min_sol: float = 0.05,
    ) -> Tuple[int, float]:
        """Calculates optimal SOL input size to maximize net profit.

        Uses analytical derivation for Constant Product AMMs with numerical
        boundary verification.

        Analytical formula:
            Let r1 = 1 - f1, r2 = 1 - f2
            A = x2 * y1 * r1 * r2
            B = x1 * y2
            C = r1 * (y2 + r2 * y1)
            optimal_dx = (sqrt(A * B) - B) / C
        """
        x1 = pool_buy.reserve_a   # SOL in Pool 1
        y1 = pool_buy.reserve_b   # Tokens in Pool 1
        y2 = pool_sell.reserve_b  # Tokens in Pool 2
        x2 = pool_sell.reserve_a  # SOL in Pool 2

        if x1 <= 0 or y1 <= 0 or x2 <= 0 or y2 <= 0:
            return 0, 0.0

        r1 = (10000 - pool_buy.fee_bps) / 10000.0
        r2 = (10000 - pool_sell.fee_bps) / 10000.0

        A = float(x2) * float(y1) * r1 * r2
        B = float(x1) * float(y2)
        C = r1 * (float(y2) + r2 * float(y1))

        if A * B <= 0 or C <= 0:
            return 0, 0.0

        sqrt_ab = math.sqrt(A * B)
        if sqrt_ab <= B:
            # Not profitable at any size
            return 0, 0.0

        optimal_lamports_float = (sqrt_ab - B) / C
        optimal_lamports = int(optimal_lamports_float)

        min_lamports = int(min_sol * 1e9)
        max_lamports = int(max_sol * 1e9)

        if optimal_lamports < min_lamports:
            return 0, 0.0

        optimal_lamports = min(optimal_lamports, max_lamports)
        optimal_sol = optimal_lamports / 1e9
        return optimal_lamports, optimal_sol

    @classmethod
    def evaluate_arbitrage(
        cls,
        pool_a: PoolState,
        pool_b: PoolState,
        min_profit_sol: float = 0.005,
        max_trade_sol: float = 5.0,
        min_trade_sol: float = 0.05,
        tip_percentage: float = 0.50,
        max_tip_sol: float = 0.05,
    ) -> Optional[ArbOpportunity]:
        """Compares two pools for price dislocation and evaluates arb viability in both directions."""
        price_a = pool_a.price_b_in_a
        price_b = pool_b.price_b_in_a

        if price_a <= 0 or price_b <= 0:
            return None

        # Determine direction: buy on cheaper pool, sell on expensive pool
        if price_a < price_b:
            pool_buy = pool_a
            pool_sell = pool_b
        else:
            pool_buy = pool_b
            pool_sell = pool_a

        spread_pct = ((max(price_a, price_b) - min(price_a, price_b)) / min(price_a, price_b)) * 100.0

        # Fast filter: spread must be greater than combined fees (e.g. 50 bps)
        combined_fee_bps = pool_buy.fee_bps + pool_sell.fee_bps
        if spread_pct < (combined_fee_bps / 100.0):
            return None

        optimal_lamports, optimal_sol = cls.calculate_optimal_trade_size(
            pool_buy=pool_buy,
            pool_sell=pool_sell,
            max_sol=max_trade_sol,
            min_sol=min_trade_sol,
        )

        if optimal_lamports <= 0:
            return None

        # Execute Leg 1: Buy Token B using SOL on pool_buy
        swap_leg1 = AMMMath.get_amount_out(
            amount_in=optimal_lamports,
            reserve_in=pool_buy.reserve_a,
            reserve_out=pool_buy.reserve_b,
            fee_bps=pool_buy.fee_bps,
        )

        tokens_received = swap_leg1.amount_out
        if tokens_received <= 0:
            return None

        # Execute Leg 2: Sell Token B for SOL on pool_sell
        swap_leg2 = AMMMath.get_amount_out(
            amount_in=tokens_received,
            reserve_in=pool_sell.reserve_b,
            reserve_out=pool_sell.reserve_a,
            fee_bps=pool_sell.fee_bps,
        )

        final_sol_lamports = swap_leg2.amount_out
        gross_profit_lamports = final_sol_lamports - optimal_lamports
        gross_profit_sol = gross_profit_lamports / 1e9

        if gross_profit_sol <= 0:
            return None

        # Dynamic Tip calculation: min(tip_percentage * GrossProfit, max_tip_sol)
        estimated_tip_sol = min(tip_percentage * gross_profit_sol, max_tip_sol)
        # Network base fee (approx 0.000010 SOL for 2 instructions + priority fee)
        base_fee_sol = 0.000015
        net_profit_sol = gross_profit_sol - estimated_tip_sol - base_fee_sol

        roi_pct = (net_profit_sol / optimal_sol) * 100.0 if optimal_sol > 0 else 0.0
        is_profitable = net_profit_sol >= min_profit_sol

        return ArbOpportunity(
            pool_buy=pool_buy,
            pool_sell=pool_sell,
            optimal_input_sol=optimal_sol,
            optimal_input_lamports=optimal_lamports,
            tokens_acquired=tokens_received,
            final_sol_lamports=final_sol_lamports,
            gross_profit_sol=gross_profit_sol,
            net_profit_sol=net_profit_sol,
            estimated_jito_tip_sol=estimated_tip_sol,
            price_spread_pct=spread_pct,
            roi_pct=roi_pct,
            is_profitable=is_profitable,
        )
