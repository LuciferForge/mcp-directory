"""
In-memory sliding window rate limiter.
"""
import time
from collections import defaultdict, deque

class SlidingWindowRateLimiter:
    def __init__(self, max_requests: int = 60, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window = window_seconds
        self.clients = defaultdict(deque)

    def allow_request(self, client_id: str) -> bool:
        now = time.time()
        queue = self.clients[client_id]
        while queue and queue[0] <= now - self.window:
            queue.popleft()
        if len(queue) < self.max_requests:
            queue.append(now)
            return True
        return False
