# TheBull - Binance Futures Algorithmic Trading Bot

![TheBull Banner](https://raw.githubusercontent.com/manjunathg-dev/thebull/main/thebull_banner.png)

> **Commercial-Grade Multi-Factor Momentum & Market Regime Trading Engine for Binance USDT-Margined Futures.**

---

## 🚀 Key Highlights

- **100-Point Multi-Factor Scoring Engine:**
  - **Trend Alignment (25 pts):** Multi-timeframe trend confluence across 1h, 4h, and daily EMAs.
  - **Momentum Power (20 pts):** Dual-speed zero-lag acceleration, RSI momentum slopes, and directional thrust.
  - **Volume Confirmation (15 pts):** Volume surge detection eliminating false breakout traps.
  - **Market Regime Support (15 pts):** ADX trend strength + Bollinger band squeeze detection.
  - **Technical Confluence (10 pts):** MACD histogram expansions, Supertrend confirmation.
  - **Volatility & Location (15 pts):** Dynamic ATR positioning & range boundaries.
- **Dynamic Risk & Margin Sizing:**
  - 1% account risk per trade with dynamic ATR-based stop sizing.
  - Portfolio heat cap prevents overexposure during sudden market-wide movements.
- **Dynamic Multi-Stage Trailing Stops:**
  - Auto-moves stops to Break-Even at +2.0% profit.
  - Progressively trails price to capture major multi-day trend runners.
- **High-Throughput Batch Scanning:** Automatically scans up to 250+ top liquid USDT futures contracts in rapid parallel batches.
- **Automatic Server Time Offset Sync:** Eliminates `-1021 Timestamp` errors automatically.

---

## 📦 Quick Start (Under 3 Minutes)

### Windows (1-Click Run)
1. Double-click `start_bot.bat`.
2. The script will automatically create a virtual environment, install requirements, and prompt you to enter your Binance API keys in `.env`.
3. Save your `.env` file, press any key, and the bot begins scanning!

### Linux / macOS
```bash
chmod +x start_bot.sh
./start_bot.sh
```

---

## 🛠️ Manual Installation

```bash
# 1. Clone repository
git clone https://github.com/manja316/thebull-binance-bot.git
cd thebull-binance-bot

# 2. Virtual Environment
python3 -m venv .venv
# On Windows:
.venv\Scripts\activate
# On Linux/macOS:
source .venv/bin/activate

# 3. Install Requirements
pip install -r requirements.txt

# 4. Setup Credentials
cp .env.example .env
# Edit .env and paste your API_KEY and API_SECRET
```

---

## ⚙️ Configuration (`config.json`)

```json
{
  "bot_name": "TheBull Binance Futures Zero-Lag Momentum Bot",
  "leverage": 10,
  "default_max_positions": 50,
  "min_signal_strength": 55,
  "scan_interval_seconds": 30,
  "scan_batch_size": 50,
  "risk_management": {
    "max_position_risk_pct": 1.0,
    "max_portfolio_heat_pct": 25.0
  }
}
```

---

## 🛡️ Risk Management & API Setup Rules

1. **Binance API Permissions:**
   - Enable **Reading** and **Enable Futures**.
   - **DO NOT** enable Spot/Margin or Withdrawal permissions. Keep withdrawals disabled for security.
2. **IP Whitelisting (Recommended):** Whitelist your PC or VPS IP in Binance API Management.
3. **Position Sizing:** Default risk is capped at 1% of equity per trade.

---

## ⚠️ Disclaimer

*Futures trading involves substantial risk and is not suitable for every investor. Automated systems do not eliminate risk. Past performance does not guarantee future results. Trade only with funds you can afford to lose.*
