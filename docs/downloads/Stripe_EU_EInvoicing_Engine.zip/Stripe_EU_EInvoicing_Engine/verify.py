"""
Autonomous Verification Runner for Stripe EU E-Invoicing Engine.
Runs zero-touch validation across all test suites and prints compliance matrix.
"""

import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from tests.test_engine import (
    test_domestic_french_invoice,
    test_reverse_charge_eu_invoice,
    test_multi_line_mixed_tax_invoice,
    test_stripe_signature_verification,
    test_process_stripe_event_e2e,
)


def run_all_verifications():
    print("=" * 75)
    print("  STRIPE EU E-INVOICING ENGINE: AUTONOMOUS TEST & VERIFICATION SUITE")
    print("  Standard: Factur-X 1.0 / ZUGFeRD 2.2 / EN 16931:2017")
    print("=" * 75)

    tests = [
        ("Domestic B2B French Invoice (20% Standard VAT)", test_domestic_french_invoice),
        ("Intra-EU Reverse Charge Supply (0% VAT, Art. 196)", test_reverse_charge_eu_invoice),
        ("Multi-line Mixed Tax Rates (19% Standard & 7% Reduced)", test_multi_line_mixed_tax_invoice),
        ("Stripe Webhook Signature Verification (HMAC-SHA256)", test_stripe_signature_verification),
        ("End-to-End Event Dispatcher & Factur-X Generation", test_process_stripe_event_e2e),
    ]

    all_passed = True
    results = []

    for idx, (name, test_func) in enumerate(tests, 1):
        try:
            test_func()
            status = "PASS"
            err_msg = ""
        except Exception as exc:
            status = "FAIL"
            err_msg = str(exc)
            all_passed = False

        results.append((idx, name, status, err_msg))
        symbol = "✓" if status == "PASS" else "✗"
        print(f"[{symbol}] Test {idx:02d}: {name:<55} -> {status}")
        if err_msg:
            print(f"    Error: {err_msg}")

    print("=" * 75)
    if all_passed:
        print(">>> ALL 5/5 AUTONOMOUS COMPLIANCE CHECKS PASSED SUCCESSFULLY. <<<")
        print(">>> Standard Factur-X / ZUGFeRD 2.2 CII XML output is certified. <<<")
    else:
        print(">>> SOME VERIFICATION CHECKS FAILED. See log details above. <<<")
    print("=" * 75)

    return 0 if all_passed else 1


if __name__ == "__main__":
    exit_code = run_all_verifications()
    sys.exit(exit_code)
