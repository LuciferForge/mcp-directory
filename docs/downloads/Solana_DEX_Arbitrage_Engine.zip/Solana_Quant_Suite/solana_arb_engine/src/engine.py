"""Solana Long-Tail & Migration Arbitrage Engine Orchestrator.

Coordinates pool listeners, automated token contract security analysis,
optimal trade sizing & price impact math, dynamic Jito MEV bundle construction,
and real-time paper-trading execution.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, Any, Optional, List

from .config import EngineConfig
from .safety_filter import TokenSafetyFilter, SafetyReport
from .arb_math import ArbCalculator, ArbOpportunity, PoolState
from .jito_bundler import JitoBundler, JitoBundle, SimulationExecutionResult
from .pool_listener import PoolListener, PoolEvent

logger = logging.getLogger(__name__)


@dataclass
class EngineStats:
    """Running performance statistics for the arbitrage engine."""
    events_received: int = 0
    safety_violations_blocked: int = 0
    clean_tokens_evaluated: int = 0
    unprofitable_skipped: int = 0
    bundles_generated: int = 0
    successful_paper_trades: int = 0
    failed_reverts: int = 0
    cumulative_gross_profit_sol: float = 0.0
    cumulative_jito_tips_sol: float = 0.0
    cumulative_net_profit_sol: float = 0.0
    current_sol_balance: float = 10.0
    start_time_utc: float = field(default_factory=time.time)

    @property
    def win_rate_pct(self) -> float:
        total = self.successful_paper_trades + self.failed_reverts
        return (self.successful_paper_trades / total * 100.0) if total > 0 else 0.0

    @property
    def total_pnl_pct(self) -> float:
        initial = 10.0
        return ((self.current_sol_balance - initial) / initial) * 100.0


@dataclass
class EngineExecutionReport:
    """Detailed summary of single event processing."""
    token_mint: str
    safety_report: SafetyReport
    arb_opportunity: Optional[ArbOpportunity] = None
    jito_bundle: Optional[JitoBundle] = None
    simulation_result: Optional[SimulationExecutionResult] = None
    decision: str = "IGNORED"  # "BLOCKED_HONEYPOT", "SKIPPED_UNPROFITABLE", "EXECUTED_PROFITABLE", "REVERTED"


class ArbitrageEngine:
    """The central orchestration engine for Solana Long-Tail & Migration Arbitrage."""

    def __init__(self, config: Optional[EngineConfig] = None):
        self.config = config or EngineConfig.load()
        self.safety_filter = TokenSafetyFilter(
            rpc_url=self.config.rpc_url,
            max_allowed_transfer_fee_bps=self.config.slippage_tolerance_bps,
        )
        self.jito_bundler = JitoBundler(
            tip_percentage=self.config.tip_percentage,
            max_tip_sol=self.config.max_tip_sol,
            min_profit_sol=self.config.min_profit_sol,
        )
        self.pool_listener = PoolListener(
            ws_url=self.config.ws_url,
            dex_programs=self.config.dex_programs,
        )
        self.stats = EngineStats(
            current_sol_balance=self.config.simulation.initial_sol_balance,
        )
        self._ensure_log_directory()

    def _ensure_log_directory(self) -> None:
        """Create log output directory if needed."""
        log_path = Path(self.config.simulation.log_file)
        if not log_path.is_absolute():
            log_path = Path(__file__).resolve().parent.parent / log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_filepath = log_path

    def process_opportunity(
        self,
        pool1: PoolState,
        pool2: PoolState,
        token_metadata: Optional[Dict[str, Any]] = None,
        largest_holders: Optional[List[Dict[str, Any]]] = None,
    ) -> EngineExecutionReport:
        """Processes a pair of pools through the entire pipeline:

        Pipeline:
        1. Token Contract Safety Audit (Honeypot, Mint authority, Freeze authority, Token-2022 extensions)
        2. AMM & DLMM Cross-Pool Mathematical Arbitrage Sizing
        3. Net Profitability & Jito dynamic tip threshold validation
        4. Atomic Jito Bundle assembly
        5. Simulation / Paper-Trading execution with balance update
        """
        self.stats.events_received += 1
        target_token = pool1.token_mint_b

        # 1. Automated Token Security Inspection
        safety_report = self.safety_filter.inspect_mint(
            mint=target_token,
            parsed_data=token_metadata,
            largest_accounts=largest_holders,
        )

        if not safety_report.is_safe:
            self.stats.safety_violations_blocked += 1
            logger.info("BLOCKED HONEYPOT TOKEN %s: %s", target_token[:8], ", ".join(safety_report.reasons))
            return EngineExecutionReport(
                token_mint=target_token,
                safety_report=safety_report,
                decision="BLOCKED_HONEYPOT",
            )

        self.stats.clean_tokens_evaluated += 1

        # 2. Mathematical Arbitrage Evaluation & Trade Sizing
        arb_opp = ArbCalculator.evaluate_arbitrage(
            pool_a=pool1,
            pool_b=pool2,
            min_profit_sol=self.config.min_profit_sol,
            max_trade_sol=self.config.max_trade_sol,
            min_trade_sol=self.config.min_trade_sol,
            tip_percentage=self.config.tip_percentage,
            max_tip_sol=self.config.max_tip_sol,
        )

        if arb_opp is None or not arb_opp.is_profitable:
            self.stats.unprofitable_skipped += 1
            return EngineExecutionReport(
                token_mint=target_token,
                safety_report=safety_report,
                arb_opportunity=arb_opp,
                decision="SKIPPED_UNPROFITABLE",
            )

        # 3. Dynamic Jito MEV Bundle Construction with Atomic Safety Assertion
        bundle = self.jito_bundler.construct_bundle(arb=arb_opp)
        if not bundle:
            return EngineExecutionReport(
                token_mint=target_token,
                safety_report=safety_report,
                arb_opportunity=arb_opp,
                decision="SKIPPED_UNPROFITABLE",
            )

        self.stats.bundles_generated += 1

        # 4. Atomic Execution Simulation (Paper Trading)
        sim_result = self.jito_bundler.simulate_execution(
            bundle=bundle,
            current_wallet_balance_sol=self.stats.current_sol_balance,
        )

        if sim_result.success:
            self.stats.successful_paper_trades += 1
            self.stats.cumulative_gross_profit_sol += sim_result.gross_profit_sol
            self.stats.cumulative_jito_tips_sol += sim_result.tip_paid_sol
            self.stats.cumulative_net_profit_sol += sim_result.net_profit_sol
            self.stats.current_sol_balance = sim_result.final_balance_sol
            decision = "EXECUTED_PROFITABLE"
        else:
            self.stats.failed_reverts += 1
            decision = "REVERTED"

        report = EngineExecutionReport(
            token_mint=target_token,
            safety_report=safety_report,
            arb_opportunity=arb_opp,
            jito_bundle=bundle,
            simulation_result=sim_result,
            decision=decision,
        )

        self._log_trade_record(report)
        return report

    def _log_trade_record(self, report: EngineExecutionReport) -> None:
        """Appends structured JSON record to the audit log."""
        if not self.log_filepath:
            return

        arb = report.arb_opportunity
        sim = report.simulation_result
        bundle = report.jito_bundle

        record = {
            "timestamp": time.time(),
            "decision": report.decision,
            "token_mint": report.token_mint,
            "is_safe": report.safety_report.is_safe,
            "risk_score": report.safety_report.risk_score,
            "reasons": report.safety_report.reasons,
        }

        if arb and sim and bundle:
            record.update({
                "bundle_id": bundle.bundle_id,
                "buy_dex": arb.pool_buy.dex_name,
                "sell_dex": arb.pool_sell.dex_name,
                "input_sol": arb.optimal_input_sol,
                "tokens_acquired": arb.tokens_acquired,
                "spread_pct": round(arb.price_spread_pct, 4),
                "gross_profit_sol": round(sim.gross_profit_sol, 6),
                "jito_tip_sol": round(sim.tip_paid_sol, 6),
                "net_profit_sol": round(sim.net_profit_sol, 6),
                "current_sol_balance": round(self.stats.current_sol_balance, 6),
                "latency_ms": round(sim.execution_time_ms, 3),
            })

        try:
            with open(self.log_filepath, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as e:
            logger.error("Failed to write simulation log: %s", e)

    async def run_paper_trading_loop(
        self,
        max_events: Optional[int] = None,
        event_interval: float = 1.0,
        print_callback: Optional[callable] = None,
    ) -> None:
        """Runs the continuous asynchronous paper trading loop using synthetic/live market feeds."""
        logger.info("Initializing Solana Arbitrage Paper-Trading Engine...")
        logger.info("Initial Paper Wallet Balance: %.4f SOL", self.stats.current_sol_balance)

        async for ev_buy, ev_sell, token_meta in self.pool_listener.stream_synthetic_events(
            interval_sec=event_interval,
            max_events=max_events,
        ):
            pool1 = ev_buy.to_pool_state()
            pool2 = ev_sell.to_pool_state()

            report = self.process_opportunity(
                pool1=pool1,
                pool2=pool2,
                token_metadata=token_meta,
            )

            if print_callback:
                print_callback(report, self.stats)

    def stop(self) -> None:
        """Gracefully halts the engine."""
        self.pool_listener.stop()
