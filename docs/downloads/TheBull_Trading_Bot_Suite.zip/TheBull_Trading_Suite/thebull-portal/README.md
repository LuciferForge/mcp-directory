# TheBull Distribution Portal & Documentation Hub

> **Interactive Onboarding & Deployment Web Portal for TheBull Algorithmic Trading Systems.**

This directory contains the standalone web portal that you can either host for free on **GitHub Pages** or open locally in any browser.

---

## 🌐 Deploying to GitHub Pages (Free & 2 Minutes)

1. Create a repository on GitHub named `thebull` (or `thebull-portal`).
2. Push the files in this directory to the repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of TheBull Web Portal"
   git branch -M main
   git remote add origin https://github.com/manja316/thebull-portal.git
   git push -u origin main
   ```
3. On GitHub, navigate to **Settings -> Pages**.
4. Under **Branch**, select `main` and folder `/ (root)`, then click **Save**.
5. Your interactive portal will instantly be live at:
   `https://manja316.github.io/thebull-portal/`

Friends can now visit this link directly from their browser, choose their exchange, copy the commands, and set up the bot!

---

## 🖥️ Local Viewing

You can also double-click `index.html` on your PC to view the portal locally in Google Chrome, Edge, or Firefox.
