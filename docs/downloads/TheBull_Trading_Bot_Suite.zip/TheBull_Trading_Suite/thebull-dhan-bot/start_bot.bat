@echo off
TITLE TheBull Dhan 80/20 Hybrid Trading Bot
color 0E

echo ==============================================================================
echo                 THEBULL - DHAN 80/20 HYBRID TRADING BOT
echo ==============================================================================
echo.

:: 1. Check Python installation
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python is not installed or not in your system PATH!
    echo Please download and install Python 3.10+ from https://www.python.org/downloads/
    echo Make sure to check the box "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

:: 2. Set up virtual environment
if not exist ".venv" (
    echo [SETUP] Creating isolated Python virtual environment (.venv)...
    python -m venv .venv
    if %ERRORLEVEL% NEQ 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

:: 3. Activate virtual environment
call .venv\Scripts\activate.bat

:: 4. Install dependencies
echo [SETUP] Checking and installing required dependencies...
python -m pip install --upgrade pip >nul 2>nul
pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

:: 5. Check .env configuration
if not exist ".env" (
    echo [SETUP] No .env file found. Creating from .env.example...
    copy .env.example .env >nul
    echo.
    echo ==============================================================================
    echo [ACTION REQUIRED] Please open '.env' in Notepad and enter your Dhan credentials:
    echo   - DHAN_CLIENT_ID
    echo   - DHAN_ACCESS_TOKEN
    echo ==============================================================================
    echo.
    notepad .env
    echo When you have saved and closed your .env file, press any key to start the bot.
    pause >nul
)

:: 6. Launch the bot daemon
echo.
echo ==============================================================================
echo [LAUNCHING] Starting TheBull Dhan 80/20 Hybrid Engine (Paper Trading Mode)...
echo (To trade with real capital later, run with --live flag)
echo Press CTRL+C at any time to safely stop the daemon.
echo ==============================================================================
echo.
python dhan_bot.py --daemon %*

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ALERT] Bot stopped with an error code: %ERRORLEVEL%
)

echo.
pause
