import os
import json
import time
import logging
import requests
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Any

logger = logging.getLogger("NewsShield")

class NewsCalendarShield:
    def __init__(self, cache_file: Optional[str] = None, refresh_hours: float = 2.0):
        if cache_file is None:
            base_dir = r"C:\Users\ManjunathG\.gemini\antigravity\scratch\fundingpips_bot"
            cache_file = os.path.join(base_dir, "news_calendar_cache.json")
        self.cache_file = cache_file
        self.refresh_interval = refresh_hours * 3600.0
        self.events: List[Dict[str, Any]] = []
        self.last_fetch_time = 0.0
        self.last_attempt_time = 0.0
        self.fetch_calendar()

    def fetch_calendar(self) -> bool:
        """Fetches the official Faireconomy Forex Factory calendar feed."""
        self.last_attempt_time = time.time()
        url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                self.events = resp.json()
                self.last_fetch_time = time.time()
                try:
                    with open(self.cache_file, "w", encoding="utf-8") as f:
                        json.dump(self.events, f, indent=2)
                except Exception as fe:
                    logger.warning(f"Failed to cache calendar to file: {fe}")
                logger.info(f"[NEWS SHIELD] Successfully updated {len(self.events)} weekly events from Forex Factory.")
                return True
            else:
                logger.warning(f"[NEWS SHIELD] API returned HTTP {resp.status_code}. Loading cache...")
        except Exception as e:
            logger.warning(f"[NEWS SHIELD] Network error fetching calendar ({e}). Loading fallback cache...")

        # Load from cache fallback
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, "r", encoding="utf-8") as f:
                    self.events = json.load(f)
                logger.info(f"[NEWS SHIELD] Loaded {len(self.events)} events from local cache.")
                return True
            except Exception as e:
                logger.error(f"[NEWS SHIELD] Failed reading cache: {e}")
        return False

    def refresh_if_needed(self):
        now = time.time()
        min_wait = self.refresh_interval if (self.last_fetch_time > 0 and self.events) else 900.0
        
        # Check if cache is from a previous calendar week
        needs_rollover = False
        if self.events:
            try:
                today_utc = datetime.now(timezone.utc).date()
                event_dates = [datetime.fromisoformat(e["date"]).date() for e in self.events if e.get("date")]
                if event_dates and max(event_dates) < today_utc:
                    needs_rollover = True
            except Exception:
                pass

        if needs_rollover or (now - self.last_attempt_time > min_wait):
            self.fetch_calendar()

    def get_symbol_currencies(self, symbol: str) -> List[str]:
        """Extracts base and quote currencies from standard FX pair symbols (e.g. GBPCAD -> ['GBP', 'CAD'])."""
        sym = symbol.upper().replace(".SIM", "").replace("/", "")
        if len(sym) == 6:
            return [sym[:3], sym[3:]]
        # For non-FX or commodities
        if "USD" in sym:
            return ["USD"]
        return ["GBP", "EUR", "USD", "CAD"]

    def is_bank_holiday(self, symbol: str) -> Tuple[bool, Optional[str]]:
        """
        Returns (True, holiday_name) if today is an official Bank Holiday in any of the
        symbol's currency jurisdictions (e.g. UK London Bank Holiday for GBP).
        """
        self.refresh_if_needed()
        if not self.events:
            return False, None

        now_utc = datetime.now(timezone.utc)
        today_utc = now_utc.date()
        currencies = self.get_symbol_currencies(symbol)

        for ev in self.events:
            ev_country = ev.get("country", "").upper()
            ev_impact = ev.get("impact", "")
            if ev_country in currencies and (ev_impact == "Holiday" or "HOLIDAY" in ev.get("title", "").upper()):
                dt_str = ev.get("date", "")
                try:
                    ev_dt = datetime.fromisoformat(dt_str).astimezone(timezone.utc)
                    if ev_dt.date() == today_utc:
                        desc = f"[{ev_country}] {ev.get('title')} (Bank Holiday)"
                        return True, desc
                except Exception:
                    continue
        return False, None

    def is_news_blackout(self, symbol: str, buffer_minutes: int = 15) -> Tuple[bool, Optional[str]]:
        """
        Returns (True, event_details) if a High or Medium impact news event is scheduled
        within +/- buffer_minutes of now for the currencies involved in the symbol.
        """
        self.refresh_if_needed()
        if not self.events:
            return False, None

        now_utc = datetime.now(timezone.utc)
        currencies = self.get_symbol_currencies(symbol)

        for ev in self.events:
            ev_country = ev.get("country", "").upper()
            ev_impact = ev.get("impact", "")

            # Filter for High and Medium impact events on affected currencies
            if ev_country in currencies and ev_impact in ["High", "Medium"]:
                dt_str = ev.get("date", "")
                try:
                    ev_dt = datetime.fromisoformat(dt_str).astimezone(timezone.utc)
                    diff_mins = (ev_dt - now_utc).total_seconds() / 60.0

                    # Within blackout window: -buffer_minutes <= diff <= +buffer_minutes
                    if -buffer_minutes <= diff_mins <= buffer_minutes:
                        if diff_mins > 0:
                            time_rel = f"in {int(diff_mins)}m"
                        elif diff_mins < 0:
                            time_rel = f"{int(abs(diff_mins))}m ago"
                        else:
                            time_rel = "NOW"
                        desc = f"[{ev_country}] {ev.get('title')} ({ev_impact} Impact, {time_rel})"
                        return True, desc
                except Exception:
                    continue

        return False, None

    def get_upcoming_events_today(self, currencies: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        """Returns all scheduled events for today sorted by time."""
        self.refresh_if_needed()
        now_utc = datetime.now(timezone.utc)
        today_utc = now_utc.date()
        target_currs = set(currencies) if currencies else {"GBP", "EUR", "USD", "CAD"}

        upcoming = []
        for ev in self.events:
            if ev.get("country") in target_currs and ev.get("impact") in ["High", "Medium"]:
                dt_str = ev.get("date", "")
                try:
                    ev_dt = datetime.fromisoformat(dt_str).astimezone(timezone.utc)
                    if ev_dt.date() == today_utc:
                        mins = (ev_dt - now_utc).total_seconds() / 60.0
                        upcoming.append({
                            "country": ev.get("country"),
                            "impact": ev.get("impact"),
                            "title": ev.get("title"),
                            "time_utc": ev_dt.strftime("%H:%M UTC"),
                            "diff_minutes": round(mins, 1),
                            "forecast": ev.get("forecast", ""),
                            "previous": ev.get("previous", "")
                        })
                except Exception:
                    continue

        upcoming.sort(key=lambda x: x["diff_minutes"])
        return upcoming
