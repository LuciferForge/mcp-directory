"""
Stripe Webhook Handler & Verification Engine.
Handles signature verification, event dispatch, and Factur-X XML output.
"""

import os
import hmac
import hashlib
import time
from typing import Dict, Any, Tuple, Optional
from src.parser import parse_stripe_invoice
from src.zugferd_generator import generate_zugferd_xml
from src.models import WebhookProcessingResult


STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")
STORAGE_DIR = os.getenv("EINVOICE_STORAGE_DIR", "generated_invoices")


def verify_stripe_signature(payload_bytes: bytes, signature_header: str, secret: str, tolerance: int = 300) -> bool:
    """
    Verifies the Stripe webhook signature manually using HMAC-SHA256.
    Complies with Stripe's signature scheme: t=timestamp,v1=signature
    """
    if not signature_header or not secret:
        return False

    elements = signature_header.split(",")
    timestamp = None
    signatures = []

    for item in elements:
        parts = item.split("=", 1)
        if len(parts) == 2:
            key, val = parts[0].strip(), parts[1].strip()
            if key == "t":
                timestamp = val
            elif key == "v1":
                signatures.append(val)

    if not timestamp or not signatures:
        return False

    # Check timestamp tolerance
    try:
        ts_int = int(timestamp)
        current_time = int(time.time())
        if abs(current_time - ts_int) > tolerance:
            # Expired or clock drift
            return False
    except ValueError:
        return False

    signed_payload = f"{timestamp}.".encode("utf-8") + payload_bytes
    expected_sig = hmac.new(
        secret.encode("utf-8"),
        signed_payload,
        hashlib.sha256,
    ).hexdigest()

    return any(hmac.compare_digest(expected_sig, s) for s in signatures)


def process_stripe_event(
    event_payload: Dict[str, Any],
    save_to_disk: bool = True,
    seller_override: Optional[Dict[str, Any]] = None,
) -> WebhookProcessingResult:
    """
    Processes an incoming parsed Stripe event, generates the Factur-X XML,
    and returns a structured result.
    """
    event_type = event_payload.get("type", "")
    event_id = event_payload.get("id", "evt_unknown")

    # Only process invoice events
    supported_events = {"invoice.paid", "invoice.created", "invoice.finalized"}
    if event_type not in supported_events:
        return WebhookProcessingResult(
            status="ignored",
            stripe_event_id=event_id,
            xml_generated=False,
            message=f"Event type '{event_type}' ignored. Engine processes: {list(supported_events)}",
        )

    invoice_obj = event_payload.get("data", {}).get("object", {})
    stripe_invoice_id = invoice_obj.get("id")

    # 1. Parse and validate
    invoice_data = parse_stripe_invoice(event_payload, seller_override=seller_override)

    # 2. Generate Factur-X / ZUGFeRD 2.2 XML
    xml_content = generate_zugferd_xml(invoice_data)
    xml_bytes = xml_content.encode("utf-8")

    # 3. Optional persistent storage
    saved_path = None
    if save_to_disk:
        os.makedirs(STORAGE_DIR, exist_ok=True)
        filename = f"{invoice_data.invoice_number}_facturx.xml"
        file_path = os.path.join(STORAGE_DIR, filename)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(xml_content)
        saved_path = file_path

    return WebhookProcessingResult(
        status="success",
        stripe_event_id=event_id,
        stripe_invoice_id=stripe_invoice_id,
        invoice_number=invoice_data.invoice_number,
        xml_generated=True,
        xml_size_bytes=len(xml_bytes),
        en16931_compliant=True,
        message=f"Factur-X XML successfully generated for {invoice_data.invoice_number}."
        + (f" Saved to {saved_path}" if saved_path else ""),
        xml_content=xml_content,
    )
