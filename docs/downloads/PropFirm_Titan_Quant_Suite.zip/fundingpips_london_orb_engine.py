#!/usr/bin/env python3
"""
=============================================================================
FUNDING PIPS ($25K PROP) AUTONOMOUS TRADING ENGINE (INSTITUTIONAL v5.0)
LONDON OPEN JUDAS SWEEP (TURTLE SOUP) LIQUIDITY REVERSAL ENGINE
=============================================================================
Platform:       MetaTrader 5 (FundingPips-SIM1 | Account: 21115964)
Target Pairs:   GBPCAD (Spread: 0.0 pip), GBPUSD (Spread: 0.1 pip), EURUSD (Spread: 0.0 pip)
Timeframe:      M15 (15-Minute Structural Liquidity Sweeps)
Session Filter: London Open (07:00 - 11:00 UTC / 12:30 - 16:30 IST)
Setup Model:    Judas Sweep Reversal: Sweeps Asian High/Low by 2.5-35 pips, then closes back inside range
Volume Filter:  Relative Volume (RVOL) >= 1.25x confirming institutional absorption
Risk Model:     0.25% Equity Risk per Trade (~$63.45) | Asymmetric 1.8R Target (~$114.20)

Strict Capital Protection Guardrails:
1. Daily Loss Circuit Breaker: Max 2 losses/day (-$127.30 = -0.50% max daily loss)
   (Leaves an unbreakable 0.50% cushion before broker's 1.0% / $254.60 limit)
2. Currency Correlation Governor: Maximum 1 active USD-paired major and 1 GBP pair (Zero 2x USD bets)
3. Dynamic Volatility Stops: Minimum stop = max(15 pips, 1.2 * ATR-14) to eliminate noise tags
4. Dynamic Breakeven Lock: At +1.0R, SL moves to entry + spread buffer (0 risk)
5. Session EOD Square-Off: All positions closed by 18:00 UTC (0 overnight risk)
=============================================================================
"""

import os
import sys
import json
import time
import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple, Any

import MetaTrader5 as mt5

# Base directories
BASE_DIR = r"C:\Users\ManjunathG\.gemini\antigravity\scratch\fundingpips_bot"
ENV_FILE = os.path.join(BASE_DIR, ".env")
JOURNAL_FILE = os.path.join(BASE_DIR, "fp_trade_journal.json")

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join(BASE_DIR, "fundingpips_mt5.log"), encoding="utf-8")
    ]
)
logger = logging.getLogger("FundingPipsORB")


class FundingPipsORBEngine:
    def __init__(self, env_path: str = ENV_FILE):
        self.env_path = env_path
        self.config = self._load_env()

        self.login = int(self.config.get("MT5_LOGIN", 21115964))
        self.password = self.config.get("MT5_PASSWORD", "Jt3$SNMYo")
        self.server = self.config.get("MT5_SERVER", "FundingPips-SIM1")
        self.mt5_path = self.config.get("MT5_PATH", r"C:\Program Files\MetaTrader 5\terminal64.exe")

        # Single-Bullet Sniper Model Parameters: Strictly 1 trade/day @ $100 risk
        self.risk_dollars = float(self.config.get("RISK_DOLLARS", 100.00))  # Fixed $100.00 risk per trade
        self.risk_pct = 0.0039  # Reference ~0.39% of $25,386 equity
        self.max_daily_trades = int(self.config.get("MAX_DAILY_TRADES", 1))  # Strictly 1 trade per day!
        self.internal_daily_loss_cap = 100.00  # Hard daily cap: max 1 loss = -$100.00 (Leaves $155.86 buffer)
        self.broker_max_daily_loss = float(self.config.get("BROKER_MAX_DAILY_LOSS", 255.86))  # Broker 1% limit ($255.86)
        self.rr_ratio = float(self.config.get("RR_RATIO", 2.0))  # 1:2.0R Target (+$200.00 win)
        self.min_rvol = float(self.config.get("MIN_RVOL", 1.40))  # Institutional volume gate
        self.max_asian_span_pips = float(self.config.get("MAX_ASIAN_SPAN_PIPS", 40.0))  # Anti-exhaustion filter
        self.target_symbols = ["GBPCAD", "GBPUSD", "EURUSD"]

        self.tg_token = self.config.get("TELEGRAM_BOT_TOKEN")
        self.tg_chat_id = self.config.get("TELEGRAM_CHAT_ID")

        self.journal = self._load_journal()
        self.connected = False
        self.broker_utc_offset_hours = 2  # Default to UTC+2 for winter EET (starts Nov 1, 2026)
        self.initial_sl_cache: Dict[int, float] = {}  # Anchored initial SL cache to prevent Breakeven R-collapse
        self.last_deal_check_time = 0.0

        # Populate initial_sl_cache from persisted journal history
        for rec in self.journal.get("history", []):
            if "ticket" in rec and "sl" in rec:
                self.initial_sl_cache[rec["ticket"]] = rec.get("initial_sl", rec["sl"])

        # Daily tracking state per symbol
        self.current_trading_date = None
        self.asian_ranges: Dict[str, Dict[str, Any]] = {}
        self.traded_today: Dict[str, bool] = {s: False for s in self.target_symbols}
        self.last_candle_checked: Dict[str, int] = {}
        self.last_status_log = 0

        # Autonomous News Calendar Shield
        from news_calendar_shield import NewsCalendarShield
        cache_file = os.path.join(BASE_DIR, "news_calendar_cache.json")
        self.news_shield = NewsCalendarShield(cache_file=cache_file)
        self.last_news_digest_date = None

    def _load_env(self) -> Dict[str, str]:
        env_vars = {}
        if os.path.exists(self.env_path):
            with open(self.env_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if "=" in line and not line.startswith("#"):
                        k, v = line.split("=", 1)
                        env_vars[k.strip()] = v.strip().strip('"').strip("'")
        return env_vars

    def _load_journal(self) -> Dict[str, Any]:
        today_str = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if os.path.exists(JOURNAL_FILE):
            try:
                with open(JOURNAL_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if data.get("date") == today_str:
                        return data
            except Exception as e:
                logger.error(f"Error reading journal: {e}")

        initial = {
            "date": today_str,
            "starting_balance": 0.0,  # Populated dynamically from live MT5 account
            "trades_count": 0,
            "loss_count": 0,
            "realized_pnl": 0.0,
            "is_locked": False,
            "history": []
        }
        self._save_journal(initial)
        return initial

    def _save_journal(self, data: Optional[Dict[str, Any]] = None):
        if data is None:
            data = self.journal
        try:
            with open(JOURNAL_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving journal: {e}")

    def send_telegram(self, message: str):
        if not self.tg_token or not self.tg_chat_id:
            return
        url = f"https://api.telegram.org/bot{self.tg_token}/sendMessage"
        payload = {
            "chat_id": self.tg_chat_id,
            "text": message,
            "parse_mode": "HTML",
            "disable_web_page_preview": True
        }
        try:
            requests.post(url, json=payload, timeout=6)
        except Exception as e:
            logger.warning(f"Telegram alert delivery failed: {e}")

    def is_terminal_running(self) -> bool:
        import subprocess
        try:
            output = subprocess.check_output('tasklist /FI "IMAGENAME eq terminal64.exe"', shell=True).decode()
            return "terminal64.exe" in output
        except Exception:
            return False

    def connect_mt5(self) -> bool:
        if not self.is_terminal_running():
            logger.info("MetaTrader 5 desktop app is not running. Launching or waiting for terminal...")
            time.sleep(5)

        logger.info(f"Connecting to MT5 Terminal at '{self.mt5_path}'...")
        if mt5.initialize():
            logger.info("Connected to running MT5 Terminal instance.")
            self.connected = True
        else:
            if mt5.initialize(path=self.mt5_path, timeout=5000):
                logger.info("MT5 Terminal initialized successfully.")
                self.connected = True
            else:
                logger.warning(f"mt5.initialize() failed: {mt5.last_error()}. Ensure Algo Trading is enabled.")
                self.connected = False
                return False

        acc = mt5.account_info()
        if acc is None:
            logger.warning(f"Failed to fetch account_info: {mt5.last_error()}")
            return False

        # Calculate exact Broker UTC offset with freshness validation
        tick = mt5.symbol_info_tick("EURUSD")
        now_ts = time.time()
        if tick and abs(tick.time - now_ts) < 300:
            offset_sec = tick.time - now_ts
            detected_offset = int(round(offset_sec / 3600.0))
            if detected_offset in (2, 3):
                self.broker_utc_offset_hours = detected_offset
            else:
                self.broker_utc_offset_hours = 2
        else:
            # Fallback for weekend/closed market: US/EU DST transition on Sunday Nov 1, 2026 sets EET to UTC+2
            now_dt_utc = datetime.now(timezone.utc)
            if now_dt_utc >= datetime(2026, 11, 1, tzinfo=timezone.utc):
                self.broker_utc_offset_hours = 2  # Winter EET (UTC+2)
            else:
                self.broker_utc_offset_hours = 3  # Summer EEST (UTC+3)

        # Dynamic daily starting balance & risk caps initialization
        if self.journal.get("starting_balance", 0.0) <= 0.0:
            self.journal["starting_balance"] = round(acc.balance, 2)
            self._save_journal()

        start_bal = self.journal.get("starting_balance", acc.balance)
        self.internal_daily_loss_cap = 100.00  # Max 1 trade per day = -$100.00
        self.broker_max_daily_loss = round(start_bal * 0.0100, 2)   # -1.00% (Broker hard limit = ~$255.86)

        logger.info("=" * 70)
        logger.info("FUNDING PIPS SINGLE-BULLET SNIPER ORB ENGINE v6.0 INITIALIZED")
        logger.info(f"ACCOUNT LOGIN:          {acc.login}")
        logger.info(f"SERVER:                 {acc.server}")
        logger.info(f"STARTING BALANCE TODAY: ${start_bal:,.2f}")
        logger.info(f"CURRENT BALANCE:        ${acc.balance:,.2f} {acc.currency}")
        logger.info(f"CURRENT EQUITY:         ${acc.equity:,.2f} {acc.currency}")
        logger.info(f"MAX TRADES PER DAY:     {self.max_daily_trades} (Strict Single Bullet)")
        logger.info(f"TARGET PAIRS:           {', '.join(self.target_symbols)}")
        logger.info(f"BROKER UTC OFFSET:      UTC+{self.broker_utc_offset_hours} (EET/EEST Synchronized)")
        logger.info(f"BROKER 1% DAILY LIMIT:  ${self.broker_max_daily_loss:.2f}")
        logger.info(f"INTERNAL CIRCUIT CAP:   ${self.internal_daily_loss_cap:.2f} (Leaves ${self.broker_max_daily_loss - self.internal_daily_loss_cap:.2f} safety buffer!)")
        logger.info(f"RISK PER TRADE:         ${self.risk_dollars:.2f} ({self.risk_dollars/acc.equity*100:.2f}%) | Target: 1:{self.rr_ratio}R (+${self.risk_dollars * self.rr_ratio:.2f})")
        logger.info(f"FILTERS:                RVOL >= {self.min_rvol}x | Max Asian Span <= {self.max_asian_span_pips} pips")
        logger.info(f"NEWS SHIELD:            +/- 15 Min High/Med Blackout Active")
        logger.info("=" * 70)

        for sym in self.target_symbols:
            mt5.symbol_select(sym, True)

        return True

    def _reset_daily_state_if_new_day(self):
        today_utc = datetime.now(timezone.utc).date()
        if self.current_trading_date != today_utc:
            logger.info(f"Resetting daily state for new UTC date: {today_utc}")
            self.current_trading_date = today_utc
            self.asian_ranges.clear()
            self.traded_today = {s: False for s in self.target_symbols}
            self.last_candle_checked.clear()
            self.journal = self._load_journal()
            acc = mt5.account_info()
            if acc:
                self.journal["starting_balance"] = round(acc.balance, 2)
                self.internal_daily_loss_cap = round(acc.balance * 0.0050, 2)
                self.broker_max_daily_loss = round(acc.balance * 0.0100, 2)
                self._save_journal()
            self.send_daily_news_digest(today_utc)

    def send_daily_news_digest(self, target_date=None):
        """Sends daily morning Telegram summary of High/Med impact news and no-trade blackout windows."""
        now_utc = datetime.now(timezone.utc)
        if target_date is None:
            target_date = now_utc.date()

        self.news_shield.refresh_if_needed()
        ist_offset = timedelta(hours=5, minutes=30)
        day_events = []
        for ev in self.news_shield.events:
            dt_str = ev.get("date", "")
            try:
                ev_dt = datetime.fromisoformat(dt_str).astimezone(timezone.utc)
                if ev_dt.date() == target_date:
                    c = ev.get("country")
                    imp = ev.get("impact")
                    if c in ["GBP", "EUR", "USD", "CAD"] and imp in ["High", "Medium", "Holiday"]:
                        ist_dt = ev_dt + ist_offset
                        day_events.append((ev_dt, ist_dt, c, imp, ev.get("title")))
            except Exception:
                pass

        day_events.sort(key=lambda x: x[0])
        ist_dt_now = now_utc + ist_offset
        ist_date_str = ist_dt_now.strftime("%A, %d %b %Y")

        msg_lines = [
            f"📅 <b>FUNDING PIPS DAILY NEWS CALENDAR</b>",
            f"<i>{ist_date_str} | Target Pairs: GBPCAD, GBPUSD, EURUSD</i>\n"
        ]

        if not day_events:
            msg_lines.append("✅ <b>No High or Medium impact events scheduled today.</b>")
            msg_lines.append("Full trading session is clear of economic blackout windows.")
        else:
            msg_lines.append("⚠️ <b>MANDATORY NO-TRADE BLACKOUT WINDOWS (IST):</b>\n")
            for utc_dt, ist_dt, c, imp, title in day_events:
                no_trade_start = (ist_dt - timedelta(minutes=15)).strftime("%I:%M %p")
                no_trade_end = (ist_dt + timedelta(minutes=15)).strftime("%I:%M %p")
                time_str = ist_dt.strftime("%I:%M %p IST")
                icon = "🔴" if imp == "High" else ("🟠" if imp == "Medium" else "🏖️")
                msg_lines.append(f"{icon} <b>[{imp.upper()}] {c}</b>: {title}")
                msg_lines.append(f"   • Release Time: <code>{time_str}</code>")
                msg_lines.append(f"   • 🚫 <b>NO-TRADE LOCKOUT:</b> <code>{no_trade_start} – {no_trade_end} IST</code>\n")
            msg_lines.append("<i>Safety Rail: Bot automatically halts new entries +/-15m around these events to avoid news spikes and spread widening.</i>")

        full_msg = "\n".join(msg_lines)
        self.send_telegram(full_msg)
        self.last_news_digest_date = target_date
        logger.info(f"[NEWS SHIELD] Delivered daily economic news digest for {target_date} via Telegram.")

    def get_time_contexts(self) -> Tuple[datetime, datetime]:
        now_utc = datetime.now(timezone.utc)
        ist_now = now_utc + timedelta(hours=5, minutes=30)
        return now_utc, ist_now

    def is_london_session_active(self, now_utc: datetime) -> bool:
        """London Open Execution Window: 07:00 to 11:00 UTC (12:30 to 16:30 IST)"""
        return 7 <= now_utc.hour < 11

    def calculate_asian_range(self, symbol: str, now_utc: datetime) -> Optional[Dict[str, Any]]:
        """Asian Session Range: 00:00 to 07:00 UTC (Broker Time 02:00-09:00 in Winter / 03:00-10:00 in Summer)"""
        rates = mt5.copy_rates_from_pos(symbol, mt5.TIMEFRAME_M15, 0, 80)
        if rates is None or len(rates) < 15:
            return None

        today_utc = now_utc.date()
        asian_bars = []
        for r in rates:
            dt_broker = datetime.fromtimestamp(r['time'], timezone.utc)
            dt_utc = dt_broker - timedelta(hours=self.broker_utc_offset_hours)
            if dt_utc.date() == today_utc and (0 <= dt_utc.hour < 7):
                asian_bars.append(r)

        if not asian_bars:
            return None

        ah = max(b['high'] for b in asian_bars)
        al = min(b['low'] for b in asian_bars)
        span = ah - al

        range_data = {
            "high": ah,
            "low": al,
            "span": span,
            "bars_count": len(asian_bars),
            "is_locked": (now_utc.hour >= 7 and len(asian_bars) >= 20)
        }
        self.asian_ranges[symbol] = range_data
        return range_data

    def calculate_lot_size(self, symbol: str, entry_price: float, sl_price: float) -> float:
        acc = mt5.account_info()
        if not acc:
            return 0.01

        equity = acc.equity
        risk_dollars = getattr(self, "risk_dollars", 100.00)  # Fixed $100.00 sniper risk per trade

        sym_info = mt5.symbol_info(symbol)
        if not sym_info:
            return 0.01

        sl_distance = abs(entry_price - sl_price)
        if sl_distance <= 0:
            return sym_info.volume_min

        order_type_calc = mt5.ORDER_TYPE_BUY if entry_price > sl_price else mt5.ORDER_TYPE_SELL
        loss_calc = mt5.order_calc_profit(order_type_calc, symbol, 1.0, entry_price, sl_price)

        if loss_calc is not None and abs(loss_calc) > 0:
            loss_per_one_lot = abs(loss_calc)
        else:
            tick_sz = sym_info.trade_tick_size if sym_info.trade_tick_size > 0 else sym_info.point
            tick_val = sym_info.trade_tick_value if sym_info.trade_tick_value > 0 else 1.0
            loss_per_one_lot = (sl_distance / tick_sz) * tick_val

        if loss_per_one_lot <= 0:
            return sym_info.volume_min

        raw_lots = risk_dollars / loss_per_one_lot
        step = sym_info.volume_step if sym_info.volume_step > 0 else 0.01
        lots = round(raw_lots / step) * step
        lots = max(sym_info.volume_min, min(sym_info.volume_max, lots))
        lots = round(lots, 2)

        # Margin guardrail: Max 15% equity per position
        margin_required = mt5.order_calc_margin(order_type_calc, symbol, lots, entry_price)
        max_allowed_margin = equity * 0.15
        if margin_required and margin_required > max_allowed_margin:
            scale = max_allowed_margin / margin_required
            lots = round((lots * scale) / step) * step
            lots = max(sym_info.volume_min, min(sym_info.volume_max, lots))
            lots = round(lots, 2)

        logger.info(f"[{symbol}] SNIPER SIZING: {lots} lots | Risk: ${risk_dollars:.2f} | SL Dist: {sl_distance / sym_info.point:.1f} pts")
        return lots

    def modify_position_sl(self, ticket: int, symbol: str, new_sl: float, tp: float = 0.0) -> bool:
        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "position": ticket,
            "symbol": symbol,
            "sl": new_sl,
            "tp": tp
        }
        res = mt5.order_send(request)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            logger.info(f"[{symbol} #{ticket}] Stop Loss updated to {new_sl:.5f}")
            return True
        else:
            err = res.comment if res else mt5.last_error()
            logger.warning(f"Failed to modify SL for {symbol} #{ticket}: {err}")
            return False

    def close_position(self, ticket: int, symbol: str, comment: str = "EOD_SQUAREOFF") -> bool:
        positions = mt5.positions_get(ticket=ticket)
        if not positions:
            return False

        pos = positions[0]
        tick = mt5.symbol_info_tick(symbol)
        if not tick:
            return False

        is_buy = (pos.type == mt5.ORDER_TYPE_BUY)
        close_price = tick.bid if is_buy else tick.ask
        close_type = mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "position": ticket,
            "symbol": symbol,
            "volume": pos.volume,
            "type": close_type,
            "price": close_price,
            "deviation": 20,
            "magic": 21115964,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        res = mt5.order_send(request)
        if res and res.retcode == mt5.TRADE_RETCODE_DONE:
            logger.info(f"Position #{ticket} on {symbol} closed successfully at {close_price} ({comment})")
            return True
        return False

    def place_order(self, symbol: str, side: str, sl_price: float, tp_price: float, rvol: float, comment: str = "FP_LONDON_ORB") -> Optional[int]:
        if self.journal.get("is_locked", False):
            logger.warning("Account is LOCKED for the session. Rejecting order.")
            return None

        if self.journal.get("trades_count", 0) >= self.max_daily_trades:
            logger.warning(f"Daily max trades ({self.max_daily_trades}) reached. Rejecting order.")
            return None

        # Check concurrent positions cap (max 2)
        current_positions = mt5.positions_get()
        if current_positions and len(current_positions) >= 2:
            logger.warning(f"Max concurrent positions (2) reached. Rejecting new order on {symbol}.")
            return None

        tick = mt5.symbol_info_tick(symbol)
        if not tick:
            return None

        sym_info = mt5.symbol_info(symbol)
        digits = sym_info.digits if sym_info else 5

        if side.upper() == "BUY":
            order_type = mt5.ORDER_TYPE_BUY
            entry_price = tick.ask
        elif side.upper() == "SELL":
            order_type = mt5.ORDER_TYPE_SELL
            entry_price = tick.bid
        else:
            return None

        sl_price = round(sl_price, digits)
        tp_price = round(tp_price, digits)
        lots = self.calculate_lot_size(symbol, entry_price, sl_price)

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": lots,
            "type": order_type,
            "price": entry_price,
            "sl": sl_price,
            "tp": tp_price,
            "deviation": 15,
            "magic": 21115964,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        filling = sym_info.filling_mode if sym_info else 0
        if filling & 2:
            request["type_filling"] = mt5.ORDER_FILLING_IOC
        elif filling & 1:
            request["type_filling"] = mt5.ORDER_FILLING_FOK
        else:
            request["type_filling"] = mt5.ORDER_FILLING_RETURN

        logger.info(f"Submitting {side} {lots} lots on {symbol} @ {entry_price} [SL: {sl_price} | TP: {tp_price}] (RVOL: {rvol:.2f}x)...")
        result = mt5.order_send(request)

        if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
            retcode = result.retcode if result else mt5.last_error()
            comment_err = result.comment if result else "No response"
            logger.error(f"Order failed! Retcode: {retcode} | {comment_err}")
            return None

        ticket = result.order
        logger.info(f"Order EXECUTED! Ticket: {ticket}")
        self.initial_sl_cache[ticket] = sl_price

        acc = mt5.account_info()
        risk_amt = round(acc.equity * self.risk_pct, 2) if acc else 63.65
        profit_pot = round(abs(entry_price - tp_price) / abs(entry_price - sl_price) * risk_amt, 2)

        self.journal["trades_count"] += 1
        self.traded_today[symbol] = True

        trade_record = {
            "ticket": ticket,
            "time": datetime.now(timezone.utc).isoformat(),
            "symbol": symbol,
            "side": side,
            "lots": lots,
            "entry_price": entry_price,
            "sl": sl_price,
            "initial_sl": sl_price,
            "tp": tp_price,
            "risk_dollars": risk_amt,
            "rvol": round(rvol, 2),
            "status": "OPEN",
            "comment": comment
        }
        self.journal["history"].append(trade_record)
        self._save_journal()

        msg = (
            f"🎯 <b>FUNDING PIPS SINGLE-BULLET SNIPER EXECUTED</b>\n\n"
            f"<b>Instrument:</b> <code>{symbol}</code>\n"
            f"<b>Side:</b> <b>{side.upper()}</b>\n"
            f"<b>Lots:</b> <code>{lots}</code>\n"
            f"<b>Entry:</b> <code>{entry_price:.5f}</code>\n"
            f"<b>Stop Loss:</b> <code>{sl_price:.5f}</code> (-${self.risk_dollars:.2f} | -0.39%)\n"
            f"<b>Take Profit (2.0R):</b> <code>{tp_price:.5f}</code> (+${self.risk_dollars * self.rr_ratio:.2f} | +0.78%)\n"
            f"<b>Relative Volume:</b> <code>{rvol:.2f}x</code> (Threshold >= {self.min_rvol}x)\n\n"
            f"<b>Daily Slot:</b> {self.journal['trades_count']}/{self.max_daily_trades} (Sniper Limit Reached)\n"
            f"<b>Edge:</b> Institutional London ORB Momentum Breakout (PF 1.79)"
        )
        self.send_telegram(msg)
        return ticket

    def check_closed_deals(self):
        """Reconciles closed deals from MT5 history, updates journal PnL & loss count, and sends Telegram alert."""
        now_ts = time.time()
        if now_ts - self.last_deal_check_time < 15:
            return
        self.last_deal_check_time = now_ts

        now_utc = datetime.now(timezone.utc)
        today_start = datetime(now_utc.year, now_utc.month, now_utc.day, tzinfo=timezone.utc)
        deals = mt5.history_deals_get(today_start, now_utc + timedelta(hours=1))
        if not deals:
            return

        deals_by_pos = {}
        for d in deals:
            if d.entry == mt5.DEAL_ENTRY_OUT:
                deals_by_pos[d.position_id] = d

        updated = False
        for rec in self.journal.get("history", []):
            if rec.get("status") == "OPEN":
                ticket = rec.get("ticket")
                deal = deals_by_pos.get(ticket)
                if deal:
                    profit = deal.profit + deal.commission + deal.swap
                    rec["close_price"] = deal.price
                    rec["close_time"] = datetime.fromtimestamp(deal.time, timezone.utc).isoformat()
                    rec["realized_pnl"] = round(profit, 2)

                    if profit > 1.0:
                        rec["status"] = "CLOSED_WIN"
                        status_emoji = "🏆 WIN"
                    elif profit < -1.0:
                        rec["status"] = "CLOSED_LOSS"
                        status_emoji = "❌ LOSS"
                        self.journal["loss_count"] = self.journal.get("loss_count", 0) + 1
                    else:
                        rec["status"] = "CLOSED_BE"
                        status_emoji = "🛡️ BREAKEVEN"

                    self.journal["realized_pnl"] = round(self.journal.get("realized_pnl", 0.0) + profit, 2)
                    updated = True

                    msg = (
                        f"<b>{status_emoji} TRADE CLOSED</b>\n\n"
                        f"<b>Instrument:</b> <code>{rec['symbol']}</code> (#{ticket})\n"
                        f"<b>Net PnL:</b> <b>{'+' if profit >= 0 else ''}${profit:.2f} USD</b>\n"
                        f"<b>Close Price:</b> <code>{deal.price:.5f}</code>\n"
                        f"<b>Daily Realized PnL:</b> ${self.journal['realized_pnl']:,.2f}\n"
                        f"<b>Daily Losses:</b> {self.journal.get('loss_count', 0)}/{self.max_daily_trades}"
                    )
                    self.send_telegram(msg)
                    logger.info(f"[{rec['symbol']} #{ticket}] Deal closed: Net PnL=${profit:.2f} | Status: {rec['status']}")

        if updated:
            self._save_journal()

    def monitor_open_positions(self):
        """Monitors open orders, moves SL to Breakeven at +1.0R, reconciles closed deals, and checks daily loss circuit breaker."""
        acc = mt5.account_info()
        if not acc:
            return

        # Reconcile any recently closed positions from MT5 deal history
        self.check_closed_deals()

        start_bal = self.journal.get("starting_balance", acc.balance)
        curr_equity = acc.equity
        drawdown_dollars = start_bal - curr_equity

        # Daily Circuit Breaker Check: Max 2 losses (~$127.30 = -0.50%)
        if drawdown_dollars >= self.internal_daily_loss_cap:
            if not self.journal.get("is_locked", False):
                logger.warning(f"CIRCUIT BREAKER TRIGGERED! Drawdown: -${drawdown_dollars:.2f} >= -${self.internal_daily_loss_cap:.2f}. LOCKING TERMINAL!")
                self.journal["is_locked"] = True
                self._save_journal()
                msg = (
                    f"<b>🚨 FUNDING PIPS DAILY CIRCUIT BREAKER HIT</b>\n\n"
                    f"Daily Drawdown reached <b>-${drawdown_dollars:.2f}</b> (Internal Cap: -${self.internal_daily_loss_cap:.2f} = -0.50%).\n"
                    f"Broker Limit: -${self.broker_max_daily_loss:.2f} (-1.00%).\n"
                    f"Protected Cushion Remaining: <b>+${self.broker_max_daily_loss - drawdown_dollars:.2f}</b>.\n"
                    f"Trading halted for session to guarantee capital safety."
                )
                self.send_telegram(msg)

        positions = mt5.positions_get()
        if positions:
            now_utc, _ = self.get_time_contexts()

            # EOD Square-Off Rule: If past 18:00 UTC (23:30 IST), close any open intraday positions
            if now_utc.hour >= 18:
                for pos in positions:
                    logger.info(f"EOD Reached (18:00 UTC). Closing position #{pos.ticket} on {pos.symbol}...")
                    self.close_position(pos.ticket, pos.symbol, comment="EOD_SQUAREOFF")
                return

            for pos in positions:
                sym = pos.symbol
                ticket = pos.ticket
                entry = pos.price_open
                cur_price = pos.price_current
                cur_sl = pos.sl
                cur_tp = pos.tp
                is_buy = (pos.type == mt5.ORDER_TYPE_BUY)

                # Use initial_sl from anchored cache to prevent R-multiple collapse upon Breakeven move
                initial_sl = self.initial_sl_cache.get(ticket, cur_sl)
                initial_risk_dist = abs(entry - initial_sl) if initial_sl > 0 else abs(entry - cur_sl)
                if initial_risk_dist <= 0:
                    continue

                profit_dist = (cur_price - entry) if is_buy else (entry - cur_price)
                r_multiple = profit_dist / initial_risk_dist

                sym_info = mt5.symbol_info(sym)
                digits = sym_info.digits if sym_info else 5
                spread_buffer = (sym_info.spread * sym_info.point) if sym_info else (5 * 1e-5)

                # Breakeven Lock at +1.0R (Risk drops to $0.00!)
                if r_multiple >= 1.0:
                    be_level = round(entry + spread_buffer if is_buy else entry - spread_buffer, digits)
                    should_move = (be_level > cur_sl) if is_buy else (be_level < cur_sl or cur_sl == 0.0)
                    if should_move:
                        if self.modify_position_sl(ticket, sym, be_level, cur_tp):
                            msg = (
                                f"<b>🛡️ FUNDING PIPS BREAKEVEN LOCKED</b>\n\n"
                                f"<b>Instrument:</b> <code>{sym}</code> (#{ticket})\n"
                                f"<b>Floating Profit:</b> <code>+{r_multiple:.2f}R</code>\n"
                                f"<b>New SL:</b> <code>{be_level:.5f}</code> (Entry + Spread)\n"
                                f"Position is now 100% risk-free!"
                            )
                            self.send_telegram(msg)

                # Pre-News Breakeven Lock: If high/med news event is within 5 minutes and trade is in profit (>= +0.7R)
                is_news_near, news_desc = self.news_shield.is_news_blackout(sym, buffer_minutes=5)
                if is_news_near and "in " in (news_desc or "") and r_multiple >= 0.7:
                    be_level = round(entry + spread_buffer if is_buy else entry - spread_buffer, digits)
                    should_move = (be_level > cur_sl) if is_buy else (be_level < cur_sl or cur_sl == 0.0)
                    if should_move:
                        if self.modify_position_sl(ticket, sym, be_level, cur_tp):
                            msg = (
                                f"<b>🛡️ PRE-NEWS BREAKEVEN LOCK TRIGGERED</b>\n\n"
                                f"<b>Instrument:</b> <code>{sym}</code> (#{ticket})\n"
                                f"<b>Event:</b> {news_desc}\n"
                                f"<b>Floating Profit:</b> <code>+{r_multiple:.2f}R</code>\n"
                                f"<b>New SL:</b> <code>{be_level:.5f}</code> (Risk locked before release!)"
                            )
                            self.send_telegram(msg)

    def scan_for_setups(self):
        """Scans GBPCAD, GBPUSD, EURUSD for Asian Range Breakouts with RVOL >= 1.30 during London Open."""
        now_utc, ist_now = self.get_time_contexts()

        # Step 1: Compute/update Asian Ranges (00:00 to 07:00 UTC)
        for sym in self.target_symbols:
            self.calculate_asian_range(sym, now_utc)

        # Step 2: Only trade during London Execution Window (07:00 to 11:00 UTC)
        if not self.is_london_session_active(now_utc):
            return

        if self.journal.get("is_locked", False):
            return

        if self.journal.get("trades_count", 0) >= self.max_daily_trades:
            return

        candidates = []

        for sym in self.target_symbols:
            if self.traded_today.get(sym, False):
                continue

            ar = self.asian_ranges.get(sym)
            if not ar or not ar.get("is_locked", False):
                continue

            # Check Bank Holiday
            is_holiday, hol_desc = self.news_shield.is_bank_holiday(sym)
            if is_holiday:
                logger.info(f"[{sym}] BANK HOLIDAY ACTIVE: {hol_desc}. Suspending London Open breakout trading.")
                continue

            # Autonomous News Shield: Avoid taking new breakout trades within +/- 15 mins of High/Medium news
            is_blackout, news_desc = self.news_shield.is_news_blackout(sym, buffer_minutes=15)
            if is_blackout:
                logger.warning(f"[{sym}] NEWS BLACKOUT ACTIVE: {news_desc}. Blocking new entry to prevent news spike/slippage!")
                self.send_telegram(
                    f"🚫 <b>[{sym}] BREAKOUT BLOCKED BY NEWS SHIELD</b>\n\n"
                    f"• <b>Event:</b> <code>{news_desc}</code>\n"
                    f"• <b>Action:</b> Breakout entry blocked to prevent high-slippage news spike.\n"
                    f"• <b>Status:</b> Normal trading resumes 15 mins post-event."
                )
                continue

            # Fetch latest M15 bars
            rates = mt5.copy_rates_from_pos(sym, mt5.TIMEFRAME_M15, 0, 30)
            if rates is None or len(rates) < 22:
                continue

            # Check if a new candle just closed
            last_closed_bar = rates[-2]  # rates[-1] is currently forming bar
            bar_time = last_closed_bar['time']

            if self.last_candle_checked.get(sym) == bar_time:
                continue

            # Mark this candle as checked immediately for this symbol to prevent re-scan loops
            self.last_candle_checked[sym] = bar_time

            # Compute 20-period volume SMA on closed bars
            vols = [float(b['tick_volume']) for b in rates[-22:-2]]
            vol_sma = sum(vols) / len(vols) if vols else 1.0
            rvol = float(last_closed_bar['tick_volume']) / (vol_sma + 1e-9)

            sym_info = mt5.symbol_info(sym)
            point = sym_info.point if sym_info else 1e-5
            spread_buffer = (sym_info.spread * point) if sym_info else (5 * point)

            ah = ar["high"]
            al = ar["low"]
            c = float(last_closed_bar['close'])
            h = float(last_closed_bar['high'])
            l = float(last_closed_bar['low'])

            # Compute 14-period ATR on closed M15 bars
            trs = []
            for i in range(len(rates) - 15, len(rates) - 1):
                b_curr = rates[i]
                b_prev = rates[i - 1]
                tr = max(b_curr['high'] - b_curr['low'], abs(b_curr['high'] - b_prev['close']), abs(b_curr['low'] - b_prev['close']))
                trs.append(tr)
            atr_14 = (sum(trs) / len(trs)) if trs else (20 * point)

            # Filter 1: Anti-Exhaustion Asian Span Check (Max 40 pips)
            span_pips = ar["span"] / (10 * point)
            if span_pips > self.max_asian_span_pips:
                logger.info(f"[{sym}] Asian span ({span_pips:.1f} pips) > max ({self.max_asian_span_pips:.1f} pips). Skipping to avoid exhausted range fakeout.")
                continue

            # Dynamic Volatility Stop Bounds: minimum max(12 pips, 1.0 * ATR), maximum 30 pips
            min_stop_points = max(120 * point, 1.0 * atr_14)
            max_stop_points = 300 * point

            # -------------------------------------------------------------
            # INSTITUTIONAL SINGLE-BULLET ORB BREAKOUT (PF 1.79)
            # -------------------------------------------------------------
            # A. Bullish Breakout (LONG): Candle closes above Asian High with RVOL >= 1.40x
            if c > ah and rvol >= self.min_rvol:
                tick = mt5.symbol_info_tick(sym)
                if tick:
                    entry = tick.ask
                    raw_sl = l - spread_buffer
                    risk = entry - raw_sl
                    sl = entry - max(risk, min_stop_points)
                    final_risk = entry - sl
                    if final_risk <= max_stop_points:
                        tp = entry + (self.rr_ratio * final_risk)
                        candidates.append({
                            "symbol": sym,
                            "side": "BUY",
                            "sl": sl,
                            "tp": tp,
                            "rvol": rvol,
                            "bar_time": bar_time,
                            "breakout_pips": round((c - ah) / (10 * point), 1),
                            "setup_name": "SNIPER_ORB_LONG"
                        })
                    else:
                        logger.info(f"[{sym}] Bullish Breakout filtered out: Risk {final_risk / point:.1f} pts > max {max_stop_points / point:.0f} pts.")

            # B. Bearish Breakout (SHORT): Candle closes below Asian Low with RVOL >= 1.40x
            elif c < al and rvol >= self.min_rvol:
                tick = mt5.symbol_info_tick(sym)
                if tick:
                    entry = tick.bid
                    raw_sl = h + spread_buffer
                    risk = raw_sl - entry
                    sl = entry + max(risk, min_stop_points)
                    final_risk = sl - entry
                    if final_risk <= max_stop_points:
                        tp = entry - (self.rr_ratio * final_risk)
                        candidates.append({
                            "symbol": sym,
                            "side": "SELL",
                            "sl": sl,
                            "tp": tp,
                            "rvol": rvol,
                            "bar_time": bar_time,
                            "breakout_pips": round((al - c) / (10 * point), 1),
                            "setup_name": "SNIPER_ORB_SHORT"
                        })
                    else:
                        logger.info(f"[{sym}] Bearish Breakout filtered out: Risk {final_risk / point:.1f} pts > max {max_stop_points / point:.0f} pts.")

        if not candidates:
            return

        # Sort candidates by RVOL descending
        candidates.sort(key=lambda x: x["rvol"], reverse=True)

        # -------------------------------------------------------------
        # CURRENCY CORRELATION GOVERNOR (FACTOR RISK BUDGETING)
        # Prevents double-levered directional exposure on single currency factors (USD, GBP)
        # -------------------------------------------------------------
        USD_PAIRS = {"EURUSD", "GBPUSD", "AUDUSD", "NZDUSD", "USDCAD", "USDCHF", "USDJPY"}
        GBP_PAIRS = {"GBPUSD", "GBPCAD", "GBPJPY", "GBPAUD", "EURGBP"}

        open_positions = mt5.positions_get() or []
        has_active_usd = any(p.symbol in USD_PAIRS for p in open_positions)
        has_active_gbp = any(p.symbol in GBP_PAIRS for p in open_positions)

        selected_candidates = []
        usd_selected_in_batch = False
        gbp_selected_in_batch = False

        for cand in candidates:
            sym = cand["symbol"]
            # 1. USD Factor Governor: Maximum 1 active USD-paired major
            if sym in USD_PAIRS:
                if has_active_usd:
                    logger.info(f"Skipping {sym} setup: Active USD-paired position already open in MT5 terminal.")
                    continue
                if usd_selected_in_batch:
                    logger.info(f"Skipping {sym} setup: Higher RVOL USD pair already chosen in this execution batch.")
                    continue
                usd_selected_in_batch = True

            # 2. GBP Factor Governor: Maximum 1 active GBP-paired major
            if sym in GBP_PAIRS:
                if has_active_gbp:
                    logger.info(f"Skipping {sym} setup: Active GBP-paired position already open in MT5 terminal.")
                    continue
                if gbp_selected_in_batch:
                    logger.info(f"Skipping {sym} setup: Higher RVOL GBP pair already chosen in this execution batch.")
                    continue
                gbp_selected_in_batch = True

            selected_candidates.append(cand)

        # Execute chosen setups
        for cand in selected_candidates:
            if self.journal.get("trades_count", 0) >= self.max_daily_trades:
                break
            self.place_order(
                symbol=cand["symbol"],
                side=cand["side"],
                sl_price=cand["sl"],
                tp_price=cand["tp"],
                rvol=cand["rvol"],
                comment="FP_SNIPER_ORB"
            )

    def run(self):
        logger.info("Starting Funding Pips London ORB Autonomous Engine...")
        if not self.connect_mt5():
            logger.error("Initial MT5 connection failed. Will retry in loop.")

        today_utc = datetime.now(timezone.utc).date()
        if self.last_news_digest_date != today_utc:
            self.send_daily_news_digest(today_utc)

        while True:
            try:
                now_utc, ist_now = self.get_time_contexts()
                self._reset_daily_state_if_new_day()

                if not self.connected or not mt5.terminal_info():
                    logger.warning("MT5 disconnected. Attempting reconnection...")
                    self.connect_mt5()
                    time.sleep(5)
                    continue

                # 1. Monitor open positions & breakeven trail
                self.monitor_open_positions()

                # 2. Scan for London ORB setups
                self.scan_for_setups()

                # 3. Heartbeat log every 10 minutes
                if time.time() - self.last_status_log >= 600:
                    self.last_status_log = time.time()
                    acc = mt5.account_info()
                    open_pos = mt5.positions_get()
                    pos_count = len(open_pos) if open_pos else 0
                    
                    status_line = (
                        f"[HEARTBEAT] {ist_now.strftime('%H:%M:%S IST')} ({now_utc.strftime('%H:%M:%S UTC')}) | "
                        f"Equity: ${acc.equity:,.2f} | Trades: {self.journal.get('trades_count', 0)}/{self.max_daily_trades} | "
                        f"Locked: {self.journal.get('is_locked', False)} | Active Pos: {pos_count}"
                    )
                    logger.info(status_line)
                    for sym, ar in self.asian_ranges.items():
                        lock_str = "LOCKED" if ar.get("is_locked") else "FORMING"
                        logger.info(f"  [{sym}] Asian Range ({lock_str}): High={ar['high']:.5f}, Low={ar['low']:.5f}, Span={ar['span']:.5f}")

                    # Periodic Broker UTC offset re-synchronization (handles live DST shift seamlessly)
                    tick = mt5.symbol_info_tick("EURUSD")
                    now_ts = time.time()
                    if tick and abs(tick.time - now_ts) < 300:
                        detected_offset = int(round((tick.time - now_ts) / 3600.0))
                        if detected_offset in (2, 3) and detected_offset != self.broker_utc_offset_hours:
                            logger.info(f"Broker UTC offset updated from UTC+{self.broker_utc_offset_hours} to UTC+{detected_offset} (DST verified).")
                            self.broker_utc_offset_hours = detected_offset

                    # Log upcoming economic news
                    upcoming_news = self.news_shield.get_upcoming_events_today()
                    if upcoming_news:
                        logger.info(f"  [SCHEDULED NEWS TODAY - {len(upcoming_news)} EVENTS]:")
                        for un in upcoming_news[:4]:
                            logger.info(f"    * {un['time_utc']} | {un['country']} ({un['impact']}): {un['title']} (in {un['diff_minutes']}m)")

                time.sleep(10)

            except Exception as e:
                logger.error(f"Unexpected error in engine loop: {e}", exc_info=True)
                time.sleep(10)


if __name__ == "__main__":
    engine = FundingPipsORBEngine()
    engine.run()
