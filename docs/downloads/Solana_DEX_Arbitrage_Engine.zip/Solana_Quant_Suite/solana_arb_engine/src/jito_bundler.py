"""Jito Bundle constructor with dynamic tip bidding and atomic safety assertions.

Builds atomic MEV bundles targeting Jito Block Engine validator tips.
Enforces on-chain atomic assertions: require(final_sol >= initial_sol + min_profit).
"""

from __future__ import annotations

import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from .arb_math import ArbOpportunity

logger = logging.getLogger(__name__)

# Known public Jito Tip Accounts
JITO_TIP_ACCOUNTS = [
    "96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5",
    "HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe",
    "Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY",
    "ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49",
    "DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh",
    "ADuUkR4vqLUMWXxW9gh6D6L8pWHLnjvnxKLQm3EDLphx",
    "DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL",
    "3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT",
]

JITO_BLOCK_ENGINES = [
    "https://mainnet.block-engine.jito.wtf/api/v1/bundles",
    "https://amsterdam.mainnet.block-engine.jito.wtf/api/v1/bundles",
    "https://frankfurt.mainnet.block-engine.jito.wtf/api/v1/bundles",
    "https://ny.mainnet.block-engine.jito.wtf/api/v1/bundles",
    "https://tokyo.mainnet.block-engine.jito.wtf/api/v1/bundles",
]


@dataclass
class AtomicSafetyAssertion:
    """Represents an atomic on-chain safety assertion instruction."""
    min_sol_out_lamports: int
    assertion_type: str = "BALANCE_DELTA_GE_MIN_PROFIT"
    expected_profit_sol: float = 0.0

    def verify(self, post_swap_lamports: int, initial_lamports: int) -> bool:
        """Simulate on-chain execution of require(final_sol >= initial_sol + min_profit)."""
        actual_profit = post_swap_lamports - initial_lamports
        min_required = self.min_sol_out_lamports - initial_lamports
        return actual_profit >= min_required


@dataclass
class JitoTipQuote:
    """Calculated dynamic tip details."""
    gross_profit_sol: float
    tip_sol: float
    tip_lamports: int
    tip_account: str
    tip_percentage_applied: float
    max_tip_cap_hit: bool


@dataclass
class JitoBundle:
    """Represents an assembled Jito MEV bundle ready for dispatch or simulation."""
    bundle_id: str
    target_engine_url: str
    transactions: List[str]  # Simulated base58 or serialized hex transactions
    tip_quote: JitoTipQuote
    safety_assertion: AtomicSafetyAssertion
    arb_opportunity: ArbOpportunity
    created_at_utc: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_json_rpc(self) -> Dict[str, Any]:
        """Format as Jito sendBundle JSON-RPC payload."""
        return {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "sendBundle",
            "params": [
                self.transactions,
            ],
        }


@dataclass
class SimulationExecutionResult:
    """Execution simulation results of an atomic bundle."""
    success: bool
    bundle_id: str
    gross_profit_sol: float
    tip_paid_sol: float
    net_profit_sol: float
    initial_balance_sol: float
    final_balance_sol: float
    execution_time_ms: float
    logs: List[str]
    revert_reason: Optional[str] = None


class JitoBundler:
    """Builds, dynamically tips, and validates atomic Jito bundles."""

    def __init__(
        self,
        tip_percentage: float = 0.50,
        max_tip_sol: float = 0.05,
        min_tip_sol: float = 0.00001,
        min_profit_sol: float = 0.005,
        engine_url: Optional[str] = None,
    ):
        self.tip_percentage = tip_percentage
        self.max_tip_sol = max_tip_sol
        self.min_tip_sol = min_tip_sol
        self.min_profit_sol = min_profit_sol
        self.engine_url = engine_url or JITO_BLOCK_ENGINES[0]

    def compute_dynamic_tip(self, gross_profit_sol: float) -> JitoTipQuote:
        """Calculate dynamic tip based on gross profit: tip = min(tip_pct * gross_profit, max_tip).

        Guarantees tip never exceeds gross profit or max_tip cap.
        """
        if gross_profit_sol <= 0:
            return JitoTipQuote(
                gross_profit_sol=gross_profit_sol,
                tip_sol=0.0,
                tip_lamports=0,
                tip_account=random.choice(JITO_TIP_ACCOUNTS),
                tip_percentage_applied=0.0,
                max_tip_cap_hit=False,
            )

        raw_tip = self.tip_percentage * gross_profit_sol
        max_cap_hit = raw_tip > self.max_tip_sol
        tip_sol = min(raw_tip, self.max_tip_sol)
        tip_sol = max(tip_sol, self.min_tip_sol)

        # Make sure tip does not exceed gross profit
        if tip_sol >= gross_profit_sol:
            tip_sol = gross_profit_sol * 0.90  # fallback cap

        tip_lamports = int(tip_sol * 1e9)
        tip_account = random.choice(JITO_TIP_ACCOUNTS)

        return JitoTipQuote(
            gross_profit_sol=gross_profit_sol,
            tip_sol=tip_sol,
            tip_lamports=tip_lamports,
            tip_account=tip_account,
            tip_percentage_applied=self.tip_percentage,
            max_tip_cap_hit=max_cap_hit,
        )

    def create_safety_assertion(
        self,
        initial_lamports: int,
        min_profit_sol: Optional[float] = None,
    ) -> AtomicSafetyAssertion:
        """Creates atomic assertion require(final_sol >= initial_sol + min_profit)."""
        profit_threshold = min_profit_sol if min_profit_sol is not None else self.min_profit_sol
        min_required_lamports = initial_lamports + int(profit_threshold * 1e9)

        return AtomicSafetyAssertion(
            min_sol_out_lamports=min_required_lamports,
            assertion_type="ATOMIC_MIN_PROFIT_ASSERTION",
            expected_profit_sol=profit_threshold,
        )

    def construct_bundle(
        self,
        arb: ArbOpportunity,
        user_wallet: str = "PaperTradingWallet111111111111111111111111",
    ) -> Optional[JitoBundle]:
        """Constructs an atomic Jito bundle for an evaluated arbitrage opportunity."""
        if not arb.is_profitable:
            logger.debug("Skipping bundle creation: arb is not profitable.")
            return None

        tip_quote = self.compute_dynamic_tip(arb.gross_profit_sol)
        safety_assertion = self.create_safety_assertion(
            initial_lamports=arb.optimal_input_lamports,
            min_profit_sol=self.min_profit_sol,
        )

        bundle_id = f"bundle_{int(time.time() * 1000)}_{random.randint(1000, 9999)}"

        # Generate simulated Solana instruction descriptors
        # Leg 1: Swap SOL -> Token on Buy Pool
        tx_leg1 = (
            f"TX_SWAP_LEG1[dex={arb.pool_buy.dex_name},in={arb.optimal_input_lamports}lamports,"
            f"out={arb.tokens_acquired}raw_tokens,pool={arb.pool_buy.pool_id[:8]}]"
        )
        # Leg 2: Swap Token -> SOL on Sell Pool
        tx_leg2 = (
            f"TX_SWAP_LEG2[dex={arb.pool_sell.dex_name},in={arb.tokens_acquired}raw_tokens,"
            f"out={arb.final_sol_lamports}lamports,pool={arb.pool_sell.pool_id[:8]}]"
        )
        # Leg 3: Atomic Safety Assertion require(final >= initial + min_profit)
        tx_assertion = (
            f"TX_ASSERTION[require_sol_gte={safety_assertion.min_sol_out_lamports}lamports]"
        )
        # Leg 4: Tip Transfer to Jito Validator
        tx_tip = (
            f"TX_JITO_TIP[to={tip_quote.tip_account[:8]},amount={tip_quote.tip_lamports}lamports]"
        )

        transactions = [tx_leg1, tx_leg2, tx_assertion, tx_tip]

        return JitoBundle(
            bundle_id=bundle_id,
            target_engine_url=self.engine_url,
            transactions=transactions,
            tip_quote=tip_quote,
            safety_assertion=safety_assertion,
            arb_opportunity=arb,
            metadata={
                "user_wallet": user_wallet,
                "token_mint": arb.pool_buy.token_mint_b,
                "spread_pct": arb.price_spread_pct,
            },
        )

    def simulate_execution(
        self,
        bundle: JitoBundle,
        current_wallet_balance_sol: float,
        slippage_factor: float = 1.0,
    ) -> SimulationExecutionResult:
        """Simulates atomic bundle execution in paper-trading / dry-run mode.

        Validates all conditions, balances, and assertions without touching mainnet funds.
        """
        start_time = time.perf_counter()
        arb = bundle.arb_opportunity
        logs = []

        logs.append(f"Starting simulation of bundle {bundle.bundle_id}")
        logs.append(f"Input: {arb.optimal_input_sol:.6f} SOL from wallet balance {current_wallet_balance_sol:.6f} SOL")

        if current_wallet_balance_sol < arb.optimal_input_sol:
            elapsed = (time.perf_counter() - start_time) * 1000
            return SimulationExecutionResult(
                success=False,
                bundle_id=bundle.bundle_id,
                gross_profit_sol=0.0,
                tip_paid_sol=0.0,
                net_profit_sol=0.0,
                initial_balance_sol=current_wallet_balance_sol,
                final_balance_sol=current_wallet_balance_sol,
                execution_time_ms=elapsed,
                logs=logs,
                revert_reason="Insufficient wallet SOL balance for trade input",
            )

        # Apply slippage factor (simulating real-world variance if requested)
        actual_final_lamports = int(arb.final_sol_lamports * slippage_factor)
        logs.append(f"Leg 1 Swap OK: Bought {arb.tokens_acquired} tokens on {arb.pool_buy.dex_name}")
        logs.append(f"Leg 2 Swap OK: Sold for {actual_final_lamports / 1e9:.6f} SOL on {arb.pool_sell.dex_name}")

        # Check atomic safety assertion
        assertion_passed = bundle.safety_assertion.verify(
            post_swap_lamports=actual_final_lamports,
            initial_lamports=arb.optimal_input_lamports,
        )

        if not assertion_passed:
            elapsed = (time.perf_counter() - start_time) * 1000
            logs.append("ATOMIC ASSERTION REVERT: post-swap SOL balance fell below min profit threshold!")
            return SimulationExecutionResult(
                success=False,
                bundle_id=bundle.bundle_id,
                gross_profit_sol=0.0,
                tip_paid_sol=0.0,
                net_profit_sol=0.0,
                initial_balance_sol=current_wallet_balance_sol,
                final_balance_sol=current_wallet_balance_sol,
                execution_time_ms=elapsed,
                logs=logs,
                revert_reason="Atomic assertion reverted (require(final_sol >= initial_sol + min_profit))",
            )

        actual_gross_profit_sol = (actual_final_lamports - arb.optimal_input_lamports) / 1e9
        tip_sol = bundle.tip_quote.tip_sol
        base_fee_sol = 0.000015
        net_profit_sol = actual_gross_profit_sol - tip_sol - base_fee_sol

        final_balance = current_wallet_balance_sol + net_profit_sol
        elapsed = (time.perf_counter() - start_time) * 1000

        logs.append(f"Jito Tip Dispatched: {tip_sol:.6f} SOL to {bundle.tip_quote.tip_account[:8]}...")
        logs.append(f"Bundle Successfully Executed. Net PnL: +{net_profit_sol:.6f} SOL")

        return SimulationExecutionResult(
            success=True,
            bundle_id=bundle.bundle_id,
            gross_profit_sol=actual_gross_profit_sol,
            tip_paid_sol=tip_sol,
            net_profit_sol=net_profit_sol,
            initial_balance_sol=current_wallet_balance_sol,
            final_balance_sol=final_balance,
            execution_time_ms=elapsed,
            logs=logs,
        )
