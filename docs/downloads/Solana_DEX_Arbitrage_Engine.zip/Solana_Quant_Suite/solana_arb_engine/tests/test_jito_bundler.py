"""Unit tests for Jito Bundler and Dynamic Tipping module."""

import unittest
from src.jito_bundler import JitoBundler, JITO_TIP_ACCOUNTS
from src.arb_math import ArbOpportunity, PoolState


class TestJitoBundler(unittest.TestCase):
    def setUp(self):
        self.bundler = JitoBundler(
            tip_percentage=0.50,
            max_tip_sol=0.05,
            min_profit_sol=0.005,
        )

    def test_dynamic_tip_calculation_within_cap(self):
        """Dynamic tip should be exactly 50% of gross profit when below max_tip."""
        gross_profit = 0.04  # 0.04 SOL
        quote = self.bundler.compute_dynamic_tip(gross_profit)

        self.assertAlmostEqual(quote.tip_sol, 0.02, places=6)
        self.assertFalse(quote.max_tip_cap_hit)
        self.assertIn(quote.tip_account, JITO_TIP_ACCOUNTS)

    def test_dynamic_tip_capped_at_max(self):
        """Dynamic tip should cap at max_tip_sol (0.05 SOL) when 50% is higher."""
        gross_profit = 0.30  # 50% would be 0.15 SOL
        quote = self.bundler.compute_dynamic_tip(gross_profit)

        self.assertEqual(quote.tip_sol, 0.05)
        self.assertTrue(quote.max_tip_cap_hit)

    def test_dynamic_tip_zero_for_zero_or_negative_profit(self):
        """Non-profitable trades should quote zero tip."""
        quote_zero = self.bundler.compute_dynamic_tip(0.0)
        self.assertEqual(quote_zero.tip_sol, 0.0)

        quote_neg = self.bundler.compute_dynamic_tip(-0.01)
        self.assertEqual(quote_neg.tip_sol, 0.0)

    def test_atomic_safety_assertion_passes_when_profit_met(self):
        """Assertion require(final_sol >= initial_sol + min_profit) must pass when target reached."""
        initial_lamports = 1_000_000_000  # 1 SOL
        assertion = self.bundler.create_safety_assertion(
            initial_lamports=initial_lamports,
            min_profit_sol=0.01,  # requires 1.01 SOL final
        )

        # Received 1.02 SOL (exceeds min profit)
        passed = assertion.verify(
            post_swap_lamports=1_020_000_000,
            initial_lamports=initial_lamports,
        )
        self.assertTrue(passed)

    def test_atomic_safety_assertion_reverts_when_profit_under(self):
        """Assertion must fail/revert if MEV frontrunner sandwich reduces profit below threshold."""
        initial_lamports = 1_000_000_000  # 1 SOL
        assertion = self.bundler.create_safety_assertion(
            initial_lamports=initial_lamports,
            min_profit_sol=0.01,
        )

        # Received only 1.002 SOL (under the 0.01 SOL required)
        passed = assertion.verify(
            post_swap_lamports=1_002_000_000,
            initial_lamports=initial_lamports,
        )
        self.assertFalse(passed)

    def test_bundle_construction_and_json_rpc(self):
        """Verify Jito bundle construction and JSON-RPC formatting."""
        pool_buy = PoolState("p1", "Raydium", "SOL", "TOKEN", 50_000_000_000, 100_000_000_000)
        pool_sell = PoolState("p2", "Meteora", "SOL", "TOKEN", 60_000_000_000, 100_000_000_000)

        mock_arb = ArbOpportunity(
            pool_buy=pool_buy,
            pool_sell=pool_sell,
            optimal_input_sol=1.0,
            optimal_input_lamports=1_000_000_000,
            tokens_acquired=1_500_000,
            final_sol_lamports=1_100_000_000,
            gross_profit_sol=0.10,
            net_profit_sol=0.049985,
            estimated_jito_tip_sol=0.05,
            price_spread_pct=20.0,
            roi_pct=5.0,
            is_profitable=True,
        )

        bundle = self.bundler.construct_bundle(mock_arb)
        self.assertIsNotNone(bundle)
        self.assertEqual(len(bundle.transactions), 4)

        json_payload = bundle.to_json_rpc()
        self.assertEqual(json_payload["method"], "sendBundle")
        self.assertEqual(len(json_payload["params"][0]), 4)

    def test_simulation_execution_success(self):
        """Simulate successful paper execution."""
        pool_buy = PoolState("p1", "Raydium", "SOL", "TOKEN", 50_000_000_000, 100_000_000_000)
        pool_sell = PoolState("p2", "Meteora", "SOL", "TOKEN", 60_000_000_000, 100_000_000_000)

        mock_arb = ArbOpportunity(
            pool_buy=pool_buy,
            pool_sell=pool_sell,
            optimal_input_sol=1.0,
            optimal_input_lamports=1_000_000_000,
            tokens_acquired=1_500_000,
            final_sol_lamports=1_080_000_000,
            gross_profit_sol=0.08,
            net_profit_sol=0.039985,
            estimated_jito_tip_sol=0.04,
            price_spread_pct=16.0,
            roi_pct=4.0,
            is_profitable=True,
        )

        bundle = self.bundler.construct_bundle(mock_arb)
        result = self.bundler.simulate_execution(
            bundle=bundle,
            current_wallet_balance_sol=10.0,
        )

        self.assertTrue(result.success)
        self.assertGreater(result.final_balance_sol, 10.0)
        self.assertAlmostEqual(result.final_balance_sol - 10.0, result.net_profit_sol, places=6)


if __name__ == "__main__":
    unittest.main()
