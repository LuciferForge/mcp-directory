# Sub-1ms Token Stream Interceptor
class StreamInterceptor:
    def intercept_chunk(self, chunk: str):
        return True, chunk
