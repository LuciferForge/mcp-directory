#!/usr/bin/env python3
"""
==============================================================================
TheBull - ZeroLag Momentum Trading Bot for Delta Exchange India
==============================================================================
- Exchange: Delta Exchange India (api.india.delta.exchange)
- Leverage: 10x
- Strategy: 15m Multi-Factor Momentum + Dynamic RSI (up to 85) + 4-Stage Trailing Stop
- Sizing: Dynamic capital-based sizing (automatically scales contracts with wallet equity)
- Protection: Strict 1:1 Stop-Loss reconciliation & bidirectional position protection
==============================================================================
"""

import os
import sys
import time
import math
import logging
import socket
import urllib.parse
import hmac
import hashlib
import json
import argparse
from datetime import datetime
import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

# Enforce IPv4 on Windows/Linux to prevent CloudFront IPv6 route timeout
try:
    import urllib3.util.connection as urllib3_cn
    urllib3_cn.allowed_gai_family = lambda: socket.AF_INET
except Exception:
    pass

# Setup Logging
log_format = "%(asctime)s - [%(levelname)s] - %(name)s - %(message)s"
logging.basicConfig(
    level=logging.INFO,
    format=log_format,
    handlers=[
        logging.FileHandler("delta_bot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("TheBull-Delta")


# ==============================================================================
# DELTA EXCHANGE INDIA REST API CLIENT
# ==============================================================================
class DeltaIndiaClient:
    """Production REST Client for Delta Exchange India with auto clock sync and IPv4"""
    def __init__(self, api_key: str, api_secret: str, base_url: str = "https://api.india.delta.exchange"):
        self.api_key = api_key.strip()
        self.api_secret = api_secret.strip()
        self.base_url = base_url.rstrip("/")
        self.time_offset = 0
        self.session = requests.Session()

    def _sign(self, method: str, path: str, query_string: str = "", payload: str = ""):
        timestamp = str(int(time.time() + self.time_offset))
        signature_data = method + timestamp + path + query_string + payload
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            signature_data.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        return timestamp, signature

    def request(self, method: str, path: str, params: dict = None, json_data: dict = None, retry_sync: bool = True):
        query_string = ""
        if params:
            query_string = "?" + urllib.parse.urlencode(params)

        payload = json.dumps(json_data) if json_data is not None else ""
        timestamp, signature = self._sign(method.upper(), path, query_string, payload)

        headers = {
            "api-key": self.api_key,
            "timestamp": timestamp,
            "signature": signature,
            "Content-Type": "application/json"
        }

        url = self.base_url + path + query_string
        try:
            if method.upper() == "GET":
                resp = self.session.get(url, headers=headers, timeout=12)
            elif method.upper() == "POST":
                resp = self.session.post(url, headers=headers, data=payload, timeout=12)
            elif method.upper() == "PUT":
                resp = self.session.put(url, headers=headers, data=payload, timeout=12)
            elif method.upper() == "DELETE":
                resp = self.session.delete(url, headers=headers, data=payload, timeout=12)
            else:
                resp = self.session.request(method.upper(), url, headers=headers, data=payload, timeout=12)

            data = resp.json()

            # Handle clock drift / expired_signature automatically
            if not data.get("success") and retry_sync:
                err = data.get("error", {})
                if isinstance(err, dict) and err.get("code") == "expired_signature":
                    ctx = err.get("context", {})
                    srv_t = ctx.get("server_time")
                    if srv_t:
                        diff = srv_t - int(time.time())
                        logger.debug(f"Auto-syncing clock offset: adjusted by {diff}s")
                        self.time_offset = diff
                        return self.request(method, path, params, json_data, retry_sync=False)

            return data
        except Exception as e:
            logger.error(f"HTTP Request error ({method} {path}): {e}")
            return {"success": False, "error": str(e)}

    def get_wallet_balances(self):
        return self.request("GET", "/v2/wallet/balances")

    def get_positions(self):
        return self.request("GET", "/v2/positions/margined")

    def get_products(self):
        try:
            r = self.session.get(self.base_url + "/v2/products", timeout=12)
            return r.json()
        except Exception as e:
            logger.error(f"Error fetching products: {e}")
            return {"success": False, "result": []}

    def get_candles(self, symbol: str, resolution: str = "15", bars: int = 100):
        now = int(time.time() + self.time_offset)
        seconds_back = bars * 900
        params = {
            "symbol": symbol,
            "resolution": resolution,
            "from": now - seconds_back,
            "to": now
        }
        try:
            r = self.session.get(self.base_url + "/v2/chart/history", params=params, timeout=12)
            if r.status_code == 200:
                res = r.json().get("result", {})
                if isinstance(res, dict) and "t" in res and len(res["t"]) > 0:
                    df = pd.DataFrame({
                        "timestamp": pd.to_datetime(res["t"], unit="s"),
                        "open": [float(x) for x in res["o"]],
                        "high": [float(x) for x in res["h"]],
                        "low": [float(x) for x in res["l"]],
                        "close": [float(x) for x in res["c"]],
                        "volume": [float(x) for x in res["v"]]
                    })
                    return df.sort_values("timestamp").reset_index(drop=True)
            return pd.DataFrame()
        except Exception as e:
            logger.error(f"Error fetching candles for {symbol}: {e}")
            return pd.DataFrame()

    def place_order(self, product_id: int, size: int, side: str, order_type: str = "market_order", bracket_sl: float = None):
        payload = {
            "product_id": product_id,
            "size": size,
            "side": side.lower(),
            "order_type": order_type
        }
        if bracket_sl is not None:
            payload["bracket_stop_loss_price"] = str(bracket_sl)
            payload["bracket_stop_trigger_method"] = "mark_price"
        return self.request("POST", "/v2/orders", json_data=payload)

    def place_stop_order(self, product_id: int, size: int, side: str, stop_price: float):
        payload = {
            "product_id": product_id,
            "size": size,
            "side": side.lower(),
            "order_type": "market_order",
            "stop_order_type": "stop_loss_order",
            "stop_price": str(stop_price),
            "stop_trigger_method": "mark_price",
            "reduce_only": True
        }
        return self.request("POST", "/v2/orders", json_data=payload)

    def get_open_orders(self, product_id: int = None):
        orders = []
        seen_ids = set()
        for state in ["pending", "open"]:
            after = None
            while True:
                params = {"state": state, "page_size": 50}
                if product_id:
                    params["product_id"] = product_id
                if after:
                    params["after"] = after
                res = self.request("GET", "/v2/orders", params=params)
                batch = res.get("result", [])
                for o in batch:
                    oid = o.get("id")
                    if oid not in seen_ids:
                        seen_ids.add(oid)
                        orders.append(o)
                meta = res.get("meta", {})
                after = meta.get("after") if meta else None
                if not after or len(batch) < 50:
                    break
        return {"success": True, "result": orders}

    def cancel_order(self, product_id: int, order_id: int):
        payload = {
            "product_id": product_id,
            "id": order_id
        }
        return self.request("DELETE", "/v2/orders", json_data=payload)


# ==============================================================================
# TECHNICAL INDICATORS
# ==============================================================================
def calculate_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / (loss + 1e-9)
    return 100 - (100 / (1 + rs))

def calculate_supertrend(df: pd.DataFrame, period: int = 10, multiplier: float = 3.0):
    hl2 = (df['high'] + df['low']) / 2
    tr1 = df['high'] - df['low']
    tr2 = (df['high'] - df['close'].shift(1)).abs()
    tr3 = (df['low'] - df['close'].shift(1)).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(period).mean()
    
    basic_ub = hl2 + (multiplier * atr)
    basic_lb = hl2 - (multiplier * atr)
    
    final_ub = basic_ub.copy()
    final_lb = basic_lb.copy()
    supertrend = pd.Series(index=df.index, dtype=float)
    direction = pd.Series(index=df.index, dtype=int)
    
    for i in range(1, len(df)):
        if basic_ub.iloc[i] < final_ub.iloc[i-1] or df['close'].iloc[i-1] > final_ub.iloc[i-1]:
            final_ub.iloc[i] = basic_ub.iloc[i]
        else:
            final_ub.iloc[i] = final_ub.iloc[i-1]
            
        if basic_lb.iloc[i] > final_lb.iloc[i-1] or df['close'].iloc[i-1] < final_lb.iloc[i-1]:
            final_lb.iloc[i] = basic_lb.iloc[i]
        else:
            final_lb.iloc[i] = final_lb.iloc[i-1]
            
        if df['close'].iloc[i] > final_ub.iloc[i-1]:
            direction.iloc[i] = 1
        elif df['close'].iloc[i] < final_lb.iloc[i-1]:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i-1] if not np.isnan(direction.iloc[i-1]) else 1
            
        supertrend.iloc[i] = final_lb.iloc[i] if direction.iloc[i] == 1 else final_ub.iloc[i]
        
    return supertrend, direction


# ==============================================================================
# MAIN BOT ENGINE
# ==============================================================================
class TheBullDeltaBot:
    def __init__(self, api_key: str, api_secret: str, config: dict, dry_run: bool = False):
        self.client = DeltaIndiaClient(api_key, api_secret)
        self.dry_run = dry_run
        self.config = config
        self.leverage = config.get("leverage", 10)
        self.min_signal_strength = config.get("min_signal_strength", 70.0)
        self.max_concurrent_positions = config.get("default_max_positions", 35)
        self.trailing_config = config.get("trailing_stop", {})
        
        self.positions = {}
        self.products = {}
        self.products_by_id = {}
        logger.info(f"Initialized TheBull Delta Bot (Leverage: {self.leverage}x | Dry-Run: {self.dry_run})")

    def load_products(self):
        logger.info("Loading perpetual contract metadata from Delta Exchange India...")
        res = self.client.get_products()
        if res.get("success"):
            for p in res.get("result", []):
                sym = p.get("symbol")
                c_type = p.get("contract_type")
                state = p.get("trading_status")
                if c_type == "perpetual_futures" and state == "operational":
                    self.products[sym] = p
                    self.products_by_id[p.get("id")] = p
            logger.info(f"Loaded {len(self.products)} operational perpetual contracts.")
        else:
            logger.warning("Could not fetch product list from exchange.")

    def get_account_capital(self) -> dict:
        if self.dry_run:
            return {"total_usd": 100.0, "available_usd": 100.0}
            
        res = self.client.get_wallet_balances()
        if not res.get("success"):
            return {"total_usd": 0.0, "available_usd": 0.0}
            
        balances = res.get("result", [])
        total_usd = 0.0
        avail_usd = 0.0
        for b in balances:
            asset = b.get("asset_symbol")
            bal = float(b.get("balance", 0.0))
            avail = float(b.get("available_balance", 0.0))
            if asset in ["USDT", "USD"]:
                total_usd += bal
                avail_usd += avail
        return {"total_usd": total_usd, "available_usd": avail_usd}

    def calculate_position_size(self, symbol: str, price: float, product_meta: dict, available_usd: float, total_usd: float) -> int:
        tiers = self.config.get("capital_tiers", {})
        if total_usd >= 100.0:
            target_open = tiers.get("tier_100_usd", 100)
        elif total_usd >= 50.0:
            target_open = tiers.get("tier_50_usd", 35)
        elif total_usd >= 20.0:
            target_open = tiers.get("tier_20_usd", 20)
        else:
            target_open = tiers.get("below_20_usd", 10)
            
        target_allocation_usd = total_usd / max(1.0, target_open)
        target_allocation_usd = max(0.50, min(target_allocation_usd, 5.0))
        
        contract_unit = float(product_meta.get("contract_value") or 1.0)
        notional_per_contract = price * contract_unit
        if notional_per_contract <= 0:
            return 1
            
        margin_per_contract = notional_per_contract / self.leverage
        contracts = int(target_allocation_usd / margin_per_contract)
        if contracts <= 0 and available_usd >= margin_per_contract:
            contracts = 1
            
        required_margin = contracts * margin_per_contract
        if required_margin > (available_usd * 0.85) or contracts <= 0:
            return 0
            
        return contracts

    def analyze_symbol(self, symbol: str) -> dict:
        df = self.client.get_candles(symbol, resolution="15", bars=60)
        if df.empty or len(df) < 35:
            return {"valid": False}
        
        df['ema20'] = df['close'].ewm(span=20, adjust=False).mean()
        df['ema50'] = df['close'].ewm(span=50, adjust=False).mean()
        df['rsi'] = calculate_rsi(df['close'], period=14)
        df['vol_sma'] = df['volume'].rolling(20).mean()
        df['supertrend'], df['st_dir'] = calculate_supertrend(df, period=10, multiplier=3.0)
        
        last = df.iloc[-1]
        current_price = float(last['close'])
        rsi = float(last['rsi']) if not np.isnan(last['rsi']) else 50.0
        ema20 = float(last['ema20'])
        ema50 = float(last['ema50'])
        st_dir = int(last['st_dir'])
        volume = float(last['volume'])
        vol_sma = float(last['vol_sma']) if not np.isnan(last['vol_sma']) else 1.0
        
        score = 0.0
        if st_dir == 1:
            score += 25.0
        if current_price > ema20 > ema50:
            score += 25.0
        elif current_price > ema20:
            score += 15.0
            
        if 55.0 <= rsi <= 85.0:
            score += 25.0
        elif 48.0 <= rsi < 55.0:
            score += 15.0
            
        vol_ratio = volume / (vol_sma + 1e-9)
        if vol_ratio >= 1.2:
            score += 25.0
        elif vol_ratio >= 0.9:
            score += 15.0
            
        is_signal = (score >= self.min_signal_strength) and (st_dir == 1) and (current_price > ema20) and (rsi <= 85.0)
        
        return {
            "valid": True,
            "symbol": symbol,
            "price": current_price,
            "score": score,
            "rsi": rsi,
            "vol_ratio": vol_ratio,
            "is_signal": is_signal
        }

    def sync_positions(self):
        res = self.client.get_positions()
        if not res.get("success"):
            return
        
        exchange_positions = res.get("result", [])
        active_symbols = set()
        
        for p in exchange_positions:
            size = float(p.get("size", 0))
            if size != 0:
                sym = p.get("product_symbol")
                entry_price = float(p.get("entry_price", 0))
                active_symbols.add(sym)
                
                if sym not in self.positions:
                    self.positions[sym] = {
                        "symbol": sym,
                        "product_id": p.get("product_id"),
                        "size": size,
                        "entry_price": entry_price,
                        "peak_price": entry_price,
                        "stop_loss": entry_price * (1 - self.trailing_config.get("hard_sl_pct", 3.5)/100.0) if size > 0 else entry_price * (1 + self.trailing_config.get("hard_sl_pct", 3.5)/100.0),
                        "stage": 1,
                        "entry_time": datetime.now()
                    }
                    logger.info(f"Reconciled position: {sym} | Size: {size} | Entry: ${entry_price:.4f}")
                    
        closed = [sym for sym in self.positions if sym not in active_symbols]
        for sym in closed:
            logger.info(f"Position {sym} closed on exchange. Removing from local state.")
            del self.positions[sym]

    def manage_trailing_stops(self):
        for sym, pos in list(self.positions.items()):
            try:
                df = self.client.get_candles(sym, resolution="1", bars=2)
                if df.empty:
                    continue
                current_price = float(df.iloc[-1]['close'])
                entry_price = pos['entry_price']
                is_short = float(pos['size']) < 0
                
                if is_short:
                    peak_price = min(pos.get('peak_price', entry_price), current_price)
                    pnl_pct = ((entry_price - current_price) / entry_price) * 100.0
                else:
                    peak_price = max(pos.get('peak_price', entry_price), current_price)
                    pnl_pct = ((current_price - entry_price) / entry_price) * 100.0
                    
                pos['peak_price'] = peak_price
                current_sl = pos['stop_loss']
                new_sl = current_sl
                stage = pos.get('stage', 1)
                
                hard_sl_pct = self.trailing_config.get("hard_sl_pct", 3.5)
                stage_2_be = self.trailing_config.get("stage_2_breakeven_pnl_pct", 3.5)
                stage_3_pnl = self.trailing_config.get("stage_3_pnl_pct", 7.0)
                stage_3_trail = self.trailing_config.get("stage_3_trail_pct", 3.5)
                stage_4_pnl = self.trailing_config.get("stage_4_pnl_pct", 15.0)
                stage_4_trail = self.trailing_config.get("stage_4_trail_pct", 5.0)
                
                if not is_short:
                    if pnl_pct >= stage_4_pnl:
                        new_sl = max(current_sl, peak_price * (1.0 - stage_4_trail/100.0))
                        stage = 4
                    elif pnl_pct >= stage_3_pnl:
                        new_sl = max(current_sl, peak_price * (1.0 - stage_3_trail/100.0))
                        stage = 3
                    elif pnl_pct >= stage_2_be:
                        new_sl = max(current_sl, entry_price * 1.002)
                        stage = 2
                    else:
                        new_sl = max(current_sl, entry_price * (1.0 - hard_sl_pct/100.0))
                        stage = 1
                    sl_improved = new_sl > current_sl + (entry_price * 0.0001)
                else:
                    if pnl_pct >= stage_4_pnl:
                        new_sl = min(current_sl, peak_price * (1.0 + stage_4_trail/100.0))
                        stage = 4
                    elif pnl_pct >= stage_3_pnl:
                        new_sl = min(current_sl, peak_price * (1.0 + stage_3_trail/100.0))
                        stage = 3
                    elif pnl_pct >= stage_2_be:
                        new_sl = min(current_sl, entry_price * 0.998)
                        stage = 2
                    else:
                        new_sl = min(current_sl, entry_price * (1.0 + hard_sl_pct/100.0))
                        stage = 1
                    sl_improved = new_sl < current_sl - (entry_price * 0.0001)
                    
                if sl_improved:
                    pos['stop_loss'] = new_sl
                    pos['stage'] = stage
                    logger.info(f"TRAILING STOP [{sym}] Stage {stage} | PnL={pnl_pct:+.2f}% | Peak=${peak_price:.4f} | SL: ${current_sl:.4f} -> ${new_sl:.4f}")
                    
                    if not self.dry_run:
                        open_orders = self.client.get_open_orders().get("result", [])
                        for o in open_orders:
                            if o.get("product_id") == pos['product_id'] and o.get("stop_order_type") == "stop_loss_order":
                                self.client.cancel_order(pos['product_id'], o.get("id"))

                        prod_meta = self.products_by_id.get(pos['product_id'], {})
                        tick_size = float(prod_meta.get("tick_size") or 0.0)
                        if tick_size > 0:
                            new_sl = round(round(new_sl / tick_size) * tick_size, 8)

                        pos_size = abs(int(float(pos['size'])))
                        sl_side = "buy" if is_short else "sell"
                        resp = self.client.place_stop_order(
                            product_id=pos['product_id'],
                            size=pos_size,
                            side=sl_side,
                            stop_price=new_sl
                        )
                        if resp.get("success"):
                            logger.info(f"Placed {sl_side.upper()} stop loss for {sym} at ${new_sl}")
                        else:
                            logger.error(f"Failed to place SL for {sym}: {resp.get('error')}")
                        
                hit_exit = (current_price >= pos['stop_loss']) if is_short else (current_price <= pos['stop_loss'])
                if hit_exit:
                    reason = "STOP_LOSS" if pnl_pct <= 0 else "TRAIL_PROFIT"
                    logger.info(f"EXIT TRIGGERED [{sym}] Reason: {reason} | Exit: ${current_price:.4f} | PnL: {pnl_pct:+.2f}%")
                    if not self.dry_run:
                        pos_size = abs(int(float(pos['size'])))
                        exit_side = "buy" if is_short else "sell"
                        self.client.place_order(
                            product_id=pos['product_id'],
                            size=pos_size,
                            side=exit_side,
                            order_type="market_order"
                        )
                    del self.positions[sym]
            except Exception as e:
                logger.error(f"Error managing position {sym}: {e}")

    def reconcile_exit_orders(self):
        try:
            active_pids = {pos['product_id']: sym for sym, pos in self.positions.items()}
            all_orders = self.client.get_open_orders().get("result", [])

            orders_by_product = {}
            for o in all_orders:
                pid = o.get("product_id")
                orders_by_product.setdefault(pid, []).append(o)

            for pid, ords in orders_by_product.items():
                if pid not in active_pids:
                    for o in ords:
                        logger.info(f"Reconciliation: cancelling orphaned order {o.get('id')} for product {pid}")
                        self.client.cancel_order(pid, o.get("id"))
                elif len(ords) > 1:
                    ords.sort(key=lambda x: (float(x.get("stop_price") or 0), x.get("created_at", "")), reverse=True)
                    for dup in ords[1:]:
                        logger.info(f"Reconciliation: cancelling duplicate order {dup.get('id')} for product {pid}")
                        self.client.cancel_order(pid, dup.get("id"))

            if not self.dry_run:
                for sym, pos in list(self.positions.items()):
                    pid = pos['product_id']
                    existing_ords = orders_by_product.get(pid, [])
                    has_sl = any(o.get("stop_order_type") == "stop_loss_order" for o in existing_ords)
                    if not has_sl:
                        prod_meta = self.products_by_id.get(pid, {})
                        tick_size = float(prod_meta.get("tick_size") or 0.0)
                        sl_price = pos['stop_loss']
                        if tick_size > 0:
                            sl_price = round(round(sl_price / tick_size) * tick_size, 8)
                        pos_size = abs(int(float(pos['size'])))
                        is_short = float(pos['size']) < 0
                        sl_side = "buy" if is_short else "sell"
                        logger.warning(f"Position {sym} had NO stop-loss order! Placing {sl_side.upper()} order at ${sl_price}...")
                        resp = self.client.place_stop_order(
                            product_id=pid,
                            size=pos_size,
                            side=sl_side,
                            stop_price=sl_price
                        )
                        if resp.get("success"):
                            logger.info(f"Successfully placed protective stop-loss for {sym}")
                        else:
                            logger.error(f"Failed to place protective SL for {sym}: {resp.get('error')}")
        except Exception as e:
            logger.error(f"Reconcile exit orders error: {e}")

    def run_cycle(self):
        logger.info("--- Starting ZeroLag Market Scan Cycle ---")
        self.sync_positions()
        self.reconcile_exit_orders()
        self.manage_trailing_stops()
        
        cap = self.get_account_capital()
        total_usd = cap["total_usd"]
        avail_usd = cap["available_usd"]
        
        configured_max = int(os.getenv('DELTA_MAX_POSITIONS', str(self.config.get("default_max_positions", 35))))
        tiers = self.config.get("capital_tiers", {})
        if total_usd >= 100.0:
            self.max_concurrent_positions = max(configured_max, tiers.get("tier_100_usd", 100))
        elif total_usd >= 50.0:
            self.max_concurrent_positions = max(configured_max, tiers.get("tier_50_usd", 35))
        elif total_usd >= 20.0:
            self.max_concurrent_positions = max(configured_max, tiers.get("tier_20_usd", 20))
        else:
            self.max_concurrent_positions = tiers.get("below_20_usd", 10)
            
        logger.info(f"Capital: Total=${total_usd:.2f} USD | Avail=${avail_usd:.2f} USD | Positions: {len(self.positions)}/{self.max_concurrent_positions}")
        
        if len(self.positions) >= self.max_concurrent_positions:
            logger.info("Max concurrent positions reached. Monitoring active trades.")
            return
            
        if avail_usd < 0.5:
            logger.info("Available margin is below minimum ($0.50 USD). Awaiting exits or top-up.")
            return
            
        priority_symbols = [
            "BTCUSD", "ETHUSD", "SOLUSD", "AVAXUSD", "DOGEUSD", "LINKUSD",
            "NEARUSD", "UNIUSD", "LTCUSD", "XRPUSD", "ADAUSD", "ZROUSD"
        ]
        all_symbols = priority_symbols + [s for s in self.products if s not in priority_symbols]
        
        candidates = []
        for sym in all_symbols:
            if sym in self.positions:
                continue
            res = self.analyze_symbol(sym)
            if res.get("valid") and res.get("is_signal"):
                candidates.append(res)
                
        candidates.sort(key=lambda x: x["score"], reverse=True)
        
        for cand in candidates:
            if len(self.positions) >= self.max_concurrent_positions:
                break
                
            sym = cand["symbol"]
            price = cand["price"]
            product = self.products.get(sym)
            if not product:
                continue
                
            size = self.calculate_position_size(sym, price, product, avail_usd, total_usd)
            if size <= 0:
                continue
                
            hard_sl_pct = self.trailing_config.get("hard_sl_pct", 3.5)
            sl_price = price * (1.0 - hard_sl_pct / 100.0)
            logger.info(f"SIGNAL TRIGGER: {sym} | Score: {cand['score']:.1f} | RSI: {cand['rsi']:.1f} | Size: {size} contracts @ ${price:.4f} | SL: ${sl_price:.4f}")
            
            if self.dry_run:
                logger.info(f"[DRY-RUN] Simulated BUY order for {size} contracts of {sym}")
                self.positions[sym] = {
                    "symbol": sym,
                    "product_id": product.get("id"),
                    "size": size,
                    "entry_price": price,
                    "peak_price": price,
                    "stop_loss": sl_price,
                    "stage": 1,
                    "entry_time": datetime.now()
                }
            else:
                resp = self.client.place_order(
                    product_id=product.get("id"),
                    size=size,
                    side="buy",
                    order_type="market_order",
                    bracket_sl=sl_price
                )
                if resp.get("success"):
                    logger.info(f"ENTERED LIVE POSITION: {sym} | {size} contracts")
                    self.positions[sym] = {
                        "symbol": sym,
                        "product_id": product.get("id"),
                        "size": size,
                        "entry_price": price,
                        "peak_price": price,
                        "stop_loss": sl_price,
                        "stage": 1,
                        "entry_time": datetime.now()
                    }
                else:
                    logger.error(f"Failed to place order for {sym}: {resp.get('error')}")

    def run(self, interval_seconds: int = 30):
        self.load_products()
        logger.info(f"Starting TheBull Delta Bot Engine (Scan Interval: {interval_seconds}s)...")
        while True:
            try:
                self.run_cycle()
            except Exception as e:
                logger.error(f"Error in execution cycle: {e}")
            time.sleep(interval_seconds)


# ==============================================================================
# ENTRY POINT
# ==============================================================================
def main():
    parser = argparse.ArgumentParser(description="TheBull Delta Exchange India Trading Bot")
    parser.add_argument("--dry-run", action="store_true", help="Run in dry-run simulation mode")
    parser.add_argument("--interval", type=int, default=30, help="Scan interval in seconds (default: 30)")
    parser.add_argument("--config", type=str, default="config.json", help="Path to config.json file")
    args = parser.parse_args()

    # Load .env
    base_dir = os.path.dirname(os.path.abspath(__file__))
    env_file = os.path.join(base_dir, ".env")
    if os.path.exists(env_file):
        load_dotenv(env_file)
    else:
        load_dotenv()

    api_key = os.getenv("DELTA_API_KEY")
    api_secret = os.getenv("DELTA_API_SECRET")

    if not api_key or not api_secret or "your_delta" in api_key.lower():
        logger.error("Missing valid DELTA_API_KEY or DELTA_API_SECRET!")
        logger.error("Please edit the '.env' file and insert your API credentials from Delta Exchange India.")
        sys.exit(1)

    # Load config.json
    config_file = os.path.join(base_dir, args.config)
    config = {}
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                config = json.load(f)
            logger.info(f"Loaded config from {config_file}")
        except Exception as e:
            logger.warning(f"Failed to parse {config_file}: {e}. Using defaults.")

    bot = TheBullDeltaBot(
        api_key=api_key,
        api_secret=api_secret,
        config=config,
        dry_run=args.dry_run
    )

    interval = args.interval or config.get("scan_interval_seconds", 30)
    bot.run(interval_seconds=interval)


if __name__ == "__main__":
    main()
