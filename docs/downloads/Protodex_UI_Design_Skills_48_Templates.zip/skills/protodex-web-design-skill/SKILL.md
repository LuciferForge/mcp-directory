---
name: protodex-web-design-skill
description: "Generate Awwwards-grade, futuristic developer interfaces, AI agent command centers, dark mode SaaS landing pages, and bento grids using Tailwind CSS and modern Web standards."
---

# Protodex Web Design Skill (2026 Edition)

Use this skill when you need to design, prototype, or build high-converting, developer-focused web interfaces, landing pages, dashboards, and AI agent HUDs.

## Design System Tokens
- **Canvas**: Deep Obsidian `#05060A`, Card Surfaces `rgba(14, 17, 28, 0.72)`
- **Atmospheric Lighting**: Electric Cyan (`#2DD9E0`), Cyber Violet (`#8B5CF6`), Laser Amber (`#F59E0B`), Neon Lime (`#22C55E`)
- **Glassmorphism 2.0**: `backdrop-filter: blur(16px); box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.14); border: 1px solid rgba(255, 255, 255, 0.08);`
- **Typography**: Inter (UI), JetBrains Mono (Code & Telemetry)

## Catalog of 48 Specialized Template archetypes:
1. AI Agent Mission Control & Swarm Orchestrators
2. Interactive MCP Server & API Catalogs
3. Linear & Vercel Style Obsidian Dark SaaS
4. Awwwards Bento Grids & Specular Chamfers
5. AegisMesh Cyber-HUD Security Terminals
6. Polymarket & Quant Trading Terminals
7. GitBook Technical Docs & SDK Blueprints
8. Viral Developer Waitlists & Launchpads

## Command Usage:
To generate any archetype, prompt your AI agent:
`Generate a [archetype name] template using protodex-web-design-skill with Tailwind CSS.`
