"""Unit tests for the Token Safety Filter module."""

import unittest
from src.safety_filter import TokenSafetyFilter, SPL_TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID


class TestSafetyFilter(unittest.TestCase):
    def setUp(self):
        self.safety_filter = TokenSafetyFilter(max_allowed_transfer_fee_bps=50)

    def test_clean_spl_token_passes(self):
        """A clean standard SPL token with revoked authorities should pass inspection."""
        clean_token_data = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 9,
            "supply": 1_000_000_000_000_000_000,
        }
        report = self.safety_filter.inspect_mint(
            mint="CleanTokenMint111111111111111111111111111111",
            parsed_data=clean_token_data,
            program_id=SPL_TOKEN_PROGRAM_ID,
        )
        self.assertTrue(report.is_safe)
        self.assertEqual(report.risk_score, 0.0)
        self.assertEqual(len(report.reasons), 0)
        self.assertIsNone(report.freeze_authority)
        self.assertIsNone(report.mint_authority)

    def test_unrevoked_freeze_authority_rejected(self):
        """Tokens with active freeze authorities can blacklist buyers (Honeypot vector)."""
        honeypot_data = {
            "mintAuthority": None,
            "freezeAuthority": "AttackerFreezeWallet11111111111111111111111",
            "decimals": 6,
            "supply": 100_000_000_000_000,
        }
        report = self.safety_filter.inspect_mint(
            mint="FreezeHoneypot1111111111111111111111111111111",
            parsed_data=honeypot_data,
            program_id=SPL_TOKEN_PROGRAM_ID,
        )
        self.assertFalse(report.is_safe)
        self.assertEqual(report.risk_score, 1.0)
        self.assertTrue(any("freeze authority detected" in r for r in report.reasons))

    def test_unrevoked_mint_authority_rejected(self):
        """Tokens with active mint authorities can print infinite supply and dump."""
        inflation_rug_data = {
            "mintAuthority": "AttackerMintWallet1111111111111111111111111",
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 1_000_000_000_000,
        }
        report = self.safety_filter.inspect_mint(
            mint="MintAuthorityRug11111111111111111111111111111",
            parsed_data=inflation_rug_data,
            program_id=SPL_TOKEN_PROGRAM_ID,
        )
        self.assertFalse(report.is_safe)
        self.assertGreaterEqual(report.risk_score, 0.7)
        self.assertTrue(any("mint authority detected" in r for r in report.reasons))

    def test_token_2022_transfer_hook_rejected(self):
        """Token-2022 transfer hooks can hijack transfers to block sells (Honeypot)."""
        token_2022_hook_data = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 500_000_000_000_000,
            "extensions": [
                {
                    "extension": "transferHook",
                    "state": {
                        "programId": "MaliciousHookProgram1111111111111111111111",
                    },
                }
            ],
        }
        report = self.safety_filter.inspect_mint(
            mint="TransferHookToken111111111111111111111111111",
            parsed_data=token_2022_hook_data,
            program_id=TOKEN_2022_PROGRAM_ID,
        )
        self.assertFalse(report.is_safe)
        self.assertEqual(report.risk_score, 1.0)
        self.assertTrue(any("transfer hook" in r.lower() for r in report.reasons))

    def test_token_2022_predatory_transfer_tax_rejected(self):
        """Token-2022 transfer fees above threshold must be rejected."""
        token_2022_tax_data = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 500_000_000_000_000,
            "extensions": [
                {
                    "extension": "transferFeeConfig",
                    "state": {
                        "newerTransferFee": {"transferFeeBasisPoints": 1000},  # 10% TAX
                        "transferFeeConfigAuthority": "ScammerTaxAuth111111111111111111111111111",
                    },
                }
            ],
        }
        report = self.safety_filter.inspect_mint(
            mint="HighTaxToken11111111111111111111111111111111",
            parsed_data=token_2022_tax_data,
            program_id=TOKEN_2022_PROGRAM_ID,
        )
        self.assertFalse(report.is_safe)
        self.assertGreaterEqual(report.risk_score, 0.8)
        self.assertTrue(any("Transfer fee" in r for r in report.reasons))

    def test_token_2022_permanent_delegate_rejected(self):
        """Token-2022 permanent delegate can confiscate user balances."""
        token_delegate_data = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 100_000_000_000_000,
            "extensions": [
                {
                    "extension": "permanentDelegate",
                    "state": {
                        "delegate": "DrainerWallet111111111111111111111111111111",
                    },
                }
            ],
        }
        report = self.safety_filter.inspect_mint(
            mint="PermanentDelegateToken111111111111111111111",
            parsed_data=token_delegate_data,
            program_id=TOKEN_2022_PROGRAM_ID,
        )
        self.assertFalse(report.is_safe)
        self.assertEqual(report.risk_score, 1.0)
        self.assertTrue(any("permanent delegate" in r.lower() for r in report.reasons))

    def test_top_holder_concentration_warning(self):
        """Excessive holder concentration triggers risk flag."""
        token_data = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 1_000_000,
        }
        # Top holder holds 40% of supply
        largest_holders = [
            {"address": "Whale1", "amount": 400_000},
            {"address": "Holder2", "amount": 50_000},
        ]
        report = self.safety_filter.inspect_mint(
            mint="WhaleConcentratedToken1111111111111111111",
            parsed_data=token_data,
            program_id=SPL_TOKEN_PROGRAM_ID,
            largest_accounts=largest_holders,
        )
        self.assertFalse(report.is_safe)
        self.assertTrue(any("Top holders control" in r for r in report.reasons))


if __name__ == "__main__":
    unittest.main()
