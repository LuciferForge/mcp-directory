#!/usr/bin/env python3
"""
Solana "Phoenix Reversal" Engine: Mature Tokens (> 7 Days Old) Awakening
========================================================================
Operational Modes:
- LIVE EXECUTION (--live): Real Jupiter swaps with dedicated meme wallet
- PAPER SIMULATION (Default): Risk-free simulation for telemetry

Author: Quant Systems & Microstructure Architecture Team

Core Thesis:
- Discards noisy, rug-heavy < 48-hour new launches.
- Screens for mature Solana tokens (Age 7 to 60 days) that have already dumped from
  initial launch, consolidated an accumulation base, and are now breaking out with
  fresh organic volume, heavy buy dominance (Buys/Sells >= 1.75x), and safe liquidity.
- Trades with strict Risk Management:
  * Live Size: 0.020 SOL per slot (~$3.10 USD) | Paper Size: $10.00 USD
  * Hard Stop Loss: -15.0%
  * Take Profit 1: +50.0% (Sell 50%, lock Breakeven +1.0% stop)
  * Take Profit 2: +100.0% (Sell remaining 50% on 2x runner)
  * Stagnation Time-Stop: Exit if flat after 24 hours
"""

import os
import sys
import time
import json
import base64
import logging
import argparse
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any, Tuple
import requests

# UTF-8 stdout configuration
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# --- CONFIGURATION & PATHS ---
DATA_DIR = "/opt/trading_bots" if os.path.exists("/opt/trading_bots") else os.path.dirname(os.path.abspath(__file__))
POSITIONS_FILE = os.path.join(DATA_DIR, "solana_phoenix_positions.json")
LEDGER_FILE = os.path.join(DATA_DIR, "solana_phoenix_trade_ledger.json")
LOG_FILE = os.path.join(DATA_DIR, "solana_phoenix.log")
KEYPAIR_PATH = os.path.join(DATA_DIR, "meme_trading_wallet.json")

# --- SOLANA CLUSTER & JUPITER ENDPOINTS ---
RPC_URL = "https://api.mainnet-beta.solana.com"
SOL_MINT = "So11111111111111111111111111111111111111112"
JUPITER_QUOTE_URL = "https://api.jup.ag/swap/v1/quote"
JUPITER_SWAP_URL = "https://api.jup.ag/swap/v1/swap"

# --- LOGGING SETUP ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("PhoenixReversal")

# --- TELEGRAM CONFIGURATION ---
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8876734134:AAFBjmwE-KT9IDghZw994Wc3gPVFtuqUncs")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "257190241")

def send_telegram(message: str, priority: bool = False):
    """Sends a Telegram alert message."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": message,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    try:
        requests.post(url, json=payload, timeout=5)
    except Exception as e:
        logger.warning(f"Telegram alert delivery failed: {e}")

# --- STRATEGY PARAMETERS ---
STRATEGY_CONFIG = {
    "min_age_days": 7.0,
    "max_age_days": 60.0,
    "min_liquidity_usd": 40000.0,
    "min_24h_volume_usd": 75000.0,
    "min_market_cap_usd": 250000.0,
    "max_market_cap_usd": 25000000.0,
    "price_change_24h_min": 12.0,   # Minimum +12% 24h momentum ignition
    "price_change_24h_max": 85.0,   # Cap at +85% to avoid chasing blowoff tops
    "price_change_1h_min": 0.0,     # Must be green in the last 1 hour
    "min_buy_sell_ratio": 1.70,     # Aggressive buy accumulation dominance
    "live_slot_sol": 0.020,         # ~0.020 SOL (~$3.10 USD) per live trade
    "min_sol_reserve": 0.015,       # Reserve for Solana gas fees & ATA rent
    "simulated_slot_usd": 10.0,     # $10 paper capital per slot
    "max_concurrent_positions": 1,  # Max 1 concurrent live position to preserve wallet margin
    "stop_loss_pct": -15.0,         # -15% hard stop
    "tp1_pct": 50.0,                # +50% TP1 (sell 50%, lock BE)
    "tp2_pct": 100.0,               # +100% TP2 (sell remaining 50%)
    "stagnation_hours": 24.0,       # 24h stagnation cut
}

class SolanaWalletClient:
    """Manages real on-chain Solana transactions, balance queries, and Jupiter swaps."""
    def __init__(self, keypair_path: str = KEYPAIR_PATH):
        self.keypair = None
        self.pubkey = None
        if os.path.exists(keypair_path):
            try:
                from solders.keypair import Keypair
                with open(keypair_path, "r", encoding="utf-8") as f:
                    secret = json.load(f)
                self.keypair = Keypair.from_bytes(bytes(secret))
                self.pubkey = str(self.keypair.pubkey())
                logger.info(f"🔑 Loaded Solana Meme Wallet: {self.pubkey}")
            except Exception as e:
                logger.error(f"Failed to load keypair from {keypair_path}: {e}")

    def get_sol_balance(self) -> float:
        if not self.pubkey:
            return 0.0
        try:
            payload = {"jsonrpc": "2.0", "id": 1, "method": "getBalance", "params": [self.pubkey]}
            r = requests.post(RPC_URL, json=payload, timeout=8)
            lamports = r.json().get("result", {}).get("value", 0)
            return float(lamports) / 1e9
        except Exception as e:
            logger.error(f"Error fetching SOL balance: {e}")
            return 0.0

    def get_token_balance_raw(self, mint: str) -> int:
        if not self.pubkey:
            return 0
        try:
            payload = {
                "jsonrpc": "2.0", "id": 1, "method": "getTokenAccountsByOwner",
                "params": [self.pubkey, {"mint": mint}, {"encoding": "jsonParsed"}]
            }
            r = requests.post(RPC_URL, json=payload, timeout=8)
            accs = r.json().get("result", {}).get("value", [])
            if not accs:
                return 0
            return int(accs[0]["account"]["data"]["parsed"]["info"]["tokenAmount"]["amount"])
        except Exception as e:
            logger.error(f"Error fetching token balance for {mint}: {e}")
            return 0

    def execute_jupiter_buy(self, mint: str, sol_amount: float) -> Tuple[bool, int, str]:
        """Buys a token using Jupiter Swap API. Returns (success, out_tokens_raw, tx_sig)."""
        if not self.keypair:
            logger.error("No keypair loaded for live execution.")
            return False, 0, ""

        lamports = int(sol_amount * 1e9)
        params = {
            "inputMint": SOL_MINT,
            "outputMint": mint,
            "amount": str(lamports),
            "slippageBps": 300
        }
        try:
            # 1. Get Quote
            q_res = requests.get(JUPITER_QUOTE_URL, params=params, timeout=10)
            if q_res.status_code != 200:
                logger.error(f"Jupiter Buy Quote failed: {q_res.text}")
                return False, 0, ""
            quote = q_res.json()
            out_tokens = int(quote.get("outAmount", 0))

            time.sleep(1.0) # Rate limit safety

            # 2. Build Swap Transaction
            swap_payload = {
                "quoteResponse": quote,
                "userPublicKey": self.pubkey,
                "wrapAndUnwrapSol": True,
                "dynamicComputeUnitLimit": True,
                "prioritizationFeeLamports": "auto"
            }
            s_res = requests.post(JUPITER_SWAP_URL, json=swap_payload, timeout=10)
            if s_res.status_code != 200:
                logger.error(f"Jupiter Buy Swap build failed: {s_res.text}")
                return False, 0, ""

            # 3. Sign & Send
            from solders.transaction import VersionedTransaction
            from solders import message
            from solana.rpc.api import Client
            from solana.rpc.types import TxOpts

            tx_bytes = base64.b64decode(s_res.json()["swapTransaction"])
            raw_tx = VersionedTransaction.from_bytes(tx_bytes)
            sig = self.keypair.sign_message(message.to_bytes_versioned(raw_tx.message))
            signed_tx = VersionedTransaction.populate(raw_tx.message, [sig])

            sol_client = Client(RPC_URL)
            opts = TxOpts(skip_preflight=True)
            res = sol_client.send_raw_transaction(bytes(signed_tx), opts=opts)
            tx_sig = str(res.value)
            logger.info(f"✅ Live Buy Transaction Sent: {tx_sig}")
            return True, out_tokens, tx_sig
        except Exception as e:
            logger.error(f"Live buy execution exception: {e}")
            return False, 0, ""

    def execute_jupiter_sell(self, mint: str, token_amount_raw: int) -> Tuple[bool, float, str]:
        """Sells tokens back to native SOL via Jupiter Swap API. Returns (success, sol_received, tx_sig)."""
        if not self.keypair or token_amount_raw <= 0:
            return False, 0.0, ""

        params = {
            "inputMint": mint,
            "outputMint": SOL_MINT,
            "amount": str(token_amount_raw),
            "slippageBps": 400
        }
        try:
            q_res = requests.get(JUPITER_QUOTE_URL, params=params, timeout=10)
            if q_res.status_code != 200:
                logger.error(f"Jupiter Sell Quote failed: {q_res.text}")
                return False, 0.0, ""
            quote = q_res.json()
            out_lamports = int(quote.get("outAmount", 0))
            sol_received = float(out_lamports) / 1e9

            time.sleep(1.0)

            swap_payload = {
                "quoteResponse": quote,
                "userPublicKey": self.pubkey,
                "wrapAndUnwrapSol": True,
                "dynamicComputeUnitLimit": True,
                "prioritizationFeeLamports": "auto"
            }
            s_res = requests.post(JUPITER_SWAP_URL, json=swap_payload, timeout=10)
            if s_res.status_code != 200:
                logger.error(f"Jupiter Sell Swap build failed: {s_res.text}")
                return False, 0.0, ""

            from solders.transaction import VersionedTransaction
            from solders import message
            from solana.rpc.api import Client
            from solana.rpc.types import TxOpts

            tx_bytes = base64.b64decode(s_res.json()["swapTransaction"])
            raw_tx = VersionedTransaction.from_bytes(tx_bytes)
            sig = self.keypair.sign_message(message.to_bytes_versioned(raw_tx.message))
            signed_tx = VersionedTransaction.populate(raw_tx.message, [sig])

            sol_client = Client(RPC_URL)
            opts = TxOpts(skip_preflight=True)
            res = sol_client.send_raw_transaction(bytes(signed_tx), opts=opts)
            tx_sig = str(res.value)
            logger.info(f"✅ Live Sell Transaction Sent: {tx_sig} (~{sol_received:.5f} SOL)")
            return True, sol_received, tx_sig
        except Exception as e:
            logger.error(f"Live sell execution exception: {e}")
            return False, 0.0, ""

class RugCheckAuditor:
    """Audits token contracts via RugCheck API for critical security risks."""
    @staticmethod
    def audit_token(mint: str) -> Dict[str, Any]:
        url = f"https://api.rugcheck.xyz/v1/tokens/{mint}/report"
        try:
            r = requests.get(url, timeout=6)
            if r.status_code == 200:
                data = r.json()
                score = data.get("score", 999)
                risks = data.get("risks", [])
                high_risks = [rk for rk in risks if rk.get("level") in ["danger", "high"]]
                return {
                    "safe": (score <= 600 and len(high_risks) == 0),
                    "score": score,
                    "risks": [rk.get("name") for rk in high_risks]
                }
        except Exception as e:
            logger.debug(f"Rugcheck lookup error for {mint}: {e}")
        return {"safe": True, "score": 0, "risks": []}

class PhoenixScanner:
    """Scans Dexscreener and on-chain pools for mature 7-day+ breakout candidates."""
    
    @staticmethod
    def gather_candidate_mints() -> List[str]:
        mints = set()
        
        # 1. DexScreener Latest Token Profiles
        try:
            r1 = requests.get("https://api.dexscreener.com/token-profiles/latest/v1", timeout=8)
            if r1.status_code == 200:
                for item in r1.json():
                    if item.get("chainId") == "solana":
                        mints.add(item.get("tokenAddress"))
        except Exception as e:
            logger.debug(f"DexScreener profiles error: {e}")

        # 2. DexScreener Top Boosts
        try:
            r2 = requests.get("https://api.dexscreener.com/token-boosts/top/v1", timeout=8)
            if r2.status_code == 200:
                for item in r2.json():
                    if item.get("chainId") == "solana":
                        mints.add(item.get("tokenAddress"))
        except Exception as e:
            logger.debug(f"DexScreener boosts error: {e}")

        # 3. DexScreener Latest Boosts
        try:
            r3 = requests.get("https://api.dexscreener.com/token-boosts/latest/v1", timeout=8)
            if r3.status_code == 200:
                for item in r3.json():
                    if item.get("chainId") == "solana":
                        mints.add(item.get("tokenAddress"))
        except Exception as e:
            logger.debug(f"DexScreener latest boosts error: {e}")

        return list(mints)

    @classmethod
    def scan_for_reversals(cls) -> List[Dict[str, Any]]:
        mints = cls.gather_candidate_mints()
        if not mints:
            logger.warning("No candidate mints discovered from initial query.")
            return []

        now_ms = time.time() * 1000
        candidates = []
        chunk_size = 25

        for i in range(0, len(mints), chunk_size):
            chunk = mints[i:i + chunk_size]
            url = f"https://api.dexscreener.com/latest/dex/tokens/{','.join(chunk)}"
            try:
                res = requests.get(url, timeout=10)
                if res.status_code == 200:
                    pairs = res.json().get("pairs", [])
                    for p in pairs:
                        if p.get("chainId") != "solana":
                            continue
                        
                        created_at = p.get("pairCreatedAt")
                        if not created_at:
                            continue
                        
                        age_days = (now_ms - created_at) / (1000 * 86400.0)
                        
                        # CRITERIA 1: Age between 7.0 and 60.0 Days
                        if age_days < STRATEGY_CONFIG["min_age_days"] or age_days > STRATEGY_CONFIG["max_age_days"]:
                            continue

                        liq = float(p.get("liquidity", {}).get("usd") or 0)
                        mc = float(p.get("marketCap") or 0)
                        vol_24h = float(p.get("volume", {}).get("h24") or 0)
                        pc_24h = float(p.get("priceChange", {}).get("h24") or 0)
                        pc_6h = float(p.get("priceChange", {}).get("h6") or 0)
                        pc_1h = float(p.get("priceChange", {}).get("h1") or 0)
                        price_usd = float(p.get("priceUsd") or 0)

                        txns = p.get("txns", {}).get("h24", {})
                        buys_24h = int(txns.get("buys") or 0)
                        sells_24h = int(txns.get("sells") or 0)
                        bsr = round(buys_24h / (sells_24h + 1e-4), 2)

                        # CRITERIA 2: Liquidity & Market Cap Runway
                        if liq < STRATEGY_CONFIG["min_liquidity_usd"]:
                            continue
                        if mc < STRATEGY_CONFIG["min_market_cap_usd"] or mc > STRATEGY_CONFIG["max_market_cap_usd"]:
                            continue
                        if vol_24h < STRATEGY_CONFIG["min_24h_volume_usd"]:
                            continue

                        # CRITERIA 3: Momentum & Accumulation Floor Reversal
                        if not (STRATEGY_CONFIG["price_change_24h_min"] <= pc_24h <= STRATEGY_CONFIG["price_change_24h_max"]):
                            continue
                        if pc_1h < STRATEGY_CONFIG["price_change_1h_min"]:
                            continue
                        if bsr < STRATEGY_CONFIG["min_buy_sell_ratio"]:
                            continue
                        if price_usd <= 0:
                            continue

                        sym = p.get("baseToken", {}).get("symbol", "UNKNOWN")
                        base_mint = p.get("baseToken", {}).get("address")
                        pair_addr = p.get("pairAddress")
                        dex = p.get("dexId", "unknown")

                        candidates.append({
                            "symbol": sym,
                            "mint": base_mint,
                            "pair_address": pair_addr,
                            "dex": dex,
                            "age_days": round(age_days, 1),
                            "liquidity": liq,
                            "market_cap": mc,
                            "vol_24h": vol_24h,
                            "price_usd": price_usd,
                            "pc_24h": pc_24h,
                            "pc_6h": pc_6h,
                            "pc_1h": pc_1h,
                            "buys_24h": buys_24h,
                            "sells_24h": sells_24h,
                            "bsr": bsr,
                            "url": p.get("url", f"https://dexscreener.com/solana/{base_mint}")
                        })
                time.sleep(0.3)
            except Exception as e:
                logger.error(f"Error querying token chunk: {e}")

        unique = {}
        for c in candidates:
            m = c["mint"]
            if m not in unique or c["liquidity"] > unique[m]["liquidity"]:
                unique[m] = c

        ranked = list(unique.values())
        ranked.sort(key=lambda x: (x["pc_24h"] * 0.4 + (x["vol_24h"] / 100000.0) * 0.6), reverse=True)
        return ranked

class PositionManager:
    """Manages active live or simulated positions, stop losses, and take profit scaling."""
    
    def __init__(self, is_live: bool = False, wallet_client: Optional[SolanaWalletClient] = None):
        self.is_live = is_live
        self.wallet_client = wallet_client
        self.positions: Dict[str, Dict[str, Any]] = self._load_positions()

    def _load_positions(self) -> Dict[str, Dict[str, Any]]:
        if os.path.exists(POSITIONS_FILE):
            try:
                with open(POSITIONS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading positions: {e}")
        return {}

    def _save_positions(self):
        try:
            with open(POSITIONS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.positions, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving positions: {e}")

    def get_open_count(self) -> int:
        return len(self.positions)

    def is_already_open(self, mint: str) -> bool:
        return mint in self.positions

    def open_position(self, candidate: Dict[str, Any]):
        mint = candidate["mint"]
        sym = candidate["symbol"]
        price = candidate["price_usd"]

        if not self.is_live:
            # Paper Mode
            slot_usd = STRATEGY_CONFIG["simulated_slot_usd"]
            units = slot_usd / price if price > 0 else 0
            pos = {
                "symbol": sym,
                "mint": mint,
                "is_live": False,
                "pair_address": candidate["pair_address"],
                "dex": candidate["dex"],
                "entry_time": datetime.now(timezone.utc).isoformat(),
                "entry_price": price,
                "current_price": price,
                "highest_price": price,
                "initial_slot_usd": slot_usd,
                "current_notional_usd": slot_usd,
                "units": units,
                "units_raw": 0,
                "sol_cost": 0.0,
                "tp1_hit": False,
                "stop_loss_pct": STRATEGY_CONFIG["stop_loss_pct"],
                "age_at_entry": candidate["age_days"],
                "bsr_at_entry": candidate["bsr"],
                "url": candidate["url"]
            }
            self.positions[mint] = pos
            self._save_positions()

            msg = (
                f"🟢 <b>[PAPER] PHOENIX REVERSAL POSITION OPENED</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"💎 <b>Token:</b> {sym} (<code>{mint[:6]}...{mint[-4:]}</code>)\n"
                f"⏳ <b>Age:</b> {candidate['age_days']} Days Old (Consolidated Base)\n"
                f"💵 <b>Entry Price:</b> ${price:.8f}\n"
                f"💰 <b>Simulated Size:</b> ${slot_usd:.2f} USD\n"
                f"💧 <b>Liquidity:</b> ${candidate['liquidity']:,.0f} | <b>MCap:</b> ${candidate['market_cap']:,.0f}\n"
                f"📊 <b>24h Vol:</b> ${candidate['vol_24h']:,.0f} | <b>24h Gain:</b> +{candidate['pc_24h']:.1f}%\n"
                f"🐋 <b>Buy/Sell Ratio:</b> {candidate['bsr']:.1f}x Dominance\n"
                f"🎯 <b>Targets:</b> TP1 +50% (${price * 1.5:.8f}) | TP2 +100% (${price * 2.0:.8f})\n"
                f"🛑 <b>Hard SL:</b> -15% (${price * 0.85:.8f})\n"
                f"🔗 <a href='{candidate['url']}'>DexScreener Chart</a>"
            )
            logger.info(f"OPENED PAPER POSITION: {sym} at ${price:.8f}")
            send_telegram(msg)
            return

        # LIVE EXECUTION MODE
        sol_amount = STRATEGY_CONFIG["live_slot_sol"]
        current_sol_bal = self.wallet_client.get_sol_balance()
        if current_sol_bal < (sol_amount + STRATEGY_CONFIG["min_sol_reserve"]):
            logger.warning(f"Insufficient SOL balance ({current_sol_bal:.4f} SOL) for trade ({sol_amount} SOL + reserve). Skipping live buy.")
            return

        logger.info(f"⚡ EXECUTING LIVE BUY FOR {sym} ({sol_amount} SOL)...")
        success, units_raw, tx_sig = self.wallet_client.execute_jupiter_buy(mint, sol_amount)
        if not success or units_raw <= 0:
            logger.error(f"Live buy failed for {sym}.")
            return

        pos = {
            "symbol": sym,
            "mint": mint,
            "is_live": True,
            "pair_address": candidate["pair_address"],
            "dex": candidate["dex"],
            "entry_time": datetime.now(timezone.utc).isoformat(),
            "entry_price": price,
            "current_price": price,
            "highest_price": price,
            "initial_slot_sol": sol_amount,
            "sol_cost": sol_amount,
            "initial_units_raw": units_raw,
            "remaining_units_raw": units_raw,
            "buy_tx": tx_sig,
            "tp1_hit": False,
            "stop_loss_pct": STRATEGY_CONFIG["stop_loss_pct"],
            "age_at_entry": candidate["age_days"],
            "bsr_at_entry": candidate["bsr"],
            "url": candidate["url"]
        }
        self.positions[mint] = pos
        self._save_positions()

        msg = (
            f"🚀 <b>[LIVE REAL MONEY] PHOENIX REVERSAL POSITION BOUGHT!</b>\n"
            f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💎 <b>Token:</b> {sym} (<code>{mint[:6]}...{mint[-4:]}</code>)\n"
            f"⏳ <b>Age:</b> {candidate['age_days']} Days Old (Post-Graduation Base)\n"
            f"💵 <b>Entry:</b> ${price:.8f}\n"
            f"💰 <b>Cost:</b> {sol_amount:.3f} SOL (~${sol_amount * 155:.2f} USD)\n"
            f"💧 <b>Liquidity:</b> ${candidate['liquidity']:,.0f} | <b>MCap:</b> ${candidate['market_cap']:,.0f}\n"
            f"🐋 <b>Buy/Sell Ratio:</b> {candidate['bsr']:.1f}x Dominance\n"
            f"🎯 <b>Targets:</b> TP1 +50% | TP2 +100% | <b>Hard SL:</b> -15%\n"
            f"🔗 <a href='https://solscan.io/tx/{tx_sig}'>Solscan Transaction</a> | <a href='{candidate['url']}'>DexScreener</a>"
        )
        logger.info(f"✅ LIVE POSITION CONFIRMED: {sym} | Tx: {tx_sig}")
        send_telegram(msg, priority=True)

    def update_and_manage(self, trade_ledger: 'TradeLedger'):
        """Queries live prices for open positions, evaluates SL, TP1, TP2, and stagnation."""
        if not self.positions:
            return

        mints = list(self.positions.keys())
        url = f"https://api.dexscreener.com/latest/dex/tokens/{','.join(mints)}"
        try:
            r = requests.get(url, timeout=10)
            if r.status_code != 200:
                logger.warning(f"Failed to query live prices for open positions: {r.status_code}")
                return
            pairs = r.json().get("pairs", [])
            price_map = {}
            for p in pairs:
                if p.get("chainId") == "solana":
                    m = p.get("baseToken", {}).get("address")
                    pr = float(p.get("priceUsd") or 0)
                    if m and pr > 0:
                        if m not in price_map or float(p.get("liquidity", {}).get("usd") or 0) > price_map[m][1]:
                            price_map[m] = (pr, float(p.get("liquidity", {}).get("usd") or 0))
        except Exception as e:
            logger.error(f"Error updating open position prices: {e}")
            return

        now_utc = datetime.now(timezone.utc)
        to_close = []

        for mint, pos in list(self.positions.items()):
            if mint not in price_map:
                continue

            current_price = price_map[mint][0]
            entry_price = pos["entry_price"]
            pos["current_price"] = current_price
            if current_price > pos.get("highest_price", entry_price):
                pos["highest_price"] = current_price

            pnl_pct = ((current_price - entry_price) / entry_price) * 100.0

            try:
                entry_dt = datetime.fromisoformat(pos["entry_time"])
                hold_hours = (now_utc - entry_dt).total_seconds() / 3600.0
            except Exception:
                hold_hours = 0.0

            # 1. CHECK TAKE PROFIT 1 (+50%)
            if not pos.get("tp1_hit", False) and pnl_pct >= STRATEGY_CONFIG["tp1_pct"]:
                pos["tp1_hit"] = True
                pos["stop_loss_pct"] = 1.0 # Move SL to Breakeven (+1%)

                if pos.get("is_live") and self.wallet_client:
                    # Sell 50% on Jupiter
                    tokens_to_sell = int(pos["remaining_units_raw"] * 0.50)
                    success, sol_rec, tx_sig = self.wallet_client.execute_jupiter_sell(mint, tokens_to_sell)
                    pos["remaining_units_raw"] -= tokens_to_sell
                    self._save_positions()

                    msg = (
                        f"🎯 <b>[LIVE] TAKE PROFIT 1 HIT (+50%)</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                        f"💎 <b>Token:</b> {pos['symbol']}\n"
                        f"📈 <b>Gain:</b> +{pnl_pct:.1f}%\n"
                        f"💰 <b>Harvested:</b> 50% Sold ➔ +{sol_rec:.5f} SOL Returned\n"
                        f"🛡️ <b>Stop Loss:</b> Moved to BREAKEVEN (+1.0%)\n"
                        f"🔗 <a href='https://solscan.io/tx/{tx_sig}'>Solscan Tx</a>"
                    )
                    send_telegram(msg, priority=True)
                else:
                    pos["current_notional_usd"] /= 2.0
                    pos["units"] /= 2.0
                    self._save_positions()
                    msg = (
                        f"🎯 <b>[PAPER] TAKE PROFIT 1 HIT (+50%)</b>\n"
                        f"Token: {pos['symbol']} | Gain: +{pnl_pct:.1f}% | SL moved to BE"
                    )
                    send_telegram(msg, priority=True)
                continue

            # 2. CHECK TAKE PROFIT 2 (+100% / 2x Runner)
            if pos.get("tp1_hit", False) and pnl_pct >= STRATEGY_CONFIG["tp2_pct"]:
                to_close.append((mint, "TP2 (+100% Full Runner)", pnl_pct, hold_hours))
                continue

            # 3. CHECK STOP LOSS
            sl_threshold = pos.get("stop_loss_pct", STRATEGY_CONFIG["stop_loss_pct"])
            if pnl_pct <= sl_threshold:
                reason = "Trailing Breakeven Stop" if pos.get("tp1_hit") else "Hard Stop Loss (-15%)"
                to_close.append((mint, reason, pnl_pct, hold_hours))
                continue

            # 4. CHECK STAGNATION TIME-STOP (> 24 hours and flat)
            if hold_hours >= STRATEGY_CONFIG["stagnation_hours"] and (-5.0 <= pnl_pct <= 8.0):
                to_close.append((mint, f"Stagnation Cut ({hold_hours:.1f}h Flat)", pnl_pct, hold_hours))
                continue

        # Process closed positions
        for mint, reason, pnl_pct, hold_hours in to_close:
            pos = self.positions.pop(mint)
            self._save_positions()

            sol_returned = 0.0
            tx_sig = ""
            if pos.get("is_live") and self.wallet_client:
                # Sell remaining tokens on Jupiter
                tokens_to_sell = pos.get("remaining_units_raw", 0)
                if tokens_to_sell > 0:
                    success, sol_returned, tx_sig = self.wallet_client.execute_jupiter_sell(mint, tokens_to_sell)
                sol_net = sol_returned - pos.get("sol_cost", 0.0)
                trade_ledger.record_live_trade(pos, reason, pnl_pct, sol_net, hold_hours, tx_sig)

                icon = "🏆" if sol_net > 0 else "🛑"
                msg = (
                    f"{icon} <b>[LIVE REAL MONEY] POSITION CLOSED</b>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 <b>Token:</b> {pos['symbol']}\n"
                    f"📋 <b>Reason:</b> {reason}\n"
                    f"⏱️ <b>Hold Time:</b> {hold_hours:.1f}h\n"
                    f"📊 <b>PnL:</b> {pnl_pct:+.1f}% ({sol_net:+.4f} SOL)\n"
                    f"💰 <b>Wallet Balance:</b> {self.wallet_client.get_sol_balance():.5f} SOL\n"
                    f"🔗 <a href='https://solscan.io/tx/{tx_sig}'>Solscan Tx</a>"
                )
                logger.info(f"CLOSED LIVE POSITION {pos['symbol']}: {reason} | Net: {sol_net:+.4f} SOL")
                send_telegram(msg, priority=True)
            else:
                pnl_usd = pos.get("current_notional_usd", 10.0) * (pnl_pct / 100.0)
                trade_ledger.record_trade(pos, reason, pnl_pct, pnl_usd, hold_hours)
                icon = "✅" if pnl_pct > 0 else "🛑"
                msg = (
                    f"{icon} <b>[PAPER] PHOENIX POSITION CLOSED</b>\n"
                    f"Token: {pos['symbol']} | Reason: {reason} | PnL: {pnl_pct:+.1f}% (${pnl_usd:+.2f})"
                )
                send_telegram(msg, priority=True)

class TradeLedger:
    """Maintains permanent historical ledger and performance metrics for the Phoenix Reversal strategy."""
    
    def __init__(self):
        self.trades: List[Dict[str, Any]] = self._load_ledger()

    def _load_ledger(self) -> List[Dict[str, Any]]:
        if os.path.exists(LEDGER_FILE):
            try:
                with open(LEDGER_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading trade ledger: {e}")
        return []

    def _save_ledger(self):
        try:
            with open(LEDGER_FILE, "w", encoding="utf-8") as f:
                json.dump(self.trades, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving trade ledger: {e}")

    def record_trade(self, pos: Dict[str, Any], reason: str, pnl_pct: float, pnl_usd: float, hold_hours: float):
        trade_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "PAPER",
            "symbol": pos["symbol"],
            "mint": pos["mint"],
            "entry_price": pos["entry_price"],
            "exit_price": pos["current_price"],
            "hold_hours": round(hold_hours, 1),
            "exit_reason": reason,
            "pnl_pct": round(pnl_pct, 2),
            "pnl_usd": round(pnl_usd, 3),
            "tp1_hit": pos.get("tp1_hit", False)
        }
        self.trades.append(trade_record)
        self._save_ledger()

    def record_live_trade(self, pos: Dict[str, Any], reason: str, pnl_pct: float, pnl_sol: float, hold_hours: float, tx_sig: str):
        trade_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "mode": "LIVE_SOL",
            "symbol": pos["symbol"],
            "mint": pos["mint"],
            "entry_price": pos["entry_price"],
            "exit_price": pos["current_price"],
            "hold_hours": round(hold_hours, 1),
            "exit_reason": reason,
            "pnl_pct": round(pnl_pct, 2),
            "pnl_sol": round(pnl_sol, 5),
            "pnl_usd": round(pnl_sol * 155.0, 2),
            "tx_sig": tx_sig,
            "tp1_hit": pos.get("tp1_hit", False)
        }
        self.trades.append(trade_record)
        self._save_ledger()

    def get_summary_line(self) -> str:
        if not self.trades:
            return "0 Trades Completed"
        total = len(self.trades)
        wins = [t for t in self.trades if t.get("pnl_pct", 0) > 0]
        losses = [t for t in self.trades if t.get("pnl_pct", 0) <= 0]
        wr = (len(wins) / total) * 100.0
        return f"{total} Trades | WR: {wr:.1f}% ({len(wins)}W / {len(losses)}L)"

def run_reversal_cycle(scanner: PhoenixScanner, pos_manager: PositionManager, ledger: TradeLedger):
    """Executes one scan and position management cycle."""
    logger.info("=" * 80)
    logger.info(f"🦅 INITIATING PHOENIX REVERSAL SCAN CYCLE [{'LIVE REAL SOL' if pos_manager.is_live else 'PAPER SIMULATION'}]")
    logger.info("=" * 80)

    # 1. Update and manage existing open positions
    open_count = pos_manager.get_open_count()
    logger.info(f"Managing {open_count}/{STRATEGY_CONFIG['max_concurrent_positions']} open positions...")
    pos_manager.update_and_manage(ledger)

    # 2. Check capacity
    available_slots = STRATEGY_CONFIG["max_concurrent_positions"] - pos_manager.get_open_count()
    if available_slots <= 0:
        logger.info("Maximum concurrent positions reached. Monitoring active positions...")
        return

    # 3. Scan for mature floor reversals
    candidates = scanner.scan_for_reversals()
    logger.info(f"Scan complete. Discovered {len(candidates)} qualifying floor reversal candidates.")

    entered_count = 0
    for cand in candidates:
        if entered_count >= available_slots:
            break
        mint = cand["mint"]
        if pos_manager.is_already_open(mint):
            continue

        audit = RugCheckAuditor.audit_token(mint)
        if not audit["safe"]:
            logger.warning(f"Skipping {cand['symbol']} due to security audit flags: {audit['risks']}")
            continue

        pos_manager.open_position(cand)
        entered_count += 1
        time.sleep(1.0)

    logger.info(f"Cycle finished. Active Open Positions: {pos_manager.get_open_count()} | {ledger.get_summary_line()}")

def main():
    parser = argparse.ArgumentParser(description="Solana Phoenix Reversal Engine")
    parser.add_argument("--live", action="store_true", help="Execute REAL LIVE orders on Solana via Jupiter")
    parser.add_argument("--once", action="store_true", help="Run a single scan cycle and exit")
    parser.add_argument("--daemon", action="store_true", help="Run continuously in background daemon mode")
    parser.add_argument("--interval", type=int, default=300, help="Scan interval in seconds (default: 300)")
    args = parser.parse_args()

    wallet_client = SolanaWalletClient() if args.live else None
    scanner = PhoenixScanner()
    pos_manager = PositionManager(is_live=args.live, wallet_client=wallet_client)
    ledger = TradeLedger()

    mode_label = "LIVE REAL SOL EXECUTION" if args.live else "PAPER SIMULATION (Zero Risk)"
    sol_bal = wallet_client.get_sol_balance() if wallet_client else 0.0

    print("=" * 90)
    print("🚀 SOLANA PHOENIX REVERSAL TRADING ENGINE INITIALIZED")
    print("=" * 90)
    print(f"Mode: {mode_label}")
    if args.live:
        print(f"Wallet: {wallet_client.pubkey} | Balance: {sol_bal:.5f} SOL")
        print(f"Live Slot Size: {STRATEGY_CONFIG['live_slot_sol']} SOL (~${STRATEGY_CONFIG['live_slot_sol'] * 155:.2f})")
    print(f"Scan Interval: {args.interval}s")
    print(f"Watch Criteria: Age 7-60d | Liq >= $40k | Vol >= $75k | 24h Gain +12% to +85% | BSR >= 1.70x")
    print(f"Risk Management: Hard SL -15% | TP1 +50% (Lock BE) | TP2 +100% | 24h Cut")
    print("=" * 90)

    send_telegram(
        f"🦅 <b>SOLANA PHOENIX REVERSAL ENGINE STARTED</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🛡️ <b>Mode:</b> {mode_label}\n"
        f"💰 <b>Wallet:</b> <code>{wallet_client.pubkey if wallet_client else 'SIMULATED'}</code>\n"
        f"💵 <b>Balance:</b> {sol_bal:.5f} SOL\n"
        f"🎯 <b>Focus:</b> Mature Meme Coins (> 7 Days Old) Awakening from Floor\n"
        f"⚙️ <b>Slot Size:</b> {STRATEGY_CONFIG['live_slot_sol'] if args.live else '$10'} | <b>SL:</b> -15% | <b>TP1:</b> +50% | <b>TP2:</b> +100%\n"
        f"⏱️ <b>Cycle:</b> Scanning every 5 minutes"
    )

    if args.once:
        run_reversal_cycle(scanner, pos_manager, ledger)
        return

    while True:
        try:
            run_reversal_cycle(scanner, pos_manager, ledger)
        except Exception as e:
            logger.error(f"Unexpected error in execution loop: {e}", exc_info=True)
        time.sleep(args.interval)

if __name__ == "__main__":
    main()
