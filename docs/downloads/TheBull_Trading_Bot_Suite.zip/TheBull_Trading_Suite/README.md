# 🐂 TheBull - Multi-Exchange Algorithmic Trading Suite
### Commercial-Grade Algorithmic Trading Engines for Binance, Delta Exchange, and Dhan HQ

Welcome to **TheBull Trading Bot Suite**! This turnkey algorithmic trading toolkit provides fully automated, quantitative trading engines engineered for spot, futures, and options markets.

---

## 📦 What's Inside This Suite:

### 1. `thebull-binance-bot` (Binance USDT-Margined Futures)
- **100-Point Multi-Factor Scoring Engine:**
  - Multi-timeframe trend confluence (1h, 4h, Daily EMAs)
  - Dual-speed zero-lag momentum acceleration & RSI slope analysis
  - Volume surge breakout validation
  - ADX trend strength & Bollinger Band squeeze regime detection
  - MACD histogram expansions & Supertrend confluence
- **Risk Management & Position Sizing:**
  - Dynamic ATR-based stop sizing (1% risk per trade)
  - Dynamic multi-stage trailing stops (auto break-even at +2.0%, trailing runner lock)
  - Portfolio heat capping against market-wide correlation spikes
- **1-Click Launchers:** `start_bot.bat` (Windows) & `start_bot.sh` (Linux/macOS)

### 2. `thebull-delta-bot` (Delta Exchange Crypto Derivatives)
- Automated futures and perpetual contracts trading engine
- Real-time WebSocket order book and ticker updates
- Trailing stop-loss and dynamic take-profit execution
- Integrated Telegram alert system for trade entries and exits

### 3. `thebull-dhan-bot` (NSE Equities & F&O via Dhan HQ)
- High-speed anomaly scanner across NSE 500 universe
- Intraday volume surge and price momentum breakout triggers
- Supertrend, VWAP, and EMA confluence filtering
- Direct order execution via Dhan HQ REST API
- Telegram notification dispatcher

### 4. `thebull-portal` (Local Trading Dashboard)
- Interactive web portal to visualize active positions, execution logs, and PnL.

---

## ⚡ Quick Start (Under 3 Minutes)

### Windows
1. Open the folder of the bot you wish to run (e.g. `thebull-binance-bot`).
2. Copy `.env.example` to `.env` and enter your API keys.
3. Double-click `start_bot.bat`.
   - The launcher creates a virtual environment, installs dependencies, and runs the bot in safe simulation or live mode!

### Linux / macOS
```bash
cd thebull-binance-bot
cp .env.example .env
# Edit .env with your favorite editor
chmod +x start_bot.sh
./start_bot.sh
```

---

## 🛡️ Risk Disclaimer & License
*Algorithmic trading involves substantial risk of financial loss. Always backtest strategies and run in testnet/paper-trading mode before allocating live capital. This software is licensed for private and commercial use by the purchaser.*
