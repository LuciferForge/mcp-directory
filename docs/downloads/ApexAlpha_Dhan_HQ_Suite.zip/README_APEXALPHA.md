# ApexAlpha Dhan HQ Institutional F&O Suite (NSE Nifty & BSE Sensex)
=============================================================================
Automated Quantitative Derivatives Trading Engine for Indian Markets
Execution: Dhan HQ API v2 & Webhook Bridge
Overnight Risk: ₹0 (100% Intraday MIS Square-Off at 15:15 IST)
Capital Multiplier: 3.6x Asymmetric Payoff
=============================================================================

## Included Production Strategies (11 Total):
- IA-1: Nifty Opening Range Breakout (Option Buy CE/PE)
- IA-2: Nifty VWAP Mean Reversion Scalp
- IA-3: BankNifty 15m Momentum Continuation
- IA-4: Sensex Tuesday Trend Acceleration (58.82% Win Rate, 2.45 R:R)
- IA-5: Nifty Weekly Credit Spread (Iron Condor Hedged)
- IA-6: Nifty Expiry Zero-Hero Gamma Pin
- IA-7: Nifty Wednesday 1-DTE Gamma Scalper (61.02% Win Rate, 2.16 R:R, ₹110 Target Premium)
- IA-8: BankNifty Expiry Short Straddle Hedged
- IA-9: Sensex Gamma Thrust Buy
- IA-10: Nifty Friday 2-DTE Bear Pivot (64.29% Win Rate, 2.05 R:R, ₹100 Target Put)
- IA-11: Multi-Index Delta Neutral Synthetic Hedge

## The Cherry-Picked Top 3 Pilot System:
1. IA-7 (Wednesday Nifty Bullish CE @ ₹110)
2. IA-10 (Friday Nifty Bearish PE @ ₹100)
3. IA-4 (Tuesday Sensex Momentum CE/PE)

## Quick Start:
1. Open `.env` and fill in your DHAN_CLIENT_ID and DHAN_ACCESS_TOKEN.
2. Double-click `run_apex_pilot.bat` to launch the automated live trader or paper engine.
