# The 31,500+ MCP Server Global Ecosystem Dataset
**Compiled and maintained by Protodex (https://protodex.io)**

## Overview
This archive contains the definitive, gap-checked global dataset of 31,595+ Model Context Protocol (MCP) servers indexed across GitHub and open-source repositories.

Each record includes repository coordinates, category taxonomy (14 standardized categories), star counts, primary implementation language, description, and security audit assessment.

## Included Files
- `mcp_servers_31k.csv`: Standard UTF-8 CSV with header row. Opens in pandas, Excel, Google Sheets, Polars, and R.
- `mcp_servers.sqlite`: Fully indexed SQLite 3 database. Pre-indexed on `category`, `stars DESC`, and `language` for sub-millisecond queries.
- `mcp_servers_full.json`: Standard JSON array containing all indexed server objects.
- `README.md`: This reference manual & schema documentation.

## Database Schema (SQLite & CSV)
| Column | Type | Description |
| :--- | :--- | :--- |
| `name` | TEXT | Friendly name of the MCP server |
| `repo` | TEXT | GitHub repository path (`owner/repo`) |
| `stars` | INTEGER | Current GitHub star count |
| `category` | TEXT | Primary functional domain (AI/LLM, Database, DevOps, etc.) |
| `language` | TEXT | Primary programming language (TypeScript, Python, Go, Rust, etc.) |
| `description` | TEXT | Full description of tools and capabilities |
| `slug` | TEXT | Protodex URL slug identifier |
| `security_score`| TEXT | Security screening badge (`Clean`, `Warning`, `Critical`) |

## Quickstart Examples

### 1. Python (Pandas)
```python
import pandas as pd

df = pd.read_csv("mcp_servers_31k.csv")
print(f"Total Servers: {len(df):,}")

# Top 10 Python AI/LLM servers
top_ai = df[(df["category"] == "AI/LLM") & (df["language"] == "Python")].sort_values("stars", ascending=False).head(10)
print(top_ai[["name", "stars", "repo"]])
```

### 2. SQL (SQLite / DuckDB)
```sql
-- Query category market share
SELECT category, count(*) AS count, sum(stars) AS total_stars
FROM servers
GROUP BY category
ORDER BY count DESC;
```

## Commercial Research & Development License
This purchase grants full commercial research, analysis, and product integration rights for your organization. Redistribution of the raw dataset files as a standalone competing directory is prohibited.
