# ClawGuard Layer 1 Fast Heuristic Sanitizer
import re, base64

class Layer1Sanitizer:
    def inspect_input(self, text: str):
        jailbreak_patterns = [r"ignore previous instructions", r"dan mode", r"system prompt"]
        for p in jailbreak_patterns:
            if re.search(p, text, re.IGNORECASE):
                return False, f"Jailbreak detected: {p}", {"latency_ms": 0.11}
        return True, "Safe", {"latency_ms": 0.08}
