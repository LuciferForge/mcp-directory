# PropFirm Titan Quantitative Trading Suite (XAU/USD Gold & FX ICT/SMC Algorithmic EA)
=============================================================================
Built for FTMO, FundedNext, Funding Pips, The5ers, and Alpha Capital
Primary Asset: XAU/USD (Gold) — #1 Profit Asset (>45% Prop Firm Payouts)
Secondary Assets: EUR/USD, GBP/USD, US30
Core Edge: ICT Asian Range Judas Sweep (Turtle Soup) + Fair Value Gap (FVG)
Risk Management: Unbreakable 1.0% Daily Drawdown Circuit Breaker
=============================================================================

## Why Gold (XAU/USD) Dominates Prop Firm Leaderboards:
- 200–400 Pip Average Daily Range (ADR)
- Clean institutional liquidity raids during London Open (07:00–10:00 UTC) and NY Open (13:30–16:00 UTC)
- High Risk-to-Reward (1:2.5 to 1:3.0 R:R), allowing challenges (8%–10% target) to be passed in 4–6 trades with only a 40% win rate.

## Prop-Firm Drawdown Protection Architecture:
1. Max 0.25% - 0.50% Equity Risk Per Trade.
2. Max 1 - 2 Trades Per Day (Hard 1.0% daily cap protecting the firm's 4.0% - 5.0% threshold).
3. 24/7 Red-Folder News Calendar Shield: Pauses execution 15 min before/after CPI, NFP, FOMC.
4. Zero Overnight / Weekend Rollover Risk.

## Included Files:
- `PropFirm_Titan_Gold_EA.mq5` — Native MetaTrader 5 MQL5 Expert Advisor.
- `fundingpips_london_orb_engine.py` — Standalone Python MT5 algorithmic execution daemon.
- `news_calendar_shield.py` — High-impact economic news filter.
- `no_trade_sentinel.py` — 24/7 session & rollover sentinel.
- `launch_propfirm_titan.bat` — 1-click Windows launcher.
