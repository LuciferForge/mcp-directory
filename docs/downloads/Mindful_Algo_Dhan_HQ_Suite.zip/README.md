# Mindful Algo & Dhan HQ Indian Markets F&O Suite

Complete institutional-grade algorithmic trading architecture for **NSE Nifty 50** & **BSE Sensex** weekly options, reverse-engineered from the Mindfluential v39 production engine with **₹0 Overnight Margin Risk**.

## Key Architecture Highlights:
- **100% Intraday Flat**: All positions square off by 15:15 IST every day. Zero gap risk, zero margin held overnight.
- **The 3.6x Capital Multiplier**: Reuses capital across the week (Monday: Sensex, Tuesday: Nifty 0DTE, Wednesday: Nifty, Thursday: Sensex Expiry, Friday: Peak de-risking).
- **The Dual-Pillar Edge**:
  1. *Convexity Option Buying*: 2.2x to 7.6x Reward-to-Risk ratio with strict stop-losses.
  2. *Cash-Flow Hedged Spreads*: 54%–62% win rate defined-risk credit spreads for baseline income.

## The Cherry-Picked Top 3 Pilot Lineup:
1. **`IA-7` Nifty Range Edge (Mid-Week Bullish Buyer)**:
   - Wednesday 09:30 AM Entry | 61.02% Win Rate | 2.16x R:R | Max DD: -₹9,099
2. **`IA-10` Nifty Bear Pivot (Friday Institutional Put Buyer)**:
   - Friday 10:15 AM Entry | 37.37% Win Rate | 3.49x R:R | Max DD: just -₹3,417
3. **`IA-4` Nifty Premium Harvester (0DTE Defined-Risk Spread)**:
   - Expiry Day 09:20 AM Entry | 61.87% Win Rate | Margin benefit via Dhan basket order

## Quickstart:
1. Insert your Dhan Client ID and Access Token into `config.json`.
2. Run `run_dhan_pilot.bat` to launch the Top 3 Cherry-Picked Pilot bots.
3. Webhook listener supports direct triggers from AlgoTest (`algotest.in`) or TradingView.
