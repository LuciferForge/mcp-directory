"""
Factur-X / ZUGFeRD 2.2 XML Generator (EN 16931 Profile).
Generates standards-compliant CrossIndustryInvoice (CII) XML.
"""

import xml.etree.ElementTree as ET
from xml.dom import minidom
from src.models import InvoiceData


# Official UN/CEFACT CII namespaces for Factur-X / ZUGFeRD 2.2
NAMESPACES = {
    "rsm": "urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100",
    "ccts": "urn:un:unece:uncefact:documentation:standard:CoreComponentsTechnicalSpecification:2",
    "udt": "urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100",
    "qdt": "urn:un:unece:uncefact:data:standard:QualifiedDataType:100",
    "ram": "urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100",
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
}

for prefix, uri in NAMESPACES.items():
    ET.register_namespace(prefix, uri)


def _format_date_102(iso_date: str) -> str:
    """Converts YYYY-MM-DD to CCYYMMDD (Format 102)."""
    return iso_date.replace("-", "")


def _format_amount(val: float) -> str:
    """Formats monetary amounts to 2 decimal places."""
    return f"{val:.2f}"


def _format_quantity(val: float) -> str:
    """Formats quantity to up to 4 decimal places without trailing zeroes."""
    return f"{val:.4f}".rstrip("0").rstrip(".") if "." in f"{val:.4f}" else str(int(val))


def generate_zugferd_xml(invoice: InvoiceData) -> str:
    """
    Constructs a Factur-X / ZUGFeRD 2.2 EN 16931 compliant XML string from InvoiceData.
    """
    root = ET.Element(f"{{{NAMESPACES['rsm']}}}CrossIndustryInvoice")

    # 1. ExchangedDocumentContext
    context = ET.SubElement(root, f"{{{NAMESPACES['rsm']}}}ExchangedDocumentContext")
    doc_context = ET.SubElement(
        context,
        f"{{{NAMESPACES['ram']}}}SpecifiedTransactionSpecificationDocumentContextParameter",
    )
    guid = ET.SubElement(doc_context, f"{{{NAMESPACES['ram']}}}ID")
    # Standard Factur-X EN 16931 Comfort Profile identifier
    guid.text = invoice.profile

    # 2. ExchangedDocument
    exchanged_doc = ET.SubElement(root, f"{{{NAMESPACES['rsm']}}}ExchangedDocument")
    doc_id = ET.SubElement(exchanged_doc, f"{{{NAMESPACES['ram']}}}ID")
    doc_id.text = invoice.invoice_number

    type_code = ET.SubElement(exchanged_doc, f"{{{NAMESPACES['ram']}}}TypeCode")
    type_code.text = "380"  # 380 = Commercial Invoice

    issue_date_elem = ET.SubElement(exchanged_doc, f"{{{NAMESPACES['ram']}}}IssueDateTime")
    dt_str = ET.SubElement(
        issue_date_elem,
        f"{{{NAMESPACES['udt']}}}DateTimeString",
        {"format": "102"},
    )
    dt_str.text = _format_date_102(invoice.issue_date)

    # Included Notes (e.g. Reverse charge note, terms)
    for note_text in invoice.notes:
        note_elem = ET.SubElement(exchanged_doc, f"{{{NAMESPACES['ram']}}}IncludedNote")
        content = ET.SubElement(note_elem, f"{{{NAMESPACES['ram']}}}Content")
        content.text = note_text

    # 3. SupplyChainTradeTransaction
    transaction = ET.SubElement(root, f"{{{NAMESPACES['rsm']}}}SupplyChainTradeTransaction")

    # 3.1 Line Items
    for item in invoice.line_items:
        line_item = ET.SubElement(
            transaction, f"{{{NAMESPACES['ram']}}}IncludedSupplyChainTradeLineItem"
        )

        # Line Document ID
        line_doc = ET.SubElement(
            line_item, f"{{{NAMESPACES['ram']}}}AssociatedDocumentLineDocument"
        )
        line_doc_id = ET.SubElement(line_doc, f"{{{NAMESPACES['ram']}}}LineID")
        line_doc_id.text = item.line_id

        # Product
        prod = ET.SubElement(line_item, f"{{{NAMESPACES['ram']}}}SpecifiedTradeProduct")
        prod_name = ET.SubElement(prod, f"{{{NAMESPACES['ram']}}}Name")
        prod_name.text = item.name
        if item.description and item.description != item.name:
            prod_desc = ET.SubElement(prod, f"{{{NAMESPACES['ram']}}}Description")
            prod_desc.text = item.description

        # Line Agreement (Price)
        agreement = ET.SubElement(
            line_item, f"{{{NAMESPACES['ram']}}}SpecifiedLineTradeAgreement"
        )
        net_price = ET.SubElement(
            agreement, f"{{{NAMESPACES['ram']}}}NetPriceProductTradePrice"
        )
        charge_amt = ET.SubElement(net_price, f"{{{NAMESPACES['ram']}}}ChargeAmount")
        charge_amt.text = _format_amount(item.unit_price_net)

        # Line Delivery (Quantity)
        delivery = ET.SubElement(
            line_item, f"{{{NAMESPACES['ram']}}}SpecifiedLineTradeDelivery"
        )
        billed_qty = ET.SubElement(
            delivery,
            f"{{{NAMESPACES['ram']}}}BilledQuantity",
            {"unitCode": item.unit_code},
        )
        billed_qty.text = _format_quantity(item.quantity)

        # Line Settlement (Taxes & Monetary Summation)
        settlement = ET.SubElement(
            line_item, f"{{{NAMESPACES['ram']}}}SpecifiedLineTradeSettlement"
        )
        trade_tax = ET.SubElement(settlement, f"{{{NAMESPACES['ram']}}}ApplicableTradeTax")
        tax_type = ET.SubElement(trade_tax, f"{{{NAMESPACES['ram']}}}TypeCode")
        tax_type.text = "VAT"
        cat_code = ET.SubElement(trade_tax, f"{{{NAMESPACES['ram']}}}CategoryCode")
        cat_code.text = item.tax_category_code
        rate_elem = ET.SubElement(
            trade_tax, f"{{{NAMESPACES['ram']}}}RateApplicablePercent"
        )
        rate_elem.text = _format_amount(item.tax_rate_percent)

        line_summation = ET.SubElement(
            settlement,
            f"{{{NAMESPACES['ram']}}}SpecifiedTradeSettlementLineMonetarySummation",
        )
        line_total = ET.SubElement(
            line_summation, f"{{{NAMESPACES['ram']}}}LineTotalAmount"
        )
        line_total.text = _format_amount(item.net_total_amount)

    # 3.2 Header Trade Agreement (Seller & Buyer)
    header_agreement = ET.SubElement(
        transaction, f"{{{NAMESPACES['ram']}}}ApplicableHeaderTradeAgreement"
    )

    # Seller
    seller_elem = ET.SubElement(
        header_agreement, f"{{{NAMESPACES['ram']}}}SellerTradeParty"
    )
    seller_name = ET.SubElement(seller_elem, f"{{{NAMESPACES['ram']}}}Name")
    seller_name.text = invoice.seller.name

    if invoice.seller.tax_registration_id:
        legal_org = ET.SubElement(
            seller_elem, f"{{{NAMESPACES['ram']}}}SpecifiedLegalOrganization"
        )
        org_id = ET.SubElement(
            legal_org,
            f"{{{NAMESPACES['ram']}}}ID",
            {"schemeID": invoice.seller.electronic_address_scheme or "9957"},
        )
        org_id.text = invoice.seller.tax_registration_id

    seller_addr = ET.SubElement(
        seller_elem, f"{{{NAMESPACES['ram']}}}PostalTradeAddress"
    )
    s_postcode = ET.SubElement(seller_addr, f"{{{NAMESPACES['ram']}}}PostcodeCode")
    s_postcode.text = invoice.seller.address.postal_code
    s_line1 = ET.SubElement(seller_addr, f"{{{NAMESPACES['ram']}}}LineOne")
    s_line1.text = invoice.seller.address.line1
    s_city = ET.SubElement(seller_addr, f"{{{NAMESPACES['ram']}}}CityName")
    s_city.text = invoice.seller.address.city
    s_country = ET.SubElement(seller_addr, f"{{{NAMESPACES['ram']}}}CountryID")
    s_country.text = invoice.seller.address.country_code

    if invoice.seller.vat_id:
        seller_vat = ET.SubElement(
            seller_elem, f"{{{NAMESPACES['ram']}}}SpecifiedTaxRegistration"
        )
        vat_id_elem = ET.SubElement(
            seller_vat, f"{{{NAMESPACES['ram']}}}ID", {"schemeID": "VA"}
        )
        vat_id_elem.text = invoice.seller.vat_id

    # Buyer
    buyer_elem = ET.SubElement(
        header_agreement, f"{{{NAMESPACES['ram']}}}BuyerTradeParty"
    )
    buyer_name = ET.SubElement(buyer_elem, f"{{{NAMESPACES['ram']}}}Name")
    buyer_name.text = invoice.buyer.name

    buyer_addr = ET.SubElement(
        buyer_elem, f"{{{NAMESPACES['ram']}}}PostalTradeAddress"
    )
    b_postcode = ET.SubElement(buyer_addr, f"{{{NAMESPACES['ram']}}}PostcodeCode")
    b_postcode.text = invoice.buyer.address.postal_code
    b_line1 = ET.SubElement(buyer_addr, f"{{{NAMESPACES['ram']}}}LineOne")
    b_line1.text = invoice.buyer.address.line1
    b_city = ET.SubElement(buyer_addr, f"{{{NAMESPACES['ram']}}}CityName")
    b_city.text = invoice.buyer.address.city
    b_country = ET.SubElement(buyer_addr, f"{{{NAMESPACES['ram']}}}CountryID")
    b_country.text = invoice.buyer.address.country_code

    if invoice.buyer.vat_id:
        buyer_vat = ET.SubElement(
            buyer_elem, f"{{{NAMESPACES['ram']}}}SpecifiedTaxRegistration"
        )
        b_vat_id = ET.SubElement(
            buyer_vat, f"{{{NAMESPACES['ram']}}}ID", {"schemeID": "VA"}
        )
        b_vat_id.text = invoice.buyer.vat_id

    # 3.3 Header Trade Delivery
    ET.SubElement(transaction, f"{{{NAMESPACES['ram']}}}ApplicableHeaderTradeDelivery")

    # 3.4 Header Trade Settlement
    settlement_hdr = ET.SubElement(
        transaction, f"{{{NAMESPACES['ram']}}}ApplicableHeaderTradeSettlement"
    )

    currency_elem = ET.SubElement(
        settlement_hdr, f"{{{NAMESPACES['ram']}}}InvoiceCurrencyCode"
    )
    currency_elem.text = invoice.currency

    # Payment Means
    if invoice.payment_details:
        pay_means = ET.SubElement(
            settlement_hdr,
            f"{{{NAMESPACES['ram']}}}SpecifiedTradeSettlementPaymentMeans",
        )
        means_code = ET.SubElement(pay_means, f"{{{NAMESPACES['ram']}}}TypeCode")
        means_code.text = invoice.payment_details.payment_means_code

        if invoice.payment_details.iban:
            payee_acc = ET.SubElement(
                pay_means,
                f"{{{NAMESPACES['ram']}}}PayeePartyCreditorFinancialAccount",
            )
            iban_elem = ET.SubElement(payee_acc, f"{{{NAMESPACES['ram']}}}IBANID")
            iban_elem.text = invoice.payment_details.iban

        if invoice.payment_details.bic:
            payee_inst = ET.SubElement(
                pay_means,
                f"{{{NAMESPACES['ram']}}}PayeeSpecifiedCreditorFinancialInstitution",
            )
            bic_elem = ET.SubElement(payee_inst, f"{{{NAMESPACES['ram']}}}BICID")
            bic_elem.text = invoice.payment_details.bic

    # Applicable Trade Tax (VAT breakdown)
    for tax_item in invoice.tax_breakdown:
        tax_hdr = ET.SubElement(
            settlement_hdr, f"{{{NAMESPACES['ram']}}}ApplicableTradeTax"
        )
        calc_amt = ET.SubElement(tax_hdr, f"{{{NAMESPACES['ram']}}}CalculatedAmount")
        calc_amt.text = _format_amount(tax_item.tax_amount)

        type_code = ET.SubElement(tax_hdr, f"{{{NAMESPACES['ram']}}}TypeCode")
        type_code.text = "VAT"

        if tax_item.exemption_reason:
            exemption = ET.SubElement(
                tax_hdr, f"{{{NAMESPACES['ram']}}}ExemptionReason"
            )
            exemption.text = tax_item.exemption_reason

        basis_amt = ET.SubElement(tax_hdr, f"{{{NAMESPACES['ram']}}}BasisAmount")
        basis_amt.text = _format_amount(tax_item.taxable_amount)

        category = ET.SubElement(tax_hdr, f"{{{NAMESPACES['ram']}}}CategoryCode")
        category.text = tax_item.tax_category_code

        rate = ET.SubElement(tax_hdr, f"{{{NAMESPACES['ram']}}}RateApplicablePercent")
        rate.text = _format_amount(tax_item.tax_rate_percent)

    # Payment Terms (Due Date)
    if invoice.due_date:
        pay_terms = ET.SubElement(
            settlement_hdr, f"{{{NAMESPACES['ram']}}}SpecifiedTradePaymentTerms"
        )
        due_dt = ET.SubElement(pay_terms, f"{{{NAMESPACES['ram']}}}DueDateDateTime")
        due_dt_str = ET.SubElement(
            due_dt, f"{{{NAMESPACES['udt']}}}DateTimeString", {"format": "102"}
        )
        due_dt_str.text = _format_date_102(invoice.due_date)

    # Header Monetary Summation
    summation = ET.SubElement(
        settlement_hdr,
        f"{{{NAMESPACES['ram']}}}SpecifiedTradeSettlementHeaderMonetarySummation",
    )

    line_total_sum = ET.SubElement(summation, f"{{{NAMESPACES['ram']}}}LineTotalAmount")
    line_total_sum.text = _format_amount(invoice.total_net_amount)

    tax_basis_sum = ET.SubElement(
        summation, f"{{{NAMESPACES['ram']}}}TaxBasisTotalAmount"
    )
    tax_basis_sum.text = _format_amount(invoice.total_net_amount)

    tax_total = ET.SubElement(
        summation,
        f"{{{NAMESPACES['ram']}}}TaxTotalAmount",
        {"currencyID": invoice.currency},
    )
    tax_total.text = _format_amount(invoice.total_tax_amount)

    grand_total = ET.SubElement(summation, f"{{{NAMESPACES['ram']}}}GrandTotalAmount")
    grand_total.text = _format_amount(invoice.total_gross_amount)

    due_payable = ET.SubElement(summation, f"{{{NAMESPACES['ram']}}}DuePayableAmount")
    due_payable.text = _format_amount(invoice.due_payable_amount)

    # Convert to XML string with pretty indentation
    raw_xml = ET.tostring(root, encoding="utf-8")
    dom = minidom.parseString(raw_xml)
    return dom.toprettyxml(indent="  ", encoding="utf-8").decode("utf-8")
