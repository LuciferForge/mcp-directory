import requests
import json
from datetime import datetime, timezone

# Let's inspect the last 10 markets and fetch their trades from Polymarket CLOB API
gamma_url = "https://gamma-api.polymarket.com/events?series_id=10684&closed=true&limit=10&order=endDate&ascending=false"
r = requests.get(gamma_url, timeout=10)
events = r.json()

print(f"Analyzing trades for {len(events)} events...")

for ev in events:
    title = ev.get("title")
    slug = ev.get("slug")
    markets = ev.get("markets", [])
    if not markets:
        continue
    m = markets[0]
    
    op_raw = m.get("outcomePrices")
    op = json.loads(op_raw) if isinstance(op_raw, str) else (op_raw or [0, 0])
    winner = "UP" if float(op[0]) == 1.0 else "DOWN"
    
    clob_tokens = json.loads(m.get("clobTokenIds", "[]")) if isinstance(m.get("clobTokenIds"), str) else m.get("clobTokenIds", [])
    if len(clob_tokens) < 2:
        continue
    
    up_token = clob_tokens[0]
    down_token = clob_tokens[1]
    
    meta = ev.get("eventMetadata") or {}
    p_beat = meta.get("priceToBeat")
    p_final = meta.get("finalPrice")
    diff = (p_final - p_beat) if (p_beat and p_final) else 0.0
    
    print(f"\n=======================================================")
    print(f"EVENT: {title} ({slug})")
    print(f"RESULT: {winner} | Beat: {p_beat} -> Final: {p_final} (Diff: ${diff:+.2f})")
    
    # Query CLOB trades for UP token
    # https://clob.polymarket.com/trades?asset_id=...
    clob_url = f"https://clob.polymarket.com/trades?asset_id={up_token}&limit=100"
    rt = requests.get(clob_url, timeout=5)
    trades = rt.json() if rt.status_code == 200 else []
    
    print(f"Total CLOB trades for UP token: {len(trades)}")
    if trades:
        # Sort by timestamp
        trades.sort(key=lambda x: int(x.get("timestamp", 0)))
        
        # Sample trades across time
        prices = [float(t.get("price", 0)) for t in trades]
        sizes = [float(t.get("size", 0)) for t in trades]
        times = [int(t.get("timestamp", 0)) for t in trades]
        
        t0 = times[0]
        t_end = times[-1]
        span_s = t_end - t0
        
        print(f"Time span of trades: {span_s}s ({len(trades)} trades, total size: {sum(sizes):.0f})")
        print(f"UP token price range: Min={min(prices):.3f}, Max={max(prices):.3f}, Mean={sum(prices)/len(prices):.3f}")
        
        # Show first 3 trades, middle 3 trades, and last 3 trades
        print("First 3 trades:")
        for t in trades[:3]:
            dt_str = datetime.fromtimestamp(int(t.get("timestamp", 0)), tz=timezone.utc).strftime("%H:%M:%S")
            print(f"  [{dt_str}] Price: {float(t.get('price')):.3f} | Size: {float(t.get('size')):.1f} | Side: {t.get('side')}")
            
        if len(trades) > 6:
            mid = len(trades) // 2
            print("Middle 3 trades:")
            for t in trades[mid-1:mid+2]:
                dt_str = datetime.fromtimestamp(int(t.get("timestamp", 0)), tz=timezone.utc).strftime("%H:%M:%S")
                print(f"  [{dt_str}] Price: {float(t.get('price')):.3f} | Size: {float(t.get('size')):.1f} | Side: {t.get('side')}")
                
        print("Last 3 trades:")
        for t in trades[-3:]:
            dt_str = datetime.fromtimestamp(int(t.get("timestamp", 0)), tz=timezone.utc).strftime("%H:%M:%S")
            print(f"  [{dt_str}] Price: {float(t.get('price')):.3f} | Size: {float(t.get('size')):.1f} | Side: {t.get('side')}")
