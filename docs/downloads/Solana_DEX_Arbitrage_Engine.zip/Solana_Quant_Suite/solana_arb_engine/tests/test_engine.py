"""Integration tests for the Arbitrage Engine Orchestrator."""

import unittest
from src.engine import ArbitrageEngine
from src.arb_math import PoolState
from src.config import EngineConfig


class TestEngineIntegration(unittest.TestCase):
    def setUp(self):
        config = EngineConfig(min_profit_sol=0.005, max_trade_sol=5.0)
        self.engine = ArbitrageEngine(config=config)

    def test_pipeline_executes_profitable_clean_arbitrage(self):
        """End-to-end test: Clean token with 20% price dislocation is executed and increases balance."""
        token_mint = "CleanAlpha11111111111111111111111111111111"
        clean_metadata = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 1_000_000_000_000,
        }

        pool_raydium = PoolState(
            pool_id="pool_ray_alpha",
            dex_name="Raydium AMM v4",
            token_mint_a="SOL",
            token_mint_b=token_mint,
            reserve_a=30_000_000_000,     # 30 SOL
            reserve_b=100_000_000_000_000, # 100M tokens
            fee_bps=25,
        )

        pool_meteora = PoolState(
            pool_id="pool_met_alpha",
            dex_name="Meteora DLMM",
            token_mint_a="SOL",
            token_mint_b=token_mint,
            reserve_a=38_000_000_000,     # 38 SOL (~26.6% higher price)
            reserve_b=100_000_000_000_000,
            fee_bps=20,
        )

        initial_bal = self.engine.stats.current_sol_balance
        report = self.engine.process_opportunity(
            pool1=pool_raydium,
            pool2=pool_meteora,
            token_metadata=clean_metadata,
        )

        self.assertEqual(report.decision, "EXECUTED_PROFITABLE")
        self.assertTrue(report.safety_report.is_safe)
        self.assertIsNotNone(report.arb_opportunity)
        self.assertIsNotNone(report.jito_bundle)
        self.assertIsNotNone(report.simulation_result)
        self.assertTrue(report.simulation_result.success)

        # Balance check
        self.assertGreater(self.engine.stats.current_sol_balance, initial_bal)
        self.assertEqual(self.engine.stats.successful_paper_trades, 1)
        self.assertEqual(self.engine.stats.safety_violations_blocked, 0)

    def test_pipeline_blocks_honeypot_before_math(self):
        """Honeypot token with active freeze authority must be blocked immediately."""
        token_mint = "TrapFreezeToken1111111111111111111111111111"
        honeypot_metadata = {
            "mintAuthority": None,
            "freezeAuthority": "ScammerWallet111111111111111111111111111111",
            "decimals": 6,
            "supply": 1_000_000_000_000,
        }

        # Even with tempting 50% price dislocation, honeypot must NOT be touched
        pool1 = PoolState("p1", "Raydium", "SOL", token_mint, 20_000_000_000, 100_000_000_000)
        pool2 = PoolState("p2", "Meteora", "SOL", token_mint, 40_000_000_000, 100_000_000_000)

        initial_bal = self.engine.stats.current_sol_balance
        report = self.engine.process_opportunity(
            pool1=pool1,
            pool2=pool2,
            token_metadata=honeypot_metadata,
        )

        self.assertEqual(report.decision, "BLOCKED_HONEYPOT")
        self.assertFalse(report.safety_report.is_safe)
        self.assertIsNone(report.jito_bundle)
        self.assertEqual(self.engine.stats.safety_violations_blocked, 1)
        self.assertEqual(self.engine.stats.current_sol_balance, initial_bal)

    def test_pipeline_skips_unprofitable_opportunities(self):
        """Tightly coupled pools with negligible spread are skipped to preserve funds."""
        token_mint = "StableSpread11111111111111111111111111111111"
        clean_metadata = {
            "mintAuthority": None,
            "freezeAuthority": None,
            "decimals": 6,
            "supply": 1_000_000_000_000,
        }

        # Negligible 0.1% spread (less than DEX fees)
        pool1 = PoolState("p1", "Raydium", "SOL", token_mint, 50_000_000_000, 100_000_000_000, fee_bps=25)
        pool2 = PoolState("p2", "Meteora", "SOL", token_mint, 50_050_000_000, 100_000_000_000, fee_bps=20)

        initial_bal = self.engine.stats.current_sol_balance
        report = self.engine.process_opportunity(
            pool1=pool1,
            pool2=pool2,
            token_metadata=clean_metadata,
        )

        self.assertEqual(report.decision, "SKIPPED_UNPROFITABLE")
        self.assertTrue(report.safety_report.is_safe)
        self.assertIsNone(report.jito_bundle)
        self.assertEqual(self.engine.stats.unprofitable_skipped, 1)
        self.assertEqual(self.engine.stats.current_sol_balance, initial_bal)


if __name__ == "__main__":
    unittest.main()
