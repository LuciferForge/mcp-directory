"""Solana Long-Tail & Migration Arbitrage Engine Package."""

__version__ = "1.0.0"
__author__ = "Lead Blockchain Systems Engineer"
