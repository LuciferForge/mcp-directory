# Polymarket Prediction Trading Strategies Bundle (Multi-Risk Tiers)

A complete quantitative algorithmic suite for trading prediction markets on **Polymarket** (Polygon network) and cross-platform venues (Kalshi, PredictIt).

## 3 Tailored Risk Tiers (Deploy According to Your Risk Appetite):

### Tier 1: Low-Risk / Delta-Neutral Arbitrage
- **Binary Outcome Mispricing**: Continuously monitors orderbooks where `Yes + No < $0.985`. Purchases both sides simultaneously to guarantee positive mathematical return upon market settlement regardless of outcome.
- **Cross-Platform Spread Arbitrage**: Compares Polymarket odds against Kalshi and PredictIt, executing when implied probability spreads exceed transaction and withdrawal fees.

### Tier 2: Medium-Risk / Yield & Market Making
- **Orderbook Liquidity Provider & Spread Capture**: Automated two-sided maker quoting engine that places bids and asks around fair statistical probability. Captures the bid-ask spread and qualifies for Polymarket liquidity rewards.
- **Range Reversion Market Maker**: Quoting engine designed for macro, inflation, and political odds that trade within stable statistical ranges.

### Tier 3: High-Alpha / Event & Convexity
- **Breaking News & Fast-Oracle Latency Sniper**: Sub-second API and polling feed integration that executes trades on candidates or macro indicators before broad market odds update.
- **Whale Wallet & Smart Money Copier**: Monitors the top 50 all-time profitable Polymarket addresses on-chain, automatically mirroring high-conviction positions with configurable sizing multipliers.

## Quickstart:
1. Configure your Polygon wallet address and RPC endpoint in `config.json`.
2. Run `python polymarket_bundle_runner.py --tier low_risk` for delta-neutral arbitrage.
3. Run `python polymarket_bundle_runner.py --tier medium_risk` for automated market making.
4. Run `python polymarket_bundle_runner.py --tier high_alpha` for breaking event & whale copying.
