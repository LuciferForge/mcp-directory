# Polymarket Prediction Trading Strategies Bundle (Multi-Risk Tiers)
=============================================================================
Automated quantitative algorithms across Polymarket (Polygon CLOB) and cross-platform
prediction markets. Choose your strategy or run all three based on your risk tolerance.
=============================================================================

## Included Production Engines:
1. `polymarket_5m_btc_engine.py` (20KB):
   - 5-minute Bitcoin early micro-momentum sniper on Series 10684 ($15M vol).
   - Exploits Minute 1 & 2 momentum persistence against Chainlink TWAP oracle.
   - Empirical proof from 1,000 resolved markets: 74.06% to 84.83% win rate at 55¢–62¢.
2. `polymarket_5m_shadow_engine.py` (8KB):
   - Micro-Market Shadow Telemetry Engine.
   - Monitors "1-Cent Extreme" (0.5¢–1.5¢) and "Panic Dump" (10¢–22¢) mispricings.
   - Automates mean-reversion bounce exits targeting 45¢ and 65¢.
3. `binary_parity_arbitrage.py`:
   - Scans orderbooks where Yes + No < $0.985, buying both sides concurrently for risk-free profit.
4. `clob_depth_whale_sniper.py`:
   - Analyzes Polymarket CLOB orderbook depth, trade flow velocity, and whale wallet accumulation.

## Quick Start:
Run `python polymarket_5m_btc_engine.py --paper` for simulated execution or `--live` with private key.
