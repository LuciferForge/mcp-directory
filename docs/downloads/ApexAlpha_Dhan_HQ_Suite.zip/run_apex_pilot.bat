@echo off
title ApexAlpha Dhan HQ Algorithmic Suite
echo [ApexAlpha] Launching Dhan HQ Top-3 Production Pilot...
cd thebull-dhan-bot
python dhan_bot.py
pause
