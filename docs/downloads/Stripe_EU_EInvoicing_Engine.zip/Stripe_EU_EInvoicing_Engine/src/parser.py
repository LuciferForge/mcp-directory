"""
Stripe Payload Ingestion & Transformation Engine.
Extracts and normalizes Stripe Invoice JSON into EN 16931 InvoiceData model.
"""

import os
import datetime
from typing import Dict, Any, List, Optional
from src.models import (
    InvoiceData,
    Party,
    Address,
    PaymentDetails,
    InvoiceLineItem,
    TaxBreakdownItem,
)


# Configurable default Seller Profile (loaded from environment or venture defaults)
DEFAULT_SELLER_PROFILE = {
    "name": os.getenv("SELLER_COMPANY_NAME", "Acme Cloud Services SAS"),
    "address_line1": os.getenv("SELLER_ADDRESS_LINE1", "12 Rue de la Paix"),
    "city": os.getenv("SELLER_CITY", "Paris"),
    "postal_code": os.getenv("SELLER_POSTAL_CODE", "75002"),
    "country_code": os.getenv("SELLER_COUNTRY_CODE", "FR"),
    "vat_id": os.getenv("SELLER_VAT_ID", "FR12345678901"),
    "tax_registration_id": os.getenv("SELLER_SIRET", "12345678900012"),
    "electronic_address": os.getenv("SELLER_LEITWEG_OR_PEPPOL_ID", "0204:995712345678900012"),
    "electronic_address_scheme": os.getenv("SELLER_EAS_SCHEME", "9957"),  # 9957 = French SIRET
    "contact_email": os.getenv("SELLER_CONTACT_EMAIL", "billing@acmecloud.eu"),
    "iban": os.getenv("SELLER_IBAN", "FR7630006000011234567890189"),
    "bic": os.getenv("SELLER_BIC", "BNPAFR2AXXX"),
}


def _epoch_to_date_str(epoch: Optional[int]) -> str:
    if not epoch:
        return datetime.date.today().isoformat()
    return datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc).strftime("%Y-%m-%d")


def parse_stripe_invoice(payload: Dict[str, Any], seller_override: Optional[Dict[str, Any]] = None) -> InvoiceData:
    """
    Parses a Stripe invoice object (or a webhook event containing an invoice)
    and transforms it into a standardized EN 16931 InvoiceData model.
    """
    # Extract invoice object if nested in event
    invoice_obj = payload
    if payload.get("object") == "event":
        invoice_obj = payload.get("data", {}).get("object", {})

    stripe_invoice_id = invoice_obj.get("id", "in_mock_unknown")
    invoice_number = invoice_obj.get("number") or f"INV-{stripe_invoice_id[-8:]}"

    # Dates
    created_epoch = invoice_obj.get("status_transitions", {}).get("finalized_at") or invoice_obj.get("created")
    issue_date = _epoch_to_date_str(created_epoch)

    due_epoch = invoice_obj.get("due_date")
    due_date = _epoch_to_date_str(due_epoch) if due_epoch else issue_date

    # Currency
    currency = (invoice_obj.get("currency") or "eur").upper()

    # Seller resolution
    seller_data = {**DEFAULT_SELLER_PROFILE, **(seller_override or {})}
    seller_address = Address(
        line1=seller_data.get("address_line1", "Default Street 1"),
        city=seller_data.get("city", "Paris"),
        postal_code=seller_data.get("postal_code", "75001"),
        country_code=seller_data.get("country_code", "FR"),
    )
    seller = Party(
        name=seller_data.get("name", "Venture Vendor"),
        address=seller_address,
        vat_id=seller_data.get("vat_id"),
        tax_registration_id=seller_data.get("tax_registration_id"),
        electronic_address=seller_data.get("electronic_address"),
        electronic_address_scheme=seller_data.get("electronic_address_scheme", "9957"),
        contact_email=seller_data.get("contact_email"),
    )

    # Buyer resolution
    customer_details = invoice_obj.get("customer_details") or {}
    customer_address = customer_details.get("address") or invoice_obj.get("customer_address") or {}
    
    buyer_country = customer_address.get("country") or "FR"
    buyer_addr = Address(
        line1=customer_address.get("line1") or "Customer Street",
        line2=customer_address.get("line2"),
        city=customer_address.get("city") or "Customer City",
        postal_code=customer_address.get("postal_code") or "00000",
        country_code=buyer_country.upper(),
        state=customer_address.get("state"),
    )

    # Customer tax IDs (e.g. EU VAT)
    buyer_vat_id = None
    tax_ids = customer_details.get("tax_ids") or invoice_obj.get("customer_tax_ids") or []
    for tid in tax_ids:
        tid_val = tid.get("value") if isinstance(tid, dict) else str(tid)
        if tid_val:
            buyer_vat_id = tid_val.replace(" ", "").upper()
            break

    buyer_name = customer_details.get("name") or invoice_obj.get("customer_name") or "Valued Business Customer"
    buyer = Party(
        name=buyer_name,
        address=buyer_addr,
        vat_id=buyer_vat_id,
        contact_email=customer_details.get("email") or invoice_obj.get("customer_email"),
    )

    # Determine reverse charge condition (EU cross-border B2B with VAT number)
    is_reverse_charge = False
    notes: List[str] = []
    if (
        buyer_vat_id
        and buyer.address.country_code != seller.address.country_code
        and invoice_obj.get("tax", 0) == 0
    ):
        is_reverse_charge = True
        notes.append("Reverse charge: VAT payable by the customer according to Art 196 EU VAT Directive.")

    # Parse Line Items
    lines_data = invoice_obj.get("lines", {}).get("data", [])
    parsed_lines: List[InvoiceLineItem] = []
    tax_buckets: Dict[float, Dict[str, float]] = {}

    for idx, item in enumerate(lines_data, start=1):
        line_id = str(idx)
        description = item.get("description") or "Subscription / Digital Service"
        quantity = float(item.get("quantity") or 1.0)
        
        # Stripe amounts are in integer cents
        amount_cents = item.get("amount", 0)
        net_amount = round(amount_cents / 100.0, 2)
        unit_price = round(net_amount / quantity, 4) if quantity else net_amount

        # Extract Tax Rate for this line
        item_tax_rate = 0.0
        tax_rates = item.get("tax_rates") or []
        if tax_rates and isinstance(tax_rates, list):
            item_tax_rate = float(tax_rates[0].get("percentage", 0.0))
        elif is_reverse_charge:
            item_tax_rate = 0.0
        else:
            # Fallback to overall tax percentage if itemized tax is not present
            total_sub = invoice_obj.get("subtotal", 0)
            total_tx = invoice_obj.get("tax", 0)
            if total_sub > 0 and total_tx > 0:
                item_tax_rate = round((total_tx / total_sub) * 100.0, 2)

        # Tax Category Code
        # S = Standard rate, AE = Reverse charge, Z = Zero rated, E = Exempt
        if is_reverse_charge:
            tax_category = "AE"
        elif item_tax_rate == 0.0:
            tax_category = "Z"
        else:
            tax_category = "S"

        line_tax_amount = round(net_amount * (item_tax_rate / 100.0), 2)

        parsed_lines.append(
            InvoiceLineItem(
                line_id=line_id,
                name=description[:100],
                description=description,
                quantity=quantity,
                unit_code="C62",
                unit_price_net=unit_price,
                net_total_amount=net_amount,
                tax_category_code=tax_category,
                tax_rate_percent=item_tax_rate,
                tax_amount=line_tax_amount,
            )
        )

        # Aggregate tax breakdown
        key = (item_tax_rate, tax_category)
        if key not in tax_buckets:
            tax_buckets[key] = {"taxable": 0.0, "tax": 0.0}
        tax_buckets[key]["taxable"] += net_amount
        tax_buckets[key]["tax"] += line_tax_amount

    # Build Tax Breakdown
    tax_breakdown: List[TaxBreakdownItem] = []
    for (rate, category), amounts in tax_buckets.items():
        exemption = (
            "Reverse charge: VAT payable by the recipient (Article 196 EU VAT Directive)"
            if category == "AE"
            else None
        )
        tax_breakdown.append(
            TaxBreakdownItem(
                tax_category_code=category,
                tax_rate_percent=rate,
                taxable_amount=round(amounts["taxable"], 2),
                tax_amount=round(amounts["tax"], 2),
                exemption_reason=exemption,
            )
        )

    # Totals
    total_net = round(sum(line.net_total_amount for line in parsed_lines), 2)
    total_tax = round(sum(tb.tax_amount for tb in tax_breakdown), 2)
    total_gross = round(total_net + total_tax, 2)

    # Payment details
    payment_details = PaymentDetails(
        payment_means_code="58",  # SEPA Credit Transfer
        payment_means_name="SEPA Credit Transfer",
        iban=seller_data.get("iban"),
        bic=seller_data.get("bic"),
        payment_reference=invoice_number,
    )

    return InvoiceData(
        invoice_number=invoice_number,
        stripe_invoice_id=stripe_invoice_id,
        issue_date=issue_date,
        due_date=due_date,
        currency=currency,
        seller=seller,
        buyer=buyer,
        payment_details=payment_details,
        line_items=parsed_lines,
        tax_breakdown=tax_breakdown,
        total_net_amount=total_net,
        total_tax_amount=total_tax,
        total_gross_amount=total_gross,
        due_payable_amount=total_gross,
        notes=notes,
    )
