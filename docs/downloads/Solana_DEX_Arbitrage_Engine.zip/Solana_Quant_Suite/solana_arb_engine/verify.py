"""Autonomous zero-dependency verification suite runner for the Solana Arbitrage Engine.

Executes all test suites across:
- Token Contract Safety Filter (Freeze, Mint authority, Token-2022 extensions)
- Constant-Product AMM & Concentrated Liquidity Math (x*y=k, DLMM, Optimal Sizing)
- Jito Dynamic Tip Bidding & Atomic Safety Assertions
- End-to-End Paper-Trading Orchestrator Pipeline
"""

from __future__ import annotations

import os
import sys
import time
import unittest
from pathlib import Path

# Ensure root workspace is on python path
WORKSPACE_ROOT = Path(__file__).resolve().parent
if str(WORKSPACE_ROOT) not in sys.path:
    sys.path.insert(0, str(WORKSPACE_ROOT))

from tests.test_safety import TestSafetyFilter
from tests.test_arb_math import TestArbMath
from tests.test_jito_bundler import TestJitoBundler
from tests.test_engine import TestEngineIntegration


def run_all_verifications() -> bool:
    print("=" * 80)
    print("  SOLANA LONG-TAIL & MIGRATION ARBITRAGE ENGINE - VERIFICATION SUITE")
    print("=" * 80)
    print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}")
    print(f"Python:    {sys.version.split()[0]}")
    print(f"Directory: {WORKSPACE_ROOT}")
    print("-" * 80)

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    test_modules = [
        ("Token Safety Filter (Honeypot, Freeze, Mint Auth, Token-2022)", TestSafetyFilter),
        ("AMM & Concentrated Liquidity Math (x*y=k, DLMM, Optimal Sizing)", TestArbMath),
        ("Jito Dynamic Tip Bidding & Atomic Safety Assertions", TestJitoBundler),
        ("Orchestrator Integration & Paper-Trading Pipeline", TestEngineIntegration),
    ]

    total_tests = 0
    for name, test_class in test_modules:
        tests = loader.loadTestsFromTestCase(test_class)
        suite.addTests(tests)
        count = tests.countTestCases()
        total_tests += count
        print(f" [LOADED] {name:<65} ({count} tests)")

    print("-" * 80)
    print(f"Executing {total_tests} verification tests...\n")

    start_time = time.perf_counter()
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    elapsed = time.perf_counter() - start_time

    print("\n" + "=" * 80)
    print("  VERIFICATION AUDIT SUMMARY")
    print("=" * 80)
    print(f"Total Tests Executed: {result.testsRun}")
    print(f"Passed:               {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failed:               {len(result.failures)}")
    print(f"Errors:               {len(result.errors)}")
    print(f"Elapsed Time:         {elapsed:.3f} seconds")
    print("-" * 80)

    if result.wasSuccessful():
        print("  VERIFICATION RESULT: ALL 100% OF SYSTEM TESTS PASSED")
        print("  Engine status: PRODUCTION-READY (Paper-Trading Mode)")
        print("=" * 80)
        return True
    else:
        print("  VERIFICATION RESULT: TESTS FAILED")
        print("=" * 80)
        return False


if __name__ == "__main__":
    success = run_all_verifications()
    sys.exit(0 if success else 1)
