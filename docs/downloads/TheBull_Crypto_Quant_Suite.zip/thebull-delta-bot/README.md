# TheBull - Delta Exchange India Algorithmic Trading Bot

![TheBull Banner](https://raw.githubusercontent.com/manjunathg-dev/thebull/main/thebull_banner.png)

> **High-Performance Multi-Factor Momentum Engine with 4-Stage Progressive Trailing Stops on Delta Exchange India.**

---

## 🚀 Key Highlights

- **Native Delta Exchange India API:** Operates seamlessly with `api.india.delta.exchange` (FIU-compliant INR & crypto settlement).
- **ZeroLag Momentum Scoring:** Scans all operational perpetual contracts on 15-minute bars combining Supertrend, Dual EMA alignment (20/50), Dynamic RSI expansion (up to 85), and Volume breakout.
- **Dynamic Capital Sizing:** Automatically calculates contract lots based on your live wallet equity—safely scaling positions from $10 up to $1,000+ without overleveraging.
- **4-Stage Progressive Trailing Stops:**
  - **Stage 1 (Initial):** Hard Stop-Loss at -3.5%.
  - **Stage 2 (+3.5% Profit):** Stop moves to Break-Even (+0.2% fee cushion).
  - **Stage 3 (+7.0% Profit):** Stop trails at 3.5% below peak price.
  - **Stage 4 (+15.0% Profit):** Stop trails closely at 5.0% below peak price to lock in home-run runners.
- **Auto-Reconciliation:** Automatically synchronizes open orders and cleans up orphaned or duplicate stop-loss orders.
- **Bidirectional Protection:** Native handling for both Long and Short positions with inverted trigger rules.

---

## 📦 Quick Start (Under 3 Minutes)

### Windows (1-Click Run)
1. Double-click `start_bot.bat`.
2. The script will automatically create a virtual environment, install requirements, and prompt you to enter your API keys in `.env`.
3. Save your `.env` file, press any key, and the bot starts trading!

### Linux / macOS
```bash
chmod +x start_bot.sh
./start_bot.sh
```

---

## 🛠️ Manual Installation

If you prefer setting it up manually:

```bash
# 1. Clone or download the repository
git clone https://github.com/manja316/thebull-delta-bot.git
cd thebull-delta-bot

# 2. Create and activate a virtual environment
python3 -m venv .venv
# On Windows:
.venv\Scripts\activate
# On Linux/macOS:
source .venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure credentials
cp .env.example .env
# Open .env and add your DELTA_API_KEY and DELTA_API_SECRET
```

---

## ⚙️ Configuration (`config.json`)

You can customize risk and execution parameters directly in `config.json`:

```json
{
  "bot_name": "TheBull Delta Exchange India Zero-Lag Bot",
  "leverage": 10,
  "default_max_positions": 35,
  "min_signal_strength": 70.0,
  "scan_interval_seconds": 30,
  "capital_tiers": {
    "tier_100_usd": 100,
    "tier_50_usd": 35,
    "tier_20_usd": 20,
    "below_20_usd": 10
  },
  "trailing_stop": {
    "hard_sl_pct": 3.5,
    "stage_2_breakeven_pnl_pct": 3.5,
    "stage_3_pnl_pct": 7.0,
    "stage_3_trail_pct": 3.5,
    "stage_4_pnl_pct": 15.0,
    "stage_4_trail_pct": 5.0
  }
}
```

---

## 🧪 Simulation / Dry-Run Mode

Test the bot safely with paper trading before deploying real capital:

```bash
python delta_bot.py --dry-run
```

---

## 🛡️ Risk Management & Capital Allocation Rules

1. **Leverage:** The bot is optimized for **10x isolated leverage**. Never use cross-margin or >10x leverage.
2. **Account Minimums:** Works with as little as $10 (₹850). Suggested minimum for optimal diversification across 20+ pairs: $50 to $100.
3. **Safety Firewall:** The bot ensures margin required for any position does not exceed 85% of available balance to prevent liquidation cascades.

---

## ⚠️ Disclaimer

*Trading cryptocurrency derivatives involves substantial risk of loss and is not suitable for every investor. The valuation of futures contracts may fluctuate significantly. Only trade with risk capital you can afford to lose. Past performance of this automated strategy does not guarantee future results.*
