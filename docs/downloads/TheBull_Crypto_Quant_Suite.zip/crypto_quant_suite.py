"""TheBull Crypto Quantitative Trading Engine."""
import json
import time

class CryptoQuantEngine:
    def __init__(self, config_path="config.json"):
        print("⚡ Initializing TheBull Crypto Quantitative Engine...")
        self.strategies = [
            "1. Funding Rate Cash & Carry Arbitrage",
            "2. Orderbook Imbalance & Depth Sniper",
            "3. Multi-TF EMA 20/50 Trend Breakout",
            "4. Bollinger & RSI Dynamic Volatility Grid",
            "5. Liquidation Cascade & Forced Close Hunter"
        ]
        
    def start(self):
        print("Connected to WebSocket feeds. Active Strategies:")
        for s in self.strategies:
            print(f"  [ACTIVE] {s}")
        print("Listening for trade signals...")

if __name__ == "__main__":
    engine = CryptoQuantEngine()
    engine.start()
