"""
Realistic Stripe Webhook Fixtures for EN 16931 Factur-X / ZUGFeRD 2.2 testing.
"""

# Case 1: Standard Domestic B2B Invoice (France to France, 20% Standard VAT)
MOCK_DOMESTIC_FR_INVOICE = {
    "id": "evt_test_french_b2b_001",
    "object": "event",
    "type": "invoice.paid",
    "data": {
        "object": {
            "id": "in_1N4X00FRTEST12345678",
            "object": "invoice",
            "number": "INV-2026-FR-0042",
            "currency": "eur",
            "status": "paid",
            "created": 1774000000,
            "due_date": 1776592000,
            "status_transitions": {
                "finalized_at": 1774000000,
                "paid_at": 1774000500,
            },
            "subtotal": 100000,  # 1,000.00 EUR
            "tax": 20000,        # 200.00 EUR (20% VAT)
            "total": 120000,      # 1,200.00 EUR
            "customer_name": "Atelier de Design Parisien SAS",
            "customer_email": "compta@atelierdesign.fr",
            "customer_address": {
                "line1": "45 Avenue de l'Opéra",
                "city": "Paris",
                "postal_code": "75001",
                "country": "FR",
            },
            "customer_tax_ids": [
                {
                    "type": "eu_vat",
                    "value": "FR89987654321",
                }
            ],
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "il_line_item_01",
                        "description": "Enterprise Cloud Hosting - Annual Subscription",
                        "quantity": 1,
                        "amount": 100000,
                        "tax_rates": [
                            {
                                "percentage": 20.0,
                                "inclusive": False,
                                "jurisdiction": "FR",
                            }
                        ],
                    }
                ],
            },
        }
    },
}

# Case 2: Intra-Community Cross-Border B2B Supply (Germany Seller -> Netherlands Buyer, 0% Reverse Charge)
MOCK_REVERSE_CHARGE_EU_INVOICE = {
    "id": "evt_test_eu_reverse_charge_002",
    "object": "event",
    "type": "invoice.paid",
    "data": {
        "object": {
            "id": "in_1N4X00EUTEST98765432",
            "object": "invoice",
            "number": "INV-2026-EU-0881",
            "currency": "eur",
            "status": "paid",
            "created": 1774100000,
            "due_date": 1776692000,
            "status_transitions": {
                "finalized_at": 1774100000,
                "paid_at": 1774100100,
            },
            "subtotal": 250000,  # 2,500.00 EUR
            "tax": 0,            # 0% VAT (Reverse charge)
            "total": 250000,     # 2,500.00 EUR
            "customer_name": "Amsterdam Tech Logistics B.V.",
            "customer_email": "finance@amsterdamtech.nl",
            "customer_address": {
                "line1": "Keizersgracht 421",
                "city": "Amsterdam",
                "postal_code": "1016 EK",
                "country": "NL",
            },
            "customer_tax_ids": [
                {
                    "type": "eu_vat",
                    "value": "NL854123456B01",
                }
            ],
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "il_line_item_nl_01",
                        "description": "API Infrastructure Cluster - Dedicated Instance",
                        "quantity": 2,
                        "amount": 250000,  # 1,250.00 each
                        "tax_rates": [],
                    }
                ],
            },
        }
    },
}

# Case 3: Multi-Line Mixed VAT Invoice (Germany Domestic, 19% Standard & 7% Reduced)
MOCK_MULTI_LINE_DE_INVOICE = {
    "id": "evt_test_multi_line_de_003",
    "object": "event",
    "type": "invoice.paid",
    "data": {
        "object": {
            "id": "in_1N4X00DETEST55555555",
            "object": "invoice",
            "number": "INV-2026-DE-1049",
            "currency": "eur",
            "status": "paid",
            "created": 1774200000,
            "due_date": 1776792000,
            "status_transitions": {
                "finalized_at": 1774200000,
                "paid_at": 1774200200,
            },
            "subtotal": 300000,  # 2,000 + 1,000 = 3,000.00 EUR
            "tax": 45000,        # (2,000 * 0.19 = 380) + (1,000 * 0.07 = 70) = 450.00 EUR
            "total": 345000,     # 3,450.00 EUR
            "customer_name": "Berliner Software Manufaktur GmbH",
            "customer_email": "buchhaltung@berlinersoftware.de",
            "customer_address": {
                "line1": "Friedrichstraße 176",
                "city": "Berlin",
                "postal_code": "10117",
                "country": "DE",
            },
            "customer_tax_ids": [
                {
                    "type": "eu_vat",
                    "value": "DE123456789",
                }
            ],
            "lines": {
                "object": "list",
                "data": [
                    {
                        "id": "il_line_de_01",
                        "description": "Custom Software Engineering Services",
                        "quantity": 20,
                        "amount": 200000,  # 2,000 EUR
                        "tax_rates": [{"percentage": 19.0}],
                    },
                    {
                        "id": "il_line_de_02",
                        "description": "Technical Documentation & Digital Literature",
                        "quantity": 10,
                        "amount": 100000,  # 1,000 EUR
                        "tax_rates": [{"percentage": 7.0}],
                    },
                ],
            },
        }
    },
}
