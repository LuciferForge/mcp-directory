# Solana Long-Tail & Migration Arbitrage Engine

A production-grade, self-contained Solana arbitrage engine designed for long-tail meme tokens and Pump.fun migration/graduation events in **dry-run / paper-trading mode**.

---

## Architecture Overview

```
                      +-----------------------------+
                      |   Solana RPC / WebSocket    |
                      | (Raydium v4, DLMM, Pump.fun)|
                      +--------------+--------------+
                                     |
                                     v
                      +-----------------------------+
                      |      src/pool_listener      |
                      |   Streams pool state ticks  |
                      +--------------+--------------+
                                     |
                                     v
                      +-----------------------------+
                      |      src/safety_filter      |
                      |  Inspects mint & authorities|
                      +--------------+--------------+
                                     |
                  [Unsafe Token]     | [Clean Token]
                 +-------------------+------------------+
                 |                                      |
                 v                                      v
        +------------------+                 +----------------------+
        | BLOCKED_HONEYPOT |                 |     src/arb_math     |
        | Log & halt trade |                 | Optimal trade sizing |
        +------------------+                 +----------+-----------+
                                                        |
                                                        v
                                             +----------------------+
                                             |   src/jito_bundler   |
                                             | Dynamic tip & Atomic |
                                             |  assertion creation  |
                                             +----------+-----------+
                                                        |
                                                        v
                                             +----------------------+
                                             |     src/engine       |
                                             | Paper execution &    |
                                             | PnL ledger update    |
                                             +----------------------+
```

---

## Core Modules & Design

### 1. `src/safety_filter.py` (Automated Token Inspector)
Protects capital by filtering dangerous long-tail mints before mathematical evaluation:
- **Mint Authority Check**: Enforces `mint_authority == None`. Any unrevoked authority can inflate supply and dump.
- **Freeze Authority Check**: Enforces `freeze_authority == None`. Prevents blacklisting honeypots.
- **Token-2022 Extension Auditing**:
  - `TransferHook`: Blocks tokens with transfer hooks that revert transfers during sell transactions.
  - `PermanentDelegate`: Blocks tokens where an authority can seize holder balances.
  - `DefaultAccountState`: Blocks tokens whose default account state is frozen.
  - `TransferFeeConfig`: Calculates transfer tax percentage; flags/blocks fees exceeding slippage tolerance or unrevoked tax authorities.
- **Supply Concentration**: Flags tokens where the top 3 non-pool holders exceed concentration limits (e.g., > 25%).

### 2. `src/arb_math.py` (Constant-Product & Concentrated Liquidity Models)
- **Constant-Product AMM ($x \cdot y = k$)**: Exact lamport-level integer math for Raydium AMM v4 and CPMM:
  $$\Delta y = \frac{y \cdot \Delta x \cdot (1 - f)}{x + \Delta x \cdot (1 - f)}$$
- **Analytical Optimal Trade Sizing**: Derives the exact input $\Delta x^*$ that maximizes net profit across a two-leg arbitrage ($A \to B \to A$):
  $$\Delta x^* = \frac{\sqrt{x_1 \cdot x_2 \cdot y_1 \cdot y_2 \cdot (1 - f_1) \cdot (1 - f_2)} - x_1 \cdot y_2}{(1 - f_1) \cdot (y_2 + (1 - f_2) \cdot y_1)}$$
- **Meteora DLMM Multi-Bin Model**: Simulates crossing discrete liquidity bins $P(i) = (1 + \text{bin\_step})^i$.
- **Pump.fun Bonding Curve & Graduation**: Detects 85 SOL bonding curve completion and models initial migration pricing.

### 3. `src/jito_bundler.py` (MEV Bundle Constructor & Dynamic Tipping)
- **Dynamic Tip Bidding**:
  $$tip = \min(0.50 \times \text{GrossProfit}, \text{max\_tip})$$
  Ensures tip scales competitively with opportunity value without eroding net profits.
- **Atomic Safety Assertion**:
  Generates an on-chain condition:
  $$\text{require}(\text{final\_sol} \ge \text{initial\_sol} + \text{min\_profit})$$
  Simulates reverting the entire bundle if frontrunning or slippage sandwiches the execution.
- **Jito Payload**: Formats payloads adhering to standard Jito Block Engine `sendBundle` JSON-RPC specification.

### 4. `src/pool_listener.py` (Real-Time Event Streamer)
- Subscribes to Raydium (AMM v4 & CPMM), Meteora DLMM, and Pump.fun migration/graduation logs via Solana WebSocket RPC.
- Includes a synthetic market generator simulating real-world spread anomalies and honeypot traps for offline paper trading.

### 5. `src/engine.py` (Paper-Trading Orchestrator)
- Coordinates event ingestion, security verification, arbitrage sizing, bundle simulation, and portfolio balance ledger tracking.
- Emits structured JSON audit records to `logs/simulation_pnl.jsonl`.

---

## Configuration (`config.json`)

```json
{
  "rpc_url": "https://api.mainnet-beta.solana.com",
  "ws_url": "wss://api.mainnet-beta.solana.com",
  "min_profit_sol": 0.005,
  "max_trade_sol": 5.0,
  "min_trade_sol": 0.1,
  "max_tip_sol": 0.05,
  "tip_percentage": 0.50,
  "slippage_tolerance_bps": 50,
  "simulation": {
    "initial_sol_balance": 10.0,
    "log_file": "logs/simulation_pnl.jsonl"
  }
}
```

---

## Verification & Testing

The verification suite runs out of the box with zero external dependencies (Python 3.9+ standard library):

```bash
python verify.py
```

Expected output:
```
================================================================================
  SOLANA LONG-TAIL & MIGRATION ARBITRAGE ENGINE - VERIFICATION SUITE
================================================================================
 [LOADED] Token Safety Filter (Honeypot, Freeze, Mint Auth, Token-2022)       (7 tests)
 [LOADED] AMM & Concentrated Liquidity Math (x*y=k, DLMM, Optimal Sizing)     (7 tests)
 [LOADED] Jito Dynamic Tip Bidding & Atomic Safety Assertions                 (7 tests)
 [LOADED] Orchestrator Integration & Paper-Trading Pipeline                   (3 tests)
--------------------------------------------------------------------------------
Executing 24 verification tests...
...
================================================================================
  VERIFICATION AUDIT SUMMARY
================================================================================
Total Tests Executed: 24
Passed:               24
Failed:               0
Errors:               0
--------------------------------------------------------------------------------
  VERIFICATION RESULT: ALL 100% OF SYSTEM TESTS PASSED
  Engine status: PRODUCTION-READY (Paper-Trading Mode)
================================================================================
```

---

## Running the Live Paper-Trading Simulator

Run the dry-run CLI simulator:

```bash
# Run 20 synthetic/live events (default)
python run_sim.py

# Run continuous streaming simulation
python run_sim.py --events 0 --interval 0.5

# Connect to live Solana mainnet WebSocket feeds
python run_sim.py --live
```

---

## Structured Audit Log Sample (`logs/simulation_pnl.jsonl`)

```json
{
  "timestamp": 1716298412.34,
  "decision": "EXECUTED_PROFITABLE",
  "token_mint": "AlphaToken1111111111111111111111111111111111",
  "is_safe": true,
  "risk_score": 0.0,
  "bundle_id": "bundle_1716298412340_8921",
  "buy_dex": "Raydium AMM v4",
  "sell_dex": "Meteora DLMM",
  "input_sol": 1.25,
  "tokens_acquired": 3125000000,
  "spread_pct": 16.67,
  "gross_profit_sol": 0.124500,
  "jito_tip_sol": 0.050000,
  "net_profit_sol": 0.074485,
  "current_sol_balance": 10.074485,
  "latency_ms": 0.42
}
```
