"""
FastAPI Server for Stripe EU E-Invoicing Engine.
Production-ready webhook receiver & direct conversion API.
"""

import os
import json
from fastapi import FastAPI, Request, HTTPException, Header, Response
from fastapi.responses import JSONResponse, PlainTextResponse
from typing import Optional, Dict, Any

from src.webhook_handler import verify_stripe_signature, process_stripe_event
from src.parser import parse_stripe_invoice
from src.zugferd_generator import generate_zugferd_xml

app = FastAPI(
    title="Stripe EU E-Invoicing Webhook Engine",
    description="Factur-X / ZUGFeRD 2.2 Compliant E-Invoicing Generator for Stripe EU Merchants",
    version="1.0.0",
)

WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")


@app.get("/")
def root():
    return {
        "service": "Stripe EU E-Invoicing Webhook Engine",
        "standard": "Factur-X 1.0 / ZUGFeRD 2.2 (EN 16931 Comfort Profile)",
        "status": "operational",
        "endpoints": {
            "webhook": "POST /webhook",
            "convert": "POST /convert",
            "health": "GET /health",
        },
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "profile": "EN 16931:2017",
        "syntax": "UN/CEFACT CrossIndustryInvoice (CII) 16B",
    }


@app.post("/webhook")
async def stripe_webhook(
    request: Request,
    stripe_signature: Optional[str] = Header(None, alias="stripe-signature"),
):
    """
    Receives incoming Stripe webhook events.
    Verifies signature if STRIPE_WEBHOOK_SECRET is configured.
    """
    payload_bytes = await request.body()

    # Signature verification (if secret configured)
    if WEBHOOK_SECRET:
        if not stripe_signature or not verify_stripe_signature(payload_bytes, stripe_signature, WEBHOOK_SECRET):
            raise HTTPException(status_code=400, detail="Invalid Stripe signature")

    try:
        event = json.loads(payload_bytes.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Malformed JSON payload: {str(exc)}")

    result = process_stripe_event(event)
    return result


@app.post("/convert")
async def convert_invoice(request: Request, format: Optional[str] = "xml"):
    """
    Direct conversion endpoint: accepts raw Stripe Invoice object or Webhook event.
    Returns Factur-X XML directly (format=xml) or JSON metadata (format=json).
    """
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Malformed JSON: {str(exc)}")

    try:
        invoice_data = parse_stripe_invoice(payload)
        xml_content = generate_zugferd_xml(invoice_data)
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Error parsing invoice: {str(exc)}")

    if format == "json":
        return {
            "invoice_number": invoice_data.invoice_number,
            "currency": invoice_data.currency,
            "total_net": invoice_data.total_net_amount,
            "total_tax": invoice_data.total_tax_amount,
            "total_gross": invoice_data.total_gross_amount,
            "buyer": invoice_data.buyer.name,
            "xml_preview": xml_content[:500] + "...",
        }

    return Response(
        content=xml_content,
        media_type="application/xml",
        headers={
            "Content-Disposition": f"attachment; filename={invoice_data.invoice_number}_facturx.xml"
        },
    )


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("src.main:app", host="0.0.0.0", port=port, reload=True)
