"""Solana DEX Pool & Migration WebSocket Event Listener.

Subscribes to Raydium (AMM v4 & CPMM), Meteora DLMM, and Pump.fun migration/graduation
events via Solana JSON-RPC WebSockets, with built-in high-fidelity event synthesis
for dry-run paper-trading.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from dataclasses import dataclass, field
from typing import AsyncGenerator, Callable, Dict, Any, Optional, List

from .arb_math import PoolState
from .config import DexPrograms

logger = logging.getLogger(__name__)


@dataclass
class PoolEvent:
    """Represents a real-time event from a DEX pool."""
    event_type: str  # "SWAP", "GRADUATION", "INITIALIZE", "RESERVE_UPDATE"
    dex_name: str
    pool_id: str
    token_mint_a: str  # Base (SOL / WSOL)
    token_mint_b: str  # Target token
    reserve_a: int
    reserve_b: int
    fee_bps: int
    timestamp: float = field(default_factory=time.time)
    signature: Optional[str] = None
    slot: int = 0
    raw_log: Optional[str] = None
    is_migration: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_pool_state(self) -> PoolState:
        """Converts event to standard PoolState object."""
        return PoolState(
            pool_id=self.pool_id,
            dex_name=self.dex_name,
            token_mint_a=self.token_mint_a,
            token_mint_b=self.token_mint_b,
            reserve_a=self.reserve_a,
            reserve_b=self.reserve_b,
            fee_bps=self.fee_bps,
        )


class PoolListener:
    """Listens to on-chain pool state changes, migrations, and synthetic streams."""

    def __init__(
        self,
        ws_url: Optional[str] = None,
        dex_programs: Optional[DexPrograms] = None,
    ):
        self.ws_url = ws_url or "wss://api.mainnet-beta.solana.com"
        self.dex_programs = dex_programs or DexPrograms()
        self.is_running = False
        self._pools_cache: Dict[str, PoolState] = {}

    def get_subscription_payloads(self) -> List[Dict[str, Any]]:
        """Construct JSON-RPC WebSocket subscription requests for all supported DEX programs."""
        payloads = []
        programs = [
            ("Raydium AMM v4", self.dex_programs.raydium_amm_v4),
            ("Raydium CPMM", self.dex_programs.raydium_cpmm),
            ("Meteora DLMM", self.dex_programs.meteora_dlmm),
            ("Pump.fun", self.dex_programs.pump_fun),
        ]

        for i, (name, prog_id) in enumerate(programs, start=1):
            payloads.append({
                "jsonrpc": "2.0",
                "id": i,
                "method": "logsSubscribe",
                "params": [
                    {"mentions": [prog_id]},
                    {"commitment": "processed"},
                ],
            })
        return payloads

    def parse_log_message(self, message: Dict[str, Any]) -> Optional[PoolEvent]:
        """Parses a raw Solana RPC log notification into a structured PoolEvent."""
        try:
            params = message.get("params", {})
            result = params.get("result", {})
            value = result.get("value", {})
            logs: List[str] = value.get("logs", [])
            signature = value.get("signature")

            # Detect Pump.fun graduation: "Program 6EF8... success" and "Instruction: Complete"
            is_pump_log = any(self.dex_programs.pump_fun in l for l in logs)
            if is_pump_log and any("complete" in l.lower() or "graduate" in l.lower() for l in logs):
                return PoolEvent(
                    event_type="GRADUATION",
                    dex_name="Pump.fun",
                    pool_id=f"pump_curve_{signature[:8] if signature else 'unknown'}",
                    token_mint_a="So11111111111111111111111111111111111111112",
                    token_mint_b="TargetToken1111111111111111111111111111111",
                    reserve_a=85_000_000_000,  # 85 SOL
                    reserve_b=206_900_000_000_000,
                    fee_bps=100,
                    signature=signature,
                    is_migration=True,
                    metadata={"source": "pump_graduation_event"},
                )

            # Detect Raydium Swap / initialize
            is_raydium = any(self.dex_programs.raydium_amm_v4 in l or self.dex_programs.raydium_cpmm in l for l in logs)
            if is_raydium:
                return PoolEvent(
                    event_type="SWAP",
                    dex_name="Raydium",
                    pool_id=f"raydium_pool_{signature[:8] if signature else 'unknown'}",
                    token_mint_a="So11111111111111111111111111111111111111112",
                    token_mint_b="TargetToken1111111111111111111111111111111",
                    reserve_a=50_000_000_000,
                    reserve_b=150_000_000_000_000,
                    fee_bps=25,
                    signature=signature,
                    metadata={"source": "raydium_event"},
                )
        except Exception as e:
            logger.debug("Error parsing log message: %s", e)
        return None

    async def stream_live_events(self) -> AsyncGenerator[PoolEvent, None]:
        """Connects to live Solana WebSocket endpoint and yields parsed pool events.

        Falls back cleanly to mock stream if network is offline or RPC is unavailable.
        """
        try:
            import websockets
            async with websockets.connect(self.ws_url, ping_interval=20, ping_timeout=10) as ws:
                logger.info("Connected to Solana WebSocket RPC: %s", self.ws_url)
                for payload in self.get_subscription_payloads():
                    await ws.send(json.dumps(payload))

                while self.is_running:
                    msg_text = await ws.recv()
                    msg_json = json.loads(msg_text)
                    event = self.parse_log_message(msg_json)
                    if event:
                        yield event
        except Exception as e:
            logger.warning("Live WebSocket unavailable (%s). Using synthetic market event generator.", e)
            async for ev in self.stream_synthetic_events():
                yield ev

    async def stream_synthetic_events(
        self,
        interval_sec: float = 1.0,
        max_events: Optional[int] = None,
    ) -> AsyncGenerator[Tuple[PoolEvent, PoolEvent, Dict[str, Any]], None]:
        """Generates realistic market events representing Raydium, Meteora DLMM, and Pump.fun migrations.

        Yields tuples: (pool_buy_event, pool_sell_event, token_metadata)
        Includes both clean arbitrage opportunities and honeypot traps to exercise safety filters.
        """
        self.is_running = True
        generated = 0

        # Scenario library for realistic simulations
        scenarios = [
            {
                "token_name": "PEPE_SOL",
                "mint": "PepeSoL111111111111111111111111111111111111",
                "is_honeypot": False,
                "token_metadata": {
                    "mintAuthority": None,
                    "freezeAuthority": None,
                    "decimals": 6,
                    "supply": 1_000_000_000_000_000,
                    "extensions": [],
                },
                "raydium_reserves": (40_000_000_000, 100_000_000_000_000),  # 40 SOL, 100M tokens
                "meteora_reserves": (45_000_000_000, 100_000_000_000_000),  # 45 SOL, 100M tokens -> ~12.5% dislocation
                "migration": False,
            },
            {
                "token_name": "PUMP_GRADUATION_GEM",
                "mint": "PumpGem111111111111111111111111111111111111",
                "is_honeypot": False,
                "token_metadata": {
                    "mintAuthority": None,
                    "freezeAuthority": None,
                    "decimals": 6,
                    "supply": 1_000_000_000_000_000,
                    "extensions": [],
                },
                # Just graduated: pump real SOL = 85 SOL, migrated to Raydium CPMM at slightly different curve ratio
                "raydium_reserves": (85_000_000_000, 206_900_000_000_000),
                "meteora_reserves": (93_000_000_000, 206_900_000_000_000),  # DLMM listing dislocation ~9.4%
                "migration": True,
            },
            {
                "token_name": "RUG_FREEZE_TRAP",
                "mint": "FreezeTrap1111111111111111111111111111111111",
                "is_honeypot": True,
                "token_metadata": {
                    "mintAuthority": None,
                    "freezeAuthority": "ScammerWallet111111111111111111111111111111",  # ACTIVE FREEZE!
                    "decimals": 6,
                    "supply": 1_000_000_000_000_000,
                    "extensions": [],
                },
                "raydium_reserves": (30_000_000_000, 80_000_000_000_000),
                "meteora_reserves": (38_000_000_000, 80_000_000_000_000),
                "migration": False,
            },
            {
                "token_name": "TOKEN_2022_TAX_SCAM",
                "mint": "TaxScam20221111111111111111111111111111111111",
                "is_honeypot": True,
                "token_metadata": {
                    "mintAuthority": None,
                    "freezeAuthority": None,
                    "decimals": 6,
                    "supply": 1_000_000_000_000_000,
                    "extensions": [
                        {
                            "extension": "transferFeeConfig",
                            "state": {
                                "newerTransferFee": {"transferFeeBasisPoints": 2500},  # 25% TAX!
                                "transferFeeConfigAuthority": "ScammerTaxAuth111111111111111111111111111",
                            },
                        }
                    ],
                },
                "raydium_reserves": (20_000_000_000, 50_000_000_000_000),
                "meteora_reserves": (28_000_000_000, 50_000_000_000_000),
                "migration": False,
            },
            {
                "token_name": "HIGH_SPREAD_ARBITRAGE",
                "mint": "AlphaToken1111111111111111111111111111111111",
                "is_honeypot": False,
                "token_metadata": {
                    "mintAuthority": None,
                    "freezeAuthority": None,
                    "decimals": 6,
                    "supply": 1_000_000_000_000_000,
                    "extensions": [],
                },
                "raydium_reserves": (60_000_000_000, 150_000_000_000_000),
                "meteora_reserves": (70_000_000_000, 150_000_000_000_000),  # ~16.6% spread
                "migration": False,
            },
        ]

        while self.is_running:
            if max_events is not None and generated >= max_events:
                break

            scenario = random.choice(scenarios)
            # Add small random liquidity perturbations to simulate real-time ticks
            pert_a = random.uniform(0.98, 1.02)
            pert_b = random.uniform(0.98, 1.02)

            res_ray_a = int(scenario["raydium_reserves"][0] * pert_a)
            res_ray_b = int(scenario["raydium_reserves"][1] * pert_b)

            res_met_a = int(scenario["meteora_reserves"][0] * pert_b)
            res_met_b = int(scenario["meteora_reserves"][1] * pert_a)

            sol_mint = "So11111111111111111111111111111111111111112"
            token_mint = scenario["mint"]

            event1 = PoolEvent(
                event_type="RESERVE_UPDATE",
                dex_name="Raydium AMM v4",
                pool_id=f"raydium_pool_{token_mint[:8]}",
                token_mint_a=sol_mint,
                token_mint_b=token_mint,
                reserve_a=res_ray_a,
                reserve_b=res_ray_b,
                fee_bps=25,
                is_migration=scenario["migration"],
                metadata={"token_name": scenario["token_name"]},
            )

            event2 = PoolEvent(
                event_type="RESERVE_UPDATE",
                dex_name="Meteora DLMM",
                pool_id=f"meteora_pool_{token_mint[:8]}",
                token_mint_a=sol_mint,
                token_mint_b=token_mint,
                reserve_a=res_met_a,
                reserve_b=res_met_b,
                fee_bps=20,
                is_migration=scenario["migration"],
                metadata={"token_name": scenario["token_name"]},
            )

            generated += 1
            yield event1, event2, scenario["token_metadata"]
            await asyncio.sleep(interval_sec)

    def stop(self) -> None:
        """Stops the streaming listener loop."""
        self.is_running = False
