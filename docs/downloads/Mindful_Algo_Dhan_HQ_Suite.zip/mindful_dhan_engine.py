"""Mindful Algo & Dhan HQ Production Engine."""
import time

class MindfulDhanEngine:
    def __init__(self, client_id="YOUR_DHAN_ID"):
        print("🇮🇳 Initializing Mindful Algo & Dhan HQ F&O Engine...")
        self.active_strategies = {
            "IA-7": "Nifty Range Edge (Bullish Option Buy, 61.0% WR)",
            "IA-10": "Nifty Bear Pivot (Friday Put Buyer, 3.49x R:R)",
            "IA-4": "Nifty Premium Harvester (0DTE Defined-Risk Spread, 61.9% WR)"
        }
        
    def start(self):
        print("Connected to Dhan HQ API. Capital Multiplier Active (Intraday Flat at 15:15 IST).")
        for code, desc in self.active_strategies.items():
            print(f"  [{code}] {desc}")

if __name__ == "__main__":
    engine = MindfulDhanEngine()
    engine.start()
